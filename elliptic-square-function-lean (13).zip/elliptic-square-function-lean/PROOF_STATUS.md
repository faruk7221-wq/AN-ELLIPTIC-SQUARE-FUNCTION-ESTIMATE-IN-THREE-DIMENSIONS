# Proof status — October 14, 2026

## Main theorem: proved conditional statement

`article_main_theorem` proves `ArticleMainConclusion`, containing the graph estimate and the compact surface estimate. It has precisely these external premises:

1. `PlacementInput`: affine placement, External input 1, cited in the article as [5, Lemma 3.1].
2. `NikodymInput`: the unit-length maximal estimate, External input 3, cited as [6, Corollary 11.1].
3. `forall S, ContinuedPhase S.phi -> DiscreteDensityInput S`: External input 2 for the actual continued-phase setups constructed by the proof, cited as [5, equation (4.10)].

These are propositions passed as hypotheses. They are not project axioms, and their truth or the accuracy of the article's external citations has not been proved by this formalization. The external discrete estimate is required for each adequate setup; it is not transferred from an unrelated smaller setup.

The graph conclusion is `ReverseSquareFunction G` for every compact graph setup satisfying `GraphHypotheses`. The surface conclusion is `EuclideanSurfaceEstimate K c0 C0`. It uses Euclidean three-space, actual Schwartz maps, `Real.fourierIntegral`, and `surfaceCap`, the closed metric thickening of the carrier intersected with the open base ball as in (8.1). The constant is chosen before the real scale R >= 2, cap count, separated centers, and functions.

## Exact surface geometry

`SmoothEllipticSurfaceWithBoundary K` is an explicit extrinsic chart definition. Around every point it supplies:

- an open planar domain U and a smooth parametrization F on U;
- embeddedness of the restricted parametrization and injectivity of its differential at the chart center;
- an ambient open neighborhood in which K equals the appropriate parametrized patch;
- either the full planar model, or the half-plane model with center on its boundary;
- a unit normal and a definite second fundamental form at the center.

For a boundary chart, F is already a smooth extension to the open U. This records the local extension invoked in Section 8. It remains part of that explicit chart definition. A separate theorem now constructs the required extensions for arbitrary C∞ `ContMDiff` maps on Mathlib’s actual half-space boundary model.

The second fundamental form is explicitly `inner N (D²F(a)[v,w])`. The project proves that it equals the frozen normal-height Hessian, is symmetric and bilinear for C2 parametrizations, and transforms by pullback under smooth invertible reparametrizations. A unit normal exists for every immersed two-plane and is unique up to sign; definiteness is independent of that sign. `tangentSecondForm` is the actual bilinear form on the image tangent subspace. Its definiteness is proved equivalent to the parameter condition. `article_tangent_surface_theorem` uses this tangent-space formulation.

`positive_graph_of_immersion` constructs adapted ambient coordinates, a smooth local inverse, and the graph phase. `positive_graph_extensions_of_embedded_surface` shrinks embedded patches and derives `LocalPositiveGraphExtensions`. The earlier positivity-to-uniform-ellipticity and finite-chart results then finish the estimate. No positive graph, inverse map, quantitative Hessian bound, finite chart cover, or internal analytic estimate remains an assumption of `article_main_theorem`.

## Mathlib manifold interface and remaining scope

The previous compact boundaryless-manifold adapter and exact `mfderiv` interface remain proved. `compact_model_surface_estimate` now extends the interface to arbitrary two-dimensional Mathlib models with corners. It assumes `ContMDiff`, `IsEmbedding`, injective `mfderiv`, and definite normal curvature computed by derivatives within the canonical chart target. It additionally assumes `HasSmoothModelExtensions`.

That additional property asks only for an open smooth extension agreeing with each canonical parametrization on the model set. Embeddedness of the extension is no longer assumed: `immersion_locally_embedding` derives it from the injective derivative using a local inverse. The adapter constructs the ambient neighborhoods and all covering data.

`model_mfderiv_eq_extension` identifies an extension's derivative with `mfderiv`. `model_second_form_eq_extension` identifies its second fundamental form with `modelSecondForm`, defined through iterated derivatives within the chart target. Second derivatives do not depend on which extension is chosen. Symmetry and normal-orientation independence of the canonical model form are proved even without an extension hypothesis. For the actual half-space model, `boundarySecondFundamentalForm` now packages the scalar form on each Mathlib tangent fiber, and `boundarySecondFormVector` packages its normal-valued version independently of unit-normal choice. `boundary_intrinsic_second_form_in_chart` proves compatibility with every overlapping canonical boundary chart through Mathlib’s actual `tangentCoordChange`. Smooth coordinate contractions are proved when the local normal and vector fields are smooth. These results do not yet package the family as a smooth section of a Mathlib tensor-product bundle or construct smooth local unit-normal fields.

**The extension premise is discharged for analytic data.** `analytic_within_smooth_extension` constructs a local smooth extension from `AnalyticWithinAt`; `compact_analytic_model_surface_estimate` therefore proves the estimate for analytic embedded Mathlib manifolds with corners without assuming extensions. `smooth_model_extension_at_interior` handles every interior point from smoothness alone. `compact_boundary_analytic_surface_estimate` specializes to Mathlib's actual half-space model `𝓡∂ 2`, requiring analyticity only at boundary points (coordinate 0 equals zero).

**The extension premise is now also discharged for arbitrary C∞ data on the actual half-space model.** `halfspace_extensions_of_smooth` derives it from `ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) ∞ f`. The endpoint `compact_smooth_boundary_surface_estimate` assumes compactness, smoothness, embeddedness, injective manifold derivative, definite canonical normal curvature, and the three external analytic inputs. It does not assume analyticity, bounded derivatives, local extensions, or embedded extensions.

Still outside the checked result:

- arbitrary non-halfspace corner-model extension existence; the general `compact_model_surface_estimate` retains `HasSmoothModelExtensions`;
- optional packaging as a smooth section of a Mathlib tensor-product bundle, including construction of local smooth unit-normal fields; the fiberwise bilinear maps, unit-normal choice independence, boundary-chart compatibility, and smooth coordinate contractions are now proved;
- a line-by-line formalization of the original ambient cutoff/partition/coloring argument in Section 8 and every auxiliary assertion in the article.

The final item is not a missing premise of the proved main theorem: whole-cap assignment bypasses that argument. The three external analytic input propositions remain hypotheses throughout.

## New verified work in this continuation

| Modules | Proved contribution |
| --- | --- |
| SeeleyTensorMoments | Multilinear expansion by normal/tangential slots and exact tensor reproduction from Seeley moments. |
| SeeleyTensorSeries | Weighted summability, uniform convergence, continuity, and boundary values for every tensor order. |
| SeeleyTensorDifferentiation | Joint Fréchet differentiation of reflected tensor series on the negative half-space. |
| SeeleyTensorBoundary | Boundary derivative limits and joint gluing of adjacent tensor orders. |
| SeeleySmoothHalfSpace | All-order Taylor-series construction and global extension for bounded within-derivative jets. |
| SeeleyHalfSpaceLocalization | Uniform derivative bounds from compact cutoff support; local extension without supplied bounds. |
| SeeleyOpenHalfSpace | Local extension from data smooth on a relatively open half-space patch. |
| SeeleyPlaneExtension | Transport between the product half-space and the Euclidean planar model. |
| SmoothBoundaryTheorem | Canonical C∞ boundary-chart extensions and the compact smooth boundary-manifold surface estimate. |
| SeeleyHalfSpaceTheorem | Global extension of arbitrary smooth Banach-valued data on a finite-dimensional closed half-space. |

The global endpoint `smooth_halfspace_extension` assumes only `ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1}`, with finite-dimensional real normed X and complete real normed target E. It produces a globally C∞ F agreeing with f on the entire closed half-space. Boundedness and analyticity are not assumptions. The intermediate bounds are supplied by cutoff localization; Mathlib's smooth partition of unity combines local extensions. Joint Fréchet smoothness is proved, not inferred from separate smoothness.

The previous coefficient construction and one-dimensional extension remain unchanged.

## Further boundary geometry and endpoints

The 37 additional declarations in 12 modules complete these interfaces:

| Modules | Proved contribution |
| --- | --- |
| SmoothExtensionJets | All-order mixed jet matching and uniqueness for open extensions; canonical model jet identification. |
| TangentReparametrization | Invariance of the ambient tangent plane and full tangent bilinear form under smooth invertible changes of parameters. |
| CompactSurfacePortions | Compact portions of possibly noncompact embedded manifolds, allowing arbitrary boundaries of the chosen portion. |
| BoundarySecondFormPullback | Tensor pullback rule for within-second-derivatives on model sets using smooth extensions. |
| BoundaryChartExtensions | Banach-valued planar extension, all points of boundary charts, and actual chart-transition extensions. |
| BoundaryChartSecondForm | Pullback through actual boundary-chart transitions, agreement with the canonical form, and symmetry in every chart. |
| BoundaryChartDerivatives | First-derivative transition law, identification with mfderiv, normality transfer, and tangent-fiber compatibility. |
| BoundaryTangentSecondForm | Invertible tangent coordinate changes and a bilinear form on each Mathlib tangent fiber. |
| BoundaryChartCurvatureTheorem | Chart-independent positive, negative and full definiteness; compact-portion surface endpoint with curvature checked in any chart. |
| BoundaryNormalValuedForm | Orientation-free normal-valued bilinear form and its expression in every boundary chart. |
| BoundarySecondFormSmoothness | Smooth scalar and normal-valued coordinate contractions for smooth local normal and vector fields. |
| BoundaryChartTensorSmoothness | Exact identification of those contractions with the boundary-chart form, including smoothness at boundary points. |

`compact_smooth_boundary_portion_estimate_of_chart_curvature` requires no preferred curvature chart, analyticity, derivative bounds, or extension premise. It still requires smoothness, embeddedness, immersion, definite normal curvature, compactness of the chosen carrier, and the three external analytic inputs. The whole ambient manifold need not be compact.

The submitted 930-theorem source modules remain unchanged. A later local 963-theorem checkpoint supplied 33 extension declarations; that checkpoint was independently rebuilt and fully audited in this continuation. The 37 declarations above were developed subsequently.

## Retained analytic results

All 930 prior declarations and 222 modules are unchanged. Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions 2 and 3 retain their previously documented external-input/setup scope. Lemma 4 synthesis, density (6.2), reproducing estimate (6.11), sample estimate (6.12), and Fatou composition remain proved. Lemma 5 is proved in positive-integral form and for actual squared-Schwartz Bochner convolutions. Initial partitions, adequate setups, and both internal analytic bridges remain constructed/proved. Earlier detailed status is preserved in `verification/PROOF_STATUS_835.md`, `verification/PROOF_STATUS_771.md`, and `verification/PROOF_STATUS_705.md`.

## Verification

1000 declarations / 244 modules; 70 additions / 22 new modules relative to the submitted 930-theorem checkpoint. Fresh whole-project build and exact axiom coverage: a fresh full 963-declaration audit plus fresh disjoint audits of all 37 further declarations. All 222 baseline module hashes are unchanged. The current audit provenance, source snapshots, build log, and per-theorem dependencies are saved in `verification/`. Only `propext`, `Classical.choice`, and `Quot.sound` occur; no placeholder proofs or project axioms are permitted. Counts are not a completion percentage.

The external analytic inputs remain hypotheses, not proved results. Auxiliary results retain their documented scope: in particular the finite-profile Propositions 2 and 3 use constructed adequate setups, and the original geometric core construction and a line-by-line all-real-scale Proposition 3 are not claimed. These are distinct from the proved all-real-scale main estimate.
