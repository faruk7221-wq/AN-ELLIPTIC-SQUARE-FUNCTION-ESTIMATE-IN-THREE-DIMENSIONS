#!/usr/bin/env python3
"""Validate audit coverage, record this checkpoint, and package source only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import runpy
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VER = ROOT / "verification"
without_comments = runpy.run_path(str(ROOT / "tools/verify.py"))["without_comments"]
pattern = r"^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)"
files = sorted((ROOT / "EllipticSquareFunction").glob("*.lean"))
names = []
for path in files:
    code = without_comments(path.read_text())
    assert not re.search(r"\b(?:sorry|admit|axiom|unsafe|native_decide)\b", code), path
    names += re.findall(pattern, code, re.M)
assert len(names) == len(set(names)) == 399
assert len(files) == 67
imports = re.findall(r"^import EllipticSquareFunction\.(\w+)",
                     (ROOT / "EllipticSquareFunction.lean").read_text(), re.M)
assert set(imports) == {f.stem for f in files}
audit_names = re.findall(r"^#print axioms EllipticSquareFunction\.(\w+)",
                        (ROOT / "AxiomAudit.lean").read_text(), re.M)
assert len(audit_names) == 399 and set(audit_names) == set(names)

for name, digest in json.loads((VER / "AUDITED_392_SOURCE_SHA256.json").read_text()).items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name

prior_hashes = json.loads((VER / "SOURCE_SHA256.json").read_text())
checked = 0
for name, digest in prior_hashes.items():
    if name.startswith("EllipticSquareFunction/") and name.endswith(".lean"):
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
        checked += 1
assert checked in {66, 67}
full = (VER / "axioms-full-392.log").read_text()
extra = (VER / "axioms-supplement-6.log").read_text() + "\n" + (VER / "axioms-uniform-1.log").read_text()
full_names = re.findall(r"'EllipticSquareFunction\.(\w+)'", full)
extra_names = re.findall(r"'EllipticSquareFunction\.(\w+)'", extra)
assert len(full_names) == 392 and len(extra_names) == 7
combined = full + "\n" + extra
assert set(full_names + extra_names) == set(names)
assert len(set(full_names + extra_names)) == 399
fresh_audit = VER / "axioms-full-399.log"
fresh_passed = fresh_audit.exists()
if fresh_passed:
    direct = fresh_audit.read_text()
    direct_names = re.findall(r"'EllipticSquareFunction\.(\w+)'", direct)
    assert len(direct_names) == 399 and set(direct_names) == set(names)
    combined = direct
audit_status = ("Fresh full 399-theorem audit and final full 67-module build. "
                "Earlier 392+6+1 audits also cover every declaration; source hashes unchanged."
                if fresh_passed else
                "Full 392-theorem audit plus six and one supplemental theorem audits; "
                "final full 67-module build; original 63 and intermediate 66 source hashes "
                "unchanged; exact 399-theorem coverage.")
assert "sorryAx" not in combined
allowed = {"propext", "Classical.choice", "Quot.sound"}
for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", combined, re.S):
    assert {x.strip() for x in group.split(",") if x.strip()} <= allowed
build = (VER / "build-uniform.log").read_text()
assert "Build completed successfully." in build
assert "error:" not in build
assert (VER / "RESULT.txt").read_text().startswith(("PASS: 66 modules and 398", "PASS: 67 modules and 399"))
(VER / "axioms.log").write_text(combined)
shutil.copyfile(VER / "build-uniform.log", VER / "build.log")
(VER / "RESULT.txt").write_text(
    "PASS: 67 modules and 399 project theorems.\n"
    + audit_status + "\n"
    "All 63 full-audit and 66 intermediate-checkpoint module hashes remained unchanged.\n"
    "No placeholder proof tokens or nonstandard axiom dependencies.\n"
    "Proposition 2 and (5.10) are proved with explicit fixed-setup margins.\n"
    "Proposition 3 and the main theorem are not proved.\n"
    "PacketSamplingEstimates and TubeSmoothingEstimates remain unproved hypotheses.\n")
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
status = {
    "checkpoint_utc": now,
    "lean_version": "4.19.0",
    "mathlib_commit": "c44e0c8ee63ca166450922a373c7409c5d26b00b",
    "proved_theorems": 399,
    "modules": 67,
    "continuation_baseline_theorems": 348,
    "new_theorems_in_continuation": 51,
    "new_module_count": 16,
    "build_passed": True,
    "axiom_audit_passed": True,
    "axiom_audit_status": audit_status,
    "allowed_axioms": sorted(allowed),
    "article_theorem_verified": False,
    "proposition_2_fixed_setup_verified": True,
    "proposition_2_unqualified_setup_construction_verified": False,
    "proposition_2_status": "Whole-plane finite-profile estimate with common time origins proved from ContinuedPhase and DiscreteDensityInput, at dyadic scales and with explicit fixed-setup size/support margins. Construction of an adequately enlarged setup is not proved.",
    "equation_4_11_status": "Previously proved matrix decay/cutoff; unchanged.",
    "corrected_4_14_status": "Previously proved bounded finite separated arrays around arbitrary spatial centers, with explicit external-input/setup margins; unchanged.",
    "equation_4_15_status": "Previously proved uniform free-packet decay for every real N>=1 and |t|<=N^2; unchanged.",
    "equation_5_5_status": "Exact HasSum rebased reconstruction proved, including D^-2 normalization; one finite frequency set works for all time shifts and spacetime points.",
    "equation_5_6_status": "Exact rebased matrix normalization, drifting center and constant phase proved.",
    "equation_5_8_status": "Uniform C*(1+abs(Delta))^L bracket(w)^(-L) decay proved for all real Delta and N>=1.",
    "equation_5_9_status": "Finite and countable full-weight coefficient density bounds proved; countable summability proved. Coefficients are before fixed D^-2 normalization, incorporated in the slab consequence.",
    "equation_5_10_status": "Uniformly quantified fixed-setup rebased slab estimate proved from ContinuedPhase and external DiscreteDensityInput. No internal packet-estimate premise remains. Explicit setup margins still require construction or justification.",
    "proposition_3_verified": False,
    "unproved_internal_bridges": ["PacketSamplingEstimates", "TubeSmoothingEstimates"],
    "next_target": "Justify compatible enlarged setup margins; prove Schwartz time-cutoff summation and oversampling to complete Proposition 3.",
    "later_obligations": ["Fourier-box sampling / Lemma 4", "Nikodym smoothing / Lemma 5", "dyadic-to-arbitrary scale comparison", "affine covariance and finite chart assembly"],
    "proof_status_document": "PROOF_STATUS.md"
}
(VER / "STATUS.json").write_text(json.dumps(status, indent=2) + "\n")
paths = []
for folder, dirs, filenames in os.walk(ROOT):
    dirs[:] = sorted(d for d in dirs if d not in {".lake", "__pycache__"})
    for filename in sorted(filenames):
        path = Path(folder) / filename
        if path.suffix in {".zip", ".pyc", ".so"}:
            continue
        paths.append(path)
hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in paths if p != VER / "SOURCE_SHA256.json"}
(VER / "SOURCE_SHA256.json").write_text(json.dumps(hashes, indent=2, sort_keys=True) + "\n")
archive = ROOT.parent / "elliptic-square-function-lean.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as out:
    for path in paths:
        out.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
with zipfile.ZipFile(archive) as out:
    assert out.testzip() is None
    assert not any(".lake/" in x or x.endswith(".zip") for x in out.namelist())
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                  "theorems": 399, "modules": 67, "checkpoint_utc": now}, indent=2))
