#!/usr/bin/env python3
"""Adopt a completed fresh 962-declaration audit plus the later global extension audit.

The single added declaration is independently audited in SmoothBoundaryAudit.lean.
This does not assert the external input propositions.
"""
from pathlib import Path
import hashlib,json,re,runpy
R=Path(__file__).resolve().parents[1]
V=R/'verification'
assert (V/'full-audit-962-exit-code.txt').read_text().strip()=='0'
strip=runpy.run_path(str(R/'tools/verify.py'))['without_comments']
pat=r'^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)'
byfile={str(p.relative_to(R)):re.findall(pat,strip(p.read_text()),re.M)
        for p in sorted((R/'EllipticSquareFunction').glob('*.lean'))}
names={n for ns in byfile.values() for n in ns}
snapshot=json.loads((V/'CURRENT_AUDIT_SOURCE_SHA256.json').read_text())
assert set(snapshot)==set(byfile)
for f,h in snapshot.items():assert hashlib.sha256((R/f).read_bytes()).hexdigest()==h,f
entrypat=r"'EllipticSquareFunction\.(\w+)' (?:depends on axioms:\s*\[[^\]]*\]|does not depend on any axioms)"
full=(V/'axioms-full-962.log').read_text()
actual=re.findall(r"'EllipticSquareFunction\.(\w+)'",full)
late={'smooth_halfspace_extension'}
assert len(actual)==962 and len(actual)==len(set(actual)) and set(actual)==names-late
assert 'error:' not in full and 'sorryAx' not in full
new=(V/'axioms-smooth-boundary.log').read_text()
entries={m.group(1):m.group(0) for m in re.finditer(entrypat,new)}
assert late<=entries.keys()
global_log='\n'.join(entries[n] for n in sorted(late))+'\n'
(V/'axioms-global-halfspace.log').write_text(global_log)
combined=full.strip()+'\n\n'+global_log.strip()+'\n'
allowed={'propext','Classical.choice','Quot.sound'}
for group in re.findall(r'depends on axioms:\s*\[(.*?)\]',combined,re.S):
    assert {a.strip() for a in group.split(',') if a.strip()}<=allowed
assert len(re.findall(entrypat,combined))==len(names)==963
full_hashes={f:h for f,h in snapshot.items() if f!='EllipticSquareFunction/SeeleyHalfSpaceTheorem.lean'}
late_hashes={f:h for f,h in snapshot.items() if f not in full_hashes}
(V/'FULL_962_SOURCE_SHA256.json').write_text(json.dumps(full_hashes,indent=2)+'\n')
(V/'GLOBAL_HALFSPACE_SOURCE_SHA256.json').write_text(json.dumps(late_hashes,indent=2)+'\n')
(V/'axioms.log').write_text(combined)
desc='Fresh whole-project 232-module build; fresh 962-declaration audit plus a fresh audit of the later global half-space extension. Exact coverage of all 963 declarations; all current source hashes checked. All 222 baseline modules remain unchanged.'
(V/'AUDIT_PROVENANCE.json').write_text(json.dumps({'runs':[
 {'log':'axioms-full-962.log','theorems':962,'source_snapshot':'FULL_962_SOURCE_SHA256.json'},
 {'log':'axioms-global-halfspace.log','theorems':1,'source_snapshot':'GLOBAL_HALFSPACE_SOURCE_SHA256.json'}],
 'description':desc},indent=2)+'\n')
print(desc)
