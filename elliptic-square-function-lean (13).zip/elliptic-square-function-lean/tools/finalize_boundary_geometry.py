#!/usr/bin/env python3
"""Validate and merge the fresh, disjoint boundary-completion audit runs.

Run after lake build and the five audit commands named below. This does not
prove the three external input propositions or extend the documented scope.
"""
from pathlib import Path
import hashlib
import json
import re
import runpy
import shutil

ROOT = Path(__file__).resolve().parents[1]
V = ROOT / 'verification'
strip = runpy.run_path(str(ROOT / 'tools/verify.py'))['without_comments']
pattern = r'^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)'
files = sorted((ROOT / 'EllipticSquareFunction').glob('*.lean'))
byfile = {}
hashes = {}
for p in files:
    code = strip(p.read_text())
    assert not re.search(r'\b(?:sorry|admit|axiom|unsafe|native_decide)\b', code), p
    name = str(p.relative_to(ROOT))
    byfile[name] = re.findall(pattern, code, re.M)
    hashes[name] = hashlib.sha256(p.read_bytes()).hexdigest()
names = [n for ns in byfile.values() for n in ns]
assert len(names) == len(set(names))
base = json.loads((V / 'BASELINE_963_SOURCE_SHA256.json').read_text())
assert len(base) == 232
for p, h in base.items():
    assert hashes[p] == h, p
submitted = json.loads((V / 'BASELINE_930_SOURCE_SHA256.json').read_text())
assert len(submitted) == 222
for p, h in submitted.items():
    assert hashes[p] == h, p

groups = [
    ('axioms-fresh-963.log', 'BASELINE_963_SOURCE_SHA256.json', list(base)),
    ('boundary-completion-axioms.log', 'BOUNDARY_26_SOURCE_SHA256.json', [
        'EllipticSquareFunction/' + m + '.lean' for m in [
            'SmoothExtensionJets', 'TangentReparametrization', 'CompactSurfacePortions',
            'BoundarySecondFormPullback', 'BoundaryChartExtensions', 'BoundaryChartSecondForm',
            'BoundaryChartDerivatives', 'BoundaryTangentSecondForm']]),
    ('chart-curvature-axioms.log', 'CHART_CURVATURE_SOURCE_SHA256.json',
        ['EllipticSquareFunction/BoundaryChartCurvatureTheorem.lean']),
    ('normal-valued-axioms.log', 'NORMAL_VALUED_SOURCE_SHA256.json',
        ['EllipticSquareFunction/BoundaryNormalValuedForm.lean']),
    ('chart-tensor-smoothness-axioms.log', 'CHART_TENSOR_SMOOTHNESS_SOURCE_SHA256.json',
        ['EllipticSquareFunction/BoundaryChartTensorSmoothness.lean']),
    ('smooth-tensor-axioms.log', 'SMOOTH_TENSOR_SOURCE_SHA256.json',
        ['EllipticSquareFunction/BoundarySecondFormSmoothness.lean']),
]
seen, covered, texts, runs = set(), set(), [], []
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
for log, snapshot, paths in groups:
    assert not covered.intersection(paths)
    covered.update(paths)
    expected = {n for p in paths for n in byfile[p]}
    text = (V / log).read_text()
    assert 'error:' not in text and 'sorryAx' not in text, log
    actual = re.findall(r"'EllipticSquareFunction\.(\w+)'", text)
    assert len(actual) == len(expected) and set(actual) == expected, log
    assert not seen.intersection(actual)
    seen.update(actual)
    for group in re.findall(r'depends on axioms:\s*\[(.*?)\]', text, re.S):
        assert {a.strip() for a in group.split(',') if a.strip()} <= allowed, log
    (V / snapshot).write_text(json.dumps({p: hashes[p] for p in paths}, indent=2) + '\n')
    runs.append({'log': log, 'theorems': len(actual), 'source_snapshot': snapshot})
    texts.append(text.strip())
assert covered == set(hashes) and seen == set(names)
root_imports = re.findall(r'^import EllipticSquareFunction\.(\w+)',
                         (ROOT / 'EllipticSquareFunction.lean').read_text(), re.M)
assert len(root_imports) == len(files) and set(root_imports) == {p.stem for p in files}
audit_names = re.findall(r'^#print axioms EllipticSquareFunction\.(\w+)',
                        (ROOT / 'AxiomAudit.lean').read_text(), re.M)
assert len(audit_names) == len(names) and set(audit_names) == set(names)
build = (V / 'build-final.log').read_text()
assert 'Build completed successfully.' in build and 'error:' not in build
shutil.copyfile(V / 'build-final.log', V / 'build.log')
combined = '\n\n'.join(texts) + '\n'
(V / 'axioms.log').write_text(combined)
(V / 'CURRENT_AUDIT_SOURCE_SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n')
description = (f'Fresh whole-project {len(files)}-module build; fresh full 963-declaration audit '
               f'plus disjoint fresh audits of {len(names)-963} later declarations. '
               f'Exact coverage of all {len(names)} declarations; all current source hashes checked. '
               'All 222 submitted baseline modules remain unchanged.')
(V / 'AUDIT_PROVENANCE.json').write_text(json.dumps({'runs': runs, 'description': description}, indent=2) + '\n')
(V / 'RESULT.txt').write_text(f'PASS: {len(files)} modules and {len(names)} project theorems.\n' + description + '\n')
deps = {n: ', '.join(a.strip() for a in g.split(',') if a.strip())
        for n, g in re.findall(r"'EllipticSquareFunction\.(\w+)' depends on axioms:\s*\[(.*?)\]", combined, re.S)}
(V / 'THEOREM_INVENTORY.tsv').write_text('module\tdeclaration\taxiom_dependencies\n' + ''.join(
    f'{Path(p).stem}\tEllipticSquareFunction.{n}\t{deps.get(n, "")}\n'
    for p, ns in byfile.items() for n in ns))
print(description)
