#!/usr/bin/env python3
"""Validate the 568+26+9+4+2 audits, final build, and immutable source snapshots."""
from pathlib import Path
import hashlib
import json
import re
import runpy
import shutil

ROOT = Path(__file__).resolve().parents[1]
VER = ROOT / 'verification'
strip = runpy.run_path(str(ROOT / 'tools/verify.py'))['without_comments']
pattern = r'^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)'
files = sorted((ROOT / 'EllipticSquareFunction').glob('*.lean'))
declared = {}
for path in files:
    code = strip(path.read_text())
    assert not re.search(r'\b(?:sorry|admit|axiom|unsafe|native_decide)\b', code), path
    for name in re.findall(pattern, code, re.M):
        assert name not in declared
        declared[name] = path.stem
assert len(files) == 131 and len(declared) == 609

runs = [
    ('axioms-full-568.log', 568, 'AUDITED_568_SOURCE_SHA256.json'),
    ('axioms-smoothing-partial.log', 26, 'SMOOTHING_PARTIAL_SOURCE_SHA256.json'),
    ('axioms-tube-averages-9.log', 9, 'TUBE_AVERAGES_SOURCE_SHA256.json'),
    ('axioms-dyadic-convolution-4.log', 4, 'DYADIC_CONVOLUTION_SOURCE_SHA256.json'),
    ('axioms-tube-dilation-2.log', 2, 'TUBE_DILATION_SOURCE_SHA256.json'),
]
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
checked_all, texts, source_all = [], [], {}
for logname, count, snapshotname in runs:
    snapshot = json.loads((VER / snapshotname).read_text())
    assert not (set(source_all) & set(snapshot))
    for path, digest in snapshot.items():
        assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, path
    source_all.update(snapshot)
    log = (VER / logname).read_text()
    names = re.findall(r"'EllipticSquareFunction\.(\w+)'", log)
    assert len(names) == len(set(names)) == count, logname
    expected = {n for n, m in declared.items() if f'EllipticSquareFunction/{m}.lean' in snapshot}
    assert set(names) == expected, logname
    assert 'sorryAx' not in log and 'error:' not in log
    for group in re.findall(r'depends on axioms:\s*\[(.*?)\]', log, re.S):
        assert {a.strip() for a in group.split(',') if a.strip()} <= allowed
    checked_all.extend(names)
    texts.append(log.strip())
assert len(checked_all) == len(set(checked_all)) == len(declared)
assert set(checked_all) == set(declared)
assert set(source_all) == {str(p.relative_to(ROOT)) for p in files}
baseline = json.loads((VER / 'BASELINE_528_SOURCE_SHA256.json').read_text())
assert len(baseline) == 106
for path, digest in baseline.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == digest, path
build = (VER / 'build-final.log').read_text()
assert 'Build completed successfully.' in build and 'error:' not in build
imports = re.findall(r'^import EllipticSquareFunction\.(\w+)', (ROOT / 'EllipticSquareFunction.lean').read_text(), re.M)
assert len(imports) == len(files) and set(imports) == {p.stem for p in files}
audit_names = re.findall(r'^#print axioms EllipticSquareFunction\.(\w+)', (ROOT / 'AxiomAudit.lean').read_text(), re.M)
assert len(audit_names) == len(declared) and set(audit_names) == set(declared)
combined = '\n\n'.join(texts) + '\n'
(VER / 'axioms.log').write_text(combined)
shutil.copyfile(VER / 'build-final.log', VER / 'build.log')
description = ('Fresh full 568-theorem audit plus disjoint 26-, 9-, 4-, and 2-theorem supplemental audits; '
               'final full 131-module build. Exact 609-theorem coverage. '
               'All audited source hashes and all 106 baseline module hashes unchanged.')
(VER / 'AUDIT_PROVENANCE.json').write_text(json.dumps({
    'runs': [{'log': log, 'theorems': count, 'source_snapshot': snap} for log, count, snap in runs],
    'description': description,
}, indent=2) + '\n')
(VER / 'CURRENT_AUDIT_SOURCE_SHA256.json').write_text(json.dumps(source_all, indent=2, sort_keys=True) + '\n')
(VER / 'RESULT.txt').write_text('PASS: 131 modules and 609 project theorems.\n' + description + '\n')
deps = {n: ', '.join(a.strip() for a in group.split(',') if a.strip())
        for n, group in re.findall(r"'EllipticSquareFunction\.(\w+)' depends on axioms:\s*\[(.*?)\]", combined, re.S)}
(VER / 'THEOREM_INVENTORY.tsv').write_text('module\tdeclaration\taxiom_dependencies\n' + ''.join(
    f'{m}\tEllipticSquareFunction.{n}\t{deps.get(n, "")}\n'
    for n, m in sorted(declared.items(), key=lambda item: (item[1], item[0]))))
print(description)
