#!/usr/bin/env python3
"""Package the documented checkpoint only after exact build/audit validation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import runpy
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VER = ROOT / "verification"
strip = runpy.run_path(str(ROOT / "tools/verify.py"))["without_comments"]
pattern = r"^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)"
files = sorted((ROOT / "EllipticSquareFunction").glob("*.lean"))
names = []
for path in files:
    source = strip(path.read_text())
    assert not re.search(r"\b(?:sorry|admit|axiom|unsafe|native_decide)\b", source), path
    names += re.findall(pattern, source, re.M)
assert len(names) == len(set(names))
imports = re.findall(r"^import EllipticSquareFunction\.(\w+)",
                     (ROOT / "EllipticSquareFunction.lean").read_text(), re.M)
assert len(imports) == len(files) and set(imports) == {p.stem for p in files}
audit_names = re.findall(r"^#print axioms EllipticSquareFunction\.(\w+)",
                        (ROOT / "AxiomAudit.lean").read_text(), re.M)
assert len(audit_names) == len(names) and set(audit_names) == set(names)

snapshot = json.loads((VER / "CURRENT_AUDIT_SOURCE_SHA256.json").read_text())
assert set(snapshot) == {str(p.relative_to(ROOT)) for p in files}
for name, digest in snapshot.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
baseline = json.loads((VER / "BASELINE_930_SOURCE_SHA256.json").read_text())
assert len(baseline) == 222
for name, digest in baseline.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name

audit = (VER / "axioms.log").read_text()
provenance = json.loads((VER / "AUDIT_PROVENANCE.json").read_text())
run_names = []
run_texts = []
for entry in provenance["runs"]:
    log = (VER / entry["log"]).read_text()
    run_texts.append(log.strip())
    actual_names = re.findall(r"'EllipticSquareFunction\.(\w+)'", log)
    assert len(actual_names) == entry["theorems"]
    assert "sorryAx" not in log and "error:" not in log
    run_names.extend(actual_names)
assert len(run_names) == len(names) and set(run_names) == set(names)
assert audit.strip() == "\n\n".join(run_texts)
checked = re.findall(r"'EllipticSquareFunction\.(\w+)'", audit)
assert len(checked) == len(names) and set(checked) == set(names)
assert "sorryAx" not in audit and "error:" not in audit
allowed = {"propext", "Classical.choice", "Quot.sound"}
for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", audit, re.S):
    assert {a.strip() for a in group.split(",") if a.strip()} <= allowed
build = (VER / "build.log").read_text()
assert "Build completed successfully." in build and "error:" not in build
assert (VER / "RESULT.txt").read_text().startswith(
    f"PASS: {len(files)} modules and {len(names)} project theorems.")

now = datetime.datetime.now(datetime.timezone.utc).isoformat()
status = json.loads((VER / "STATUS.json").read_text())
status.update({
    "checkpoint_utc": now,
    "proved_theorems": len(names),
    "modules": len(files),
    "continuation_baseline_theorems": 930,
    "new_theorems_in_continuation": len(names) - 930,
    "new_module_count": len(files) - 222,
    "build_passed": True,
    "axiom_audit_passed": True,
    "axiom_audit_status": provenance["description"],
    "allowed_axioms": sorted(allowed),
    "article_theorem_verified": True,
    "article_verification_scope": "Conditional Theorem 1 for explicit smooth embedded charts, with a proved adapter from compact smooth Mathlib half-space boundary manifolds; the three external input propositions are hypotheses.",
    "embedded_parametrization_to_graph_verified": True,
    "abstract_closed_manifold_adapter_verified": True,
    "abstract_boundary_manifold_adapter_verified": True,
    "boundary_adapter_given_smooth_extensions_verified": True,
    "analytic_boundary_extensions_constructed": True,
    "analytic_manifold_with_corners_estimate_verified": True,
    "boundary_only_analytic_halfspace_estimate_verified": True,
    "general_smooth_boundary_extension_verified": True,
    "global_smooth_halfspace_extension_verified": True,
    "smooth_boundary_extension_scope": "Finite-dimensional closed half-spaces, Banach-valued targets; canonical Mathlib surface boundary model 𝓡∂ 2. Arbitrary corner models are not included.",
    "external_placement_input_proved": False,
    "external_nikodym_input_proved": False,
    "external_discrete_density_input_proved": False,
    "boundary_derivative_and_curvature_identification_verified": True,
    "model_second_form_symmetry_without_extensions_verified": True,
    "local_immersion_embedding_constructed": True,
    "unit_sphere_geometry_and_estimate_verified": True,
    "surface_estimate_carrier_monotonicity_verified": True,
    "mfderiv_immersion_interface_verified": True,
    "tangent_second_form_equivalence_verified": True,
    "normal_existence_and_orientation_independence_verified": True,
    "article_graph_theorem_verified": True,
    "surface_graph_coordinate_theorem_verified": True,
    "euclidean_surface_caps_verified": True,
    "intrinsic_surface_reduction_verified": True,
    "intrinsic_surface_reduction_status": "Full explicit embedded-chart reduction proved. Mathlib models-with-corners adapter proved given smooth extensions; extensions constructed for analytic data and automatically at interior points. General C∞ local extension is now constructed for the actual two-dimensional half-space boundary model. Arbitrary corner models still require extensions.",
    "graph_normal_second_derivative_identity_verified": True,
    "uniform_affine_cap_geometry_verified": True,
    "local_positive_hessian_ellipticity_verified": True,
    "surface_status": "article_surface_theorem and article_tangent_surface_theorem prove the Euclidean estimate from explicit smooth embedded extension charts, including half-plane boundary charts, with definite second fundamental form. Graph coordinates, local inverse, Hessian positivity and uniform bounds are derived. The Mathlib closed-manifold adapter is proved, including exact identification of immersion with injective mfderiv; curvature is expressed in canonical charts. The general model-with-corners adapter is proved given smooth extensions, which are constructed for analytic data. The C∞ boundary extension theorem and compact smooth Mathlib half-space boundary-manifold estimate are now proved. The unit sphere and arbitrary portions have fully proved geometry.",
    "proposition_2_enlarged_setup_verified": True,
    "proposition_2_status": "Whole-plane finite-profile dyadic estimate with constructed adequate label bounds, preserving the initial phase/window/spacing. External DiscreteDensityInput required for that resulting setup. Common-time translation is separately proved.",
    "equation_5_10_status": "Uniform rebased slab estimate with setup-independent margins selected before label bounds; composed into the constructed-setup Proposition 3. No internal packet-bound premise remains.",
    "label_bound_enlargement_verified": True,
    "geometric_core_construction_verified": False,
    "proposition_3_verified": False,
    "proposition_3_fixed_setup_verified": True,
    "proposition_3_enlarged_setup_verified": True,
    "proposition_3_unqualified_setup_construction_verified": True,
    "setup_margin_refactor_status": "Adequate enlarged setups are constructed for finite-profile Propositions 2 and 3. Phase/window/spacing preserved; external DiscreteDensityInput required for resulting setup, not transferred from initial setup.",
    "proposition_3_status": "Finite-profile global time-packet estimate with constructed adequate setup, ContinuedPhase and external DiscreteDensityInput, at dyadic scales; arbitrary translated time lattices. Geometric core construction and all-real-scale extension remain outside this result.",
    "lemma_4_synthesis_verified": True,
    "lemma_4_status": "Actual physical Schwartz HasSum synthesis and summable coefficient-density estimate (6.2) proved, with uniform profiles and positive integer D. Curved reproducer bounds (6.11), actual sample estimate (6.12), and finite-to-full L3 Fatou composition proved.",
    "equation_6_9_verified": True,
    "generic_reproducing_identity_verified": True,
    "free_packet_all_time_polynomial_decay_verified": True,
    "equation_6_2_verified": True,
    "equation_6_11_verified": True,
    "equation_6_12_verified": True,
    "lemma_4_verified": True,
    "sampling_fatou_composition_verified": True,
    "packet_sampling_bridge_from_discrete_verified": True,
    "arbitrary_real_scale_sampling_bridge_verified": True,
    "packet_sampling_status": "All real R>=2, constants uniform in cap count. ContinuedPhase supplied; initial squared partition T0 and adequate S now constructed; external DiscreteDensityInput S required.",
    "lemma_5_verified": True,
    "tube_geometry_dilation_verified": True,
    "nikodym_norm_dilation_verified": True,
    "equation_7_4_verified": True,
    "positive_countable_l3_verified": True,
    "lemma_5_status": "Positive-integral Lemma 5 proved for arbitrary measurable nonnegative extended-real data, M>3, bounded slopes and R>=1, from NikodymInput. Constants precede scale and family; no output finiteness premise. The actual Bochner-convolution specialization for squared Schwartz data is proved and gives TubeSmoothingEstimates.",
    "tube_smoothing_bridge_verified": True,
    "unproved_internal_bridges": [],
    "initial_partition_setup_constructed": True,
    "continued_graph_verified_from_external_inputs": True,
    "continued_graph_status": "continued_graph_reverse_square_function: ContinuedPhase G.phi, NikodymInput and external DiscreteDensityInput for phase-matching setups imply ReverseSquareFunction G. A smooth nonnegative squared lattice partition and adequate label bounds are constructed. No internal smoothing, sampling or initial-window hypothesis remains.",
    "affine_norm_covariance_verified": True,
    "affine_fourier_covariance_verified": True,
    "schwartz_affine_transport_verified": True,
    "fourier_support_transport_verified": True,
    "chart_kernel_square_function_bound_verified": True,
    "finite_placement_cover_verified": True,
    "finite_chart_assembly_status": "Actual general-graph and surface graph-atlas estimates assembled using whole-cap assignment, uniform affine cap/separation constants, finite recombination and bounded-scale packing. No chart multiplier premise remains.",
    "next_target": "Optional smooth tensor-bundle section packaging and arbitrary corner-model extensions; the main graph and smooth-boundary surface conclusions are proved conditional on the three stated external analytic inputs.",
    "seeley_coefficients_all_moments_verified": True,
    "seeley_weighted_absolute_summability_verified": True,
    "one_dimensional_smooth_halfline_extension_verified": True,
    "parameterized_seeley_joint_continuity_verified": True,
    "parameterized_seeley_joint_smoothness_verified": True,
    "seeley_reflection_multilinear_bounds_verified": True,
    "all_order_extension_jet_matching_verified": True,
    "boundary_chart_transition_extensions_verified": True,
    "boundary_chart_second_form_compatibility_verified": True,
    "tangent_fiber_scalar_second_form_verified": True,
    "normal_valued_orientation_independence_verified": True,
    "smooth_coordinate_contractions_verified": True,
    "smooth_tensor_bundle_section_packaged": False,
    "compact_noncompact_surface_portions_verified": True,
    "arbitrary_chart_curvature_endpoint_verified": True,
    "boundary_tensor_scope": "Scalar and orientation-free normal-valued bilinear forms on actual tangent fibers, compatibility with every overlapping canonical boundary chart, and smooth coordinate contractions for smooth normal/vector fields. A bundled smooth section and construction of local smooth normals are separate.",
    "later_obligations": ["arbitrary non-halfspace corner-model smooth extension", "optional smooth tensor-bundle section packaging and construction of local smooth unit normals", "optional line-by-line original chart-multiplier construction; bypassed in the proved theorem route"],
})
for key in ["proposition_2_unqualified_setup_construction_verified", "proposition_3_unqualified_setup_construction_verified"]:
    status.pop(key, None)
(VER / "STATUS.json").write_text(json.dumps(status, indent=2) + "\n")
(VER / "RESULT.txt").write_text(
    f"PASS: {len(files)} modules and {len(names)} project theorems.\n"
    f"Axiom audit: {len(names)} distinct declarations, exact coverage.\n"
    + provenance["description"] + "\n"
    "Only propext, Classical.choice, and Quot.sound occur as axiom dependencies.\n"
    "No sorry, admit, project axiom, unsafe, or native_decide proof tokens.\n"
    "All 222 baseline modules and their 930 audited declarations remain byte-for-byte unchanged.\n"
    "Joint C-infinity Seeley extension, global half-space extension without derivative bounds, and the compact smooth Mathlib boundary-manifold surface estimate are proved.\n"
    "All-order extension jets, actual boundary-chart compatibility, tangent-fiber scalar and normal-valued forms, smooth coordinate contractions, and the arbitrary-chart compact-portion endpoint are proved.\n"
    "Propositions 2 and 3 have finite-profile versions with constructed adequate setups.\n"
    "The external discrete input is required for the constructed setup.\n"
    "Lemma 4 synthesis and coefficient density are proved for physical Schwartz functions.\n"
    "Lemma 5 is proved in positive-integral form; its squared-Schwartz specialization is proved for actual Bochner convolutions.\n"
    "Both internal bridges and the initial partition setup are now proved/constructed. The continued-graph theorem follows from the stated external analytic inputs.\n"
    "The graph and explicit embedded boundary-chart surface assertions of Theorem 1 are proved from the three external input propositions. Graph construction and curvature transfer are internal proofs. The actual Mathlib half-space boundary model now has a proved C-infinity extension construction. Arbitrary corner models retain the extension hypothesis.\n")
(VER / f"axioms-complete-{len(names)}.log").write_text(audit)
paths = []
for folder, dirs, filenames in os.walk(ROOT):
    dirs[:] = sorted(d for d in dirs if d not in {".lake", "__pycache__"})
    for filename in sorted(filenames):
        path = Path(folder) / filename
        if path.suffix not in {".zip", ".pyc", ".so"}:
            paths.append(path)
hash_path = VER / "SOURCE_SHA256.json"
hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in paths if p != hash_path}
hash_path.write_text(json.dumps(hashes, indent=2, sort_keys=True) + "\n")
if hash_path not in paths:
    paths.append(hash_path)
archive = ROOT.parent / "elliptic-square-function-lean.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as out:
    for path in paths:
        out.write(path, str(Path(ROOT.name) / path.relative_to(ROOT)))
with zipfile.ZipFile(archive) as out:
    assert out.testzip() is None
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                  "theorems": len(names), "modules": len(files),
                  "checkpoint_utc": now}, indent=2))
