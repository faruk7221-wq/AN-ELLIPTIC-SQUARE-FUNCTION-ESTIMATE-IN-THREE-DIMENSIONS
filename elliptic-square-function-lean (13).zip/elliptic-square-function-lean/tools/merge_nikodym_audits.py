#!/usr/bin/env python3
"""Combine unchanged, previously checked declarations with the fresh dilation audit."""
from pathlib import Path
import hashlib,json,re,runpy,shutil
ROOT=Path(__file__).resolve().parents[1]
V=ROOT/'verification'
strip=runpy.run_path(str(ROOT/'tools/verify.py'))['without_comments']
pat=r'^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)'
files=sorted((ROOT/'EllipticSquareFunction').glob('*.lean'))
byfile={str(p.relative_to(ROOT)):re.findall(pat,strip(p.read_text()),re.M) for p in files}
names=[n for ns in byfile.values() for n in ns]
assert len(names)==len(set(names))
for p in files:assert not re.search(r'\b(?:sorry|admit|axiom|unsafe|native_decide)\b',strip(p.read_text())),p
hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
base=json.loads((V/'BASELINE_609_SOURCE_SHA256.json').read_text())
old={k:h for k,h in base.items() if hashes.get(k)==h}
changed={k:h for k,h in hashes.items() if old.get(k)!=h}
assert set(old)|set(changed)==set(hashes)
fresh=json.loads((V/'NIKODYM_DILATION_SOURCE_SHA256.json').read_text())
assert fresh==changed
entrypat=r"'EllipticSquareFunction\.(\w+)' (?:depends on axioms:\s*\[[^\]]*\]|does not depend on any axioms)"
oldraw=(V/'axioms-baseline-609.log').read_text()
oldmatches={m.group(1):m.group(0) for m in re.finditer(entrypat,oldraw)}
oldnames={n for f in old for n in byfile[f]}
assert oldnames<=oldmatches.keys()
oldlog='\n'.join(oldmatches[n] for n in sorted(oldnames))+'\n'
(V/'axioms-unchanged-baseline.log').write_text(oldlog)
(V/'UNCHANGED_BASELINE_SOURCE_SHA256.json').write_text(json.dumps(old,indent=2)+'\n')
newlog=(V/'axioms-nikodym-dilation.log').read_text()
assert 'error:' not in newlog and 'sorryAx' not in newlog
newnames=[m.group(1) for m in re.finditer(entrypat,newlog)]
assert len(newnames)==len(set(newnames))
assert set(newnames)=={n for f in changed for n in byfile[f]}
assert oldnames.isdisjoint(newnames) and oldnames|set(newnames)==set(names)
combined=oldlog.strip()+'\n\n'+newlog.strip()+'\n'
allowed={'propext','Classical.choice','Quot.sound'}
for g in re.findall(r'depends on axioms:\s*\[(.*?)\]',combined,re.S):assert {a.strip() for a in g.split(',') if a.strip()}<=allowed
imports=re.findall(r'^import EllipticSquareFunction\.(\w+)',(ROOT/'EllipticSquareFunction.lean').read_text(),re.M)
assert len(imports)==len(files) and set(imports)=={p.stem for p in files}
prints=re.findall(r'^#print axioms EllipticSquareFunction\.(\w+)',(ROOT/'AxiomAudit.lean').read_text(),re.M)
assert len(prints)==len(names) and set(prints)==set(names)
build=(V/'build-final.log').read_text()
assert 'Build completed successfully.' in build and 'error:' not in build
shutil.copyfile(V/'build-final.log',V/'build.log')
(V/'axioms.log').write_text(combined)
(V/'CURRENT_AUDIT_SOURCE_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
desc=f'{len(oldnames)} unchanged declarations retained from the verified 609-theorem checkpoint; fresh audit of {len(newnames)} declarations in new or changed modules. Fresh whole-project {len(files)}-module build. Exact {len(names)}-theorem coverage; all source hashes checked.'
(V/'AUDIT_PROVENANCE.json').write_text(json.dumps({'runs':[{'log':'axioms-unchanged-baseline.log','theorems':len(oldnames),'source_snapshot':'UNCHANGED_BASELINE_SOURCE_SHA256.json'},{'log':'axioms-nikodym-dilation.log','theorems':len(newnames),'source_snapshot':'NIKODYM_DILATION_SOURCE_SHA256.json'}],'description':desc},indent=2)+'\n')
(V/'RESULT.txt').write_text(f'PASS: {len(files)} modules and {len(names)} project theorems.\n'+desc+'\n')
deps={n:', '.join(a.strip() for a in g.split(',') if a.strip()) for n,g in re.findall(r"'EllipticSquareFunction\.(\w+)' depends on axioms:\s*\[(.*?)\]",combined,re.S)}
(V/'THEOREM_INVENTORY.tsv').write_text('module\tdeclaration\taxiom_dependencies\n'+''.join(f'{Path(f).stem}\tEllipticSquareFunction.{n}\t{deps.get(n, "")}\n' for f,ns in byfile.items() for n in ns))
print(desc)
