#!/usr/bin/env python3
"""Build and audit the formalization; does not discharge external input hypotheses."""
from pathlib import Path
import re
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def without_comments(text: str) -> str:
    """Remove Lean's nested block comments and line comments for a token check."""
    output, depth, i = [], 0, 0
    while i < len(text):
        if text.startswith("/-", i):
            depth += 1
            i += 2
        elif depth and text.startswith("-/", i):
            depth -= 1
            i += 2
        elif depth:
            i += 1
        elif text.startswith("--", i):
            end = text.find("\n", i)
            i = len(text) if end == -1 else end
        else:
            output.append(text[i])
            i += 1
    if depth:
        raise RuntimeError("Unterminated Lean block comment")
    return "".join(output)


def run(command: list[str], log_name: str) -> str:
    print(f"Running: {' '.join(command)}", flush=True)
    result = subprocess.run(command, cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / "verification" / log_name).write_text(result.stdout)
    print(result.stdout, end="", flush=True)
    if result.returncode:
        raise RuntimeError(f"Command failed with status {result.returncode}: {command}")
    return result.stdout


def main() -> None:
    lake = shutil.which("lake") or str(Path.home() / ".elan" / "bin" / "lake")
    files = sorted((ROOT / "EllipticSquareFunction").glob("*.lean"))
    declared = []
    for path in files:
        code = without_comments(path.read_text())
        banned = re.findall(r"\b(?:sorry|admit|axiom|unsafe|native_decide)\b", code)
        if banned:
            raise RuntimeError(f"Unacceptable proof token in {path.name}: {banned}")
        declared += re.findall(
            r"^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*"
            r"(?:theorem|lemma)\s+(\w+)", code, re.MULTILINE)
    root_imports = set(re.findall(
        r"^import EllipticSquareFunction\.(\w+)",
        (ROOT / "EllipticSquareFunction.lean").read_text(), re.MULTILINE))
    if root_imports != {path.stem for path in files}:
        raise RuntimeError("The root module does not import exactly all project modules")
    audit = (ROOT / "AxiomAudit.lean").read_text()
    audited = re.findall(r"^#print axioms EllipticSquareFunction\.(\w+)", audit, re.MULTILINE)
    if set(declared) != set(audited) or len(declared) != len(audited):
        raise RuntimeError("AxiomAudit.lean does not cover exactly the project theorems")
    (ROOT / "verification").mkdir(exist_ok=True)
    snapshot = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in files}
    (ROOT / "verification" / "CURRENT_AUDIT_SOURCE_SHA256.json").write_text(
        json.dumps(snapshot, indent=2) + "\n")
    run([lake, "build"], "build.log")
    output = run([lake, "env", "lean", "AxiomAudit.lean"], "axioms.log")
    if "sorryAx" in output:
        raise RuntimeError("A compiled theorem depends on sorryAx")
    allowed = {"propext", "Classical.choice", "Quot.sound"}
    for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", output, re.DOTALL):
        actual = {a.strip() for a in group.split(",") if a.strip()}
        if not actual <= allowed:
            raise RuntimeError(f"Unexpected axiom dependencies: {actual - allowed}")
    checked = re.findall(r"'EllipticSquareFunction\.(\w+)'", output)
    if len(checked) != len(declared) or set(checked) != set(declared):
        raise RuntimeError("Incomplete theorem audit output")
    for name, digest in snapshot.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Source changed during verification: {name}")
    summary = (
        f"PASS: {len(files)} modules and {len(declared)} project theorems.\n"
        "No placeholder proof tokens or nonstandard axiom dependencies.\n"
        "Audit coverage does not discharge hypotheses in theorem statements; see PROOF_STATUS.md.\n"
        "Theorem 1 is conditional on the three external inputs. The actual smooth Mathlib half-space boundary-manifold adapter is also proved; see PROOF_STATUS.md.\n"
    )
    (ROOT / "verification" / "RESULT.txt").write_text(summary)
    provenance = {
        "runs": [{"log": "axioms.log", "theorems": len(declared)}],
        "description": f"Fresh full {len(declared)}-theorem audit and {len(files)}-module build; source hashes unchanged during verification.",
    }
    (ROOT / "verification" / "AUDIT_PROVENANCE.json").write_text(
        json.dumps(provenance, indent=2) + "\n")
    print(summary, end="")


if __name__ == "__main__":
    try:
        main()
    except (OSError, RuntimeError) as error:
        print(f"Verification failed: {error}", file=sys.stderr)
        sys.exit(1)
