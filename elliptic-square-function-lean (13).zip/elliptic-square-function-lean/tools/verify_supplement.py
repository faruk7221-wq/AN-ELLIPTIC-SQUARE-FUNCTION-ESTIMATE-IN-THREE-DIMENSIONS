#!/usr/bin/env python3
"""Audit the six late additions after the unchanged 392-theorem full audit."""
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
LAKE = "/root/.elan/bin/lake"


def run(args: list[str], filename: str) -> str:
    result = subprocess.run(args, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    (ROOT / "verification" / filename).write_text(result.stdout)
    print(result.stdout, end="", flush=True)
    if result.returncode:
        raise RuntimeError(f"Failed: {args}")
    return result.stdout


run([LAKE, "build"], "build-final.log")
output = run([LAKE, "env", "lean", "SupplementalAxiomAudit.lean"], "axioms-supplement-6.log")
assert "sorryAx" not in output
allowed = {"propext", "Classical.choice", "Quot.sound"}
for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", output, re.S):
    assert {x.strip() for x in group.split(",") if x.strip()} <= allowed
assert len(re.findall(r"'EllipticSquareFunction\.[^']+'", output)) == 6
print("PASS: final build and six supplemental axiom checks.", flush=True)
