#!/usr/bin/env python3
"""Validate the 460 + 2 + 3 + 1 audit runs and unchanged sources, then combine."""
from pathlib import Path
import hashlib
import json
import re
import runpy
import shutil

ROOT = Path(__file__).resolve().parents[1]
VER = ROOT / "verification"
strip = runpy.run_path(str(ROOT / "tools/verify.py"))["without_comments"]
pattern = r"^(?:@\[[^\n]*\]\s*)*(?:(?:private|protected|noncomputable)\s+)*(?:theorem|lemma)\s+(\w+)"
files = sorted((ROOT / "EllipticSquareFunction").glob("*.lean"))
declared = {}
for p in files:
    code = strip(p.read_text())
    assert not re.search(r"\b(?:sorry|admit|axiom|unsafe|native_decide)\b", code), p
    for name in re.findall(pattern, code, re.M):
        assert name not in declared
        declared[name] = p.stem
assert len(declared) == 466 and len(files) == 84
snapshot = json.loads((VER / "AUDITED_460_SOURCE_SHA256.json").read_text())
assert len(snapshot) == 81
for name, digest in snapshot.items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name

base = VER / "axioms-full-460.log"
if not base.exists():
    current = (VER / "axioms.log").read_text()
    checked = re.findall(r"'EllipticSquareFunction\.(\w+)'", current)
    assert len(checked) == 460, "The full audit is not complete"
    assert (VER / "RESULT.txt").read_text().startswith("PASS: 81 modules and 460 project theorems.")
    base.write_text(current)
entries = [
    {"log": "axioms-full-460.log", "theorems": 460},
    {"log": "axioms-countable-2.log", "theorems": 2},
    {"log": "axioms-sampling-cs-3.log", "theorems": 3},
    {"log": "axioms-margins-1.log", "theorems": 1},
]
allowed = {"propext", "Classical.choice", "Quot.sound"}
all_names, texts = [], []
for entry in entries:
    log = (VER / entry["log"]).read_text()
    names = re.findall(r"'EllipticSquareFunction\.(\w+)'", log)
    assert len(names) == entry["theorems"] and len(names) == len(set(names))
    assert "sorryAx" not in log and "error:" not in log
    for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", log, re.S):
        assert {a.strip() for a in group.split(",") if a.strip()} <= allowed
    if entry["theorems"] == 2:
        assert set(names) == {n for n, m in declared.items() if m == "CountableSamplingDensity"}
    elif entry["theorems"] == 3:
        assert set(names) == {n for n, m in declared.items() if m == "SamplingCauchySchwarz"}
    elif entry["theorems"] == 1:
        assert set(names) == {n for n, m in declared.items() if m == "SetupMargins"}
    else:
        assert set(names) == {n for n, m in declared.items()
                              if str(Path("EllipticSquareFunction") / (m + ".lean")) in snapshot}
    all_names.extend(names)
    texts.append(log.strip())
assert len(all_names) == len(set(all_names)) == len(declared)
assert set(all_names) == set(declared)
build = (VER / "build-final.log").read_text()
assert "Build completed successfully." in build and "error:" not in build
imports = re.findall(r"^import EllipticSquareFunction\.(\w+)",
                     (ROOT / "EllipticSquareFunction.lean").read_text(), re.M)
assert len(imports) == len(files) and set(imports) == {p.stem for p in files}
audit_names = re.findall(r"^#print axioms EllipticSquareFunction\.(\w+)",
                        (ROOT / "AxiomAudit.lean").read_text(), re.M)
assert len(audit_names) == len(declared) and set(audit_names) == set(declared)
(VER / "axioms.log").write_text("\n\n".join(texts) + "\n")
shutil.copyfile(VER / "build-final.log", VER / "build.log")
description = ("Fresh full 460-theorem audit plus disjoint 2-, 3-, and 1-theorem supplemental audits; "
               "final full 84-module build. Exact 466-theorem coverage. "
               "All 81 full-audit module hashes and 67 baseline module hashes unchanged.")
(VER / "AUDIT_PROVENANCE.json").write_text(json.dumps(
    {"runs": entries, "description": description}, indent=2) + "\n")
(VER / "CURRENT_AUDIT_SOURCE_SHA256.json").write_text(json.dumps(
    {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    indent=2) + "\n")
(VER / "RESULT.txt").write_text("PASS: 84 modules and 466 project theorems.\n" + description + "\n")
deps = {n: ", ".join(a.strip() for a in group.split(",") if a.strip())
        for n, group in re.findall(r"'EllipticSquareFunction\.(\w+)' depends on axioms:\s*\[(.*?)\]",
                                  "\n".join(texts), re.S)}
(VER / "THEOREM_INVENTORY.tsv").write_text(
    "module\tdeclaration\taxiom_dependencies\n" + "".join(
        f"{module}\tEllipticSquareFunction.{name}\t{deps.get(name, '')}\n"
        for name, module in sorted(declared.items(), key=lambda item: (item[1], item[0]))))
print(description)
