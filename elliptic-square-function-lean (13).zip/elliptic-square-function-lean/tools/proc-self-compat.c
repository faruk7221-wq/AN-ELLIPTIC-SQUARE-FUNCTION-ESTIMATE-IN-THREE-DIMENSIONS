#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
/* Lean 4.19 asks for /proc/<own pid>/exe; this runtime exposes /proc/self/exe. */
ssize_t readlink(const char *path, char *buf, size_t size) {
  static ssize_t (*original)(const char *, char *, size_t);
  if (!original) original = dlsym(RTLD_NEXT, "readlink");
  char own[80];
  snprintf(own, sizeof own, "/proc/%ld/exe", (long)getpid());
  return original(strcmp(path, own) == 0 ? "/proc/self/exe" : path, buf, size);
}
