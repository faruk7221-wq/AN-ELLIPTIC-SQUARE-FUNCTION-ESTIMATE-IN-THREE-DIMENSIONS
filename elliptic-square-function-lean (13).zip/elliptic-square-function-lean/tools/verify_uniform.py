#!/usr/bin/env python3
"""Check the last uniform rebasing theorem and its full-project build."""
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
lake = shutil.which("lake") or str(Path.home() / ".elan/bin/lake")
for args, filename in [(["build"], "build-uniform.log"),
                       (["env", "lean", "RebasedUniformAxiomAudit.lean"],
                        "axioms-uniform-1.log")]:
    result = subprocess.run([lake, *args], cwd=ROOT, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (ROOT / "verification" / filename).write_text(result.stdout)
    print(result.stdout, end="", flush=True)
    assert result.returncode == 0
output = (ROOT / "verification/axioms-uniform-1.log").read_text()
assert re.findall(r"'EllipticSquareFunction\.(\w+)'", output) == ["equation_5_10_fixed_setup"]
assert "sorryAx" not in output
for group in re.findall(r"depends on axioms:\s*\[(.*?)\]", output, re.S):
    assert {x.strip() for x in group.split(",")} <= {"propext", "Classical.choice", "Quot.sound"}
print("PASS: final 67-module build and uniform (5.10) axiom check.")
