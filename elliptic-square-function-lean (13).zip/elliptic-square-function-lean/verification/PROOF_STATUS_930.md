# Proof status — October 12, 2026

## Main theorem: proved conditional statement

`article_main_theorem` proves `ArticleMainConclusion`, containing the graph estimate and the compact surface estimate. It has precisely these external premises:

1. `PlacementInput`: affine placement, External input 1, cited in the article as [6, Lemma 3.1].
2. `NikodymInput`: the unit-length maximal estimate, External input 3, cited as [7, Corollary 11.1].
3. `forall S, ContinuedPhase S.phi -> DiscreteDensityInput S`: External input 2 for the actual continued-phase setups constructed by the proof, cited as [6, equation (4.10)].

These are propositions passed as hypotheses. They are not project axioms, and their truth or the accuracy of the article's external citations has not been proved by this formalization. The external discrete estimate is required for each adequate setup; it is not transferred from an unrelated smaller setup.

The graph conclusion is `ReverseSquareFunction G` for every compact graph setup satisfying `GraphHypotheses`. The surface conclusion is `EuclideanSurfaceEstimate K c0 C0`. It uses Euclidean three-space, actual Schwartz maps, `Real.fourierIntegral`, and `surfaceCap`, the closed metric thickening of the carrier intersected with the open base ball as in (8.1). The constant is chosen before the real scale R >= 2, cap count, separated centers, and functions.

## Exact surface geometry

`SmoothEllipticSurfaceWithBoundary K` is an explicit extrinsic chart definition. Around every point it supplies:

- an open planar domain U and a smooth parametrization F on U;
- embeddedness of the restricted parametrization and injectivity of its differential at the chart center;
- an ambient open neighborhood in which K equals the appropriate parametrized patch;
- either the full planar model, or the half-plane model with center on its boundary;
- a unit normal and a definite second fundamental form at the center.

For a boundary chart, F is already a smooth extension to the open U. This records the local extension invoked in Section 8. It is part of the chosen smooth-boundary chart definition, not a theorem here about extending an arbitrary `ContMDiff` map on an abstract boundary manifold.

The second fundamental form is explicitly `inner N (D²F(a)[v,w])`. The project proves that it equals the frozen normal-height Hessian, is symmetric and bilinear for C2 parametrizations, and transforms by pullback under smooth invertible reparametrizations. A unit normal exists for every immersed two-plane and is unique up to sign; definiteness is independent of that sign. `tangentSecondForm` is the actual bilinear form on the image tangent subspace. Its definiteness is proved equivalent to the parameter condition. `article_tangent_surface_theorem` uses this tangent-space formulation.

`positive_graph_of_immersion` constructs adapted ambient coordinates, a smooth local inverse, and the graph phase. `positive_graph_extensions_of_embedded_surface` shrinks embedded patches and derives `LocalPositiveGraphExtensions`. The earlier positivity-to-uniform-ellipticity and finite-chart results then finish the estimate. No positive graph, inverse map, quantitative Hessian bound, finite chart cover, or internal analytic estimate remains an assumption of `article_main_theorem`.

## Mathlib manifold interface and remaining scope

The previous compact boundaryless-manifold adapter and exact `mfderiv` interface remain proved. `compact_model_surface_estimate` now extends the interface to arbitrary two-dimensional Mathlib models with corners. It assumes `ContMDiff`, `IsEmbedding`, injective `mfderiv`, and definite normal curvature computed by derivatives within the canonical chart target. It additionally assumes `HasSmoothModelExtensions`.

That additional property asks only for an open smooth extension agreeing with each canonical parametrization on the model set. Embeddedness of the extension is no longer assumed: `immersion_locally_embedding` derives it from the injective derivative using a local inverse. The adapter constructs the ambient neighborhoods and all covering data.

`model_mfderiv_eq_extension` identifies an extension's derivative with `mfderiv`. `model_second_form_eq_extension` identifies its second fundamental form with `modelSecondForm`, defined through iterated derivatives within the chart target. Second derivatives do not depend on which extension is chosen. Symmetry and normal-orientation independence of the canonical model form are proved even without an extension hypothesis. This is not yet a global tensor construction or a separate proof of invariance under every boundary chart transition.

**The extension premise is discharged for analytic data.** `analytic_within_smooth_extension` constructs a local smooth extension from `AnalyticWithinAt`; `compact_analytic_model_surface_estimate` therefore proves the estimate for analytic embedded Mathlib manifolds with corners without assuming extensions. `smooth_model_extension_at_interior` handles every interior point from smoothness alone. `compact_boundary_analytic_surface_estimate` specializes to Mathlib's actual half-space model `𝓡∂ 2`, requiring analyticity only at boundary points (coordinate 0 equals zero).

Still outside the checked result:

- constructing an open C∞ extension from arbitrary C∞ Mathlib boundary-manifold data; the exact remaining property is `HasSmoothModelExtensions`, reducible to boundary points only;
- a separately packaged global second-fundamental-form tensor on Mathlib tangent bundles, including full boundary chart compatibility;
- a line-by-line formalization of the original ambient cutoff/partition/coloring argument in Section 8 and every auxiliary assertion in the article.

The final item is not a missing premise of the proved main theorem: whole-cap assignment bypasses that argument. The three external analytic input propositions remain hypotheses throughout.

## New verified work in this continuation

| Modules | Proved contribution |
| --- | --- |
| SeeleyFiniteMoments | Finite Lagrange coefficients, exact polynomial moments, and recurrence. |
| SeeleyCoefficientBounds, SeeleyUniformBounds | Uniform coefficient majorant and summability after every derivative weight. |
| SeeleyCoefficientLimit, SeeleyInfiniteMoments | Convergence of coefficients; passage to every infinite moment by dominated convergence. |
| SeeleySeries, SeeleySeriesDerivative | Uniform series convergence, one-sided boundary limits, continuity, and differentiation term by term. |
| SeeleyBoundaryDerivative, SeeleySmoothJets | Boundary derivative matching and all-orders one-dimensional gluing for bounded compatible jets. |
| SeeleyHalfLineExtension, SeeleyCompactHalfLine | Actual within-derivative jets; bounds derived from smoothness and a vanishing tail. |
| SeeleyLocalHalfLine, SeeleyHalfLineTheorem | Cutoff localization and a global smooth extension of arbitrary smooth Banach-valued half-line data. |
| SeeleyReflectionGeometry | Reflection as a continuous linear map; operator norm and all-order multilinear pullback bounds. |
| SeeleyParameterSeries | Uniformity in a tangential parameter, boundary matching, and joint continuity across the boundary. |

The coefficient endpoint proves, for every natural m, both sum(a_k*(-2^k)^m)=1 and summability of |a_k|*2^(k*m). The construction is explicit through finite interpolation limits; coefficients are not assumed.

`smooth_halfline_extension` has precisely the premise `ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0)`, for a function from ℝ to a complete real normed space. It constructs F smooth on all of ℝ with F=f on the full closed half-line. It does not assume bounded derivatives or analytic data. Intermediate bounded-jet theorems do have explicit boundedness and derivative-compatibility premises; cutoff localization discharges them for this endpoint.

This is a one-dimensional domain theorem. Although its codomain can be a Banach space, separate applications at each tangential parameter do not establish joint C∞ regularity. The parameterized series currently has joint continuity only, under an explicit uniform bound. The two-dimensional smooth extension needed for the general boundary adapter remains unfinished.

## Retained analytic results

All 868 prior declarations and 207 modules are unchanged. Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions 2 and 3 retain their previously documented external-input/setup scope. Lemma 4 synthesis, density (6.2), reproducing estimate (6.11), sample estimate (6.12), and Fatou composition remain proved. Lemma 5 is proved in positive-integral form and for actual squared-Schwartz Bochner convolutions. Initial partitions, adequate setups, and both internal analytic bridges remain constructed/proved. Earlier detailed status is preserved in `verification/PROOF_STATUS_835.md`, `verification/PROOF_STATUS_771.md`, and `verification/PROOF_STATUS_705.md`.

## Verification

930 declarations / 222 modules; 62 additions / 15 new modules. Fresh whole-project build and fresh audits of all 62 additions. The 868 baseline declarations have a completed fresh full audit, retained only after checking all 207 module hashes. This gives exact coverage of all 930 declarations. Audit groups are SEELEY (53) and SEELEY_PARAMETER (5), and SEELEY_GEOMETRY (4). See `RESULT.txt`, `AUDIT_PROVENANCE.json`, `THEOREM_INVENTORY.tsv`, and `CURRENT_AUDIT_SOURCE_SHA256.json` under `verification/`. Only `propext`, `Classical.choice`, and `Quot.sound` are permitted. No placeholder proof or project axiom declarations are allowed. Counts are not a completion percentage.
