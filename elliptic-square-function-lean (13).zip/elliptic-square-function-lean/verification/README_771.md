# Elliptic square function: Lean formalization checkpoint

Faruk Temur, *The elliptic square function estimate in three dimensions*, October 8, 2026.

**The general graph theorem is proved, conditional on the article's three external inputs.** The Euclidean surface theorem is proved from local smooth graph extensions with positive-definite Hessian at each chart center. The intrinsic embedded-surface / second-fundamental-form / boundary-to-graph reduction remains unfinished. This is not a claim that every part of the article is formalized.

## Latest checkpoint

771 declarations in 176 modules: 66 new declarations in 18 modules since the 705-theorem checkpoint. All 158 prior modules are unchanged. Counts include supporting and conditional results, not a completion percentage. The authoritative verification result is `verification/RESULT.txt`.

- `general_graph_reverse_square_function`: all real R >= 2, from GraphHypotheses, PlacementInput, NikodymInput, and the discrete-density input for continued-phase setups.
- `euclidean_surface_estimate_of_positive_graphs`: actual Euclidean Schwartz functions, Fourier integral, and distance caps (8.1), from compactness and LocalPositiveGraphExtensions.
- Uniform affine cap containment and separation, exact Fourier-support transport, Schwartz preservation, determinant cancellation, finite chart assembly, scale thresholds, and bounded-scale packing are proved.
- Centerwise positive definiteness yields uniform ellipticity after shrinking. Compact parameter domains and a finite cover are constructed. Boundary portions may lie in a smooth graph extension; no extension by zero is used.

The proof assigns each whole cap to one sufficiently large fixed chart. This avoids the original ambient cutoff decomposition. Its analytic convolution bound remains proved from the previous checkpoint, but the original cutoff construction is not formalized line by line.

See `PROOF_STATUS.md` for exact assumptions and `CONTINUATION.md` for next steps.

## Verification

Lean 4.19.0; Mathlib commit `c44e0c8ee63ca166450922a373c7409c5d26b00b`.

The fresh whole-project build and fresh audit of all 66 new declarations are combined with the 705 prior audit results only after checking unchanged source hashes. Exact coverage and provenance are in `verification/`. Only propext, Classical.choice, and Quot.sound are allowed; no sorry, admit, project axiom, unsafe, or native_decide proof tokens are allowed. An axiom audit does not prove hypotheses in theorem statements.

On a normal Lean installation:

```
lake exe cache get
python3 tools/verify.py
```

The full verification script rebuilds and audits all declarations. The current incremental merge is `tools/merge_completion_audits.py`; packaging checks coverage and hashes again. Historical scripts have checkpoint-specific assumptions. The source archive excludes Lean binaries, Mathlib caches, compiled objects, and temporary runtime libraries.

GraphNormalGeometry additionally proves the graph derivative, tangent-normal orthogonality, Euclidean unit normal, differentiated tangent field, and its normal component equal to the Hessian divided by sqrt(1+norm(gradient)^2). Identification with an intrinsic second fundamental form remains unfinished.
