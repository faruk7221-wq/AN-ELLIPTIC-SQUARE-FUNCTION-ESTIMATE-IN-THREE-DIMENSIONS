# Proof status — October 12, 2026

## Main theorem: proved conditional statement

`article_main_theorem` proves `ArticleMainConclusion`, containing the graph estimate and the compact surface estimate. It has precisely these external premises:

1. `PlacementInput`: affine placement, External input 1, cited in the article as [6, Lemma 3.1].
2. `NikodymInput`: the unit-length maximal estimate, External input 3, cited as [7, Corollary 11.1].
3. `forall S, ContinuedPhase S.phi -> DiscreteDensityInput S`: External input 2 for the actual continued-phase setups constructed by the proof, cited as [6, equation (4.10)].

These are propositions passed as hypotheses. They are not project axioms, and their truth or the accuracy of the article's external citations has not been proved by this formalization. The external discrete estimate is required for each adequate setup; it is not transferred from an unrelated smaller setup.

The graph conclusion is `ReverseSquareFunction G` for every compact graph setup satisfying `GraphHypotheses`. The surface conclusion is `EuclideanSurfaceEstimate K c0 C0`. It uses Euclidean three-space, actual Schwartz maps, `Real.fourierIntegral`, and `surfaceCap`, the closed metric thickening of the carrier intersected with the open base ball as in (8.1). The constant is chosen before the real scale R >= 2, cap count, separated centers, and functions.

## Exact surface geometry

`SmoothEllipticSurfaceWithBoundary K` is an explicit extrinsic chart definition. Around every point it supplies:

- an open planar domain U and a smooth parametrization F on U;
- embeddedness of the restricted parametrization and injectivity of its differential at the chart center;
- an ambient open neighborhood in which K equals the appropriate parametrized patch;
- either the full planar model, or the half-plane model with center on its boundary;
- a unit normal and a definite second fundamental form at the center.

For a boundary chart, F is already a smooth extension to the open U. This records the local extension invoked in Section 8. It is part of the chosen smooth-boundary chart definition, not a theorem here about extending an arbitrary `ContMDiff` map on an abstract boundary manifold.

The second fundamental form is explicitly `inner N (D²F(a)[v,w])`. The project proves that it equals the frozen normal-height Hessian, is symmetric and bilinear for C2 parametrizations, and transforms by pullback under smooth invertible reparametrizations. A unit normal exists for every immersed two-plane and is unique up to sign; definiteness is independent of that sign. `tangentSecondForm` is the actual bilinear form on the image tangent subspace. Its definiteness is proved equivalent to the parameter condition. `article_tangent_surface_theorem` uses this tangent-space formulation.

`positive_graph_of_immersion` constructs adapted ambient coordinates, a smooth local inverse, and the graph phase. `positive_graph_extensions_of_embedded_surface` shrinks embedded patches and derives `LocalPositiveGraphExtensions`. The earlier positivity-to-uniform-ellipticity and finite-chart results then finish the estimate. No positive graph, inverse map, quantitative Hessian bound, finite chart cover, or internal analytic estimate remains an assumption of `article_main_theorem`.

## Mathlib manifold interface and remaining scope

`compact_manifold_surface_estimate` is proved for a compact Mathlib two-manifold without boundary, a `ContMDiff` embedding into Euclidean three-space, and `ManifoldEllipticImmersion`. The latter states differential injectivity and definite normal curvature in the canonical manifold charts. The smooth parametrizations and embedded ambient patches are derived. `manifold_derivative_eq_chart_derivative` identifies the chart differential exactly with Mathlib's `mfderiv`, and `compact_manifold_surface_estimate_of_mfderiv` uses that derivative directly for immersion and normality.

Still outside the checked result:

- the general Mathlib manifold-with-boundary adapter, including construction of an open smooth extension from that API's hypotheses;
- a separately packaged global second-fundamental-form tensor on Mathlib tangent bundles; the immersion condition itself is now identified with `mfderiv`;
- a line-by-line formalization of the original ambient cutoff/partition/coloring argument in Section 8 and every auxiliary assertion in the article.

The third item is not a missing premise of the proved main theorem: whole-cap assignment bypasses that argument. External input proofs are deliberately outside the article's conditional deduction as well.

## New verified work in this continuation

| Modules | Role |
| --- | --- |
| CriticalHessianComposition, SmoothLocalInverse | Critical-point Hessian chain rule and smooth local inverse on a prescribed domain. |
| ParametrizedGraphConstruction, TangentNormalCoordinates, ImmersionGraphConstruction | Constructed coordinates and positive graph phase from a smooth elliptic immersion. |
| EmbeddedSurfaceExtensions, EuclideanEmbeddedSurface, SurfaceWithBoundary | Embedded patch shrinking, orientation choice, Euclidean transfer, explicit interior/boundary surface theorem. |
| NormalSecondFundamentalForm, SecondFormReparametrization, SecondFormSymmetry | Standard second fundamental form, reparametrization, bilinearity, symmetry. |
| TangentSecondFundamentalForm, TangentSurfaceTheorem | Form on the actual tangent plane and equivalent surface theorem. |
| NormalDirectionUniqueness, NormalExistence | Existence of unit normals, uniqueness up to sign, orientation-independent definiteness. |
| EuclideanGraphGeometry, EllipticGraphExamples | Euclidean graph geometry, positive graph extensions, concrete compact paraboloid estimate. |
| ArticleMainTheorem, ManifoldSurfaceAdapter, ManifoldDerivativeInterface | Combined Theorem 1, compact Mathlib manifold adapter without boundary, and exact mfderiv/coordinate derivative identification. |

## Retained analytic results

All 771 prior declarations and 176 modules are unchanged. Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions 2 and 3 retain their previously documented external-input/setup scope. Lemma 4 synthesis, density (6.2), reproducing estimate (6.11), sample estimate (6.12), and Fatou composition remain proved. Lemma 5 is proved in positive-integral form and for actual squared-Schwartz Bochner convolutions. Initial partitions, adequate setups, and both internal analytic bridges remain constructed/proved. Earlier detailed status is preserved in `verification/PROOF_STATUS_771.md` and `verification/PROOF_STATUS_705.md`.

## Verification

835 declarations / 196 modules; 64 additions / 20 new modules. There is a fresh whole-project build, fresh axiom audit of all additions, and retained prior audits only for byte-identical source hashes. See `RESULT.txt`, `AUDIT_PROVENANCE.json`, `THEOREM_INVENTORY.tsv`, and `CURRENT_AUDIT_SOURCE_SHA256.json` under `verification/`. Allowed axioms are only `propext`, `Classical.choice`, and `Quot.sound`. No `sorry`, `admit`, project `axiom`, `unsafe`, or `native_decide` proof tokens are allowed. Counts are not a completion percentage.
