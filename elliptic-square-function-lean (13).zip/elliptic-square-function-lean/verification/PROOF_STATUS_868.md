# Proof status — October 12, 2026

## Main theorem: proved conditional statement

`article_main_theorem` proves `ArticleMainConclusion`, containing the graph estimate and the compact surface estimate. It has precisely these external premises:

1. `PlacementInput`: affine placement, External input 1, cited in the article as [6, Lemma 3.1].
2. `NikodymInput`: the unit-length maximal estimate, External input 3, cited as [7, Corollary 11.1].
3. `forall S, ContinuedPhase S.phi -> DiscreteDensityInput S`: External input 2 for the actual continued-phase setups constructed by the proof, cited as [6, equation (4.10)].

These are propositions passed as hypotheses. They are not project axioms, and their truth or the accuracy of the article's external citations has not been proved by this formalization. The external discrete estimate is required for each adequate setup; it is not transferred from an unrelated smaller setup.

The graph conclusion is `ReverseSquareFunction G` for every compact graph setup satisfying `GraphHypotheses`. The surface conclusion is `EuclideanSurfaceEstimate K c0 C0`. It uses Euclidean three-space, actual Schwartz maps, `Real.fourierIntegral`, and `surfaceCap`, the closed metric thickening of the carrier intersected with the open base ball as in (8.1). The constant is chosen before the real scale R >= 2, cap count, separated centers, and functions.

## Exact surface geometry

`SmoothEllipticSurfaceWithBoundary K` is an explicit extrinsic chart definition. Around every point it supplies:

- an open planar domain U and a smooth parametrization F on U;
- embeddedness of the restricted parametrization and injectivity of its differential at the chart center;
- an ambient open neighborhood in which K equals the appropriate parametrized patch;
- either the full planar model, or the half-plane model with center on its boundary;
- a unit normal and a definite second fundamental form at the center.

For a boundary chart, F is already a smooth extension to the open U. This records the local extension invoked in Section 8. It is part of the chosen smooth-boundary chart definition, not a theorem here about extending an arbitrary `ContMDiff` map on an abstract boundary manifold.

The second fundamental form is explicitly `inner N (D²F(a)[v,w])`. The project proves that it equals the frozen normal-height Hessian, is symmetric and bilinear for C2 parametrizations, and transforms by pullback under smooth invertible reparametrizations. A unit normal exists for every immersed two-plane and is unique up to sign; definiteness is independent of that sign. `tangentSecondForm` is the actual bilinear form on the image tangent subspace. Its definiteness is proved equivalent to the parameter condition. `article_tangent_surface_theorem` uses this tangent-space formulation.

`positive_graph_of_immersion` constructs adapted ambient coordinates, a smooth local inverse, and the graph phase. `positive_graph_extensions_of_embedded_surface` shrinks embedded patches and derives `LocalPositiveGraphExtensions`. The earlier positivity-to-uniform-ellipticity and finite-chart results then finish the estimate. No positive graph, inverse map, quantitative Hessian bound, finite chart cover, or internal analytic estimate remains an assumption of `article_main_theorem`.

## Mathlib manifold interface and remaining scope

The previous compact boundaryless-manifold adapter and exact `mfderiv` interface remain proved. `compact_model_surface_estimate` now extends the interface to arbitrary two-dimensional Mathlib models with corners. It assumes `ContMDiff`, `IsEmbedding`, injective `mfderiv`, and definite normal curvature computed by derivatives within the canonical chart target. It additionally assumes `HasSmoothModelExtensions`.

That additional property asks only for an open smooth extension agreeing with each canonical parametrization on the model set. Embeddedness of the extension is no longer assumed: `immersion_locally_embedding` derives it from the injective derivative using a local inverse. The adapter constructs the ambient neighborhoods and all covering data.

`model_mfderiv_eq_extension` identifies an extension's derivative with `mfderiv`. `model_second_form_eq_extension` identifies its second fundamental form with `modelSecondForm`, defined through iterated derivatives within the chart target. Second derivatives do not depend on which extension is chosen. Symmetry and normal-orientation independence of the canonical model form are proved even without an extension hypothesis. This is not yet a global tensor construction or a separate proof of invariance under every boundary chart transition.

**The extension premise is discharged for analytic data.** `analytic_within_smooth_extension` constructs a local smooth extension from `AnalyticWithinAt`; `compact_analytic_model_surface_estimate` therefore proves the estimate for analytic embedded Mathlib manifolds with corners without assuming extensions. `smooth_model_extension_at_interior` handles every interior point from smoothness alone. `compact_boundary_analytic_surface_estimate` specializes to Mathlib's actual half-space model `𝓡∂ 2`, requiring analyticity only at boundary points (coordinate 0 equals zero).

Still outside the checked result:

- constructing an open C∞ extension from arbitrary C∞ Mathlib boundary-manifold data; the exact remaining property is `HasSmoothModelExtensions`, reducible to boundary points only;
- a separately packaged global second-fundamental-form tensor on Mathlib tangent bundles, including full boundary chart compatibility;
- a line-by-line formalization of the original ambient cutoff/partition/coloring argument in Section 8 and every auxiliary assertion in the article.

The final item is not a missing premise of the proved main theorem: whole-cap assignment bypasses that argument. The three external analytic input propositions remain hypotheses throughout.

## New verified work in this continuation

| Modules | Role |
| --- | --- |
| LocalImmersionEmbedding | Derives local embeddedness from a smooth injective differential. |
| SmoothExtensionDerivatives | Identifies first and second derivatives of extensions; proves second-derivative uniqueness. |
| BoundaryManifoldDerivatives | Identifies `mfderiv` and canonical model curvature with extension derivatives. |
| BoundaryManifoldAdapter | Proves the manifold-with-corners adapter conditional only on smooth extendibility in addition to the geometric and external hypotheses. |
| AnalyticBoundaryExtension | Constructs analytic local extensions and proves the analytic manifold-with-corners estimate. |
| ModelSecondFormGeometry | Canonical model form symmetry, bilinearity, orientation independence, and boundaryless extension construction. |
| BoundaryExtensionReduction, HalfSpaceBoundaryTheorem | Reduces extension to boundary points and proves the actual half-space theorem when those points are analytic. |
| SphericalCurvature, UnitSphereEstimate | Proves the spherical normal and curvature identities, the unit sphere's geometric hypotheses, and its estimate. |
| SurfaceEstimateRestriction | Carrier monotonicity with the same constants, including arbitrary portions of the unit sphere. |

For the sphere, `constant_norm_second_form` proves II(v,w) = -inner(DF(v),DF(w)); injectivity makes this form negative definite. `unit_sphere_estimate` has no unproved geometric premise. `unit_sphere_portion_estimate` requires only that the carrier be a subset of the unit sphere; the same constants work because its caps are contained in the full sphere's caps.

## Retained analytic results

All 835 prior declarations and 196 modules are unchanged. Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions 2 and 3 retain their previously documented external-input/setup scope. Lemma 4 synthesis, density (6.2), reproducing estimate (6.11), sample estimate (6.12), and Fatou composition remain proved. Lemma 5 is proved in positive-integral form and for actual squared-Schwartz Bochner convolutions. Initial partitions, adequate setups, and both internal analytic bridges remain constructed/proved. Earlier detailed status is preserved in `verification/PROOF_STATUS_835.md`, `verification/PROOF_STATUS_771.md`, and `verification/PROOF_STATUS_705.md`.

## Verification

868 declarations / 207 modules; 33 additions / 11 new modules. There is a fresh whole-project build and fresh axiom audits of all 33 additions. The 835 earlier audit results are retained only for byte-identical source hashes, giving exact coverage of all 868 declarations. See `RESULT.txt`, `AUDIT_PROVENANCE.json`, `THEOREM_INVENTORY.tsv`, and `CURRENT_AUDIT_SOURCE_SHA256.json` under `verification/`. Allowed axioms are only `propext`, `Classical.choice`, and `Quot.sound`. No `sorry`, `admit`, project `axiom`, `unsafe`, or `native_decide` proof tokens are allowed. Counts are not a completion percentage.
