# Proof status — October 12, 2026

## Main theorem: precise scope

The graph part of Theorem 1 is proved in `general_graph_reverse_square_function`. For a compact GraphSetup G with the article's smoothness and uniform ellipticity hypotheses, it concludes ReverseSquareFunction G for every real R >= 2. Its external premises are:

1. PlacementInput: External input 1, affine placement.
2. NikodymInput: External input 3, the unit-length maximal estimate.
3. `forall S, ContinuedPhase S.phi -> DiscreteDensityInput S`: External input 2 for the continued-phase setups constructed by the proof.

These are explicit hypotheses, not project axioms or results proved here. The discrete estimate is required for the actual adequate setup; it is not transferred from an unrelated smaller setup.

The strongest surface statement is `euclidean_surface_estimate_of_positive_graphs`. It uses ordinary Euclidean three-space, Mathlib's Fourier integral, actual Euclidean Schwartz functions, and surfaceCap: closed metric thickening of the surface intersected with the open C0*delta ball, as in (8.1). The constant precedes R, the separated cap family, and its functions.

Besides the same external inputs, this result assumes LocalPositiveGraphExtensions of the surface image under spaceEuclideanEquiv. Near each point there must be an affine coordinate map and smooth extended graph containing the local surface, with positive-definite Hessian at the center. Uniform Hessian bounds, compact parameter domains, a finite cover, cap containment, separation, and the desired estimate are NOT supplied in this premise: they are derived. The inclusion formulation permits portions with boundary when smooth graph extensions are provided.

## Unfinished obligations

The intrinsic surface formulation of Theorem 1 is NOT yet proved. The project has not defined and proved the complete bridge from a compact smooth embedded manifold with definite second fundamental form, possibly with smooth boundary, to LocalPositiveGraphExtensions. Local graph construction from an immersion, curvature-to-Hessian comparison, normal-sign choice, and boundary-extension construction remain unfinished. The article is therefore not completely formalized.

The original ambient cutoff / multiplier construction in Section 8 is also not formalized line by line. It is not an outstanding premise of the new theorem route: whole-cap assignment bypasses it. The actual vector-valued convolution estimate from the previous checkpoint remains available.

## Completed in this continuation

| Modules | Verified role |
| --- | --- |
| AffineGraphCoordinates | Transpose involution/inverse; graph coordinate inverse; prescribed affine Schwartz/Fourier support transport. |
| AffineCapGeometry, CompactPhaseBounds, UniformAffineCaps | Local slope bounds; uniform cap and center-separation constants before scale/data. |
| FiniteSubfamilies, PlacedChartEstimate | Exact reindexing, subfamily monotonicity, actual single-chart estimate. |
| GeneralGraphLargeScale, GeneralGraphTheorem | Whole-cap cover, threshold, bounded-scale packing, all-real-scale graph theorem. |
| SurfaceCaps, SurfaceChartGeometry, SurfaceChartEstimate | Actual distance caps; graph containment and separation, including boundary portions. |
| CompactPacking, SurfaceAtlasTheorem | Compact metric packing and full assembly from a local graph atlas. |
| EuclideanSurfaceTheorem | Change of norm, Euclidean Fourier/Schwartz/norm identification, Euclidean surface estimate. |
| LocalSurfaceGraphs | Compact parameter domains constructed by shrinking open charts. |
| LocalEllipticity, PositiveGraphSurfaceTheorem | Positive bilinear coercivity; local uniform ellipticity; surface theorem from centerwise positive graph extensions. |

## Retained results

All 705 earlier declarations and 158 modules are unchanged. Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions 2 and 3 retain their documented external-input/setup scope. Lemma 4 synthesis, density (6.2), reproducing estimate (6.11), sample estimate (6.12), and Fatou composition remain proved. Lemma 5 is proved in positive-integral form and for actual squared-Schwartz Bochner convolutions. The initial squared lattice partition, adequate setups, and both internal analytic bridges remain constructed/proved.

The continued-phase graph theorem and actual L1 chart-kernel square-function bound remain proved. The 705-stage detailed status is preserved in verification/PROOF_STATUS_705.md.

## Verification

771 declarations / 176 modules; 66 fresh declarations / 18 new modules. Read verification/RESULT.txt, AUDIT_PROVENANCE.json, THEOREM_INVENTORY.tsv, and CURRENT_AUDIT_SOURCE_SHA256.json. Retained results are used only for unchanged source hashes; each new declaration is freshly audited. Only standard Lean axioms are permitted, with no placeholder proofs or project axiom declarations. Counts do not measure percentage completion.

GraphNormalGeometry additionally proves the graph derivative, tangent-normal orthogonality, Euclidean unit normal, differentiated tangent field, and its normal component equal to the Hessian divided by sqrt(1+norm(gradient)^2). Identification with an intrinsic second fundamental form remains unfinished.
