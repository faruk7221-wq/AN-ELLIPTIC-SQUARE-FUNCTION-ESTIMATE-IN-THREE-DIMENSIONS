# Elliptic square function: Lean formalization

Faruk Temur, *The elliptic square function estimate in three dimensions*, October 8, 2026.

**Theorem 1 now has a compiled conditional proof for graphs and for surfaces defined by explicit smooth embedded charts, including boundary charts.** The three external input propositions remain hypotheses, exactly as in the article. Graph construction is proved internally using the inverse function theorem; positive graph extensions are no longer an assumption of the main endpoint.

## Main endpoints

- `article_main_theorem`: both assertions of Theorem 1, packaged as `ArticleMainConclusion`.
- `article_surface_theorem`: actual Euclidean Schwartz functions, Fourier integral, and distance caps (8.1), for compact `SmoothEllipticSurfaceWithBoundary` carriers.
- `article_tangent_surface_theorem`: the same conclusion with definiteness stated on the actual tangent subspace.
- `compact_manifold_surface_estimate_of_mfderiv`: adapter for compact Mathlib manifolds without boundary, using `ContMDiff`, `IsEmbedding`, and injectivity of `mfderiv`; normal curvature is stated in canonical charts.
- `compact_paraboloid_estimate`: a concrete specialization for arbitrary compact portions of the paraboloid.
- `compact_model_surface_estimate`: the Mathlib manifold-with-corners adapter, conditional on `HasSmoothModelExtensions`. Immersion uses `mfderiv`; curvature uses derivatives within canonical chart targets.
- `compact_analytic_model_surface_estimate`: the extension premise is proved for analytic manifolds, including boundary/corner models.
- `compact_smooth_boundary_surface_estimate`: the actual Mathlib half-space boundary model with C∞ smoothness alone; local smooth extensions are constructed by the multivariable Seeley theorem.
- `compact_boundary_analytic_surface_estimate`: the actual half-space boundary model, smooth everywhere and analytic in canonical coordinates at boundary points only.
- `unit_sphere_estimate` / `unit_sphere_portion_estimate`: the unit sphere and arbitrary portions of it, with all geometric premises discharged.

The explicit surface definition uses an open planar domain, a smooth embedded extension, and local equality with either its full-domain or half-plane portion. At each point the immersion has definite second fundamental form. Tangent coordinates, normal-sign choice, smooth inverse, positive graph Hessian, uniform ellipticity, compact chart domains, finite cover, cap geometry, and all-scale assembly are derived.

For Mathlib's actual two-dimensional half-space model `𝓡∂ 2`, the smooth extension premise is now discharged from `ContMDiff` C∞ smoothness alone. Arbitrary models with corners still use the explicit extension premise unless analyticity is supplied. Nor is every auxiliary sentence of the article formalized line by line: the original chart cutoff argument is bypassed by assigning whole caps to fixed charts.

## New smooth-extension results

`seeley_coefficients_exist` constructs all-order Seeley coefficients with exact moments and rapid weighted summability. `smooth_halfline_extension` proves that every Banach-valued `ContDiffOn` C∞ function on `[0,∞)` extends smoothly to the whole real line. Boundedness and analyticity are not assumptions of this endpoint: a compact cutoff supplies derivative bounds locally, followed by smooth gluing.

`smooth_halfspace_extension` now proves a global smooth extension for any Banach-valued C∞ map on a finite-dimensional closed half-space. The proof uses all-order multilinear tensor moments, uniform convergence, joint Fréchet differentiation, boundary jet matching, cutoff localization, and a smooth partition of unity. No boundedness or analyticity premise remains in this endpoint.

`halfspace_extensions_of_smooth` constructs `HasSmoothModelExtensions` for canonical Mathlib boundary charts. `compact_smooth_boundary_surface_estimate` then proves the surface estimate from smoothness, embeddedness, injective `mfderiv`, definite curvature, and the three external analytic inputs.

## Latest checkpoint

963 declarations in 232 modules; 33 new declarations in 10 modules since the 930-declaration checkpoint. All 222 baseline modules remain byte-for-byte unchanged. Counts include supporting and conditional results and are not a completion percentage. See `verification/RESULT.txt` for the authoritative result and `PROOF_STATUS.md` for exact scope.

## Reproduction

Lean 4.19.0; Mathlib commit `c44e0c8ee63ca166450922a373c7409c5d26b00b`.

On a normal Lean installation:

```
lake exe cache get
python3 tools/verify.py
```

The full verifier builds and audits every declaration. The saved checkpoint has a fresh whole-project build and exact axiom coverage; `verification/AUDIT_PROVENANCE.json` records which audit runs supplied that coverage. Only `propext`, `Classical.choice`, and `Quot.sound` are permitted. No placeholder proof or project axiom declarations are allowed. An axiom audit does not prove the external input propositions.

`tools/merge_completion_audits.py` reproduces the checked incremental merge; `tools/package_checkpoint.py` validates coverage and source hashes before packaging. Historical scripts have checkpoint-specific assumptions. The archive excludes Lean binaries, Mathlib caches, compiled objects, and temporary runtime libraries.
