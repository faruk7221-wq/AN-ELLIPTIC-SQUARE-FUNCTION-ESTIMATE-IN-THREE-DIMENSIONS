# Proof status — October 12, 2026

## Main theorem

The general elliptic-graph and compact-surface version of Theorem 1 is **not
proved**. The continued-graph case is proved from the stated external analytic
inputs, with no internal sampling/smoothing bridge or initial-window premise.

The strongest result is `continued_graph_reverse_square_function`:

- Given a GraphSetup G and `ContinuedPhase G.φ`;
- given `NikodymInput` (the unit-length external maximal estimate);
- given `DiscreteDensityInput S` for phase-matching discrete setups S;
- conclude `ReverseSquareFunction G`, uniformly for every real R>=2.

`continued_graph_exists_setup` makes the narrower dependence explicit: it
constructs one adequate setup S with S.φ=G.φ, and the conclusion needs the
external discrete input for that S. No transfer of this input from a different
setup is asserted. External inputs are propositions used as hypotheses, not
project axioms and not theorems proved here.

## Completed in this continuation

### Lemma 5 and its application

`positive_tube_smoothing_bound` proves the finite positive convolution
inequality with constant A R^(γ/2), for M>3, 0<γ<=1, R>=1 and bounded slopes.
A is chosen before the scale, cardinality, directions and data. The data may
be arbitrary measurable nonnegative extended-real functions. Infinite norms
are allowed; no finiteness premise on the output is assumed.

Positive L^(3/2) duality is proved by truncating both amplitude and support,
using finite-measure spanning sets. The truncations are real finite-norm
functions; their square roots are admissible L3 tests. Hölder, cancellation
and monotone convergence finish the proof.

`schwartz_tube_smoothing_bound` separately identifies the positive integrals
with actual Bochner convolutions for squared Schwartz data, proves continuity,
integrability and L^(3/2) membership, and establishes the required bound.
`tubeSmoothingEstimates_from_nikodym` specializes this to admissible cap families.
The general positive-integral theorem uses measurable representatives; a
separate quotient-level statement for arbitrary Lp equivalence classes has
not been packaged.

### Constructed initial partition

`latticeWindowOne` is the explicit smooth cosine/sine window. Its squared
integer translates sum to one. `latticeWindowPlane` is the product window;
it is smooth, nonnegative, compactly supported in the coordinate box [-1,1]^2,
and its squared IntPlane translates sum to one. `initialDiscreteSetup` uses
spacing D=4, so the required strict support bound is proved. Existing margin
constructions then produce adequate frequency and position label bounds.

### Section 8 ingredients

- `spaceTranspose` is constructed from the nondegenerate Euclidean Fourier
  pairing on Space, independently of the equivalent product norm.
- `fourierTransform_modulatedLinearPullback` gives exact affine Fourier
  covariance, with inverse transpose and absolute inverse determinant.
- `schwartzModulatedLinearPullback` constructs the actual Schwartz transform,
  and `support_fourier_modulatedLinearPullback` proves exact support transport.
- `reverse_square_function_affine_norm_iff` proves that both sides acquire
  the same finite nonzero determinant factor; common modulation has norm one.
- `positive_young_l3` proves the positive L1-to-L3 convolution estimate.
- `chart_squareFunction_l3_bound` proves the vector-valued chart convolution
  estimate for a measurable L1 complex kernel and finite Schwartz family,
  with exactly `eLpNorm K 1` and no cap-cardinality loss.
- `finite_chart_l3_assembly` recombines supplied chart estimates. The actual
  chart estimates and decomposition remain hypotheses of this helper.
- `finite_family_l3_square_bound` proves the square-root cardinality fallback.
- `finite_placement_cover` derives finitely many placed continued charts and
  a uniform positive ball radius from PlacementInput and compactness.

## Previous checked results retained

Lemma 4's actual Schwartz HasSum synthesis and real coefficient-density bound
(6.2), reproducing bounds (6.11), sample bounds (6.12), and finite-to-full Fatou
composition remain proved. The packet/sampling bridge covers all real R>=2.

Equations (4.11), corrected (4.14), and (4.15), and finite-profile Propositions
2 and 3 retain their previously documented external-input and setup conditions.
The adequate label setup is constructed, but the external discrete estimate
must hold for that constructed setup. The new initial-window construction now
removes the need to supply its smooth squared partition separately.

Equation (7.4), including dilation from unit length to arbitrary tube length,
and summation over lengths with decreasing dyadic weights, remains proved.

## Unfinished obligations

1. Derive cap containment and quantitative separation after affine placement,
   uniformly on compact charts. Construct bounded color families if needed.
2. Construct fixed ambient smooth chart cutoffs with a partition identity,
   prove their inverse Fourier kernels are L1, and identify their multiplier
   action with the actual convolutions already bounded here.
3. Apply the analytic assembly to those actual chart families, including the
   scale threshold and bounded-cardinality fallback.
4. Formulate the general compact embedded surface and boundary-extension data
   and prove the geometric chart reduction. No final surface theorem is asserted.

## Verification scope

705 declarations, 158 modules. Fresh whole-project build; fresh audits of all
69 additions; all 636 previous declarations retained only after byte-for-byte
hash checks of their 140 modules. Exact audit coverage, hashes, provenance and
theorem inventory are saved in `verification/`. Only standard Lean axioms
`propext`, `Classical.choice`, and `Quot.sound` occur. These checks verify the
formal statements and proofs; they do not erase hypotheses or substitute for
an article-to-formal-statement comparison.
