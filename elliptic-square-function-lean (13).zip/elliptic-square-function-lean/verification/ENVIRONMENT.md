# Verification environment

Lean 4.19.0 and Mathlib v4.19.0 were used. The exact revision is pinned in
`lakefile.toml` and `lake-manifest.json`.

This execution environment hides `/proc/<process-id>/exe` from an executable
while allowing `/proc/self/exe`. Lean uses the former to find its own
installation. The optional compatibility shim in `tools/proc-self-compat.c`
redirects exactly that lookup to the equivalent self path. It does not
intercept proof checking or change Lean's executable.

To reproduce this environment-specific workaround:

```sh
gcc -shared -fPIC tools/proc-self-compat.c -o tools/proc-self-compat.so -ldl
export LD_PRELOAD="$PWD/tools/proc-self-compat.so"
export TAR_OPTIONS=--no-same-owner
lake exe cache get
lake build
lake env lean AxiomAudit.lean
```

On ordinary installations, use the three commands in the README without the
shim or these environment variables. `TAR_OPTIONS` only prevents ownership
restoration when unpacking downloaded archives in a restricted container.

`build.log` and `axioms.log` record the final verification runs. The latter
must contain no `sorryAx`; external inputs and internal bridges must appear
only as explicit theorem hypotheses or proposition definitions.

The current inventory and exact audit provenance are in RESULT.txt,
STATUS.json, and AUDIT_PROVENANCE.json. The final build covers every current
module. Every current theorem must occur exactly once in the audited
inventory, and only the three standard axioms above are allowed.

CURRENT_AUDIT_SOURCE_SHA256.json records the current checked Lean source
hashes. BASELINE_609_SOURCE_SHA256.json preserves the 131-module starting
checkpoint. 130 modules are unchanged. TubeDilation has only an unnecessary
import reduced; its two declarations were freshly audited.
When a supplemental audit follows a full audit, the unchanged source hashes
and disjoint theorem inventories are checked before combining the logs.

The earlier 392- and 399-theorem audits and their supplemental logs are
historical. They are not additional current theorem declarations and are
not a substitute for checking newly added proofs. A clean axiom audit does
not establish explicit hypotheses such as the remaining smoothing estimate.

The October 12 continuation restored Lean 4.19.0 from the official release
and Mathlib from the exact pinned commit, then fetched the official compiled
cache. The whole project was rebuilt. The current binary directory in this
runtime is /workspace/scratch/a640ed92ad81/lean-4.19.0-linux/bin. The current
shim is tools/proc-self-compat.so, rebuilt from the included C source.
