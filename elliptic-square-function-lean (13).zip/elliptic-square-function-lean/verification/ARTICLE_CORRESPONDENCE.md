# Statement correspondence with the supplied sfe(1).pdf

This is a source-level scope review of the supplied article and the checked
Lean endpoints. It does not verify the truth or original sources of the
three external propositions. Their mathematical content remains a premise.

| Article component | Lean statement or construction | Scope checked |
| --- | --- | --- |
| Theorem 1, graph estimate (1.3) | `article_main_theorem`, `ReverseSquareFunction` | Positive epsilon, every real R >= 2, arbitrary finite Schwartz families, prescribed square function. The constant precedes the scale, family size, centers and functions. |
| Graph hypotheses (1.1) | `GraphSetup`, `GraphHypotheses` | A compact parameter carrier with a smooth uniformly elliptic extension to an open neighborhood. |
| Graph caps (1.2) | `cap`, `AdmissibleFamily` | Planar Euclidean separation, tangential radius C0/sqrt(R), normal thickness C0/R. No prescribed partition or maximality premise is imposed on the input family. |
| External input 1 | `PlacementInput` | Fixed local affine graph placement, independent of scale and loss parameters. It remains an explicit hypothesis. In this PDF its reference is [5, Lemma 3.1]. |
| External input 2 (3.7) | `DiscreteDensityInput` | Finite arrays, dyadic N, integer time labels, retained terminal positions, normalization (D/N)^(-2), and N^(10*kappa+eta) log(2+N)^2. It is required for the actual constructed setup and remains a hypothesis. Its current PDF reference is [5, equation (4.10)]. |
| External input 3 (3.8) | `NikodymInput` | Unit-length maximal operator, Euclidean tube metric, positive radius less than one, L3 data, gamma-dependent constant. Length dilation is internal. Its current PDF reference is [6, Corollary 11.1]. |
| Compact surface part of Theorem 1 | `article_surface_theorem`, `compact_smooth_boundary_surface_estimate` | Euclidean three-space, actual Fourier integrals and Schwartz maps; compact smooth embedded Mathlib half-space boundary manifolds are covered without an extension or analyticity premise. |
| Surface caps (8.1) | `surfaceCap`, `EuclideanSurfaceEstimate` | Closed distance thickening of the carrier intersected with an open Euclidean base ball; thickness C0/R and base radius C0/sqrt(R). |
| Boundary extension in Section 8 | `smooth_halfspace_extension`, `halfspace_extensions_of_smooth` | Joint Frechet C-infinity extension. Neither bounded derivatives nor analyticity are premises. All mixed jets match, by `smooth_halfspace_extension_with_jets`. |
| Curvature and coordinates in Section 8 | `boundary_intrinsic_second_form_in_chart`, `boundary_chart_definite_second_form_iff` | Actual Mathlib tangent coordinate changes, all overlapping boundary charts, both signs of definiteness and independence of unit-normal choice. |
| Stronger compact-portion endpoint | `compact_smooth_boundary_portion_estimate_of_chart_curvature` | The ambient embedded manifold may be noncompact. Its chosen compact portion may have an irregular boundary. Curvature may be checked in any containing chart. |

The proof route still assigns whole caps to fixed charts instead of reproducing
every multiplier, partition and coloring step in Section 8. This is documented
in PROOF_STATUS.md and is not an additional hypothesis of the main estimate.

The tangent-fiber scalar and normal-valued forms and their boundary-chart
compatibility are proved. Smooth coordinate contractions are proved for smooth
local normal and vector fields. A separately bundled smooth tensor section and
construction of local smooth unit-normal fields are not claimed. Arbitrary
non-halfspace corner models retain the documented smooth-extension premise.

Verification: 1,000 theorem declarations in 244 modules. All 222 submitted
baseline modules remain unchanged. See AUDIT_PROVENANCE.json for the fresh,
disjoint audit runs and their exact source snapshots.
