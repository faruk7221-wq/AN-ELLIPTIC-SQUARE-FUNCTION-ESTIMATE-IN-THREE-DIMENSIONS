import EllipticSquareFunction.GlobalTimeTranslation

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- Uniform packet estimate on any translate of the unit time lattice. -/
def UniformTimeProfileBound (ι : Type*) (φ : Phase) (b : Plane → ℂ) (ψ : ℝ → ℂ)
    (c σ F M C P κ η : ℝ) : Prop :=
  ∀ j : ℕ, 1≤j → ∀ (T : Finset ℤ) (d : ℤ → FinitePacketArray ι),
    (∀ k ∈ T, SeparatedPacketArray (d k) ((2:ℝ)^j) c σ F) → ∀ s : ℝ,
    l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) φ b ψ ((2:ℝ)^j)
      (s+(k:ℝ)*((2:ℝ)^j)^2) y) volume ≤
    ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
      (∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
        arrayPacketDensity (d k) φ ((2:ℝ)^j) M (s+(k:ℝ)*((2:ℝ)^j)^2) y))^(3/2:ℝ))^(1/3:ℝ)

theorem uniform_time_profile_of_unit {ι : Type*} (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    (ψ : ℝ → ℂ) (hψ : Continuous ψ) (c σ F M C P κ η : ℝ)
    (h : ∀ j : ℕ, 1≤j → ∀ (T : Finset ℤ) (d : ℤ → FinitePacketArray ι),
      (∀ k ∈ T, SeparatedPacketArray (d k) ((2:ℝ)^j) c σ F) →
      l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) φ b ψ ((2:ℝ)^j) ((k:ℝ)*((2:ℝ)^j)^2) y) volume ≤
      ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
        (∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
          arrayPacketDensity (d k) φ ((2:ℝ)^j) M ((k:ℝ)*((2:ℝ)^j)^2) y))^(3/2:ℝ))^(1/3:ℝ)) :
    UniformTimeProfileBound ι φ b ψ c σ F M C P κ η := by
  intro j hj T d hd s
  exact translate_time_packet_estimate φ hφ b hb hbs ψ hψ (by positivity) T d M
    (C*packetConstant P κ η (((2:ℝ)^j)^2)) (h j hj T d hd) s

theorem uniform_finite_time_profiles {ι : Type*} {n : ℕ}
    (φ : Phase) (hφ : Continuous φ) (b : Fin n → Plane → ℂ)
    (hb : ∀ r, Continuous (b r)) (hbs : ∀ r, HasCompactSupport (b r))
    (ψ : Fin n → ℝ → ℂ) (hψ : ∀ r, Continuous (ψ r)) (c σ F M : ℝ)
    (hsingle : ∀ r, ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ,
      0<κ → κ<1/10 → 0<η → η≤1 → ∃ P : ℝ, 1≤P ∧
      UniformTimeProfileBound ι φ (b r) (ψ r) c σ F M C P κ η) :
    ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ (T : Fin n → Finset ℤ)
      (d : Fin n → ℤ → FinitePacketArray ι) (s : Fin n → ℝ),
      (∀ r, ∀ k ∈ T r, SeparatedPacketArray (d r k) ((2:ℝ)^j) c σ F) →
      l3 (fun y => ∑ r, ∑ k ∈ T r, arrayTimePacket (d r k) φ (b r) (ψ r)
        ((2:ℝ)^j) (s r+(k:ℝ)*((2:ℝ)^j)^2) y) volume ≤
      ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
        (∫⁻ y, (ENNReal.ofReal (∑ r, ∑ k ∈ T r,
          arrayPacketDensity (d r k) φ ((2:ℝ)^j) M (s r+(k:ℝ)*((2:ℝ)^j)^2) y))^(3/2:ℝ))^(1/3:ℝ) := by
  classical
  choose C hC hsingle using hsingle
  have hCsum : 0≤∑ r, C r := Finset.sum_nonneg (fun r _ => (hC r).le)
  refine ⟨(∑ r, C r)+1,by positivity,?_⟩
  intro κ η hκ hκ' hη hη'
  choose P hP hbound using fun r => hsingle r κ η hκ hκ' hη hη'
  let Pmax := 1+∑ r, P r
  have hPmax : 1≤Pmax := by
    have hh : 0≤∑ r, P r := Finset.sum_nonneg (fun r _ => by linarith [hP r])
    dsimp [Pmax]; linarith
  have hPP (r : Fin n) : P r≤Pmax := by
    have hh := Finset.single_le_sum (fun r (_ : r∈(Finset.univ : Finset (Fin n))) =>
      (show 0≤P r by linarith [hP r])) (Finset.mem_univ r)
    dsimp [Pmax]; linarith
  refine ⟨Pmax,hPmax,?_⟩
  intro j hj T d s hd
  let N : ℝ := (2:ℝ)^j
  have hN : N≠0 := by positivity
  have hK : 0≤packetConstant Pmax κ η (N^2) := packetConstant_nonneg_global (by linarith) κ η
  have hbnd (r : Fin n) := hbound r j hj (T r) (d r) (hd r) (s r)
  have hfamily (r : Fin n) :
      l3 (fun y => ∑ k ∈ T r, arrayTimePacket (d r k) φ (b r) (ψ r) N (s r+(k:ℝ)*N^2) y) volume ≤
        ENNReal.ofReal (C r*packetConstant Pmax κ η (N^2))*
          (∫⁻ y, (ENNReal.ofReal (∑ k ∈ T r,
            arrayPacketDensity (d r k) φ N M (s r+(k:ℝ)*N^2) y))^(3/2:ℝ))^(1/3:ℝ) := by
    apply (hbnd r).trans
    apply mul_le_mul_right'
    exact ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_left
      (packetConstant_mono_parameter (by linarith [hP r]) (hPP r) κ η) (hC r).le)
  have hh := global_finite_profile_bound Finset.univ
    (fun r y => ∑ k ∈ T r, arrayTimePacket (d r k) φ (b r) (ψ r) N (s r+(k:ℝ)*N^2) y)
    (fun r y => ∑ k ∈ T r, arrayPacketDensity (d r k) φ N M (s r+(k:ℝ)*N^2) y)
    C (packetConstant Pmax κ η (N^2))
    (fun r _ => continuous_finset_sum (T r) (fun k _ =>
      continuous_arrayTimePacket (d r k) φ hφ (b r) (hb r) (hbs r) (ψ r) (hψ r) hN _))
    (fun r _ y => Finset.sum_nonneg (fun k _ => arrayPacketDensity_nonneg ..))
    (fun r _ => (hC r).le) hK (fun r _ => hfamily r)
  apply hh.trans
  apply mul_le_mul_right'
  exact ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right (by linarith) hK)

/-- Proposition 3 for a fixed setup, with finitely many profiles and arbitrary
translates of the time lattice. Spatial arrays may vary with both profile and
time origin. Finite unions of translated lattices include fixed oversampling. -/
theorem proposition_three_fixed_setup {ι : Type*} {n : ℕ}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Fin n → Plane → ℂ) (hb : ∀ r, ContDiff ℝ (⊤ : ℕ∞) (b r))
    (hbs : ∀ r, HasCompactSupport (b r)) (ψ : Fin n → SchwartzMap ℝ ℂ)
    {c σ F M : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M) (hQ₂ : 3≤S.C₂) :
    ∃ Z A : Fin n → ℝ, (∀ r, 0<Z r) ∧ (∀ r, 1≤A r) ∧ ((∀ r, A r+1≤S.C₁) →
      ∃ Z' : Fin n → ℝ, (∀ r, 0<Z' r) ∧ ((∀ r, F+Z r+Z' r≤S.frequencyBound) →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
          ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ (T : Fin n → Finset ℤ)
          (d : Fin n → ℤ → FinitePacketArray ι) (s : Fin n → ℝ),
          (∀ r, ∀ k ∈ T r, SeparatedPacketArray (d r k) ((2:ℝ)^j) c σ F) →
          l3 (fun y => ∑ r, ∑ k ∈ T r, arrayTimePacket (d r k) S.φ (b r) (ψ r)
            ((2:ℝ)^j) (s r+(k:ℝ)*((2:ℝ)^j)^2) y) volume ≤
          ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
            (∫⁻ y, (ENNReal.ofReal (∑ r, ∑ k ∈ T r,
              arrayPacketDensity (d r k) S.φ ((2:ℝ)^j) M (s r+(k:ℝ)*((2:ℝ)^j)^2) y))^(3/2:ℝ))^(1/3:ℝ))) := by
  classical
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  have hs (r : Fin n) := proposition_three_unit_fixed_setup (ι := ι)
    S hphase hinput (b r) (hb r) (hbs r) (ψ r) hc hσ hF hM hQ₂
  choose Z A hZ hA hs using hs
  refine ⟨Z,A,hZ,hA,?_⟩
  intro hA₁
  choose Z' hZ' hs using fun r => hs r (hA₁ r)
  refine ⟨Z',hZ',?_⟩
  intro hFZ
  apply uniform_finite_time_profiles S.φ hφ.continuous b (fun r => (hb r).continuous) hbs
    (fun r => (ψ r : ℝ → ℂ)) (fun r => (ψ r).continuous) c σ F M
  intro r
  obtain ⟨C,hC,hbound⟩ := hs r (hFZ r)
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  exact ⟨P,hP,uniform_time_profile_of_unit S.φ hφ.continuous (b r) (hb r).continuous
    (hbs r) (ψ r) (ψ r).continuous c σ F M C P κ η hbound⟩

end EllipticSquareFunction
