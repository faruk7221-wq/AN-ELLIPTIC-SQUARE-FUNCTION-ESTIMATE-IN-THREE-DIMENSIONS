import EllipticSquareFunction.LocalDiscreteProof
import EllipticSquareFunction.CubicNorm

/-! # Corrected equation (4.9)

The left norm is restricted to a bounded spatial region. The core-density
factor integrates over the whole plane. This theorem assumes only the
article's stated discrete-density input and the fixed geometric setup.
It does not prove the profile estimate (4.14) or the article's main theorem.
-/

noncomputable section
open MeasureTheory Set
open scoped ENNReal
namespace EllipticSquareFunction

/-- Corrected (4.9) for any spatial region inside the fixed radius `A N²`.
The condition `A+1 ≤ C₂` ensures that the retained terminal labels lie in
the position region of the external input. The constant is independent of
the loss parameters, scale, initial labels, coefficients, and region. -/
theorem corrected_equation_4_9 (S : DiscreteSetup)
    (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (A : ℝ) (hA : A+1 ≤ S.C₂) :
    ∃ C : ℝ, 0 < C ∧ ∀ κ η : ℝ, 0 < κ → κ < 1/10 → 0 < η → η ≤ 1 →
      ∃ P : ℝ, 1 ≤ P ∧ ∀ j : ℕ, 1 ≤ j →
        let N : ℝ := (2 : ℝ)^j
        ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ), discreteLabelsAllowed S N s →
        ∀ Q : Set Plane, Q ⊆ Metric.closedBall (0 : Plane) (A*N^2) →
          LocalDiscreteEstimate S N P κ η C s d Q := by
  obtain ⟨C, hC, hc⟩ := local_discrete_cubed_of_external S hphase hinput A hA
  let B := localLossAbsorptionConstant
  have hB : 0 < B := localLossAbsorptionConstant_pos
  have hCB : 0 < C*B := mul_pos hC hB
  have hcube : C*B ≤ (C*B+1)^3 := by
    nlinarith [sq_nonneg (C*B), pow_nonneg hCB.le 3]
  refine ⟨C*B+1, by positivity, ?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P, hP, hp⟩ := hc κ η hκ hκ' hη hη'
  refine ⟨P, hP, ?_⟩
  intro j hj N s d hs Q hQ
  have hN : 1 ≤ N := one_le_pow₀ (by norm_num)
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨ρ, ζ, hρ, hρ', hζ, hsupp, hζb, hζone, hζs, hform, hφ, hrest⟩
    exact hφ
  let T := Metric.closedBall (0 : Plane) (A*N^2) ×ˢ Icc 0 (N^2)
  let D := ∫ y : Space, (discreteCoreDensity S N s d y)^(3/2 : ℝ)
  let p := packetConstant P κ η (N^2)
  have hD : 0 ≤ D := integral_nonneg (fun y => Real.rpow_nonneg
    (coreDensity_nonneg s d _ _ N (N^2) y) _)
  have hp0 : 0 ≤ p := by
    have hP0 : 0 ≤ P := by linarith
    have hl : 0 ≤ Real.log (2+N^2) := Real.log_nonneg (by nlinarith [sq_nonneg N])
    dsimp [p, packetConstant]
    positivity
  have hF : IntegrableOn (fun y => ‖discreteExtension S N s d y‖^3) T volume :=
    ContinuousOn.integrableOn_compact ((isCompact_closedBall _ _).prod isCompact_Icc)
      ((continuous_discreteExtension S hφ.continuous hN s d hs).norm.pow 3).continuousOn
  have hbound : (∫ y in T, ‖discreteExtension S N s d y‖^3) ≤ ((C*B+1)*p)^3*D := by
    calc
      _ ≤ C*(P*N^(10*κ+η)*Real.log (2+N)^2+1)*D := hp j hj s d hs
      _ ≤ C*(B*p^3)*D := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (local_loss_absorption hP hN hκ.le hη.le) hC.le) hD
      _ = C*B*(p^3*D) := by ring
      _ ≤ (C*B+1)^3*(p^3*D) := mul_le_mul_of_nonneg_right hcube (by positivity)
      _ = _ := by ring
  have hl3 := l3_le_of_cubic_integral (volume.restrict T) (discreteExtension S N s d) hF
    (mul_nonneg (by positivity) hp0) hbound
  rw [← discrete_densityCubeRoot_eq_integral S N s d] at hl3
  apply le_trans _ hl3
  apply eLpNorm_mono_measure
  apply Measure.restrict_mono _ le_rfl
  intro y hy
  exact ⟨hQ hy.1, hy.2⟩

end EllipticSquareFunction
