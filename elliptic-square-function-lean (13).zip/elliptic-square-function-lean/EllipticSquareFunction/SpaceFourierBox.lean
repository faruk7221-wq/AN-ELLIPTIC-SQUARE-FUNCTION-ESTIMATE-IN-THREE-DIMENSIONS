import EllipticSquareFunction.CurvedMultiplier

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

/-- Time is coordinate zero, followed by the two Euclidean spatial coordinates. -/
def spaceCoordinateEquiv : (Fin 3 → ℝ) ≃ᵐ Space :=
  ((MeasurableEquiv.piFinSuccAbove (fun _ : Fin 3 => ℝ) 0).trans
    MeasurableEquiv.prodComm).trans
    ((EuclideanSpace.measurableEquiv (Fin 2)).symm.prodCongr (MeasurableEquiv.refl ℝ))

theorem spaceCoordinateEquiv_apply (z : Fin 3 → ℝ) :
    spaceCoordinateEquiv z =
      ((WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => z i.succ),z 0) := by
  simp [spaceCoordinateEquiv,MeasurableEquiv.piFinSuccAbove_apply,Fin.succAbove_zero]
  rfl

theorem continuous_spaceCoordinateEquiv : Continuous spaceCoordinateEquiv := by
  change Continuous (fun z => spaceCoordinateEquiv z)
  simp_rw [spaceCoordinateEquiv_apply]
  exact ((PiLp.continuous_equiv_symm 2 _).comp
    (continuous_pi (fun i => continuous_apply i.succ))).prodMk (continuous_apply 0)

theorem measurePreserving_spaceCoordinateEquiv : MeasurePreserving spaceCoordinateEquiv := by
  have hp := (EuclideanSpace.volume_preserving_measurableEquiv (Fin 2)).symm
    (EuclideanSpace.measurableEquiv (Fin 2))
  exact (hp.prod (MeasurePreserving.id volume)).comp
    (Measure.measurePreserving_swap.comp
      (volume_preserving_piFinSuccAbove (fun _ : Fin 3 => ℝ) 0))

theorem integral_space_coordinates (f : Space → ℂ) :
    (∫ z : Fin 3 → ℝ, f (spaceCoordinateEquiv z))=∫ ζ : Space, f ζ :=
  measurePreserving_spaceCoordinateEquiv.integral_comp' f

def spaceBox (a : Fin 3 → ℝ) (D : ℝ) : Set Space :=
  spaceCoordinateEquiv '' scaledBox a D

def spaceFrequencyLattice (D : ℝ) (n : Fin 3 → ℤ) : Space :=
  (latticePoint D⁻¹ (fun i => n i.succ),D⁻¹*(n 0:ℝ))

theorem spaceBox_character (D : ℝ) (n : Fin 3 → ℤ) (z : Fin 3 → ℝ) :
    scaledBoxCharacter D n z =
      oscillation (@inner ℝ Plane _ (spaceFrequencyLattice D n).1
        (spaceCoordinateEquiv z).1+(spaceFrequencyLattice D n).2*(spaceCoordinateEquiv z).2) := by
  rw [spaceCoordinateEquiv_apply]
  unfold scaledBoxCharacter boxCharacter spaceFrequencyLattice
  congr 1
  simp only [Pi.smul_apply,smul_eq_mul,PiLp.inner_apply,latticePoint,
    WithLp.equiv_symm_pi_apply,RCLike.inner_apply,conj_trivial]
  rw [Fin.sum_univ_succ]
  simp only [mul_assoc,mul_comm,mul_left_comm,add_comm]

/-- Exact three-dimensional bilinear Fourier reconstruction in Space.
The series has coefficient D⁻³ and is a genuine HasSum statement. -/
theorem space_box_reconstruction (a : Fin 3 → ℝ) {D : ℝ} (hD : 0<D)
    {f g : Space → ℂ} (hf : Continuous f) (hg : Continuous g)
    (hfs : Function.support f ⊆ spaceBox a D)
    (hgs : Function.support g ⊆ spaceBox a D) :
    HasSum (fun n : Fin 3 → ℤ => ((D^3)⁻¹:ℝ) •
      (inverseSpaceTransform f (spaceFrequencyLattice D n)*
        inverseSpaceTransform g (spaceFrequencyLattice D (-n))))
      (∫ ζ : Space, f ζ*g ζ) := by
  have hs (F : Space → ℂ) (hF : Function.support F ⊆ spaceBox a D) :
      Function.support (fun z => F (spaceCoordinateEquiv z)) ⊆ scaledBox a D := by
    intro z hz
    obtain ⟨x,hx,he⟩ := hF hz
    exact spaceCoordinateEquiv.injective he ▸ hx
  have hh := supported_box_bilinear_reconstruction a hD
    (hf.comp continuous_spaceCoordinateEquiv) (hg.comp continuous_spaceCoordinateEquiv)
    (hs f hfs) (hs g hgs)
  have hc (F : Space → ℂ) (n : Fin 3 → ℤ) :
      (∫ z, F (spaceCoordinateEquiv z)*scaledBoxCharacter D n z)=
        inverseSpaceTransform F (spaceFrequencyLattice D n) := by
    simp_rw [spaceBox_character]
    exact integral_space_coordinates (fun ζ => F ζ*oscillation
      (@inner ℝ Plane _ (spaceFrequencyLattice D n).1 ζ.1+(spaceFrequencyLattice D n).2*ζ.2))
  have he : (∫ z, f (spaceCoordinateEquiv z)*g (spaceCoordinateEquiv z))=
      ∫ ζ : Space, f ζ*g ζ := integral_space_coordinates (fun ζ => f ζ*g ζ)
  simpa only [Function.comp_apply,Fintype.card_fin,hc,he] using hh

end EllipticSquareFunction
