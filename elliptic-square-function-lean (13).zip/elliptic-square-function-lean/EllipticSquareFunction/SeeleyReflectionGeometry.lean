import EllipticSquareFunction.SeeleyParameterSeries

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

variable {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]

def seeleyReflection (k : ℕ) : (ℝ × X) →L[ℝ] (ℝ × X) :=
  ((seeleyNode k) • ContinuousLinearMap.fst ℝ ℝ X).prod (ContinuousLinearMap.snd ℝ ℝ X)

theorem seeley_reflection_apply (k : ℕ) (p : ℝ × X) :
    seeleyReflection k p = (seeleyNode k*p.1,p.2) := rfl

theorem seeley_reflection_norm_apply (k : ℕ) (p : ℝ × X) :
    ‖seeleyReflection k p‖ ≤ (2 : ℝ)^k * ‖p‖ := by
  rw [seeley_reflection_apply,Prod.norm_def]
  apply max_le
  · rw [norm_mul,Real.norm_eq_abs,show |seeleyNode k| = (2 : ℝ)^k by simp [seeleyNode]]
    exact mul_le_mul_of_nonneg_left (norm_fst_le p) (by positivity)
  · exact (norm_snd_le p).trans (le_mul_of_one_le_left (norm_nonneg p)
      (one_le_pow₀ (by norm_num)))

theorem seeley_reflection_norm (k : ℕ) :
    ‖(seeleyReflection k : (ℝ × X) →L[ℝ] (ℝ × X))‖ ≤ (2 : ℝ)^k :=
  ContinuousLinearMap.opNorm_le_bound _ (by positivity) (seeley_reflection_norm_apply k)

/-- The same weighted majorant controls every multilinear derivative after
reflection, once a bound for the original derivative has been established. -/
theorem seeley_reflection_multilinear_bound {E : Type*} [NormedAddCommGroup E]
    [NormedSpace ℝ E] (k m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) :
    ‖A.compContinuousLinearMap (fun _ => seeleyReflection k)‖ ≤
      ‖A‖ * (2 : ℝ)^(k*m) := by
  apply (ContinuousMultilinearMap.norm_compContinuousLinearMap_le _ _).trans
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg A)
  calc
    _ ≤ ∏ _ : Fin m, (2 : ℝ)^k := Finset.prod_le_prod
      (fun _ _ => norm_nonneg _) (fun _ _ => seeley_reflection_norm k)
    _ = _ := by simp [pow_mul]

end EllipticSquareFunction
