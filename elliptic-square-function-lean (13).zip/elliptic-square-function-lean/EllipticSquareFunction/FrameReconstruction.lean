import EllipticSquareFunction.FourierSeries
import EllipticSquareFunction.ExternalInputs

/-! # Euclidean box and window reconstruction

The normalization and convergence of the Fourier frame are proved using
bilinear L² reconstruction, before imposing any oscillatory decay estimates.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

theorem continuous_oscillation : Continuous oscillation := by
  unfold oscillation
  fun_prop

theorem oscillation_add (s t : ℝ) : oscillation (s + t) = oscillation s * oscillation t := by
  unfold oscillation
  rw [← Complex.exp_add]
  congr 1
  push_cast
  ring

theorem norm_oscillation (t : ℝ) : ‖oscillation t‖ = 1 := by
  rw [oscillation, Complex.norm_exp]
  simp

def euclideanBox {d : Type*} [Fintype d] (a : d → ℝ) (D : ℝ) : Set (EuclideanSpace ℝ d) :=
  (WithLp.equiv 2 (d → ℝ)) ⁻¹' scaledBox a D

def frequencyLattice {d : Type*} [Fintype d] (c : ℝ) (n : d → ℤ) : EuclideanSpace ℝ d :=
  (WithLp.equiv 2 (d → ℝ)).symm (fun i => c * (n i : ℝ))

theorem integral_euclidean_coordinates {d : Type*} [Fintype d]
    (f : EuclideanSpace ℝ d → ℂ) :
    (∫ x : d → ℝ, f ((WithLp.equiv 2 (d → ℝ)).symm x)) = ∫ ξ, f ξ :=
  (MeasurePreserving.symm (EuclideanSpace.measurableEquiv d)
    (EuclideanSpace.volume_preserving_measurableEquiv d)).integral_comp' f

theorem boxCharacter_eq_oscillation_inner {d : Type*} [Fintype d] (D : ℝ)
    (n : d → ℤ) (x : d → ℝ) :
    scaledBoxCharacter D n x =
      oscillation (@inner ℝ (EuclideanSpace ℝ d) _ (frequencyLattice D⁻¹ n)
        ((WithLp.equiv 2 (d → ℝ)).symm x)) := by
  unfold scaledBoxCharacter boxCharacter
  congr 1
  simp only [PiLp.inner_apply, frequencyLattice, WithLp.equiv_symm_pi_apply,
    RCLike.inner_apply, conj_trivial, Pi.smul_apply, smul_eq_mul]
  apply Finset.sum_congr rfl
  intro i _
  ring

/-- An exact, convergent Fourier reconstruction identity on a Euclidean box.
For dimension two the coefficient is precisely `D⁻²`, as in (4.5). -/
theorem euclidean_box_reconstruction {d : Type*} [Fintype d]
    (a : d → ℝ) {D : ℝ} (hD : 0 < D) {f g : EuclideanSpace ℝ d → ℂ}
    (hf : Continuous f) (hg : Continuous g)
    (hfs : Function.support f ⊆ euclideanBox a D)
    (hgs : Function.support g ⊆ euclideanBox a D) :
    HasSum (fun n : d → ℤ => ((D ^ Fintype.card d)⁻¹ : ℝ) •
      ((∫ ξ, f ξ * oscillation (@inner ℝ (EuclideanSpace ℝ d) _ (frequencyLattice D⁻¹ n) ξ)) *
       (∫ ξ, g ξ * oscillation (@inner ℝ (EuclideanSpace ℝ d) _ (frequencyLattice D⁻¹ (-n)) ξ))))
      (∫ ξ, f ξ * g ξ) := by
  let e := (WithLp.equiv 2 (d → ℝ)).symm
  have hfe : Continuous (fun x => f (e x)) := hf.comp (PiLp.continuous_equiv_symm 2 _)
  have hge : Continuous (fun x => g (e x)) := hg.comp (PiLp.continuous_equiv_symm 2 _)
  have hs (F : EuclideanSpace ℝ d → ℂ) (hF : Function.support F ⊆ euclideanBox a D) :
      Function.support (fun x => F (e x)) ⊆ scaledBox a D := by
    intro x hx
    simpa only [euclideanBox, mem_preimage, e, Equiv.apply_symm_apply] using hF hx
  have h := supported_box_bilinear_reconstruction a hD hfe hge (hs f hfs) (hs g hgs)
  have hc (F : EuclideanSpace ℝ d → ℂ) (n : d → ℤ) :
      (∫ x, F (e x) * scaledBoxCharacter D n x) =
        ∫ ξ, F ξ * oscillation (@inner ℝ (EuclideanSpace ℝ d) _ (frequencyLattice D⁻¹ n) ξ) := by
    simp_rw [boxCharacter_eq_oscillation_inner]
    exact integral_euclidean_coordinates (fun ξ => F ξ *
      oscillation (@inner ℝ (EuclideanSpace ℝ d) _ (frequencyLattice D⁻¹ n) ξ))
  have he : (∫ x, f (e x) * g (e x)) = ∫ ξ, f ξ * g ξ :=
    integral_euclidean_coordinates (fun ξ => f ξ * g ξ)
  simpa only [hc, he] using h

theorem frequencyLattice_neg {d : Type*} [Fintype d] (c : ℝ) (n : d → ℤ) :
    frequencyLattice c (-n) = -frequencyLattice c n := by
  ext i
  simp [frequencyLattice]

def windowCoefficient (φ : Phase) (g : Plane → ℂ) (χ : Plane → ℝ) (w : Plane) (j : ℝ) : ℂ :=
  ∫ ξ, g ξ * (χ ξ : ℂ) * oscillation (@inner ℝ Plane _ w ξ + j * φ ξ)

def windowKernel (φ : Phase) (χ : Plane → ℝ) (z : Plane) (u : ℝ) : ℂ :=
  ∫ ξ, (χ ξ : ℂ) * oscillation (@inner ℝ Plane _ z ξ + u * φ ξ)

/-- The exact single-window synthesis identity used in Section 4.1.
The time labels `j,u` are arbitrary real numbers. -/
theorem window_reconstruction (φ : Phase) (hφ : Continuous φ)
    (g : Plane → ℂ) (hg : Continuous g) (χ : Plane → ℝ) (hχ : Continuous χ)
    (a : Fin 2 → ℝ) {D : ℝ} (hD : 0 < D)
    (hχs : Function.support χ ⊆ euclideanBox a D) (x : Plane) (j u : ℝ) :
    HasSum (fun n : IntPlane => ((D ^ 2)⁻¹ : ℝ) •
      (windowCoefficient φ g χ (latticePoint D⁻¹ n) j *
        windowKernel φ χ (x - latticePoint D⁻¹ n) u))
      (∫ ξ, g ξ * (χ ξ : ℂ) ^ 2 * oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ)) := by
  let F := fun ξ => g ξ * (χ ξ : ℂ) * oscillation (j * φ ξ)
  let G := fun ξ => (χ ξ : ℂ) * oscillation (@inner ℝ Plane _ x ξ + u * φ ξ)
  have hF : Continuous F := by
    unfold F
    exact (hg.mul (Complex.continuous_ofReal.comp hχ)).mul
      (continuous_oscillation.comp (continuous_const.mul hφ))
  have hG : Continuous G := by
    unfold G
    apply (Complex.continuous_ofReal.comp hχ).mul
    apply continuous_oscillation.comp
    exact (continuous_const.inner continuous_id).add (continuous_const.mul hφ)
  have hFs : Function.support F ⊆ euclideanBox a D := by
    intro ξ hξ
    apply hχs
    change χ ξ ≠ 0
    intro hz
    exact hξ (by simp [F, hz])
  have hGs : Function.support G ⊆ euclideanBox a D := by
    intro ξ hξ
    apply hχs
    change χ ξ ≠ 0
    intro hz
    exact hξ (by simp [G, hz])
  have h := euclidean_box_reconstruction a hD hF hG hFs hGs
  have hc (n : IntPlane) : (∫ ξ, F ξ * oscillation (@inner ℝ Plane _ (frequencyLattice D⁻¹ n) ξ)) =
      windowCoefficient φ g χ (latticePoint D⁻¹ n) j := by
    apply integral_congr_ae
    filter_upwards with ξ
    dsimp only [F]
    rw [mul_assoc, ← oscillation_add]
    congr 2
    exact add_comm _ _
  have hk (n : IntPlane) : (∫ ξ, G ξ * oscillation (@inner ℝ Plane _ (frequencyLattice D⁻¹ (-n)) ξ)) =
      windowKernel φ χ (x - latticePoint D⁻¹ n) u := by
    apply integral_congr_ae
    filter_upwards with ξ
    dsimp only [G]
    rw [mul_assoc, ← oscillation_add, frequencyLattice_neg, inner_neg_left, inner_sub_left]
    congr 2
    change @inner ℝ Plane _ x ξ + u * φ ξ + -@inner ℝ Plane _ (latticePoint D⁻¹ n) ξ = _
    ring
  have he : (∫ ξ, F ξ * G ξ) =
      ∫ ξ, g ξ * (χ ξ : ℂ) ^ 2 * oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ) := by
    apply integral_congr_ae
    filter_upwards with ξ
    dsimp only [F, G]
    have hp : @inner ℝ Plane _ x ξ + (j + u) * φ ξ =
        j * φ ξ + (@inner ℝ Plane _ x ξ + u * φ ξ) := by ring
    simp only [hp, oscillation_add]
    ring
  simpa only [Fintype.card_fin, hc, hk, he] using h

/-- Finite-window synthesis, using a square partition on the support of the
datum. This proves the extension identity following (4.5), with convergence
of the series over the entire terminal spatial lattice. -/
theorem finite_window_reconstruction {ι : Type*} (s : Finset ι)
    (φ : Phase) (hφ : Continuous φ) (g : Plane → ℂ)
    (hg : Continuous g) (hgs : HasCompactSupport g)
    (χ : ι → Plane → ℝ) (hχ : ∀ i ∈ s, Continuous (χ i))
    (a : ι → Fin 2 → ℝ) {D : ℝ} (hD : 0 < D)
    (hχs : ∀ i ∈ s, Function.support (χ i) ⊆ euclideanBox (a i) D)
    (hpartition : ∀ ξ ∈ Function.support g, ∑ i ∈ s, (χ i ξ) ^ 2 = 1)
    (x : Plane) (j u : ℝ) :
    HasSum (fun n : IntPlane => ∑ i ∈ s, ((D ^ 2)⁻¹ : ℝ) •
      (windowCoefficient φ g (χ i) (latticePoint D⁻¹ n) j *
        windowKernel φ (χ i) (x - latticePoint D⁻¹ n) u))
      (∫ ξ, g ξ * oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ)) := by
  have h := hasSum_sum (fun i hi =>
    window_reconstruction φ hφ g hg (χ i) (hχ i hi) (a i) hD (hχs i hi) x j u)
  have ho : Continuous (fun ξ => oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ)) :=
    continuous_oscillation.comp
      ((continuous_const.inner continuous_id).add (continuous_const.mul hφ))
  have hi (i : ι) (hi : i ∈ s) : Integrable (fun ξ =>
      g ξ * (χ i ξ : ℂ) ^ 2 * oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ)) :=
    ((hg.mul ((Complex.continuous_ofReal.comp (hχ i hi)).pow 2)).mul ho).integrable_of_hasCompactSupport
      (hgs.mul_right.mul_right)
  have he : (∑ i ∈ s, ∫ ξ, g ξ * (χ i ξ : ℂ) ^ 2 *
      oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ)) =
      ∫ ξ, g ξ * oscillation (@inner ℝ Plane _ x ξ + (j + u) * φ ξ) := by
    rw [← integral_finset_sum s hi]
    apply integral_congr_ae
    filter_upwards with ξ
    rw [← Finset.sum_mul, ← Finset.mul_sum]
    by_cases hz : g ξ = 0
    · simp [hz]
    · have hp : (∑ i ∈ s, (χ i ξ : ℂ) ^ 2) = 1 := by
        exact_mod_cast hpartition ξ hz
      rw [hp, mul_one]
  exact he ▸ h

end EllipticSquareFunction
