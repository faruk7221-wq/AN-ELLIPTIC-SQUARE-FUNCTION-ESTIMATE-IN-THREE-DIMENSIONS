import EllipticSquareFunction.SeparatedFrame
import EllipticSquareFunction.BoundedProfile

/-! # Bounded profiles with independently separated position families -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

def separatedProfileCountConstant (c σ F A : ℝ) : ℝ :=
  (2*((5/σ)*F+4)+3)^2 * (2*((5/c)*A+4)+3)^2

theorem separated_position_card_bound (pbox : Finset IntPlane) (v : IntPlane → Plane)
    {N c A : ℝ} (hN : 1≤N) (hc : 0<c) (hA : 0≤A)
    (hv : ∀ p ∈ pbox, ‖v p‖≤A*N^2)
    (hsep : ∀ p ∈ pbox, ∀ q ∈ pbox, p≠q → c*N≤‖v p-v q‖) :
    (pbox.card : ℝ) ≤ (2*((5/c)*A+4)+3)^2*N^2 := by
  have hN0 : 0<N := by linarith
  have hs : ∀ p ∈ pbox, ∀ q ∈ pbox, p≠q → c≤‖N⁻¹ • v p-N⁻¹ • v q‖ := by
    intro p hp q hq hpq
    rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN0)]
    have hh := mul_le_mul_of_nonneg_left (hsep p hp q hq hpq) (inv_pos.mpr hN0).le
    have he : N⁻¹*(c*N)=c := by field_simp
    rwa [he] at hh
  have hv' : ∀ p ∈ pbox, ‖N⁻¹ • v p-(0:Plane)‖≤A*N := by
    intro p hp
    rw [sub_zero,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN0)]
    have hh := mul_le_mul_of_nonneg_left (hv p hp) (inv_pos.mpr hN0).le
    convert hh using 1 <;> field_simp <;> ring
  have hh := separated_plane_card_bound pbox (fun p => N⁻¹ • v p) hc 0 hs hv'
  have hh' : (pbox.card : ℝ) ≤ (integerPlaneBox ⌈(5/c)*(A*N)+4⌉₊).card := by exact_mod_cast hh
  apply hh'.trans
  convert integerPlaneBox_card_affine_scale (B := (5/c)*A) (T := 4) (by positivity) (by norm_num) hN using 1 <;> ring

theorem separatedProfiles_l1_cubed_bound {ι : Type*} (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane)
    {N c σ F A : ℝ} (hN : 1≤N) (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hA : 0≤A)
    (hν : ∀ i ∈ s, ‖ν i‖≤F)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → σ/N≤‖ν i-ν j‖)
    (hpositions : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hv : ∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖≤A*N^2) :
    (∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖)^3 ≤
      (separatedProfileCountConstant c σ F A)^2*N^8 * ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖^3 := by
  have hf := separated_frequency_card_bound s ν hN hσ hF hν hsep
  have hp (i : ι) (hi : i ∈ s) := separated_position_card_bound (pbox i) (v i)
    hN hc hA (hv i hi) (hpositions i hi)
  have hcard : ((s.sigma pbox).card : ℝ) ≤ separatedProfileCountConstant c σ F A*N^4 := by
    rw [Finset.card_sigma,Nat.cast_sum]
    calc
      _ ≤ ∑ _i ∈ s, (2*((5/c)*A+4)+3)^2*N^2 := Finset.sum_le_sum hp
      _ = (s.card : ℝ)*((2*((5/c)*A+4)+3)^2*N^2) := by simp
      _ ≤ _ := by
        convert mul_le_mul_of_nonneg_right hf (by positivity : 0≤(2*((5/c)*A+4)+3)^2*N^2) using 1
        dsimp [separatedProfileCountConstant]; ring
  have hh := weighted_cubic_holder (s.sigma pbox) (fun _ => (1:ℝ)) (fun ip => ‖a ip.1 ip.2‖)
    (by intros; norm_num) (by intros; positivity)
  simp only [one_mul,Finset.sum_const,nsmul_eq_mul,mul_one,Finset.sum_sigma] at hh
  apply hh.trans
  have hh' := pow_le_pow_left₀ (by positivity : 0≤((s.sigma pbox).card:ℝ)) hcard 2
  have hsum : 0≤∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖^3 :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => by positivity))
  convert mul_le_mul_of_nonneg_right hh' hsum using 1 <;> ring

theorem separated_frame_integrated_density {ι : Type*}
    (S : DiscreteSetup) (hφ : ContinuedPhase S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ : ℝ} (hc : 0 < c) (hσ : 0 < σ) (L : ℕ) (hL : 2 < L) :
    ∃ B : ℝ, 0 < B ∧ ∀ {N : ℝ}, 0 < N →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (q nbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖) →
      (∫ y : Space, (discreteCoreDensity S N (q ×ˢ nbox)
        (separatedProfileCoefficient S b N s pbox a ν v) y)^(3/2 : ℝ)) ≤
      B * ∫ y : Space in spatialSlab (N^2),
        (spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2)
          N (L : ℝ) y)^(3/2 : ℝ) := by
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨B,hB,ht⟩ := separated_fine_frame_density_transport (ι := ι) hφ b hb hbs S.χ
    S.χ_smooth S.χ_compact hc (inv_pos.mpr hD) hσ L hL
  refine ⟨B^(3/2 : ℝ), Real.rpow_pos_of_pos hB _, ?_⟩
  intro N hN s pbox q nbox a ν v hpositions hsep
  let d := separatedProfileCoefficient S b N s pbox a ν v
  let H := spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N (L : ℝ)
  have he (n : IntPlane) : N • latticePoint (S.D : ℝ)⁻¹ n = latticePoint (N/S.D) n := by
    rw [← latticePoint_mul, div_eq_mul_inv]
  have hp (y : Space) : (discreteCoreDensity S N (q ×ˢ nbox) d y)^(3/2 : ℝ) ≤
      B^(3/2 : ℝ) * (H y)^(3/2 : ℝ) := by
    have hh := ht hN s pbox q nbox a ν v hpositions hsep y
    simp only [he] at hh
    have hn : 0 ≤ discreteCoreDensity S N (q ×ˢ nbox) d y := coreDensity_nonneg (q ×ˢ nbox) d _ _ N (N^2) y
    have hm := Real.rpow_le_rpow hn hh (by norm_num : (0 : ℝ) ≤ 3/2)
    have hH : 0 ≤ H y := Finset.sum_nonneg (fun k hk =>
      mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
    rw [Real.mul_rpow hB.le hH] at hm
    exact hm
  have hi := coreDensity_integrable_rpow (q ×ˢ nbox) d
    (fun k => velocity S.φ (latticePoint N⁻¹ k.1)) (fun k => latticePoint (N/S.D) k.2) N (N^2)
  have hLr : (2 : ℝ) < L := by exact_mod_cast hL
  have hiH := spatialDensity_integrable_rpow_on_slab (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2)
    hN.ne' (by nlinarith : (2 : ℝ) < (L : ℝ)*(3/2)) (N^2)
  have hh := integral_mono hi.restrict (hiH.const_mul (B^(3/2 : ℝ))) hp
  rw [integral_const_mul, setIntegral_eq_integral_of_forall_compl_eq_zero] at hh
  · exact hh
  · intro y hy
    change (discreteCoreDensity S N (q ×ˢ nbox) d y)^(3/2 : ℝ) = 0
    rw [show discreteCoreDensity S N (q ×ˢ nbox) d y = 0 from
      coreDensity_eq_zero_off_slab (q ×ˢ nbox) d _ _ N (N^2) hy]
    norm_num

theorem separated_remainder_absorbed {ι : Type*} (φ : Phase)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) {N c σ F A Q B M : ℝ}
    (hN : 1 ≤ N) (hc : 0 < c) (hσ : 0 < σ) (hF : 0 ≤ F) (hA : 0 ≤ A)
    (hQ : 0 ≤ Q) (hB : 0 ≤ B) (hM : 2 < M*(3/2))
    (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖)
    (hpositions : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hv : ∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖ ≤ A*N^2)
    (E : Space → ℂ)
    (hE : ∀ y, ‖E y‖ ≤ B*(1+N)^(-(4:ℝ))*(∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖)) :
    (∫ y in Metric.closedBall (0 : Plane) (Q*N^2) ×ˢ Icc 0 (N^2), ‖E y‖^3) ≤
      (Real.pi * Q^2 * B^3 * (separatedProfileCountConstant c σ F A)^2 /
        (Real.pi * (2 : ℝ)^(-(M*(3/2))))) *
      ∫ y : Space in spatialSlab (N^2),
        (spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y)^(3/2 : ℝ) := by
  have hN0 : 0<N := by linarith
  let H := ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖
  let J := ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖^3
  let K := separatedProfileCountConstant c σ F A
  let t := (1+N)^(-(4:ℝ))
  let C := Real.pi * Q^2 * B^3 * K^2
  let k := Real.pi * (2 : ℝ)^(-(M*(3/2)))
  have hH : 0≤H := Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => norm_nonneg _))
  have hJ : 0≤J := Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => by positivity))
  have ht : 0≤t := Real.rpow_nonneg (by linarith) _
  have hC : 0≤C := by dsimp [C]; positivity
  have hk : 0<k := mul_pos Real.pi_pos (Real.rpow_pos_of_pos (by norm_num) _)
  have hcub := separatedProfiles_l1_cubed_bound s pbox a ν v hN hc hσ hF hA hν hsep hpositions hv
  have hlow := equation_4_13 (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) hN0 hM
  simp only [Finset.sum_sigma] at hlow
  have hvol := local_uniform_remainder_cubed hN0.le hQ (mul_nonneg (mul_nonneg hB ht) hH) E hE
  calc
    _ ≤ Real.pi * Q^2 * N^6 * (B*t*H)^3 := hvol
    _ = (Real.pi * Q^2 * B^3 * (N^6*t^3))*H^3 := by ring
    _ ≤ (Real.pi * Q^2 * B^3 * (N^6*t^3))*(K^2*N^8*J) :=
      mul_le_mul_of_nonneg_left hcub (by positivity)
    _ = C*(N^14*t^3)*J := by dsimp [C]; ring
    _ ≤ C*N^4*J := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left (fine_tail_scale_absorption hN) hC) hJ
    _ = (C/k)*(k*N^4*J) := by field_simp; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hlow (div_nonneg hC hk.le)

end EllipticSquareFunction
