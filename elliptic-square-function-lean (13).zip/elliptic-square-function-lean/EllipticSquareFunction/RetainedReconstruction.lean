import EllipticSquareFunction.CanonicalFrame
import EllipticSquareFunction.ScaledLattice
import EllipticSquareFunction.WeightIntegrals

/-! # The retained terminal reconstruction estimate (4.7)

The kernel decay, rescaled lattice sum, integrability, and mass assumptions
in the abstract reconstruction inequality are verified for the actual
terminal kernels.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

set_option maxHeartbeats 800000

def terminalWeightMass : ℝ := ∫ x : Plane, bracket x ^ (-4 : ℝ)

theorem terminalWeight_integrable (w : Plane) :
    IntegrableOn (fun y : Space => bracket (y.1 - w) ^ (-4 : ℝ)) (spatialSlab 1) volume := by
  have h := integrable_spatialWeight_on_slab (N := 1) (M := 4) (by norm_num) (by norm_num) 1 0 w
  convert h using 1
  funext y
  simp [spatialWeight]

theorem terminalWeight_integral (w : Plane) :
    (∫ y in spatialSlab 1, bracket (y.1 - w) ^ (-4 : ℝ)) = terminalWeightMass := by
  have hf : Integrable (fun x : Plane => bracket x ^ (-4 : ℝ)) volume :=
    integrable_one_add_norm (by norm_num)
  have hg : Integrable ((Icc (0 : ℝ) 1).indicator (fun _ => (1 : ℝ))) volume :=
    memLp_one_iff_integrable.mp (memLp_indicator_const 1 measurableSet_Icc 1
      (Or.inr (by simp)))
  have h := integral_sheared_product (f := fun x : Plane => bracket x ^ (-4 : ℝ))
    (by unfold bracket; fun_prop) (measurable_const.indicator measurableSet_Icc) hf hg 0 w
  have he : (fun y : Space => bracket (y.1 - w + y.2 • (0 : Plane)) ^ (-4 : ℝ) *
      (Icc (0 : ℝ) 1).indicator (fun _ => (1 : ℝ)) y.2) =
      (spatialSlab 1).indicator (fun y : Space => bracket (y.1 - w) ^ (-4 : ℝ)) := by
    funext y
    by_cases hy : y.2 ∈ Icc (0 : ℝ) 1
    · rw [Set.indicator_of_mem hy, Set.indicator_of_mem (show y ∈ spatialSlab 1 from hy)]
      simp
    · rw [Set.indicator_of_not_mem hy, Set.indicator_of_not_mem (show y ∉ spatialSlab 1 from hy)]
      simp
  rw [he, integral_indicator (measurableSet_spatialSlab 1)] at h
  simpa [terminalWeightMass, integral_indicator measurableSet_Icc, Real.volume_Icc] using h

/-- The retained reconstruction bound, uniform in the finite set of spatial
labels and in the coefficients. All analytic kernel hypotheses are proved. -/
theorem retained_reconstruction_cubed (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane) :
    ∃ C : ℝ, 0 < C ∧ ∀ (s : Finset IntPlane) (c : IntPlane × IntPlane → ℂ),
      IntegrableOn (fun y : Space => ‖∑ i ∈ q ×ˢ s, c i *
        windowKernel S.φ (canonicalWindow S i.1)
          (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2‖ ^ 3) (spatialSlab 1) volume ∧
      (∫ y in spatialSlab 1, ‖∑ i ∈ q ×ˢ s, c i *
        windowKernel S.φ (canonicalWindow S i.1)
          (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2‖ ^ 3) ≤
        C * ∑ i ∈ q ×ˢ s, ‖c i‖ ^ 3 := by
  classical
  obtain ⟨A, hA, hk⟩ := finite_window_kernel_decay q S.φ hφ (canonicalWindow S)
    (canonicalWindow_smooth S) (canonicalWindow_compact S) 4
  let B := (q.card : ℝ) * A * scaledLatticeSumConstant (S.D : ℝ)⁻¹ 4
  have hmass0 : 0 ≤ terminalWeightMass := integral_nonneg (fun x =>
    Real.rpow_nonneg (bracket_pos x).le _)
  refine ⟨B ^ 2 * (A * terminalWeightMass) + 1, by positivity, ?_⟩
  intro s c
  have hD : 0 < (S.D : ℝ)⁻¹ := inv_pos.mpr (by exact_mod_cast S.D_pos)
  have hsum (y : Space) : (∑ i ∈ q ×ˢ s,
      A * bracket (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) ^ (-4 : ℝ)) ≤ B := by
    calc
      _ = (q.card : ℝ) * A * ∑ n ∈ s,
          bracket (y.1 - latticePoint (S.D : ℝ)⁻¹ n) ^ (-4 : ℝ) := by
        rw [Finset.sum_product]
        simp only [← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul]
        ring
      _ ≤ B := mul_le_mul_of_nonneg_left
        (scaled_lattice_finite_sum_le hD (by norm_num : (2 : ℝ) < 4) y.1 s) (by positivity)
  have hkernel : ∀ᵐ y ∂volume.restrict (spatialSlab 1), ∀ i ∈ q ×ˢ s,
      ‖windowKernel S.φ (canonicalWindow S i.1)
        (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2‖ ≤
      A * bracket (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) ^ (-4 : ℝ) := by
    filter_upwards [ae_restrict_mem (measurableSet_spatialSlab 1)] with y hy
    intro i hi
    exact hk i.1 (Finset.mem_product.mp hi).1 y.2 hy _
  have hF : Continuous (fun y : Space => ∑ i ∈ q ×ˢ s, c i *
      windowKernel S.φ (canonicalWindow S i.1)
        (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2) := by
    apply continuous_finset_sum
    intro i _
    have hshift : Continuous (fun y : Space =>
        (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2, y.2)) :=
      (continuous_fst.sub continuous_const).prodMk continuous_snd
    have hker : Continuous (fun y : Space => windowKernel S.φ (canonicalWindow S i.1) y.1 y.2) :=
      continuous_windowKernel S.φ hφ.continuous (canonicalWindow S i.1)
        (canonicalWindow_smooth S i.1).continuous (canonicalWindow_compact S i.1)
    have hkshift := hker.comp hshift
    dsimp only [Function.comp_def] at hkshift
    exact (continuous_const : Continuous (fun _ : Space => c i)).mul hkshift
  refine ⟨integrable_reconstruction_cubed (volume.restrict (spatialSlab 1)) (q ×ˢ s) c
    (fun i y => windowKernel S.φ (canonicalWindow S i.1)
      (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2)
    (fun i y => A * bracket (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) ^ (-4 : ℝ))
    hF.aestronglyMeasurable hkernel (Filter.Eventually.of_forall hsum)
    (fun i _ => (terminalWeight_integrable (latticePoint (S.D : ℝ)⁻¹ i.2)).const_mul A), ?_⟩
  have h := integral_reconstruction_cubed_ae (volume.restrict (spatialSlab 1)) (q ×ˢ s) c
    (fun i y => windowKernel S.φ (canonicalWindow S i.1)
      (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2)
    (fun i y => A * bracket (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) ^ (-4 : ℝ))
    (B := B) (C := A * terminalWeightMass)
    hkernel
    (Filter.Eventually.of_forall hsum)
    (fun i _ => (terminalWeight_integrable (latticePoint (S.D : ℝ)⁻¹ i.2)).const_mul A)
    (by
      intro i _
      rw [integral_const_mul, terminalWeight_integral])
  exact h.trans (mul_le_mul_of_nonneg_right (by linarith)
    (Finset.sum_nonneg (fun i _ => pow_nonneg (norm_nonneg (c i)) _)))

/-- Equation (4.7) on one unit time slab, including the canonical `D⁻²`
synthesis factor and integrability of the cubed integrand. -/
theorem normalized_retained_reconstruction_cubed (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane) :
    ∃ C : ℝ, 0 < C ∧ ∀ (s : Finset IntPlane) (c : IntPlane × IntPlane → ℂ),
      let F := fun y : Space => (((S.D : ℝ) ^ 2)⁻¹ : ℝ) •
        ∑ i ∈ q ×ˢ s, c i * windowKernel S.φ (canonicalWindow S i.1)
          (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2
      IntegrableOn (fun y => ‖F y‖ ^ 3) (spatialSlab 1) volume ∧
        (∫ y in spatialSlab 1, ‖F y‖ ^ 3) ≤ C * ∑ i ∈ q ×ˢ s, ‖c i‖ ^ 3 := by
  classical
  obtain ⟨C, hC, hc⟩ := retained_reconstruction_cubed S hφ q
  let a : ℝ := ((S.D : ℝ) ^ 2)⁻¹
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have ha : 0 < a := by dsimp [a]; positivity
  refine ⟨C * a ^ 3, by positivity, ?_⟩
  intro s c
  obtain ⟨hi, hh⟩ := hc s (fun i => a • c i)
  have he (y : Space) : (∑ i ∈ q ×ˢ s, (a • c i) * windowKernel S.φ (canonicalWindow S i.1)
      (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2) =
      a • ∑ i ∈ q ×ˢ s, c i * windowKernel S.φ (canonicalWindow S i.1)
        (y.1 - latticePoint (S.D : ℝ)⁻¹ i.2) y.2 := by
    rw [Finset.smul_sum]
    apply Finset.sum_congr rfl
    intro i _
    exact smul_mul_assoc _ _ _
  simp only [he] at hi hh
  refine ⟨hi, ?_⟩
  have hn (i : IntPlane × IntPlane) : ‖a • c i‖ ^ 3 = a ^ 3 * ‖c i‖ ^ 3 := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos ha, mul_pow]
  simpa only [hn, ← Finset.mul_sum, ← mul_assoc] using hh

end EllipticSquareFunction
