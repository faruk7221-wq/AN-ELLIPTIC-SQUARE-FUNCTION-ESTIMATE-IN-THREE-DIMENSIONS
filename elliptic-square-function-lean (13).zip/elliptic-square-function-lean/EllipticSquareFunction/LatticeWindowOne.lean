import EllipticSquareFunction.ExternalInputs

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- A smooth nonnegative window whose squared integer translates sum to one. -/
def latticeWindowOne (x : ℝ) : ℝ :=
  Real.cos (Real.pi/2*Real.smoothTransition x)*
    Real.sin (Real.pi/2*Real.smoothTransition (x+1))

theorem latticeWindowOne_smooth : ContDiff ℝ (⊤:ℕ∞) latticeWindowOne := by
  unfold latticeWindowOne
  exact ((contDiff_const.mul Real.smoothTransition.contDiff).cos).mul
    ((contDiff_const.mul (Real.smoothTransition.contDiff.comp (contDiff_id.add contDiff_const))).sin)

theorem latticeWindowOne_nonneg (x : ℝ) : 0≤latticeWindowOne x := by
  apply mul_nonneg
  · apply Real.cos_nonneg_of_mem_Icc
    constructor
    · have hp := Real.smoothTransition.nonneg x
      nlinarith [Real.pi_pos]
    · have hp := Real.smoothTransition.le_one x
      nlinarith [Real.pi_pos]
  · apply Real.sin_nonneg_of_mem_Icc
    constructor
    · exact mul_nonneg (by positivity) (Real.smoothTransition.nonneg _)
    · have hp := Real.smoothTransition.le_one (x+1)
      nlinarith [Real.pi_pos]

theorem latticeWindowOne_zero_left {x : ℝ} (hx : x≤ -1) : latticeWindowOne x=0 := by
  simp [latticeWindowOne,Real.smoothTransition.zero_of_nonpos (by linarith : x+1≤0)]

theorem latticeWindowOne_zero_right {x : ℝ} (hx : 1≤x) : latticeWindowOne x=0 := by
  simp [latticeWindowOne,Real.smoothTransition.one_of_one_le hx,Real.cos_pi_div_two]

theorem latticeWindowOne_support : tsupport latticeWindowOne⊆Set.Icc (-1:ℝ) 1 := by
  apply closure_minimal _ isClosed_Icc
  intro x hx
  constructor
  · by_contra hh
    exact hx (latticeWindowOne_zero_left (by linarith))
  · by_contra hh
    exact hx (latticeWindowOne_zero_right (by linarith))

theorem latticeWindowOne_compact : HasCompactSupport latticeWindowOne :=
  isCompact_Icc.of_isClosed_subset (isClosed_tsupport _) latticeWindowOne_support

theorem latticeWindowOne_pair {x : ℝ} (hx : 0≤x) (hx₁ : x≤1) :
    latticeWindowOne x^2+latticeWindowOne (x-1)^2=1 := by
  have hz : Real.smoothTransition (x-1)=0 := Real.smoothTransition.zero_of_nonpos (by linarith)
  have ho : Real.smoothTransition (x+1)=1 := Real.smoothTransition.one_of_one_le (by linarith)
  simp only [latticeWindowOne,hz,ho,sub_add_cancel,mul_one,Real.sin_pi_div_two,
    mul_zero,Real.cos_zero,one_mul]
  nlinarith [Real.sin_sq_add_cos_sq (Real.pi/2*Real.smoothTransition x)]

theorem latticeWindowOne_translate_zero (x : ℝ) (m : ℤ)
    (hm : m∉({Int.floor x,Int.floor x+1} : Finset ℤ)) : latticeWindowOne (x-m)=0 := by
  have hx := Int.floor_le x
  have hx' := Int.lt_floor_add_one x
  have hne : m≠Int.floor x ∧ m≠Int.floor x+1 := by simpa using hm
  by_cases hlt : m<Int.floor x
  · apply latticeWindowOne_zero_right
    have hh : (m:ℝ)+1≤Int.floor x := by exact_mod_cast (Int.add_one_le_iff.mpr hlt)
    linarith
  · apply latticeWindowOne_zero_left
    have hh : Int.floor x+2≤ m := by omega
    have hh' : (Int.floor x:ℝ)+2≤ m := by exact_mod_cast hh
    linarith

theorem latticeWindowOne_partition (x : ℝ) :
    (∑' m : ℤ, latticeWindowOne (x-m)^2)=1 := by
  classical
  rw [tsum_eq_sum (s := {Int.floor x,Int.floor x+1}) (fun m hm => by
    rw [latticeWindowOne_translate_zero x m hm]; simp)]
  have hne : Int.floor x≠Int.floor x+1 := by omega
  rw [Finset.sum_pair hne]
  simp only [Int.cast_add,Int.cast_one]
  have hh := latticeWindowOne_pair (x := x-Int.floor x) (by linarith [Int.floor_le x])
    (by linarith [Int.lt_floor_add_one x])
  convert hh using 2 <;> congr 2 <;> ring

end EllipticSquareFunction
