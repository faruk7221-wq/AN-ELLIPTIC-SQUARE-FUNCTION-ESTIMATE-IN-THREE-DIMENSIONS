import EllipticSquareFunction.AffineFourierBox
import EllipticSquareFunction.InverseTimeProfile

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Multiplication by a character translates the inverse multiplier kernel. -/
theorem inverseSpaceTransform_modulation_sub (m : Space → ℂ) (y p : Space) :
    inverseSpaceTransform (fun ζ => m ζ*oscillation (spacePair y ζ)) (-p)=
      inverseSpaceTransform m (y-p) := by
  unfold inverseSpaceTransform
  apply integral_congr_ae
  filter_upwards with ζ
  change m ζ*oscillation (spacePair y ζ)*oscillation (spacePair (-p) ζ)=
    m ζ*oscillation (spacePair (y-p) ζ)
  rw [mul_assoc,← oscillation_add,spacePair_neg_left,spacePair_sub_left,sub_eq_add_neg]

/-- Pointwise convergent sampling synthesis on an affine tangent box.
The datum is expressed as an inverse Fourier integral. The support-box and
cutoff conditions are explicit; their uniform construction is a separate step. -/
theorem affine_box_sampling (ν V : Plane) (h : ℝ)
    {r R D : ℝ} (hr : 0<r) (hR : 0<R) (hD : 0<D) (a : Fin 3 → ℝ)
    (f m : Space → ℂ) (hf : Continuous f) (hm : Continuous m)
    (hfs : HasCompactSupport f) (hms : HasCompactSupport m)
    (hfb : Function.support (fun z => f ((curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν).symm z)) ⊆ spaceBox a D)
    (hmb : Function.support (fun z => m ((curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν).symm z)) ⊆ spaceBox a D)
    (hone : ∀ ζ ∈ Function.support f, m ζ=1) (y : Space) :
    HasSum (fun n : Fin 3 → ℤ => ((r^2*R/D^3:ℝ):ℂ)*
      (inverseSpaceTransform f (unshearScale r R V (spaceFrequencyLattice D n))*
       inverseSpaceTransform m (y-unshearScale r R V (spaceFrequencyLattice D n))))
      (inverseSpaceTransform f y) := by
  let g := fun ζ : Space => m ζ*oscillation (spacePair y ζ)
  have ho : Continuous (fun ζ : Space => oscillation (spacePair y ζ)) := by
    apply continuous_oscillation.comp
    unfold spacePair
    fun_prop
  have hg : Continuous g := hm.mul ho
  have hgs : HasCompactSupport g := hms.mul_right
  have hgb : Function.support (fun z => g ((curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν).symm z)) ⊆ spaceBox a D := by
    intro z hz
    exact hmb ((mul_ne_zero_iff.mp hz).1)
  have hh := affine_box_reconstruction ν V h hr hR hD a f g hf hg hfs hgs hfb hgb
  have he : (∫ ζ : Space, f ζ*g ζ)=inverseSpaceTransform f y := by
    apply integral_congr_ae
    filter_upwards with ζ
    by_cases hz : f ζ=0
    · simp [hz]
    · simp only [g,hone ζ hz,one_mul]
      rfl
  simpa only [g,inverseSpaceTransform_modulation_sub,he] using hh

/-- Packet synthesis with coefficient D⁻³ times the actual inverse-transform
sample. This is (6.1),(6.7),(6.10) for equal fixed box sides A=B=D, provided the
explicit support and multiplier conditions hold. -/
theorem affine_curved_packet_sampling (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (hχs : HasCompactSupport χ)
    (ρ : SchwartzMap ℝ ℂ) (hρs : HasCompactSupport (ρ : ℝ → ℂ))
    (ν V : Plane) {R D : ℝ} (hR : 0<R) (hD : 0<D) (a : Fin 3 → ℝ)
    (f : Space → ℂ) (hf : Continuous f) (hfs : HasCompactSupport f)
    (hfb : Function.support (fun z => f ((curvedFrequencyHomeomorph (tangentPhase ν V (φ ν))
      (continuous_tangentPhase ν V (φ ν)) (Real.sqrt_pos.mpr hR).ne' hR.ne' ν).symm z)) ⊆ spaceBox a D)
    (hmb : Function.support (fun z => curvedMultiplier φ χ ρ (Real.sqrt R) R ν
      ((curvedFrequencyHomeomorph (tangentPhase ν V (φ ν))
      (continuous_tangentPhase ν V (φ ν)) (Real.sqrt_pos.mpr hR).ne' hR.ne' ν).symm z)) ⊆ spaceBox a D)
    (hone : ∀ ζ ∈ Function.support f, curvedMultiplier φ χ ρ (Real.sqrt R) R ν ζ=1)
    (y : Space) :
    let p := fun n : Fin 3 → ℤ => unshearScale (Real.sqrt R) R V (spaceFrequencyLattice D n)
    HasSum (fun n : Fin 3 → ℤ =>
      (((D^3)⁻¹:ℝ)*inverseSpaceTransform f (p n))*
        timePacket φ χ (inverseTimeProfile ρ) R ν (p n).1 (p n).2 y)
      (inverseSpaceTransform f y) := by
  intro p
  have hh := affine_box_sampling ν V (φ ν) (Real.sqrt_pos.mpr hR) hR hD a f
    (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) hf
    (continuous_curvedMultiplier φ hφ χ hχ ρ ρ.continuous _ _ _)
    hfs (compactSupport_curvedMultiplier φ hφ χ hχs ρ hρs (Real.sqrt_pos.mpr hR).ne' hR.ne' ν)
    hfb hmb hone y
  convert hh using 1
  funext n
  symm
  change ((Real.sqrt R^2*R/D^3:ℝ):ℂ)*
    (inverseSpaceTransform f (p n)*
      inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) (y-p n))=_
  have hk := inverse_curvedMultiplier_translated φ hφ χ hχ hχs ρ hρs hR ν (p n).1 (p n).2 y
  simp only [Prod.mk.eta] at hk
  rw [hk,Real.sq_sqrt hR.le]
  generalize inverseSpaceTransform f (p n)=u
  generalize timePacket φ χ (inverseTimeProfile ρ) R ν (p n).1 (p n).2 y=w
  have hcoef : ((R*R/D^3:ℝ):ℂ)*(((R^2)⁻¹:ℝ):ℂ)=(((D^3)⁻¹:ℝ):ℂ) := by
    rw [← Complex.ofReal_mul]
    congr 1
    field_simp [hR.ne',hD.ne']
    <;> ring
  calc
    _ = (((R*R/D^3:ℝ):ℂ)*(((R^2)⁻¹:ℝ):ℂ))*(u*w) := by ring
    _ = _ := by rw [hcoef]; ring

end EllipticSquareFunction
