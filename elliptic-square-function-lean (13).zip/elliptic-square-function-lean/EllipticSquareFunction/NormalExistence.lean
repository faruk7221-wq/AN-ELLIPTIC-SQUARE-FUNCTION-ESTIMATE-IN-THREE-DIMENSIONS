import EllipticSquareFunction.NormalDirectionUniqueness
import EllipticSquareFunction.EuclideanEmbeddedSurface

noncomputable section
namespace EllipticSquareFunction

/-- Every immersed two-plane in Euclidean three-space admits a unit normal. -/
theorem immersion_unit_normal_exists (D : Plane →L[ℝ] EuclideanThree)
    (hD : Function.Injective D) :
    ∃ N : EuclideanThree, ‖N‖=1 ∧ ∀ v : Plane, @inner ℝ EuclideanThree _ N (D v)=0 := by
  let T := LinearMap.range D.toLinearMap
  have hdim : Module.finrank ℝ T=2 := by
    rw [LinearMap.finrank_range_of_inj hD]
    exact finrank_euclideanSpace_fin
  have hcodim : Module.finrank ℝ Tᗮ=1 := by
    have hh := T.finrank_add_finrank_orthogonal
    rw [hdim,finrank_euclideanSpace_fin] at hh
    omega
  have hnt : Nontrivial Tᗮ := (Module.finrank_pos_iff (R := ℝ)).mp (by omega)
  letI := hnt
  obtain ⟨u,hu⟩ := exists_ne (0 : Tᗮ)
  have hun : (u : EuclideanThree) ≠ 0 := fun hz => hu (Subtype.ext hz)
  have hp := norm_pos_iff.mpr hun
  refine ⟨‖(u : EuclideanThree)‖⁻¹ • (u : EuclideanThree),?_,?_⟩
  · simp only [norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hp),inv_mul_cancel₀ hp.ne']
  · intro v
    rw [inner_smul_left]
    have ho : @inner ℝ EuclideanThree _ (u : EuclideanThree) (D v)=0 :=
      (Submodule.mem_orthogonal' T (u : EuclideanThree)).mp u.property (D v) ⟨v,rfl⟩
    simp [ho]

theorem euclidean_unit_normal_unique (D : Plane →L[ℝ] EuclideanThree)
    (hD : Function.Injective D) (N M : EuclideanThree) (hN : ‖N‖=1) (hM : ‖M‖=1)
    (hNort : ∀ v, @inner ℝ EuclideanThree _ N (D v)=0)
    (hMort : ∀ v, @inner ℝ EuclideanThree _ M (D v)=0) : M=N ∨ M= -N := by
  let E := spaceEuclideanEquiv
  have hD' : Function.Injective (E.toContinuousLinearMap.comp D) := E.injective.comp hD
  have hn : ‖spaceEuclideanEquiv.symm (E N)‖=1 := by simpa only [E,ContinuousLinearEquiv.symm_apply_apply] using hN
  have hm : ‖spaceEuclideanEquiv.symm (E M)‖=1 := by simpa only [E,ContinuousLinearEquiv.symm_apply_apply] using hM
  have hoN : ∀ v, spacePair (E N) ((E.toContinuousLinearMap.comp D) v)=0 := by
    intro v
    exact (spaceEuclideanEquiv_pair N (D v)).trans (hNort v)
  have hoM : ∀ v, spacePair (E M) ((E.toContinuousLinearMap.comp D) v)=0 := by
    intro v
    exact (spaceEuclideanEquiv_pair M (D v)).trans (hMort v)
  rcases unit_normal_direction_unique _ hD' (E N) (E M) hn hm hoN hoM with he | he
  · exact Or.inl (E.injective he)
  · exact Or.inr (E.injective (by simpa only [map_neg] using he))

theorem euclidean_definite_second_form_neg_iff (F : Plane → EuclideanThree)
    (N : EuclideanThree) (a : Plane) :
    EuclideanDefiniteSecondForm F (-N) a ↔ EuclideanDefiniteSecondForm F N a := by
  have he : ∀ v w, euclideanSecondFundamentalForm F (-N) a v w =
      -euclideanSecondFundamentalForm F N a v w := by
    intro v w
    exact inner_neg_left _ _
  unfold EuclideanDefiniteSecondForm
  simp only [he,neg_pos,neg_lt_zero]
  exact or_comm

/-- Definiteness is independent of which unit normal is chosen. -/
theorem euclidean_definite_second_form_normal_independent
    {F : Plane → EuclideanThree} {a : Plane} (hD : Function.Injective (fderiv ℝ F a))
    (N M : EuclideanThree) (hN : ‖N‖=1) (hM : ‖M‖=1)
    (hNort : ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F a v)=0)
    (hMort : ∀ v, @inner ℝ EuclideanThree _ M (fderiv ℝ F a v)=0) :
    EuclideanDefiniteSecondForm F M a ↔ EuclideanDefiniteSecondForm F N a := by
  rcases euclidean_unit_normal_unique _ hD N M hN hM hNort hMort with he | he
  · rw [he]
  · rw [he]
    exact euclidean_definite_second_form_neg_iff F N a

end EllipticSquareFunction
