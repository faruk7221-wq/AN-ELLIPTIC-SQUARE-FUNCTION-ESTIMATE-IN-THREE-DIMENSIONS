import EllipticSquareFunction.LpReduction

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- The pointwise square-root cardinality bound used for bounded scales. -/
theorem finite_family_square_bound {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) (y : Space) :
    ‖∑ i∈s, f i y‖≤Real.sqrt (s.card:ℝ)*squareFunction s f y := by
  have hc := Finset.sum_mul_sq_le_sq_mul_sq s (fun _ => (1:ℝ)) (fun i => ‖f i y‖)
  simp only [one_mul,one_pow,Finset.sum_const,nsmul_eq_mul,mul_one] at hc
  have hs : 0≤∑ i∈s, ‖f i y‖ := Finset.sum_nonneg (fun i hi => norm_nonneg _)
  have hS : 0≤squareFunction s f y := Real.sqrt_nonneg _
  have he := squareFunction_sq s f y
  have hcard := Real.sq_sqrt (Nat.cast_nonneg s.card)
  have hnorm := norm_sum_le s (fun i => f i y)
  have hh : (Real.sqrt (s.card:ℝ)*squareFunction s f y)^2=
      (s.card:ℝ)*(∑ i∈s, ‖f i y‖^2) := by rw [mul_pow,hcard,he]
  have hprod := mul_nonneg (Real.sqrt_nonneg (s.card:ℝ)) hS
  nlinarith

/-- Bounded cardinality controls the L3 reverse square function uniformly. -/
theorem finite_family_l3_square_bound {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) :
    l3 (fun y => ∑ i∈s, f i y)≤ENNReal.ofReal (Real.sqrt (s.card:ℝ))*
      l3Real (squareFunction s f) := by
  calc
    _ ≤ eLpNorm (fun y => Real.sqrt (s.card:ℝ)*squareFunction s f y) 3 volume := by
      apply eLpNorm_mono
      intro y
      rw [Real.norm_eq_abs,abs_of_nonneg (mul_nonneg (Real.sqrt_nonneg _) (show 0≤squareFunction s f y from Real.sqrt_nonneg _))]
      exact finite_family_square_bound s f y
    _ = _ := eLpNorm_nonneg_const_mul volume 3 _ (Real.sqrt_nonneg _)

/-- Analytic recombination of finitely many chart pieces, after each chart's
geometric transport and multiplier estimate have been supplied. -/
theorem finite_chart_l3_assembly {ι : Type*} (s : Finset ι)
    (F : Space → ℂ) (pieces : ι → Space → ℂ) (H : Space → ℝ)
    (C : ι → ℝ≥0∞) (hpieces : ∀ i∈s, AEStronglyMeasurable (pieces i) volume)
    (hsum : ∀ y, F y=∑ i∈s, pieces i y)
    (hbound : ∀ i∈s, l3 (pieces i)≤C i*l3Real H) :
    l3 F≤(∑ i∈s, C i)*l3Real H := by
  have he : F=∑ i∈s, pieces i := by ext y; simpa using hsum y
  unfold l3
  rw [he]
  apply (eLpNorm_sum_le hpieces (by norm_num : (1:ℝ≥0∞)≤3)).trans
  exact (Finset.sum_le_sum hbound).trans_eq (Finset.sum_mul ..).symm

end EllipticSquareFunction
