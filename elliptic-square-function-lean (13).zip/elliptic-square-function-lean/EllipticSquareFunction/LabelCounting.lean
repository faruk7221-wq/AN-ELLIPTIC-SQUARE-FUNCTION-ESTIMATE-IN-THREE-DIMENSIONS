import EllipticSquareFunction.ScaledLattice
import EllipticSquareFunction.Finite

/-! # Counting the initial frequency and position labels -/

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

def integerPlaneBox (k : ℕ) : Finset IntPlane :=
  Fintype.piFinset (fun _ => Finset.Icc (-(k : ℤ)) (k : ℤ))

theorem integerPlaneBox_card (k : ℕ) :
    (integerPlaneBox k).card = (2 * k + 1) ^ 2 := by
  simp [integerPlaneBox, Fintype.card_piFinset, Int.card_Icc]
  omega

theorem mem_integerPlaneBox_of_norm_le {B : ℝ} {m : IntPlane}
    (hm : ‖latticePoint 1 m‖ ≤ B) : m ∈ integerPlaneBox ⌈B⌉₊ := by
  apply Fintype.mem_piFinset.mpr
  intro i
  have hi : |(m i : ℝ)| ≤ (⌈B⌉₊ : ℝ) := by
    have h := PiLp.norm_apply_le (latticePoint 1 m) i
    have h' : |(m i : ℝ)| ≤ ‖latticePoint 1 m‖ := by
      simpa only [latticePoint, WithLp.equiv_symm_pi_apply, one_mul, Real.norm_eq_abs] using h
    exact h'.trans (hm.trans (Nat.le_ceil B))
  apply Finset.mem_Icc.mpr
  constructor
  · exact_mod_cast (abs_le.mp hi).1
  · exact_mod_cast (abs_le.mp hi).2

theorem integerPlaneBox_card_scale {B N : ℝ} (hB : 0 ≤ B) (hN : 1 ≤ N) :
    ((integerPlaneBox ⌈B * N⌉₊).card : ℝ) ≤ (2 * B + 3) ^ 2 * N ^ 2 := by
  rw [integerPlaneBox_card]
  push_cast
  have hc := Nat.ceil_lt_add_one (mul_nonneg hB (by linarith : 0 ≤ N))
  have hh : (2 * (⌈B * N⌉₊ : ℝ) + 1) ≤ (2 * B + 3) * N := by nlinarith
  have hp := pow_le_pow_left₀ (by positivity : 0 ≤ 2 * (⌈B * N⌉₊ : ℝ) + 1) hh 2
  simpa only [mul_pow] using hp

theorem discrete_label_coordinate_bounds (S : DiscreteSetup) {N : ℝ} (hN : 0 < N)
    (s : Finset PacketIndex) (hs : discreteLabelsAllowed S N s) (i : PacketIndex) (hi : i ∈ s) :
    ‖latticePoint 1 i.1‖ ≤ S.frequencyBound * N ∧
      ‖latticePoint 1 i.2‖ ≤ (S.C₁ * S.D) * N := by
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have hfreq : latticePoint 1 i.1 = N • latticePoint N⁻¹ i.1 := by
    rw [← latticePoint_mul, mul_inv_cancel₀ hN.ne']
  have hpos : latticePoint 1 i.2 = ((S.D : ℝ) / N) • latticePoint (N / S.D) i.2 := by
    rw [← latticePoint_mul]
    congr 1
    field_simp
  constructor
  · rw [hfreq, norm_smul, Real.norm_eq_abs, abs_of_pos hN]
    simpa only [mul_comm] using mul_le_mul_of_nonneg_left (hs i hi).1 hN.le
  · rw [hpos, norm_smul, Real.norm_eq_abs, abs_of_pos (div_pos hD hN)]
    have h := mul_le_mul_of_nonneg_left (hs i hi).2 (div_pos hD hN).le
    convert h using 1 <;> field_simp <;> ring

def initialLabelCountConstant (S : DiscreteSetup) : ℝ :=
  (2 * S.frequencyBound + 3) ^ 2 * (2 * (S.C₁ * S.D) + 3) ^ 2

/-- The article's `O(N⁴)` initial-label count, with an explicit constant
depending only on the fixed setup. -/
theorem discreteLabels_card_bound (S : DiscreteSetup) {N : ℝ} (hN : 1 ≤ N)
    (s : Finset PacketIndex) (hs : discreteLabelsAllowed S N s) :
    (s.card : ℝ) ≤ initialLabelCountConstant S * N ^ 4 := by
  classical
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have hsub : s ⊆ integerPlaneBox ⌈S.frequencyBound * N⌉₊ ×ˢ
      integerPlaneBox ⌈(S.C₁ * S.D) * N⌉₊ := by
    intro i hi
    obtain ⟨hf, hp⟩ := discrete_label_coordinate_bounds S (by linarith) s hs i hi
    exact Finset.mem_product.mpr ⟨mem_integerPlaneBox_of_norm_le hf,
      mem_integerPlaneBox_of_norm_le hp⟩
  have hc : (s.card : ℝ) ≤
      ((integerPlaneBox ⌈S.frequencyBound * N⌉₊).card : ℝ) *
        ((integerPlaneBox ⌈(S.C₁ * S.D) * N⌉₊).card : ℝ) := by
    have h := Finset.card_le_card hsub
    rw [Finset.card_product] at h
    exact_mod_cast h
  apply hc.trans
  have hf := integerPlaneBox_card_scale S.frequencyBound_pos.le hN
  have hp := integerPlaneBox_card_scale (mul_pos S.C₁_pos hD).le hN
  convert mul_le_mul hf hp (by positivity) (by positivity) using 1
  dsimp [initialLabelCountConstant]
  ring

/-- Cubic Hölder plus the geometric count controls the initial ℓ¹ norm. -/
theorem discreteLabels_l1_cubed_bound (S : DiscreteSetup) {N : ℝ} (hN : 1 ≤ N)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (hs : discreteLabelsAllowed S N s) :
    (∑ i ∈ s, ‖d i‖) ^ 3 ≤
      (initialLabelCountConstant S) ^ 2 * N ^ 8 * ∑ i ∈ s, ‖d i‖ ^ 3 := by
  have h := weighted_cubic_holder s (fun _ => (1 : ℝ)) (fun i => ‖d i‖)
    (by intros; norm_num) (by intros; positivity)
  simp only [one_mul, Finset.sum_const, nsmul_eq_mul, mul_one] at h
  apply h.trans
  have hc := pow_le_pow_left₀ (by positivity : 0 ≤ (s.card : ℝ))
    (discreteLabels_card_bound S hN s hs) 2
  convert mul_le_mul_of_nonneg_right hc
    (Finset.sum_nonneg (fun i _ => pow_nonneg (norm_nonneg (d i)) 3)) using 1 <;> ring

/-- A bounded translated frequency ball contains uniformly many integer
lattice points, independent of its center. -/
theorem translated_lattice_card_bound (u : Plane) (A : ℝ)
    (s : Finset IntPlane) (hs : ∀ m ∈ s, ‖u-latticePoint 1 m‖ ≤ A) :
    s.card ≤ (integerPlaneBox ⌈A+2⌉₊).card := by
  classical
  apply Finset.card_le_card_of_injOn (fun m => m-floorPoint u)
  · intro m hm
    apply mem_integerPlaneBox_of_norm_le
    rw [latticePoint_sub]
    calc
      _ = ‖(latticePoint 1 m-u) + (u-latticePoint 1 (floorPoint u))‖ := by congr 1; abel
      _ ≤ ‖latticePoint 1 m-u‖ + ‖u-latticePoint 1 (floorPoint u)‖ := norm_add_le _ _
      _ ≤ A+2 := by rw [norm_sub_rev (latticePoint 1 m)]; exact add_le_add (hs m hm) (norm_sub_floorPoint_le u)
  · intro m _ n _ h
    simpa only [sub_add_cancel] using congrArg (fun k : IntPlane => k+floorPoint u) h

end EllipticSquareFunction
