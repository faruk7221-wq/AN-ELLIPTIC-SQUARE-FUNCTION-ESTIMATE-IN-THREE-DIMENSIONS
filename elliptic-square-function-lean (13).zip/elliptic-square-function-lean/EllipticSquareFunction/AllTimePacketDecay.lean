import EllipticSquareFunction.PolynomialRebasing

noncomputable section
namespace EllipticSquareFunction

/-- The free-packet decay bound for every time, with an explicit polynomial
loss in t/N². A Schwartz time cutoff can absorb this loss in kernel bounds. -/
theorem freePacket_all_time_polynomial_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ (ν v : Plane) (y : Space),
      ‖freePacket φ b N ν v y‖ ≤ C*(1+|y.2/N^2|)^L*
        bracket (N⁻¹ • (y.1-v+y.2 • velocity φ ν))^(-(L:ℝ)) := by
  let H : Plane × Plane → ℂ := fun p => b p.2
  have hH : ContDiff ℝ (⊤ : ℕ∞) H := hb.comp contDiff_snd
  obtain ⟨C,hC,hbound⟩ := rebaseAmplitude_oscillatory_decay hphase H hH
    (isCompact_singleton (x := (0:Plane))) hbs (fun _ _ => Set.Subset.rfl) L
  refine ⟨C,hC,?_⟩
  intro N hN ν v y
  have hN₀ : 0<N := by linarith
  rw [freePacket_normalization φ b hN₀,norm_mul,norm_oscillation,one_mul]
  simpa only [H,normalizedOscillation] using
    hbound 0 (by simp) N hN ν (N⁻¹ • (y.1-v+y.2 • velocity φ ν)) (y.2/N^2)

end EllipticSquareFunction
