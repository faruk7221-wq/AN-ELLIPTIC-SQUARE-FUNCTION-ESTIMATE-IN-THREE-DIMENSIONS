import EllipticSquareFunction.TimeAssembly

/-! # The bounded-region discrete estimate in cubic integral form -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

theorem norm_add_cubed_le (z w : ℂ) :
    ‖z+w‖^3 ≤ 4 * (‖z‖^3 + ‖w‖^3) := by
  have h := pow_le_pow_left₀ (norm_nonneg _) (norm_add_le z w) 3
  have hpoly := mul_nonneg (sq_nonneg (‖z‖-‖w‖))
    (add_nonneg (norm_nonneg z) (norm_nonneg w))
  nlinarith

theorem integral_norm_add_cubed_le {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (F G : α → ℂ)
    (hF : Integrable (fun y => ‖F y‖^3) μ) (hG : Integrable (fun y => ‖G y‖^3) μ) :
    (∫ y, ‖F y+G y‖^3 ∂μ) ≤
      4 * ((∫ y, ‖F y‖^3 ∂μ) + ∫ y, ‖G y‖^3 ∂μ) := by
  calc
    _ ≤ ∫ y, 4 * (‖F y‖^3 + ‖G y‖^3) ∂μ :=
      integral_mono_of_nonneg (Filter.Eventually.of_forall (fun y => by positivity))
        ((hF.add hG).const_mul 4) (Filter.Eventually.of_forall (fun y => norm_add_cubed_le _ _))
    _ = _ := by rw [integral_const_mul, integral_add hF hG]

/-- The analytic reconstruction step preceding application of external
input 2: all discarded terms have been absorbed into the core density. -/
theorem local_discrete_cubed_reconstruction (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (A : ℝ) :
    ∃ q : Finset IntPlane, ∃ C : ℝ, 0 < C ∧
      ∀ N : ℝ, 1 ≤ N → ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ),
      discreteLabelsAllowed S N s → ∀ K : ℕ, (K : ℝ) ≤ N^2 →
      (∫ y in Metric.closedBall (0 : Plane) (A*N^2) ×ˢ Icc 0 (K : ℝ),
        ‖discreteExtension S N s d y‖^3) ≤
        C * ((∑ i ∈ q ×ˢ (retainedPositions S ((A+1)*N^2) ×ˢ Finset.range K),
          ‖terminalCoefficient S N s d i‖^3) +
          ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ)) := by
  classical
  obtain ⟨q, B, hB, hb⟩ := terminalRemainder_sum_absorbed S hφ A
  obtain ⟨C, hC, hc⟩ := retainedTerminal_sum_cubed S hφ q
  refine ⟨q, 4*(B+C), by positivity, ?_⟩
  intro N hN s d hs K hK
  let p := retainedPositions S ((A+1)*N^2)
  let T := coreTube (A*N^2) 1 0 0
  let U := fun j : ℕ => ∫ y in spatialSlab 1, ‖retainedTerminal S q p N s d j y‖^3
  let E := fun j : ℕ => ∫ y in T, ‖terminalRemainder S q N A (N^2) s d j y‖^3
  let D := ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ)
  let M := ∑ i ∈ q ×ˢ (p ×ˢ Finset.range K), ‖terminalCoefficient S N s d i‖^3
  obtain ⟨hi, hret⟩ := hc p (Finset.range K) N s d
  have hsub : T ⊆ spatialSlab 1 := fun y hy => hy.1
  have hj (j : ℕ) : (∫ y in T, ‖discreteExtension S N s d (y.1,(j : ℝ)+y.2)‖^3) ≤
      4 * (U j + E j) := by
    have he (y : Space) : discreteExtension S N s d (y.1,(j : ℝ)+y.2) =
        retainedTerminal S q p N s d j y + terminalRemainder S q N A (N^2) s d j y := by
      simp [terminalRemainder, p]
    simp_rw [he]
    apply (integral_norm_add_cubed_le (volume.restrict T) _ _ ((hi j).mono_set hsub)
      (terminalRemainder_integrable_cubed S hφ.continuous q hN A (N^2) s d hs j)).trans
    have ht : (∫ y in T, ‖retainedTerminal S q p N s d j y‖^3) ≤ U j :=
      setIntegral_mono_set (hi j) (Filter.Eventually.of_forall (fun _ => by positivity))
        (Filter.Eventually.of_forall hsub)
    exact mul_le_mul_of_nonneg_left (add_le_add_right ht _) (by norm_num)
  have hD : 0 ≤ D := integral_nonneg (fun y => Real.rpow_nonneg
    (coreDensity_nonneg s d _ _ N (N^2) y) _)
  have hM : 0 ≤ M := Finset.sum_nonneg (fun i _ => by positivity)
  calc
    _ = ∑ j ∈ Finset.range K, ∫ y in T,
        ‖discreteExtension S N s d (y.1,(j : ℝ)+y.2)‖^3 := by
      rw [localSlab_sum_units (isCompact_closedBall _ _)
        ((continuous_discreteExtension S hφ.continuous hN s d hs).norm.pow 3)]
      simp only [T, coreTube_zero_eq_product]
    _ ≤ ∑ j ∈ Finset.range K, 4*(U j+E j) := Finset.sum_le_sum (fun j _ => hj j)
    _ = 4*((∑ j ∈ Finset.range K, U j) + ∑ j ∈ Finset.range K, E j) := by
      rw [← Finset.mul_sum, Finset.sum_add_distrib]
    _ ≤ 4*(C*M+B*D) := by
      exact mul_le_mul_of_nonneg_left (add_le_add hret (hb N hN s d hs K hK)) (by norm_num)
    _ ≤ _ := by nlinarith

/-- Application of the external finite coefficient estimate to the exact
retained index set. The cutoff is required to fit the fixed external setup. -/
theorem retained_indices_external_bound (S : DiscreteSetup)
    {N A Z : ℝ} (q : Finset IntPlane) (K : ℕ) (hK : (K : ℝ) ≤ N^2)
    (hA : A+1 ≤ S.C₂) (s : Finset PacketIndex) (d : PacketIndex → ℂ)
    (hinput : ∀ t : Finset TerminalIndex,
      (∀ i ∈ t, (i.2.2 : ℝ) < N^2 ∧ ‖latticePoint (S.D : ℝ)⁻¹ i.2.1‖ ≤ S.C₂*N^2) →
      (∑ i ∈ t, ‖terminalCoefficient S N s d i‖^3) ≤ Z) :
    (∑ i ∈ q ×ˢ (retainedPositions S ((A+1)*N^2) ×ˢ Finset.range K),
      ‖terminalCoefficient S N s d i‖^3) ≤ Z := by
  apply hinput
  intro i hi
  obtain ⟨hp, hj⟩ := Finset.mem_product.mp (Finset.mem_product.mp hi).2
  constructor
  · exact (by exact_mod_cast (Finset.mem_range.mp hj) : (i.2.2 : ℝ) < K).trans_le hK
  · exact (mem_retainedPositions S _ _ |>.mp hp).trans
      (mul_le_mul_of_nonneg_right hA (sq_nonneg N))

/-- A local cubic integral estimate from the article's actual external
input. This retains the harmless additive one in the scalar factor; conversion
to the precise norm and loss notation of (4.9) is a separate final step. -/
theorem local_discrete_cubed_of_external (S : DiscreteSetup)
    (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (A : ℝ) (hA : A+1 ≤ S.C₂) :
    ∃ C : ℝ, 0 < C ∧ ∀ κ η : ℝ, 0 < κ → κ < 1/10 → 0 < η → η ≤ 1 →
      ∃ P : ℝ, 1 ≤ P ∧ ∀ j : ℕ, 1 ≤ j →
        let N : ℝ := (2 : ℝ)^j
        ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ), discreteLabelsAllowed S N s →
        (∫ y in Metric.closedBall (0 : Plane) (A*N^2) ×ˢ Icc 0 (N^2),
          ‖discreteExtension S N s d y‖^3) ≤
          C * (P*N^(10*κ+η)*Real.log (2+N)^2 + 1) *
            ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨ρ, ζ, hρ, hρ', hζ, hsupp, hζb, hζone, hζs, hform, hφ, hrest⟩
    exact hφ
  obtain ⟨q, C, hC, hc⟩ := local_discrete_cubed_reconstruction S hφ A
  refine ⟨C, hC, ?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P, hP, hp⟩ := hinput hphase κ η hκ hκ' hη hη'
  refine ⟨P, hP, ?_⟩
  intro j hj N s d hs
  let K : ℕ := (2^j)^2
  have hKN : (K : ℝ) = N^2 := by simp [K, N]
  have hN : 1 ≤ N := one_le_pow₀ (by norm_num)
  have hret := retained_indices_external_bound S q K hKN.le hA s d (hp j hj s d hs)
  have h := hc N hN s d hs K hKN.le
  rw [hKN] at h
  apply h.trans
  have hh := mul_le_mul_of_nonneg_left (add_le_add_right hret
    (∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ))) hC.le
  convert hh using 1 <;> ring

end EllipticSquareFunction
