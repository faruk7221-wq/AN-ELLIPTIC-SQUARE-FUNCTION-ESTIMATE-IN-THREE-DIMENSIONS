import EllipticSquareFunction.CoreGeometry

/-! # Integrating the actual sheared packet weights -/

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Integrability is unchanged by a spatial translation depending on time. -/
theorem integrable_sheared_product {f : Plane → ℝ} {g : ℝ → ℝ}
    (hfm : Measurable f) (hgm : Measurable g)
    (hf : Integrable f volume) (hg : Integrable g volume) (V v : Plane) :
    Integrable (fun y : Space => f (y.1 - v + y.2 • V) * g y.2) volume := by
  apply (integrable_prod_iff' (Measurable.aestronglyMeasurable (by fun_prop))).mpr
  constructor
  · apply Filter.Eventually.of_forall
    intro t
    have he (x : Plane) : x - v + t • V = x + (-v + t • V) := by abel
    simpa only [he] using (hf.comp_add_right (-v + t • V)).mul_const (g t)
  · have he (t : ℝ) : (∫ x : Plane, ‖f (x - v + t • V) * g t‖) =
        (∫ x : Plane, ‖f x‖) * ‖g t‖ := by
      simp_rw [norm_mul, integral_mul_const]
      have he (x : Plane) : x - v + t • V = x + (-v + t • V) := by abel
      exact congrArg (fun z : ℝ => z * ‖g t‖)
        (by simpa only [sub_eq_add_neg, add_assoc] using
          integral_add_right_eq_self (fun x : Plane => ‖f x‖) (-v + t • V))
    simpa only [he] using hg.norm.const_mul (∫ x : Plane, ‖f x‖)

/-- The shear has Jacobian one, established here directly by Fubini and
translation invariance of Lebesgue measure. -/
theorem integral_sheared_product {f : Plane → ℝ} {g : ℝ → ℝ}
    (hfm : Measurable f) (hgm : Measurable g)
    (hf : Integrable f volume) (hg : Integrable g volume) (V v : Plane) :
    (∫ y : Space, f (y.1 - v + y.2 • V) * g y.2) =
      (∫ x : Plane, f x) * ∫ t : ℝ, g t := by
  change (∫ y : Space, f (y.1 - v + y.2 • V) * g y.2 ∂volume.prod volume) = _
  rw [integral_prod_symm _ (integrable_sheared_product hfm hgm hf hg V v)]
  have he (t : ℝ) : (∫ x : Plane, f (x - v + t • V) * g t) =
      (∫ x : Plane, f x) * g t := by
    rw [integral_mul_const]
    have he (x : Plane) : x - v + t • V = x + (-v + t • V) := by abel
    simp_rw [he, integral_add_right_eq_self]
  simp_rw [he, integral_const_mul]

def spatialSlab (R : ℝ) : Set Space := {y | y.2 ∈ Icc 0 R}

theorem measurableSet_spatialSlab (R : ℝ) : MeasurableSet (spatialSlab R) :=
  measurableSet_Icc.preimage measurable_snd

theorem integrable_scaled_spatial_bracket {N M : ℝ} (hN : N ≠ 0) (hM : 2 < M) :
    Integrable (fun x : Plane => bracket (N⁻¹ • x) ^ (-M)) volume := by
  have h : Integrable (fun x : Plane => bracket x ^ (-M)) volume :=
    integrable_one_add_norm (by simpa using hM)
  exact h.comp_smul (inv_ne_zero hN)

theorem integrable_spatialWeight_on_slab {N M : ℝ} (hN : N ≠ 0) (hM : 2 < M)
    (R : ℝ) (V v : Plane) :
    IntegrableOn (spatialWeight N M V v) (spatialSlab R) volume := by
  have hg : Integrable ((Icc (0 : ℝ) R).indicator (fun _ => (1 : ℝ))) volume :=
    memLp_one_iff_integrable.mp (memLp_indicator_const 1 measurableSet_Icc 1
      (Or.inr (by simp)))
  have h := integrable_sheared_product (f := fun x : Plane => bracket (N⁻¹ • x) ^ (-M))
    (by unfold bracket; fun_prop) (measurable_const.indicator measurableSet_Icc)
    (integrable_scaled_spatial_bracket hN hM) hg V v
  apply (integrable_indicator_iff (measurableSet_spatialSlab R)).mp
  convert h using 1
  ext y
  by_cases ht : y.2 ∈ Icc 0 R
  · rw [Set.indicator_of_mem (show y ∈ spatialSlab R from ht), Set.indicator_of_mem ht]
    simp [spatialWeight]
  · rw [Set.indicator_of_not_mem (show y ∉ spatialSlab R from ht), Set.indicator_of_not_mem ht]
    simp

/-- The weight has finite `3/2` norm on a finite slab when `3M/2 > 2`. -/
theorem spatialWeight_memLp_on_slab {N M : ℝ} (hN : N ≠ 0) (hM : 2 < M * (3 / 2))
    (R : ℝ) (V v : Plane) :
    MemLp (spatialWeight N M V v) (3 / 2) (volume.restrict (spatialSlab R)) := by
  apply (integrable_norm_rpow_iff (Measurable.aestronglyMeasurable (by unfold spatialWeight bracket; fun_prop))
    (by norm_num) (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne).mp
  have he (y : Space) : ‖spatialWeight N M V v y‖ ^ (3 / 2 : ℝ) =
      spatialWeight N (M * (3 / 2)) V v y := by
    rw [Real.norm_eq_abs, abs_of_nonneg (spatialWeight_nonneg N M V v y)]
    unfold spatialWeight
    rw [← Real.rpow_mul (bracket_pos _).le]
    congr 1
    ring
  simpa only [ENNReal.toReal_div, ENNReal.toReal_ofNat, he] using
    integrable_spatialWeight_on_slab hN hM R V v

theorem spatialDensity_integrable_rpow_on_slab {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N M : ℝ} (hN : N ≠ 0) (hM : 2 < M * (3 / 2)) (R : ℝ) :
    IntegrableOn (fun y => spatialDensity s a V v N M y ^ (3 / 2 : ℝ))
      (spatialSlab R) volume := by
  have h : MemLp (spatialDensity s a V v N M) (3 / 2)
      (volume.restrict (spatialSlab R)) := by
    exact memLp_finset_sum s (fun i _ => (spatialWeight_memLp_on_slab hN hM R (V i) (v i)).const_mul _)
  have hn (y : Space) : 0 ≤ spatialDensity s a V v N M y :=
    Finset.sum_nonneg (fun i _ => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg _ _ _ _ _))
  simpa only [ENNReal.toReal_div, ENNReal.toReal_ofNat, Real.norm_eq_abs,
    abs_of_nonneg (hn _)] using h.integrable_norm_rpow
    (by norm_num) (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne

/-- On the geometric core, the spatial packet weight is at least `2⁻ᴹ`. -/
theorem spatialWeight_lower_on_core {N M R : ℝ} (hN : 0 < N) (hM : 0 ≤ M)
    (V v : Plane) {y : Space} (hy : y ∈ coreTube N R V v) :
    (2 : ℝ) ^ (-M) ≤ spatialWeight N M V v y := by
  have hn : ‖N⁻¹ • (y.1 - v + y.2 • V)‖ ≤ 1 := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hN)]
    have h := mul_le_mul_of_nonneg_left hy.2 (inv_nonneg.mpr hN.le)
    simpa only [inv_mul_cancel₀ hN.ne'] using h
  exact Real.rpow_le_rpow_of_nonpos (bracket_pos _)
    (by unfold bracket; linarith) (neg_nonpos.mpr hM)

theorem coreDensity_le_spatialDensity {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N M : ℝ} (hN : 0 < N) (hM : 0 ≤ M)
    (R : ℝ) (y : Space) :
    (2 : ℝ) ^ (-M) * coreDensity s a V v N R y ≤ spatialDensity s a V v N M y := by
  classical
  unfold coreDensity spatialDensity
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i _
  by_cases hy : y ∈ coreTube N R (V i) (v i)
  · rw [Set.indicator_of_mem hy, mul_comm]
    exact mul_le_mul_of_nonneg_left (spatialWeight_lower_on_core hN hM (V i) (v i) hy)
      (sq_nonneg _)
  · rw [Set.indicator_of_not_mem hy, mul_zero]
    exact mul_nonneg (sq_nonneg _) (spatialWeight_nonneg _ _ _ _ _)

theorem coreDensity_eq_zero_off_slab {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) {y : Space} (hy : y ∉ spatialSlab R) :
    coreDensity s a V v N R y = 0 := by
  apply Finset.sum_eq_zero
  intro i _
  exact Set.indicator_of_not_mem (fun h => hy h.1) _

/-- Equation (4.13), with an explicit valid constant and no integrability
premises. The decay threshold here is the sharp integrability threshold. -/
theorem equation_4_13 {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N M : ℝ} (hN : 0 < N) (hM : 2 < M * (3 / 2)) :
    (Real.pi * (2 : ℝ) ^ (-(M * (3 / 2)))) * N ^ 4 * ∑ i ∈ s, ‖a i‖ ^ 3 ≤
      ∫ y : Space in spatialSlab (N ^ 2), spatialDensity s a V v N M y ^ (3 / 2 : ℝ) := by
  have hM0 : 0 ≤ M := by linarith
  have hp (y : Space) : (2 : ℝ) ^ (-(M * (3 / 2))) *
      coreDensity s a V v N (N ^ 2) y ^ (3 / 2 : ℝ) ≤
      spatialDensity s a V v N M y ^ (3 / 2 : ℝ) := by
    have h := Real.rpow_le_rpow (mul_nonneg (Real.rpow_nonneg (by norm_num) _)
      (coreDensity_nonneg s a V v N (N ^ 2) y))
      (coreDensity_le_spatialDensity s a V v hN hM0 (N ^ 2) y) (by norm_num : (0 : ℝ) ≤ 3 / 2)
    rw [Real.mul_rpow (Real.rpow_nonneg (by norm_num) _)
      (coreDensity_nonneg s a V v N (N ^ 2) y), ← Real.rpow_mul (by norm_num : (0 : ℝ) ≤ 2)] at h
    convert h using 1
    ring_nf
  have hi := integral_mono
    (((coreDensity_integrable_rpow s a V v N (N ^ 2)).restrict).const_mul
      ((2 : ℝ) ^ (-(M * (3 / 2)))))
    (spatialDensity_integrable_rpow_on_slab s a V v hN.ne' hM (N ^ 2)) hp
  rw [integral_const_mul, setIntegral_eq_integral_of_forall_compl_eq_zero] at hi
  · have h := mul_le_mul_of_nonneg_left (equation_4_8 s a V v N hN.le)
      (Real.rpow_nonneg (by norm_num : (0 : ℝ) ≤ 2) (-(M * (3 / 2))))
    convert h.trans hi using 1
    ring
  · intro y hy
    rw [coreDensity_eq_zero_off_slab s a V v N (N ^ 2) hy]
    norm_num

def spatialWeightMass (M : ℝ) : ℝ := ∫ x : Plane, bracket x ^ (-M)
def temporalWeightMass (M : ℝ) : ℝ := ∫ t : ℝ, bracket t ^ (-M)

theorem integrable_scaled_temporal_bracket {R M : ℝ} (hR : R ≠ 0) (hM : 1 < M) :
    Integrable (fun t : ℝ => bracket (t / R) ^ (-M)) volume := by
  have h : Integrable (fun t : ℝ => bracket t ^ (-M)) volume :=
    integrable_one_add_norm (by simpa using hM)
  simpa only [smul_eq_mul, div_eq_inv_mul] using h.comp_smul (inv_ne_zero hR)

/-- The full spacetime packet weights are integrable for `M > 2`. -/
theorem packetWeight_integrable {R M : ℝ} (hR : 0 < R) (hM : 2 < M)
    (V v : Plane) (s : ℝ) : Integrable (packetWeight R M V v s) volume := by
  have ht := (integrable_scaled_temporal_bracket hR.ne' (by linarith : 1 < M)).comp_add_right (-s)
  have h := integrable_sheared_product
    (f := fun x : Plane => bracket ((Real.sqrt R)⁻¹ • x) ^ (-M))
    (g := fun t : ℝ => bracket ((t - s) / R) ^ (-M))
    (by unfold bracket; fun_prop) (by unfold bracket; fun_prop)
    (integrable_scaled_spatial_bracket (Real.sqrt_pos.mpr hR).ne' hM)
    (by simpa only [sub_eq_add_neg] using ht) V (v + s • V)
  convert h using 1
  ext y
  unfold packetWeight
  congr 3
  module

/-- Packet mass is `R²` times one fixed constant, independent of slope,
center, and time origin. -/
theorem integral_packetWeight {R M : ℝ} (hR : 0 < R) (hM : 2 < M)
    (V v : Plane) (s : ℝ) :
    (∫ y : Space, packetWeight R M V v s y) =
      R ^ 2 * (spatialWeightMass M * temporalWeightMass M) := by
  have hf := integrable_scaled_spatial_bracket (Real.sqrt_pos.mpr hR).ne' hM
  have hg := integrable_scaled_temporal_bracket hR.ne' (by linarith : 1 < M)
  have he (y : Space) : packetWeight R M V v s y =
      bracket ((Real.sqrt R)⁻¹ • (y.1 - (v + s • V) + y.2 • V)) ^ (-M) *
      bracket ((y.2 - s) / R) ^ (-M) := by
    unfold packetWeight
    congr 3
    module
  simp_rw [he]
  rw [integral_sheared_product
    (f := fun x : Plane => bracket ((Real.sqrt R)⁻¹ • x) ^ (-M))
    (g := fun t : ℝ => bracket ((t - s) / R) ^ (-M))
    (by unfold bracket; fun_prop) (by unfold bracket; fun_prop)
    hf (by simpa only [sub_eq_add_neg] using hg.comp_add_right (-s)) V (v + s • V)]
  have ht : (∫ t : ℝ, bracket ((t - s) / R) ^ (-M)) =
      R * temporalWeightMass M := by
    have hshift := integral_add_right_eq_self (μ := volume) (fun t : ℝ => bracket (t / R) ^ (-M)) (-s)
    rw [show (∫ t : ℝ, bracket ((t - s) / R) ^ (-M)) =
      ∫ t : ℝ, bracket (t / R) ^ (-M) from (by simpa only [sub_eq_add_neg] using hshift)]
    simpa only [smul_eq_mul, div_eq_inv_mul, Module.finrank_self, pow_one] using
      Measure.integral_comp_inv_smul_of_nonneg volume (fun t : ℝ => bracket t ^ (-M)) hR.le
  rw [ht, Measure.integral_comp_inv_smul_of_nonneg volume
    (fun x : Plane => bracket x ^ (-M)) (Real.sqrt_nonneg R)]
  simp only [finrank_euclideanSpace, Fintype.card_fin, smul_eq_mul, Real.sq_sqrt hR.le]
  unfold spatialWeightMass
  ring

theorem tubeKernel_integrable {R M : ℝ} (hR : 0 < R) (hM : 2 < M) (V : Plane) :
    Integrable (tubeKernel R M V) volume :=
  (packetWeight_integrable hR hM V 0 0).const_mul _

/-- The normalized kernel (6.3) has mass independent of `R` and `V`. -/
theorem integral_tubeKernel {R M : ℝ} (hR : 0 < R) (hM : 2 < M) (V : Plane) :
    (∫ y : Space, tubeKernel R M V y) = spatialWeightMass M * temporalWeightMass M := by
  unfold tubeKernel
  rw [integral_const_mul, integral_packetWeight hR hM]
  field_simp

theorem packetWeight_memLp {R M : ℝ} (hR : 0 < R) (hM : 2 < M * (3 / 2))
    (V v : Plane) (s : ℝ) : MemLp (packetWeight R M V v s) (3 / 2) volume := by
  apply (integrable_norm_rpow_iff (Measurable.aestronglyMeasurable
    (by unfold packetWeight bracket; fun_prop))
    (by norm_num) (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne).mp
  have he (y : Space) : ‖packetWeight R M V v s y‖ ^ (3 / 2 : ℝ) =
      packetWeight R (M * (3 / 2)) V v s y := by
    rw [Real.norm_eq_abs, abs_of_nonneg (packetWeight_nonneg R M V v s y)]
    unfold packetWeight
    rw [Real.mul_rpow (Real.rpow_nonneg (bracket_pos _).le _) (Real.rpow_nonneg (bracket_pos _).le _)]
    simp_rw [← Real.rpow_mul (bracket_pos _).le]
    congr 2 <;> ring
  simpa only [ENNReal.toReal_div, ENNReal.toReal_ofNat, he] using packetWeight_integrable hR hM V v s

theorem packetDensity_memLp {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (t₀ : ι → ℝ) {R M : ℝ} (hR : 0 < R) (hM : 2 < M * (3 / 2)) :
    MemLp (packetDensity s a V v t₀ R M) (3 / 2) volume :=
  memLp_finset_sum s (fun i _ => (packetWeight_memLp hR hM (V i) (v i) (t₀ i)).const_mul _)

end EllipticSquareFunction
