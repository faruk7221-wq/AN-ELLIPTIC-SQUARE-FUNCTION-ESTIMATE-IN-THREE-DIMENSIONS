import EllipticSquareFunction.SurfaceCaps

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1800000

theorem surface_chart_separation (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) :
    ∃ c : ℝ, 0 < c ∧ ∀ p q : Space,
      (A p).1 ∈ G.K → (A q).1 ∈ G.K →
      (A p).2=G.φ (A p).1 → (A q).2=G.φ (A q).1 →
      c*‖p-q‖ ≤ ‖(A p).1-(A q).1‖ := by
  obtain ⟨H,hH,hphase⟩ := graph_phase_compact_bound G hG
  let B := affineSize A.symm*(1+H)+1
  have hB : 0 < B := by
    have ha := affineSize_nonneg A.symm
    dsimp [B]
    positivity
  refine ⟨B⁻¹,inv_pos.mpr hB,?_⟩
  intro p q hp hq hep heq
  have hφ := hphase _ hp _ hq
  have hprod : ‖A p-A q‖ ≤ (1+H)*‖(A p).1-(A q).1‖ := by
    rw [Prod.norm_def]
    simp only [Prod.fst_sub,Prod.snd_sub,Real.norm_eq_abs,hep,heq]
    apply max_le <;> nlinarith [norm_nonneg ((A p).1-(A q).1)]
  have hbound : ‖p-q‖ ≤ B*‖(A p).1-(A q).1‖ := by
    calc
      _ = ‖A.symm (A p)-A.symm (A q)‖ := by simp
      _ ≤ affineSize A.symm*‖A p-A q‖ := affine_norm_sub_le _ _ _
      _ ≤ affineSize A.symm*((1+H)*‖(A p).1-(A q).1‖) :=
        mul_le_mul_of_nonneg_left hprod (affineSize_nonneg _)
      _ ≤ _ := by dsimp [B]; nlinarith [norm_nonneg ((A p).1-(A q).1)]
  have hh : ‖p-q‖/B ≤ ‖(A p).1-(A q).1‖ :=
    (div_le_iff₀ hB).mpr (by simpa only [mul_comm] using hbound)
  simpa only [div_eq_mul_inv,mul_comm] using hh

/-- Surface distance caps, including one-sided boundary caps, fit inside
fixed enlarged graph caps. No lower interior box is required. -/
theorem surface_chart_caps (S : SurfaceSetup) (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) {W : Set Space}
    (hgraph : ∀ q ∈ S.carrier ∩ W, (A q).1 ∈ G.K ∧ (A q).2=G.φ (A q).1) :
    ∃ r D : ℝ, 0 < r ∧ 0 < D ∧ ∀ δ : ℝ, 0 ≤ δ → δ ≤ 1 → S.C₀*δ < r →
      ∀ p : Space, (∀ q ∈ S.carrier, ‖q-p‖ ≤ S.C₀*δ → q ∈ W) →
      ∀ z ∈ surfaceCap S.carrier p δ S.C₀,
        A z ∈ cap G.φ (A p).1 δ D := by
  obtain ⟨r₀,H,hr₀,hH,hphase⟩ := graph_phase_local_bound G hG
  let a := affineSize A
  have ha : 0 ≤ a := affineSize_nonneg A
  have hap : 0 < a+1 := by linarith
  let D := a*S.C₀*(H+3)+1
  have hD : 0 < D := by dsimp [D]; have := S.C₀_pos; positivity
  refine ⟨r₀/(a+1),D,div_pos hr₀ hap,hD,?_⟩
  intro δ hδ hδ1 hsmall p hW z hz
  obtain ⟨q,hq,hqp,hzq⟩ := surfaceCap_nearby_point S.compact_carrier S.C₀_pos.le hz
  obtain ⟨hqK,hqgraph⟩ := hgraph q ⟨hq,hW q hq hqp⟩
  have hδsq : δ^2 ≤ δ := by nlinarith
  have he : ‖A z-A q‖ ≤ a*S.C₀*δ^2 :=
    (affine_norm_sub_le A z q).trans (by
      calc
        _ ≤ a*(S.C₀*δ^2) := mul_le_mul_of_nonneg_left hzq ha
        _ = _ := by ring)
  have hxe : ‖(A z).1-(A q).1‖ ≤ a*S.C₀*δ^2 := (norm_fst_le _).trans he
  have hte : |(A z).2-G.φ (A q).1| ≤ a*S.C₀*δ^2 := by
    have ht := (norm_snd_le _).trans he
    simpa only [Prod.snd_sub,Real.norm_eq_abs,hqgraph] using ht
  have hnear : ‖(A z).1-(A q).1‖ < r₀ := by
    have hs := (lt_div_iff₀ hap).mp hsmall
    have hnon : 0 ≤ S.C₀*δ := mul_nonneg S.C₀_pos.le hδ
    have hsq := mul_le_mul_of_nonneg_left hδsq (mul_nonneg ha S.C₀_pos.le)
    nlinarith
  have hlip := hphase (A q).1 hqK (A z).1 hnear
  constructor
  · have hdist : ‖z-p‖ ≤ S.C₀*δ^2+S.C₀*δ := by
      have htri : ‖z-p‖ ≤ ‖z-q‖+‖q-p‖ := by
        simpa only [dist_eq_norm] using dist_triangle z q p
      exact htri.trans (add_le_add hzq hqp)
    calc
      _ ≤ ‖A z-A p‖ := norm_fst_le _
      _ ≤ a*‖z-p‖ := affine_norm_sub_le _ _ _
      _ ≤ a*(S.C₀*δ^2+S.C₀*δ) := mul_le_mul_of_nonneg_left hdist ha
      _ ≤ D*δ := by
        have hsq := mul_le_mul_of_nonneg_left hδsq (mul_nonneg ha S.C₀_pos.le)
        have hnon := mul_nonneg (mul_nonneg (mul_nonneg ha S.C₀_pos.le) hH.le) hδ
        dsimp [D]
        nlinarith
  · have hh := hlip.trans (mul_le_mul_of_nonneg_left hxe hH.le)
    calc
      _ ≤ |(A z).2-G.φ (A q).1|+|G.φ (A q).1-G.φ (A z).1| := abs_sub_le _ _ _
      _ ≤ a*S.C₀*δ^2+H*(a*S.C₀*δ^2) := by
        rw [abs_sub_comm (G.φ (A q).1)]
        exact add_le_add hte hh
      _ ≤ D*δ^2 := by
        dsimp [D]
        nlinarith [mul_nonneg (mul_nonneg ha S.C₀_pos.le) (sq_nonneg δ),sq_nonneg δ]

end EllipticSquareFunction
