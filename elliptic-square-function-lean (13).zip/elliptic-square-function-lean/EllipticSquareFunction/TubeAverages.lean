import EllipticSquareFunction.UniformTubeComparison

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000
attribute [local instance] space_volume_add_left_invariant

/-- Translation covariance of the genuine Euclidean tubes. -/
theorem geometricTube_add (x a b z : Space) (r : ℝ) :
    x+z∈geometricTube (x+a) (x+b) r ↔ z∈geometricTube a b r := by
  have he (s : ℝ) : x+z-((1-s) • (x+a)+s • (x+b))=z-((1-s) • a+s • b) := by module
  simp only [geometricTube,mem_setOf_eq,he]

theorem volume_geometricTube_add (x a b : Space) (r : ℝ) :
    volume (geometricTube (x+a) (x+b) r)=volume (geometricTube a b r) := by
  have he : (fun z => x+z) ⁻¹' geometricTube (x+a) (x+b) r=geometricTube a b r := by
    ext z
    exact geometricTube_add x a b z r
  rw [← he,measure_preimage_add]

/-- A positive average over a subset is controlled by the larger-set average
when their volumes are comparable. This holds without measurability or
integrability assumptions on the nonnegative datum. -/
theorem set_average_le_of_volume_comparison (A B : Set Space) (hAB : A⊆B)
    (hA₀ : volume A≠0) (hAfin : volume A≠⊤) (C : ℝ≥0∞) (hCfin : C≠⊤)
    (hvol : volume B≤C*volume A) (g : Space → ℝ≥0∞) :
    (volume A)⁻¹*(∫⁻ z in A, g z)≤C*((volume B)⁻¹*(∫⁻ z in B, g z)) := by
  have hB₀ : volume B≠0 := by
    intro hb
    apply hA₀
    exact le_antisymm (hb ▸ measure_mono hAB) bot_le
  have hBfin : volume B≠⊤ := ne_top_of_le_ne_top (ENNReal.mul_ne_top hCfin hAfin) hvol
  have hi : (volume A)⁻¹≤C*(volume B)⁻¹ := by
    change (volume A)⁻¹≤C/volume B
    apply (ENNReal.le_div_iff_mul_le (Or.inl hB₀) (Or.inl hBfin)).mpr
    have hh := mul_le_mul_left' hvol (volume A)⁻¹
    simpa only [mul_comm,mul_left_comm,mul_assoc,ENNReal.inv_mul_cancel hA₀ hAfin,ENNReal.mul_inv_cancel hA₀ hAfin,mul_one] using hh
  have hh := mul_le_mul' hi (lintegral_mono_set (μ := volume) (f := g) hAB)
  simpa only [mul_assoc] using hh

/-- A translated Euclidean tube average is among the tubes in Nikodym's
supremum whenever its central axis has the prescribed length. -/
theorem translated_tube_average_le_nikodym (h : Space → ℝ) (x a b : Space)
    {r τ L : ℝ} (hr : r=τ*L) (hL : euclideanLength (b-a)=L)
    (hzero : (0:Space)∈geometricTube a b r) :
    (volume (geometricTube a b r))⁻¹*
      (∫⁻ z in geometricTube a b r, ENNReal.ofReal |h (x+z)|) ≤ nikodym τ L h x := by
  have hm := (measurePreserving_add_left (volume : Measure Space) x).setLIntegral_comp_preimage_emb
    (Homeomorph.addLeft x).measurableEmbedding (fun z => ENNReal.ofReal |h z|)
    (geometricTube (x+a) (x+b) r)
  have he : (fun z => x+z) ⁻¹' geometricTube (x+a) (x+b) r=geometricTube a b r := by
    ext z
    exact geometricTube_add x a b z r
  rw [he] at hm
  rw [hm,← volume_geometricTube_add x a b r]
  change tubeAverage h (geometricTube (x+a) (x+b) r)≤_
  rw [hr]
  apply le_iSup_of_le (x+a)
  apply le_iSup_of_le (x+b)
  apply le_iSup_of_le (show euclideanLength ((x+b)-(x+a))=L by
    simpa only [add_sub_add_left_eq_sub] using hL)
  apply le_iSup_of_le (show x∈geometricTube (x+a) (x+b) (τ*L) by
    rw [← hr]
    simpa only [add_zero] using (geometricTube_add x a b 0 r).mpr hzero)
  exact le_rfl

/-- Uniform pointwise Nikodym control of all symmetric sheared tube averages
with a fixed bound for their slopes. No L3 maximal estimate is assumed here. -/
theorem symmetric_tube_average_le_nikodym (h : Space → ℝ) (x : Space)
    {r T F : ℝ} (hr : 0<r) (hT : 0<T) (hrT : r≤T) (hF : 0≤F)
    (V : Plane) (hV : ‖V‖≤F) :
    (volume (symmetricTube r T V))⁻¹*
      (∫⁻ z in symmetricTube r T V, ENNReal.ofReal |h (x+z)|) ≤
      ENNReal.ofReal (2*(1+F)^3)*nikodym (r/(2*(1+F)*T)) (2*(1+F)*T) h x := by
  let U := uniformTubeHalfTime T F V
  let B := geometricTube (U • V,-U) (-U • V,U) r
  have hA₀ : volume (symmetricTube r T V)≠0 := by
    rw [volume_symmetricTube]
    exact mul_ne_zero (mul_ne_zero (pow_ne_zero _ (ENNReal.ofReal_pos.mpr hr).ne')
      (ENNReal.ofReal_pos.mpr Real.pi_pos).ne') (ENNReal.ofReal_pos.mpr (by positivity : 0<2*T)).ne'
  have hAfin : volume (symmetricTube r T V)≠⊤ := by
    rw [volume_symmetricTube]
    exact ENNReal.mul_ne_top (ENNReal.mul_ne_top (ENNReal.pow_ne_top ENNReal.ofReal_ne_top)
      ENNReal.ofReal_ne_top) ENNReal.ofReal_ne_top
  have hh := set_average_le_of_volume_comparison (symmetricTube r T V) B
    (symmetricTube_subset_uniform_geometricTube hT hF V hV) hA₀ hAfin
    (ENNReal.ofReal (2*(1+F)^3)) ENNReal.ofReal_ne_top
    (volume_uniform_geometricTube_le hr.le hT hrT hF V hV) (fun z => ENNReal.ofReal |h (x+z)|)
  apply hh.trans
  apply mul_le_mul_left'
  apply translated_tube_average_le_nikodym
  · exact (div_mul_cancel₀ r (by positivity : 2*(1+F)*T≠0)).symm
  · exact uniform_tube_axis_length hT hF V hV
  · apply symmetricTube_subset_uniform_geometricTube hT hF V hV
    constructor
    · simpa only [Prod.snd_zero,abs_zero] using hT.le
    · simpa only [Prod.fst_zero,Prod.snd_zero,zero_smul,zero_add,norm_zero] using hr.le

end EllipticSquareFunction
