import EllipticSquareFunction.AffineSampling

noncomputable section
namespace EllipticSquareFunction

/-- The three integer coordinates are exactly a spatial pair and a time integer. -/
def samplingIndexEquiv : (Fin 3 → ℤ) ≃ IntPlane × ℤ :=
  (Fin.insertNthEquiv (fun _ : Fin 3 => ℤ) 0).symm.trans (Equiv.prodComm _ _)

theorem samplingIndexEquiv_apply (n : Fin 3 → ℤ) :
    samplingIndexEquiv n=((fun i => n i.succ),n 0) := by
  simp [samplingIndexEquiv]
  rfl

/-- Reindex the proved Fourier HasSum by the literal spatial/time sample grid. -/
theorem sampling_hasSum_reindex (r R D : ℝ) (V : Plane) (F : Space → ℂ) (z : ℂ) :
    HasSum (fun n : Fin 3 → ℤ => F (unshearScale r R V (spaceFrequencyLattice D n))) z ↔
    HasSum (fun i : IntPlane × ℤ =>
      F (samplePoint r R D D V (latticePoint 1 i.1) i.2)) z := by
  have hh := samplingIndexEquiv.hasSum_iff (f := fun i : IntPlane × ℤ =>
    F (samplePoint r R D D V (latticePoint 1 i.1) i.2)) (a := z)
  simpa only [Function.comp_def,samplingIndexEquiv_apply,← affine_dual_lattice_sample] using hh

/-- The exact absolute-value normalization in (6.10), for A=B=D. -/
theorem sampling_coefficient_norm {D : ℝ} (hD : 0<D) (u : ℂ) :
    ‖(((D^3)⁻¹:ℝ):ℂ)*u‖=(D^3)⁻¹*‖u‖ := by
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr (pow_pos hD 3))]

end EllipticSquareFunction
