import EllipticSquareFunction.Definitions

/-! # Fourier reconstruction by L² pairing

This module starts from Mathlib's proved Fourier basis on a finite-dimensional
torus, and transfers its reconstruction identity to ordinary frequency boxes.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal ComplexConjugate
namespace EllipticSquareFunction

attribute [local instance] Real.fact_zero_lt_one

def torusMeasure (d : Type*) [Fintype d] : Measure (UnitAddTorus d) :=
  Measure.pi (fun _ => (AddCircle.haarAddCircle : Measure UnitAddCircle))

theorem memLp_conj {α : Type*} [MeasurableSpace α] {μ : Measure α}
    {f : α → ℂ} {p : ℝ≥0∞} (hf : MemLp f p μ) : MemLp (fun x => conj (f x)) p μ := by
  apply hf.of_le
  · exact Complex.continuous_conj.comp_aestronglyMeasurable hf.aestronglyMeasurable
  · filter_upwards with x
    simp

/-- The bilinear Parseval formula, with the plus sign in analysis and minus
sign in synthesis used in (4.5). It includes convergence of the scalar series. -/
theorem torus_bilinear_reconstruction {d : Type*} [Fintype d]
    {f g : UnitAddTorus d → ℂ} (hf : MemLp f 2 (torusMeasure d))
    (hg : MemLp g 2 (torusMeasure d)) :
    HasSum (fun n : d → ℤ =>
      (∫ z, f z * UnitAddTorus.mFourier n z ∂torusMeasure d) *
      (∫ z, g z * UnitAddTorus.mFourier (-n) z ∂torusMeasure d))
      (∫ z, f z * g z ∂torusMeasure d) := by
  let F := (memLp_conj hf).toLp (fun z => conj (f z))
  let G := hg.toLp g
  have h := UnitAddTorus.hasSum_prod_mFourierCoeff F G
  have hF (n : d → ℤ) : conj (UnitAddTorus.mFourierCoeff F n) =
      ∫ z, f z * UnitAddTorus.mFourier n z ∂torusMeasure d := by
    unfold UnitAddTorus.mFourierCoeff
    rw [← integral_conj]
    apply integral_congr_ae
    filter_upwards [(memLp_conj hf).coeFn_toLp] with z hz
    simp [F, hz, smul_eq_mul, ← UnitAddTorus.mFourier_neg, mul_comm]
  have hG (n : d → ℤ) : UnitAddTorus.mFourierCoeff G n =
      ∫ z, g z * UnitAddTorus.mFourier (-n) z ∂torusMeasure d := by
    apply integral_congr_ae
    filter_upwards [hg.coeFn_toLp] with z hz
    simp [G, hz, mul_comm]
  have hFG : (∫ z, conj (F z) * G z ∂torusMeasure d) =
      ∫ z, f z * g z ∂torusMeasure d := by
    apply integral_congr_ae
    filter_upwards [(memLp_conj hf).coeFn_toLp, hg.coeFn_toLp] with z hz hw
    simp [F, G, hz, hw]
  have hh : HasSum (fun n : d → ℤ => conj (UnitAddTorus.mFourierCoeff F n) *
      UnitAddTorus.mFourierCoeff G n) (∫ z, conj (F z) * G z ∂torusMeasure d) := h
  simpa only [hF, hG, hFG] using hh

def unitBox {d : Type*} (a : d → ℝ) : Set (d → ℝ) :=
  Set.univ.pi (fun i => Ioc (a i) (a i + 1))

def quotientCoordinates {d : Type*} (x : d → ℝ) : UnitAddTorus d :=
  fun i => (x i : UnitAddCircle)

def representativeCoordinates {d : Type*} (a : d → ℝ) (z : UnitAddTorus d) : d → ℝ :=
  fun i => (AddCircle.measurableEquivIoc 1 (a i) (z i) : ℝ)

theorem measurable_representativeCoordinates {d : Type*} (a : d → ℝ) :
    Measurable (representativeCoordinates a) := by
  exact measurable_pi_lambda _ (fun i => measurable_subtype_coe.comp
    ((AddCircle.measurableEquivIoc 1 (a i)).measurable.comp (measurable_pi_apply i)))

theorem representativeCoordinates_mem {d : Type*} (a : d → ℝ) (z : UnitAddTorus d) :
    representativeCoordinates a z ∈ unitBox a := by
  intro i _
  exact (AddCircle.measurableEquivIoc 1 (a i) (z i)).property

theorem representative_quotientCoordinates {d : Type*} (a x : d → ℝ) (hx : x ∈ unitBox a) :
    representativeCoordinates a (quotientCoordinates x) = x := by
  funext i
  exact AddCircle.liftIoc_coe_apply (f := id) (hx i (mem_univ i))

theorem quotientCoordinates_measurePreserving {d : Type*} [Fintype d] (a : d → ℝ) :
    MeasurePreserving (quotientCoordinates (d := d)) (volume.restrict (unitBox a)) (torusMeasure d) := by
  have h (i : d) : MeasurePreserving (fun x : ℝ => (x : UnitAddCircle))
      (volume.restrict (Ioc (a i) (a i + 1))) AddCircle.haarAddCircle := by
    simpa only [AddCircle.volume_eq_smul_haarAddCircle, ENNReal.ofReal_one, one_smul] using
      UnitAddCircle.measurePreserving_mk (a i)
  simpa only [← Measure.restrict_pi_pi, ← volume_pi, unitBox, torusMeasure, quotientCoordinates] using
    measurePreserving_pi _ _ h

/-- Integration on the torus is integration over one Euclidean unit box. -/
theorem integral_quotientCoordinates {d : Type*} [Fintype d] (a : d → ℝ)
    {F : UnitAddTorus d → ℂ} (hF : Measurable F) :
    (∫ x in unitBox a, F (quotientCoordinates x)) = ∫ z, F z ∂torusMeasure d := by
  have hq := quotientCoordinates_measurePreserving a
  have h := integral_map hq.aemeasurable (hF.aestronglyMeasurable (μ := Measure.map quotientCoordinates
    (volume.restrict (unitBox a))))
  rw [hq.map_eq] at h
  exact h.symm

theorem memLp_representativeCoordinates {d : Type*} [Fintype d]
    (a : d → ℝ) {f : (d → ℝ) → ℂ} (hfm : Measurable f)
    (hf : MemLp f 2 (volume.restrict (unitBox a))) :
    MemLp (f ∘ representativeCoordinates a) 2 (torusMeasure d) := by
  have hq := quotientCoordinates_measurePreserving a
  have hm := hfm.comp (measurable_representativeCoordinates a)
  have h := memLp_map_measure_iff (p := 2) (hm.aestronglyMeasurable
    (μ := Measure.map quotientCoordinates (volume.restrict (unitBox a)))) hq.aemeasurable
  rw [hq.map_eq] at h
  apply h.mpr
  apply hf.ae_eq
  filter_upwards [ae_restrict_mem (MeasurableSet.univ_pi (fun _ => measurableSet_Ioc))] with x hx
  simp only [Function.comp_apply, representative_quotientCoordinates a x hx]

def boxCharacter {d : Type*} [Fintype d] (n : d → ℤ) (x : d → ℝ) : ℂ :=
  oscillation (∑ i, (n i : ℝ) * x i)

theorem mFourier_quotientCoordinates {d : Type*} [Fintype d] (n : d → ℤ) (x : d → ℝ) :
    UnitAddTorus.mFourier n (quotientCoordinates x) = boxCharacter n x := by
  classical
  simp only [UnitAddTorus.mFourier, ContinuousMap.coe_mk, quotientCoordinates,
    fourier_coe_apply, Complex.ofReal_one, div_one, ← Complex.exp_sum, boxCharacter, oscillation,
    Complex.ofReal_mul, Complex.ofReal_sum, Complex.ofReal_intCast, Complex.ofReal_ofNat]
  congr 1
  simp only [Finset.mul_sum, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  ring

theorem integral_representative_character {d : Type*} [Fintype d]
    (a : d → ℝ) {f : (d → ℝ) → ℂ} (hfm : Measurable f) (n : d → ℤ) :
    (∫ z, f (representativeCoordinates a z) * UnitAddTorus.mFourier n z ∂torusMeasure d) =
      ∫ x in unitBox a, f x * boxCharacter n x := by
  rw [← integral_quotientCoordinates a
    (F := fun z => f (representativeCoordinates a z) * UnitAddTorus.mFourier n z)
    (hfm.comp (measurable_representativeCoordinates a) |>.mul
      (UnitAddTorus.mFourier n).continuous.measurable)]
  apply setIntegral_congr_fun (MeasurableSet.univ_pi (fun _ => measurableSet_Ioc))
  intro x hx
  dsimp only
  rw [representative_quotientCoordinates a x hx, mFourier_quotientCoordinates]

/-- Exact reconstruction on a unit Euclidean box, tested against an arbitrary
`L²` function. Both the identity and convergence are proved. -/
theorem unitBox_bilinear_reconstruction {d : Type*} [Fintype d]
    (a : d → ℝ) {f g : (d → ℝ) → ℂ} (hfm : Measurable f) (hgm : Measurable g)
    (hf : MemLp f 2 (volume.restrict (unitBox a)))
    (hg : MemLp g 2 (volume.restrict (unitBox a))) :
    HasSum (fun n : d → ℤ =>
      (∫ x in unitBox a, f x * boxCharacter n x) *
      (∫ x in unitBox a, g x * boxCharacter (-n) x))
      (∫ x in unitBox a, f x * g x) := by
  have h := torus_bilinear_reconstruction (memLp_representativeCoordinates a hfm hf)
    (memLp_representativeCoordinates a hgm hg)
  simp only [Function.comp_apply, integral_representative_character a hfm,
    integral_representative_character a hgm] at h
  have he : (∫ z, f (representativeCoordinates a z) * g (representativeCoordinates a z) ∂torusMeasure d) =
      ∫ x in unitBox a, f x * g x := by
    rw [← integral_quotientCoordinates a
      (F := fun z => f (representativeCoordinates a z) * g (representativeCoordinates a z))
      ((hfm.comp (measurable_representativeCoordinates a)).mul
        (hgm.comp (measurable_representativeCoordinates a)))]
    apply setIntegral_congr_fun (MeasurableSet.univ_pi (fun _ => measurableSet_Ioc))
    intro x hx
    dsimp only
    rw [representative_quotientCoordinates a x hx]
  rwa [he] at h

theorem continuous_memLp_unitBox {d : Type*} [Fintype d] (a : d → ℝ)
    {f : (d → ℝ) → ℂ} (hf : Continuous f) : MemLp f 2 (volume.restrict (unitBox a)) := by
  apply (integrable_norm_rpow_iff hf.aestronglyMeasurable (by norm_num) (by norm_num)).mp
  have hi : IntegrableOn (fun x => ‖f x‖ ^ 2) (Icc a (fun i => a i + 1)) volume :=
    (hf.norm.pow 2).continuousOn.integrableOn_compact isCompact_Icc
  have hs : unitBox a ⊆ Icc a (fun i => a i + 1) := by
    intro x hx
    exact ⟨fun i => (hx i (mem_univ i)).1.le, fun i => (hx i (mem_univ i)).2⟩
  simpa only [ENNReal.toReal_ofNat, Real.rpow_two] using hi.mono_set hs

open scoped Pointwise

def scaledBox {d : Type*} (a : d → ℝ) (D : ℝ) : Set (d → ℝ) := D • unitBox a

def scaledBoxCharacter {d : Type*} [Fintype d] (D : ℝ) (n : d → ℤ) (x : d → ℝ) : ℂ :=
  boxCharacter n (D⁻¹ • x)

theorem scaledBoxCharacter_smul {d : Type*} [Fintype d] {D : ℝ} (hD : D ≠ 0)
    (n : d → ℤ) (x : d → ℝ) : scaledBoxCharacter D n (D • x) = boxCharacter n x := by
  simp [scaledBoxCharacter, smul_smul, hD]

theorem integral_scaledBox_character {d : Type*} [Fintype d]
    (a : d → ℝ) {D : ℝ} (hD : 0 < D) (f : (d → ℝ) → ℂ) (n : d → ℤ) :
    (∫ x in unitBox a, f (D • x) * boxCharacter n x) =
      ((D ^ Fintype.card d)⁻¹ : ℝ) • ∫ x in scaledBox a D, f x * scaledBoxCharacter D n x := by
  have h := Measure.setIntegral_comp_smul_of_pos volume
    (fun x => f x * scaledBoxCharacter D n x) (unitBox a) hD
  simpa only [scaledBoxCharacter_smul hD.ne', Module.finrank_pi, Module.finrank_self,
    Finset.sum_const, smul_eq_mul, nsmul_eq_mul, mul_one, Nat.cast_id, scaledBox] using h

/-- Reconstruction on a box of side `D` has exactly the factor `D⁻ᵈ`.
The functions need only be continuous; no Fourier coefficient decay is assumed. -/
theorem scaledBox_bilinear_reconstruction {d : Type*} [Fintype d]
    (a : d → ℝ) {D : ℝ} (hD : 0 < D) {f g : (d → ℝ) → ℂ}
    (hf : Continuous f) (hg : Continuous g) :
    HasSum (fun n : d → ℤ => ((D ^ Fintype.card d)⁻¹ : ℝ) •
      ((∫ x in scaledBox a D, f x * scaledBoxCharacter D n x) *
        (∫ x in scaledBox a D, g x * scaledBoxCharacter D (-n) x)))
      (∫ x in scaledBox a D, f x * g x) := by
  have hfD : Continuous (fun x => f (D • x)) := hf.comp (continuous_const.smul continuous_id)
  have hgD : Continuous (fun x => g (D • x)) := hg.comp (continuous_const.smul continuous_id)
  have h := unitBox_bilinear_reconstruction a hfD.measurable hgD.measurable
    (continuous_memLp_unitBox a hfD) (continuous_memLp_unitBox a hgD)
  simp only [integral_scaledBox_character a hD] at h
  have he : (∫ x in unitBox a, f (D • x) * g (D • x)) =
      ((D ^ Fintype.card d)⁻¹ : ℝ) • ∫ x in scaledBox a D, f x * g x := by
    simpa only [Module.finrank_pi, Module.finrank_self, Finset.sum_const,
      nsmul_eq_mul, mul_one, Nat.cast_id, scaledBox] using
      Measure.setIntegral_comp_smul_of_pos volume (fun x => f x * g x) (unitBox a) hD
  rw [he] at h
  have h' := h.mul_left ((D ^ Fintype.card d : ℝ) : ℂ)
  have hDn : ((D ^ Fintype.card d : ℝ) : ℂ) ≠ 0 := by exact_mod_cast pow_ne_zero _ hD.ne'
  have hcD : (D : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hD.ne'
  convert h' using 1
  · funext n
    simp only [Complex.real_smul, Complex.ofReal_inv]
    field_simp [hcD]
    ring
  · simp only [Complex.real_smul, Complex.ofReal_inv]
    field_simp [hcD]

theorem supported_box_bilinear_reconstruction {d : Type*} [Fintype d]
    (a : d → ℝ) {D : ℝ} (hD : 0 < D) {f g : (d → ℝ) → ℂ}
    (hf : Continuous f) (hg : Continuous g)
    (hfs : Function.support f ⊆ scaledBox a D) (hgs : Function.support g ⊆ scaledBox a D) :
    HasSum (fun n : d → ℤ => ((D ^ Fintype.card d)⁻¹ : ℝ) •
      ((∫ x, f x * scaledBoxCharacter D n x) * (∫ x, g x * scaledBoxCharacter D (-n) x)))
      (∫ x, f x * g x) := by
  have hfc (n : d → ℤ) : (∫ x in scaledBox a D, f x * scaledBoxCharacter D n x) =
      ∫ x, f x * scaledBoxCharacter D n x := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro x hx
    have hz : f x = 0 := by by_contra h; exact hx (hfs h)
    rw [hz, zero_mul]
  have hgc (n : d → ℤ) : (∫ x in scaledBox a D, g x * scaledBoxCharacter D n x) =
      ∫ x, g x * scaledBoxCharacter D n x := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro x hx
    have hz : g x = 0 := by by_contra h; exact hx (hgs h)
    rw [hz, zero_mul]
  have hfg : (∫ x in scaledBox a D, f x * g x) = ∫ x, f x * g x := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro x hx
    have hz : f x = 0 := by by_contra h; exact hx (hfs h)
    rw [hz, zero_mul]
  simpa only [hfc, hgc, hfg] using scaledBox_bilinear_reconstruction a hD hf hg

end EllipticSquareFunction
