import EllipticSquareFunction.ExternalInputs
import EllipticSquareFunction.Weights

/-!
# Uniform translated-lattice estimates

The constants in these theorems are independent of the translation.
The two-dimensional summability input is a proved Mathlib theorem obtained
by counting integer lattice shells, not an extra hypothesis of this project.
-/

noncomputable section
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

@[simp]
theorem latticePoint_zero (a : ℝ) : latticePoint a 0 = 0 := by
  ext i
  simp [latticePoint]

theorem latticePoint_sub (a : ℝ) (m n : IntPlane) :
    latticePoint a (m - n) = latticePoint a m - latticePoint a n := by
  ext i
  simp [latticePoint, mul_sub]

theorem lattice_sup_norm_le (m : IntPlane) : ‖m‖ ≤ ‖latticePoint 1 m‖ := by
  apply (pi_norm_le_iff_of_nonneg (norm_nonneg _)).2
  intro i
  simpa [latticePoint] using PiLp.norm_apply_le (latticePoint 1 m) i

theorem regularized_lattice_summable {b : ℝ} (hb : 2 < b) :
    Summable (fun m : IntPlane => bracket (latticePoint 1 m) ^ (-b)) := by
  classical
  have hs := (hasSum_ite_eq (0 : IntPlane) (1 : ℝ)).summable.add
    (EisensteinSeries.summable_one_div_norm_rpow hb)
  apply hs.of_nonneg_of_le (fun m => Real.rpow_nonneg (bracket_pos _).le _)
  intro m
  by_cases hm : m = 0
  · simp [hm, bracket, Real.zero_rpow (by linarith : -b ≠ 0)]
  · simp only [if_neg hm, zero_add]
    exact Real.rpow_le_rpow_of_nonpos (norm_pos_iff.mpr hm)
      (by have := lattice_sup_norm_le m; unfold bracket; linarith)
      (by linarith)

def floorPoint (u : Plane) : IntPlane := fun i => ⌊u i⌋

theorem norm_sub_floorPoint_le (u : Plane) :
    ‖u - latticePoint 1 (floorPoint u)‖ ≤ 2 := by
  have hc (i : Fin 2) : ‖(u - latticePoint 1 (floorPoint u)) i‖ ≤ 1 := by
    simpa [latticePoint, floorPoint, Real.norm_eq_abs, Int.self_sub_floor,
      abs_of_nonneg (Int.fract_nonneg (u i))] using (Int.fract_lt_one (u i)).le
  rw [EuclideanSpace.norm_eq]
  apply Real.sqrt_le_iff.mpr
  refine ⟨by norm_num, ?_⟩
  calc
    _ ≤ ∑ _ : Fin 2, (1 : ℝ) := by
      apply Finset.sum_le_sum
      intro i _
      have := hc i
      nlinarith [norm_nonneg ((u - latticePoint 1 (floorPoint u)) i)]
    _ ≤ _ := by norm_num

/-- A translated lattice weight is bounded by a translate of a single
summable sequence. The numerical constant `3` is nonoptimal. -/
theorem translated_lattice_majorant (u : Plane) (m : IntPlane) {b : ℝ} (hb : 0 ≤ b) :
    bracket (u - latticePoint 1 m) ^ (-b) ≤
      3 ^ b * bracket (latticePoint 1 (m - floorPoint u)) ^ (-b) := by
  let q := latticePoint 1 (floorPoint u)
  have htri := bracket_sub_le_mul (latticePoint 1 m) u q
  have hsym : bracket (latticePoint 1 m - u) = bracket (u - latticePoint 1 m) := by
    simp only [bracket, norm_sub_rev]
  rw [hsym] at htri
  have hq : bracket (u - q) ≤ 3 := by
    have := norm_sub_floorPoint_le u
    dsimp [bracket, q]
    linarith
  have hm : bracket (latticePoint 1 (m - floorPoint u)) ≤
      bracket (u - latticePoint 1 m) * 3 := by
    rw [latticePoint_sub]
    exact htri.trans (mul_le_mul_of_nonneg_left hq (bracket_pos _).le)
  have h := Real.rpow_le_rpow_of_nonpos
    (bracket_pos (latticePoint 1 (m - floorPoint u))) hm (neg_nonpos.mpr hb)
  rw [Real.mul_rpow (bracket_pos _).le (by norm_num : (0 : ℝ) ≤ 3)] at h
  have h3 : 0 < (3 : ℝ) ^ b := Real.rpow_pos_of_pos (by norm_num) _
  rw [Real.rpow_neg (by norm_num : (0 : ℝ) ≤ 3)] at h
  have h' := mul_le_mul_of_nonneg_left h h3.le
  have heq : (3 : ℝ) ^ b * (bracket (u - latticePoint 1 m) ^ (-b) * (3 ^ b)⁻¹) =
      bracket (u - latticePoint 1 m) ^ (-b) := by field_simp
  rw [heq] at h'
  exact h'

def latticeSumConstant (b : ℝ) : ℝ :=
  3 ^ b * ∑' m : IntPlane, bracket (latticePoint 1 m) ^ (-b)

theorem translated_lattice_summable (u : Plane) {b : ℝ} (hb : 2 < b) :
    Summable (fun m : IntPlane => bracket (u - latticePoint 1 m) ^ (-b)) := by
  have hs := (Equiv.subRight (floorPoint u)).summable_iff.mpr (regularized_lattice_summable hb)
  exact (hs.mul_left (3 ^ b)).of_nonneg_of_le
    (fun m => Real.rpow_nonneg (bracket_pos _).le _)
    (fun m => translated_lattice_majorant u m (by linarith))

theorem translated_lattice_sum_le (u : Plane) {b : ℝ} (hb : 2 < b) :
    (∑' m : IntPlane, bracket (u - latticePoint 1 m) ^ (-b)) ≤ latticeSumConstant b := by
  have hs := (Equiv.subRight (floorPoint u)).summable_iff.mpr (regularized_lattice_summable hb)
  calc
    _ ≤ ∑' m : IntPlane,
        3 ^ b * bracket (latticePoint 1 (m - floorPoint u)) ^ (-b) :=
      Summable.tsum_le_tsum (fun m => translated_lattice_majorant u m (by linarith))
        (translated_lattice_summable u hb) (hs.mul_left _)
    _ = latticeSumConstant b := by
      rw [tsum_mul_left]
      exact congrArg (fun x : ℝ => 3 ^ b * x)
        ((Equiv.subRight (floorPoint u)).tsum_eq
          (fun m : IntPlane => bracket (latticePoint 1 m) ^ (-b)))

/-- Equation (2.2) for the unit spatial lattice, with its uniform constant
constructed and its summability proved. -/
theorem spatial_lattice_convolution (u v : Plane) {a b : ℝ}
    (ha : 0 ≤ a) (hab : 2 < b - a) :
    (∑' m : IntPlane, bracket (u - latticePoint 1 m) ^ (-b) *
      bracket (latticePoint 1 m - v) ^ (-a)) ≤
      latticeSumConstant (b - a) * bracket (u - v) ^ (-a) := by
  exact infinite_weight_convolution (latticePoint 1) u v ha
    (translated_lattice_summable u hab) (translated_lattice_sum_le u hab)

end EllipticSquareFunction
