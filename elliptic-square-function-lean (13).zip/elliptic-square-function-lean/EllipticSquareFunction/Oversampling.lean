import EllipticSquareFunction.PropositionThree
import Mathlib.Logic.Equiv.Fin.Basic

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

def oversamplingIndex (B : ℕ) (r : Fin B) (q : ℤ) : ℤ := q * B + r

def oversamplingTimes (B : ℕ) [NeZero B] (T : Finset ℤ) (r : Fin B) : Finset ℤ :=
  (T.filter (fun m => (Int.divModEquiv B m).2 = r)).image
    (fun m => (Int.divModEquiv B m).1)

theorem oversampling_reconstruct (B : ℕ) [NeZero B] (m : ℤ) :
    oversamplingIndex B (Int.divModEquiv B m).2 (Int.divModEquiv B m).1 = m :=
  (Int.divModEquiv B).symm_apply_apply m

theorem oversampling_sum {α : Type*} [AddCommMonoid α]
    (B : ℕ) [NeZero B] (T : Finset ℤ) (f : ℤ → α) :
    (∑ r : Fin B, ∑ q ∈ oversamplingTimes B T r, f (oversamplingIndex B r q)) =
      ∑ m ∈ T, f m := by
  classical
  rw [← Finset.sum_fiberwise T (fun m => (Int.divModEquiv B m).2) f]
  apply Finset.sum_congr rfl
  intro r _
  unfold oversamplingTimes
  rw [Finset.sum_image]
  · apply Finset.sum_congr rfl
    intro m hm
    rw [← (Finset.mem_filter.mp hm).2, oversampling_reconstruct]
  · intro m hm m' hm' h
    apply (Int.divModEquiv B).injective
    exact Prod.ext h ((Finset.mem_filter.mp hm).2.trans (Finset.mem_filter.mp hm').2.symm)

theorem oversampling_mem (B : ℕ) [NeZero B] (T : Finset ℤ)
    (r : Fin B) (q : ℤ) (hq : q ∈ oversamplingTimes B T r) :
    oversamplingIndex B r q ∈ T := by
  classical
  obtain ⟨m,hm,hq⟩ := Finset.mem_image.mp hq
  rw [← hq, ← (Finset.mem_filter.mp hm).2, oversampling_reconstruct]
  exact (Finset.mem_filter.mp hm).1

theorem oversampling_time (B : ℕ) [NeZero B] (r : Fin B) (q : ℤ) (R s : ℝ) :
    s + (oversamplingIndex B r q : ℝ) * (R / B) =
      (s + (r : ℝ) * (R / B)) + (q : ℝ) * R := by
  have hB : (B : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (NeZero.ne B)
  simp only [oversamplingIndex, Int.cast_add, Int.cast_mul, Int.cast_natCast]
  field_simp
  <;> ring

theorem oversampling_sum_shifted {α : Type*} [AddCommMonoid α]
    (B : ℕ) [NeZero B] (T : Finset ℤ) (f : ℤ → ℝ → α) (R s : ℝ) :
    (∑ r : Fin B, ∑ q ∈ oversamplingTimes B T r,
      f (oversamplingIndex B r q) ((s+(r:ℝ)*(R/B))+(q:ℝ)*R)) =
      ∑ m ∈ T, f m (s+(m:ℝ)*(R/B)) := by
  rw [← oversampling_sum B T (fun m => f m (s+(m:ℝ)*(R/B)))]
  apply Finset.sum_congr rfl
  intro r _
  apply Finset.sum_congr rfl
  intro q _
  rw [oversampling_time]

/-- Literal fixed oversampling, with a scale-independent factor B. The input
is precisely the translated unit-lattice estimate supplied by Proposition 3. -/
theorem oversampled_time_profile_of_uniform {ι : Type*}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (B : ℕ) [NeZero B] (c σ F M C P κ η : ℝ) (hC : 0≤C) (hP : 0≤P)
    (hbound : UniformTimeProfileBound ι φ b ψ c σ F M C P κ η)
    (j : ℕ) (hj : 1≤j) (T : Finset ℤ) (d : ℤ → FinitePacketArray ι)
    (hd : ∀ m ∈ T, SeparatedPacketArray (d m) ((2:ℝ)^j) c σ F) (s : ℝ) :
    l3 (fun y => ∑ m ∈ T, arrayTimePacket (d m) φ b ψ ((2:ℝ)^j)
      (s+(m:ℝ)*(((2:ℝ)^j)^2/B)) y) volume ≤
    ENNReal.ofReal ((B:ℝ)*C*packetConstant P κ η (((2:ℝ)^j)^2))*
      (∫⁻ y, (ENNReal.ofReal (∑ m ∈ T,
        arrayPacketDensity (d m) φ ((2:ℝ)^j) M
          (s+(m:ℝ)*(((2:ℝ)^j)^2/B)) y))^(3/2:ℝ))^(1/3:ℝ) := by
  classical
  let N : ℝ := (2:ℝ)^j
  let ts := oversamplingTimes B T
  let dd := fun r q => d (oversamplingIndex B r q)
  let ss := fun r : Fin B => s+(r:ℝ)*(N^2/B)
  let FF := fun r y => ∑ q ∈ ts r,
    arrayTimePacket (dd r q) φ b ψ N (ss r+(q:ℝ)*N^2) y
  let DD := fun r y => ∑ q ∈ ts r,
    arrayPacketDensity (dd r q) φ N M (ss r+(q:ℝ)*N^2) y
  have hN : N≠0 := by positivity
  have hh := global_finite_profile_bound Finset.univ FF DD (fun _ => C)
    (packetConstant P κ η (N^2))
    (fun r _ => continuous_finset_sum (ts r) (fun q _ =>
      continuous_arrayTimePacket (dd r q) φ hφ b hb hbs ψ hψ hN _))
    (fun r _ y => Finset.sum_nonneg (fun q _ => arrayPacketDensity_nonneg ..))
    (fun _ _ => hC) (packetConstant_nonneg_global hP κ η)
    (fun r _ => hbound j hj (ts r) (dd r)
      (fun q hq => hd _ (oversampling_mem B T r q hq)) (ss r))
  have hFF (y : Space) : (∑ r : Fin B, FF r y)=∑ m ∈ T,
      arrayTimePacket (d m) φ b ψ N (s+(m:ℝ)*(N^2/B)) y := by
    exact oversampling_sum_shifted B T (fun m t => arrayTimePacket (d m) φ b ψ N t y) (N^2) s
  have hDD (y : Space) : (∑ r : Fin B, DD r y)=∑ m ∈ T,
      arrayPacketDensity (d m) φ N M (s+(m:ℝ)*(N^2/B)) y := by
    exact oversampling_sum_shifted B T (fun m t => arrayPacketDensity (d m) φ N M t y) (N^2) s
  simpa only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,hFF,hDD,N] using hh

end EllipticSquareFunction
