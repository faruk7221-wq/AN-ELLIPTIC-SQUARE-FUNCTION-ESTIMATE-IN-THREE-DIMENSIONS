import EllipticSquareFunction.SurfaceChartGeometry

noncomputable section
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1400000

theorem surface_chart_estimate (S : SurfaceSetup) (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) {W : Set Space}
    (hgraph : ∀ q ∈ S.carrier ∩ W, (A q).1 ∈ G.K ∧ (A q).2=G.φ (A q).1)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ T : DiscreteSetup, ContinuedPhase T.φ → DiscreteDensityInput T)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ r C : ℝ, 0 < r ∧ 0 < C ∧ ∀ R : ℝ, 2 ≤ R → S.C₀*(Real.sqrt R)⁻¹ < r →
      ∀ {ι : Type} (s : Finset ι) (p : ι → Space) (f : ι → SchwartzMap Space ℂ),
      (∀ i ∈ s, p i ∈ S.carrier ∩ W) →
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → S.c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
      (∀ i ∈ s, Function.support (fourierTransform (f i)) ⊆ surfaceCap S.carrier (p i) (Real.sqrt R)⁻¹ S.C₀) →
      (∀ i ∈ s, ∀ q ∈ S.carrier, ‖q-p i‖ ≤ S.C₀*(Real.sqrt R)⁻¹ → q ∈ W) →
      l3 (fun y => ∑ i ∈ s, f i y) ≤ ENNReal.ofReal (C*R^ε)*
        l3Real (squareFunction s (fun i => f i)) := by
  obtain ⟨c,hc,hsep⟩ := surface_chart_separation G hG A
  obtain ⟨r,D,hr,hD,hcap⟩ := surface_chart_caps S G hG A hgraph
  let G' : GraphSetup := { G with
    c₀ := c*S.c₀
    C₀ := D
    c₀_pos := mul_pos hc S.c₀_pos
    C₀_pos := hD }
  have hG' : GraphHypotheses G' := hG
  have hmain := general_graph_reverse_square_function G' hG' hplacement hnikodym hdiscrete
  obtain ⟨C,hC,hbound⟩ := reverse_square_function_finset G' hmain hε
  refine ⟨r,C,hr,hC,?_⟩
  intro R hR hsmall ι s p f hp hpsep hsupp hlocal
  have hδ : 0 ≤ (Real.sqrt R)⁻¹ := inv_nonneg.mpr (Real.sqrt_nonneg _)
  have hδ1 : (Real.sqrt R)⁻¹ ≤ 1 :=
    inv_le_one_of_one_le₀ (Real.one_le_sqrt.mpr (by linarith))
  apply (reverse_square_function_affine_schwartz_iff s A f _).mp
  apply hbound R hR s (fun i => (A (p i)).1) (fun i => schwartzAffineFrequency A (f i))
  · intro i hi
    exact (hgraph _ (hp i hi)).1
  · intro i hi j hj hij
    change c*S.c₀*(Real.sqrt R)⁻¹ ≤ _
    calc
      _ = c*(S.c₀*(Real.sqrt R)⁻¹) := by ring
      _ ≤ c*‖p i-p j‖ := mul_le_mul_of_nonneg_left (hpsep i hi j hj hij) hc.le
      _ ≤ _ := hsep _ _ (hgraph _ (hp i hi)).1 (hgraph _ (hp j hj)).1
        (hgraph _ (hp i hi)).2 (hgraph _ (hp j hj)).2
  · intro i hi η hη
    rw [support_fourier_schwartzAffineFrequency] at hη
    obtain ⟨z,hz,rfl⟩ := hη
    exact hcap _ hδ hδ1 hsmall (p i) (hlocal i hi) z (hsupp i hi hz)

end EllipticSquareFunction
