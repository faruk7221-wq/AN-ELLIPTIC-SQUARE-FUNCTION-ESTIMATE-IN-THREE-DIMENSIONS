import EllipticSquareFunction.SeeleyTensorMoments

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def seeleyTensorSeries (m : ℕ)
    (J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E)
    (p : ℝ × X) : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E :=
  ∑' k : ℕ, seeleyCoeff k • (J (seeleyReflection (X := X) k p)).compContinuousLinearMap
    (fun _ => seeleyReflection (X := X) k)

theorem seeley_tensor_term_bound (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E} {B : ℝ}
    (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B) {p : ℝ × X} (hp : p.1 ≤ 0) (k : ℕ) :
    ‖seeleyCoeff k • (J (seeleyReflection (X := X) k p)).compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)‖ ≤
      (|seeleyCoeff k| * (2 : ℝ)^(k*m)) * B := by
  rw [norm_smul (seeleyCoeff k) ((J (seeleyReflection (X := X) k p)).compContinuousLinearMap
    (fun _ => seeleyReflection (X := X) k)),Real.norm_eq_abs]
  have hr : 0 ≤ (seeleyReflection (X := X) k p).1 := seeley_reflected_nonneg hp k
  calc
    _ ≤ |seeleyCoeff k| * (‖J (seeleyReflection (X := X) k p)‖ * (2 : ℝ)^(k*m)) :=
      mul_le_mul_of_nonneg_left (seeley_reflection_multilinear_bound k m _) (abs_nonneg _)
    _ ≤ |seeleyCoeff k| * (B * (2 : ℝ)^(k*m)) := mul_le_mul_of_nonneg_left
      (mul_le_mul_of_nonneg_right (hJ _ hr) (by positivity)) (abs_nonneg _)
    _ = _ := by ring

theorem seeley_tensor_series_summable (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E} {B : ℝ}
    (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B) {p : ℝ × X} (hp : p.1 ≤ 0) :
    Summable (fun k : ℕ => seeleyCoeff k •
      (J (seeleyReflection (X := X) k p)).compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)) :=
  ((seeley_coeff_weighted_summable m).mul_right B).of_norm_bounded _
    (seeley_tensor_term_bound m hJ hp)

theorem seeley_tensor_series_uniform (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E} {B : ℝ}
    (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B) :
    TendstoUniformlyOn
      (fun N : ℕ => fun p : ℝ × X => ∑ k ∈ Finset.range N,
        seeleyCoeff k • (J (seeleyReflection (X := X) k p)).compContinuousLinearMap (fun _ => seeleyReflection (X := X) k))
      (seeleyTensorSeries m J) atTop {p : ℝ × X | p.1 ≤ 0} :=
  tendstoUniformlyOn_tsum_nat ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k p hp => seeley_tensor_term_bound m hJ hp k)

theorem seeley_tensor_series_continuousOn (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E} {B : ℝ}
    (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B)
    (hc : ContinuousOn J {p : ℝ × X | 0 ≤ p.1}) :
    ContinuousOn (seeleyTensorSeries m J) {p : ℝ × X | p.1 ≤ 0} := by
  apply continuousOn_tsum _ ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k p hp => seeley_tensor_term_bound m hJ hp k)
  intro k
  exact ((ContinuousMultilinearMap.compContinuousLinearMapL
    (fun _ : Fin m => (seeleyReflection (X := X) k : (ℝ × X) →L[ℝ] (ℝ × X)))).continuous.comp_continuousOn
      (hc.comp (seeleyReflection (X := X) k).continuous.continuousOn
        (fun p hp => seeley_reflected_nonneg hp k))).const_smul _

theorem seeley_tensor_series_boundary (m : ℕ)
    (J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) (y : X) :
    seeleyTensorSeries m J (0,y) = J (0,y) := by
  simp only [seeleyTensorSeries,seeley_reflection_apply,mul_zero]
  exact seeley_tensor_reproduction m (J (0,y))

/-- Every candidate derivative tensor glues continuously across the entire
boundary. Compatibility with differentiation is a separate theorem. -/
theorem seeley_tensor_extension_continuous (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E} {B : ℝ}
    (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B)
    (hc : ContinuousOn J {p : ℝ × X | 0 ≤ p.1}) :
    Continuous (fun p : ℝ × X => if 0 ≤ p.1 then J p else seeleyTensorSeries m J p) := by
  apply continuous_if_le continuous_const continuous_fst hc
    (seeley_tensor_series_continuousOn m hJ hc)
  intro p hp
  have he : p = (0,p.2) := by ext <;> simp [hp.symm]
  rw [he,seeley_tensor_series_boundary]

end EllipticSquareFunction
