import EllipticSquareFunction.SmoothExtensionJets

noncomputable section
open Filter
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Banach-valued planar version, also usable for coordinate transitions. -/
theorem smooth_plane_halfspace_extension_banach {f : Plane → E} {V : Set Plane}
    (hV : IsOpen V) {a : Plane} (ha : a ∈ V)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f ({p : Plane | 0 ≤ p 0} ∩ V)) :
    ∃ (F : Plane → E) (U : Set Plane), IsOpen U ∧ a ∈ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Set.EqOn F f (U ∩ {p : Plane | 0 ≤ p 0}) := by
  let L := planeHalfspaceEquiv
  have hs : ∀ q : ℝ × ℝ, (L.symm q) 0 = q.1 := by
    intro q
    rw [← plane_halfspace_equiv_fst (L.symm q)]
    exact congrArg Prod.fst (L.apply_symm_apply q)
  have hg : ContDiffOn ℝ (⊤ : ℕ∞) (f ∘ L.symm)
      ({q : ℝ × ℝ | 0 ≤ q.1} ∩ L.symm ⁻¹' V) := by
    apply hf.comp L.symm.contDiff.contDiffOn
    intro q hq
    exact ⟨by change 0 ≤ (L.symm q) 0; rw [hs]; exact hq.1,hq.2⟩
  obtain ⟨F,U,hU,haU,hF,heq⟩ := smooth_open_halfspace_extension
    (hV.preimage L.symm.continuous) (a := L a) (by simpa using ha) hg
  refine ⟨F ∘ L,L ⁻¹' U,hU.preimage L.continuous,haU,
    hF.comp L.contDiff.contDiffOn (fun _ h => h),?_⟩
  intro p hp
  have hh := heq ⟨hp.1,by change 0 ≤ (L p).1; exact hp.2⟩
  simpa only [Function.comp_apply,L.symm_apply_apply] using hh

/-- Smooth data on a relative neighborhood in the half-space have an open
smooth extension that agrees on a full relative neighborhood. -/
theorem smooth_boundary_data_extension {f : Plane → E} {S : Set Plane} {a : Plane}
    (hS : S ∈ 𝓝[{p : Plane | 0 ≤ p 0}] a)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f S) :
    ∃ (F : Plane → E) (U : Set Plane), IsOpen U ∧ a ∈ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Set.EqOn F f (U ∩ {p : Plane | 0 ≤ p 0}) := by
  obtain ⟨r,hr,hsub⟩ := Metric.mem_nhdsWithin_iff.mp hS
  exact smooth_plane_halfspace_extension_banach Metric.isOpen_ball
    (Metric.mem_ball_self hr) (hf.mono (fun _ hp => hsub ⟨hp.2,hp.1⟩))

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- Extensions exist at every point of every smooth boundary chart, rather
than only at the preferred center of that chart. -/
theorem boundary_chart_param_extension {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) :
    ∃ (F : Plane → EuclideanThree) (U : Set Plane), IsOpen U ∧
      extChartAt (𝓡∂ 2) x z ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
      Set.EqOn F (modelSurfaceParam (𝓡∂ 2) f x) (U ∩ Set.range (𝓡∂ 2)) := by
  have ha := (extChartAt (𝓡∂ 2) x).map_source hz
  have hn := extChartAt_target_mem_nhdsWithin' (I := 𝓡∂ 2) hz
  rw [range_modelWithCornersEuclideanHalfSpace] at hn ⊢
  exact smooth_boundary_data_extension hn (model_surface_param_smooth (𝓡∂ 2) hf x)

/-- Actual Mathlib boundary chart transitions have smooth open extensions.
This supplies the transition-map premise in the boundary tensor pullback rule. -/
theorem boundary_chart_transition_extension (x y z : M)
    (hzx : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (hzy : z ∈ (extChartAt (𝓡∂ 2) y).source) :
    ∃ (G : Plane → Plane) (U : Set Plane), IsOpen U ∧
      extChartAt (𝓡∂ 2) x z ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) G U ∧
      Set.EqOn G (extChartAt (𝓡∂ 2) y ∘ (extChartAt (𝓡∂ 2) x).symm)
        (U ∩ Set.range (𝓡∂ 2)) := by
  have hn := PartialHomeomorph.extend_coord_change_source_mem_nhdsWithin'
    (chartAt (EuclideanHalfSpace 2) x) (chartAt (EuclideanHalfSpace 2) y)
    (I := 𝓡∂ 2) (by simpa only [extChartAt_source] using hzx)
      (by simpa only [extChartAt_source] using hzy)
  rw [range_modelWithCornersEuclideanHalfSpace] at hn ⊢
  exact smooth_boundary_data_extension hn (contDiffOn_ext_coord_change (I := 𝓡∂ 2) y x)

end EllipticSquareFunction
