import EllipticSquareFunction.DensityTransport
import EllipticSquareFunction.Taylor

/-! # Separated-net packing and velocity transport

The overlap constants below are independent of scale and net cardinality.
-/
noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

/-- A separated finite planar family in a ball has uniformly bounded size.
The deliberately nonoptimal constant is obtained by an injective floor map. -/
theorem separated_plane_card_bound {ι : Type*} (s : Finset ι) (ν : ι → Plane)
    {δ A : ℝ} (hδ : 0 < δ) (u : Plane)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → δ ≤ ‖ν i - ν j‖)
    (hball : ∀ i ∈ s, ‖ν i - u‖ ≤ A) :
    s.card ≤ (integerPlaneBox ⌈(5/δ)*A+4⌉₊).card := by
  classical
  let f : ι → IntPlane := fun i => floorPoint ((5/δ) • ν i)
  have hscale : 0 < 5/δ := div_pos (by norm_num) hδ
  have hinj : Set.InjOn f ↑s := by
    intro i hi j hj hf
    by_contra hij
    have hbound : ‖(5/δ) • ν i - (5/δ) • ν j‖ ≤ 4 := by
      calc
        _ = ‖((5/δ) • ν i - latticePoint 1 (f i)) -
            ((5/δ) • ν j - latticePoint 1 (f j))‖ := by rw [hf]; congr 1; abel
        _ ≤ ‖(5/δ) • ν i - latticePoint 1 (f i)‖ +
            ‖(5/δ) • ν j - latticePoint 1 (f j)‖ := norm_sub_le _ _
        _ ≤ 4 := by linarith [norm_sub_floorPoint_le ((5/δ) • ν i),
          norm_sub_floorPoint_le ((5/δ) • ν j)]
    rw [← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hscale] at hbound
    have hlow := mul_le_mul_of_nonneg_left (hsep i hi j hj hij) hscale.le
    have he : (5/δ)*δ = 5 := by field_simp
    rw [he] at hlow
    linarith
  have hcard := translated_lattice_card_bound ((5/δ) • u) ((5/δ)*A+2)
    (s.image f) (by
      intro m hm
      obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp hm
      calc
        _ = ‖((5/δ) • u - (5/δ) • ν i) +
            ((5/δ) • ν i - latticePoint 1 (f i))‖ := by congr 1; abel
        _ ≤ ‖(5/δ) • u - (5/δ) • ν i‖ +
            ‖(5/δ) • ν i - latticePoint 1 (f i)‖ := norm_add_le _ _
        _ ≤ (5/δ)*A+2 := by
          rw [← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hscale, norm_sub_rev]
          exact add_le_add (mul_le_mul_of_nonneg_left (hball i hi) hscale.le)
            (norm_sub_floorPoint_le _))
  rw [Finset.card_image_of_injOn hinj] at hcard
  convert hcard using 1 <;> congr 2 <;> ring

/-- Separation at scale `N⁻¹` supplies the reverse overlap of the original
frequency net needed by weighted Cauchy--Schwarz. -/
theorem frequencyOverlap_of_separated {ι : Type*} (s : Finset ι) (ν : ι → Plane)
    {N σ A : ℝ} (hN : 0 < N) (hσ : 0 < σ)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i - ν j‖) (μ : Plane) :
    FrequencyOverlap N A s ν μ (integerPlaneBox ⌈(5/σ)*A+4⌉₊).card := by
  classical
  unfold FrequencyOverlap
  apply separated_plane_card_bound _ (fun i => N • ν i) hσ (N • μ)
  · intro i hi j hj hij
    rw [← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hN]
    have h := (div_le_iff₀ hN).mp
      (hsep i (Finset.mem_filter.mp hi).1 j (Finset.mem_filter.mp hj).1 hij)
    nlinarith
  · intro i hi
    rw [← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hN, norm_sub_rev]
    have h := (le_div_iff₀ hN).mp (Finset.mem_filter.mp hi).2
    nlinarith

/-- The forward overlap: each original frequency meets only uniformly many
canonical fine frequencies. This geometric form does not depend on a matrix
entry being nonzero. -/
theorem canonical_frequency_near_count {N A : ℝ} (hN : 0 < N)
    (ν : Plane) (q : Finset IntPlane) :
    (q.filter (fun m => ‖latticePoint N⁻¹ m - ν‖ ≤ A/N)).card ≤
      (integerPlaneBox ⌈A+2⌉₊).card := by
  classical
  apply translated_lattice_card_bound (N • ν) A
  intro m hm
  have hm' := (Finset.mem_filter.mp hm).2
  have he : N • ν - latticePoint 1 m = N • (ν - latticePoint N⁻¹ m) := by
    rw [smul_sub, ← latticePoint_mul, mul_inv_cancel₀ hN.ne']
  rw [he, norm_smul, Real.norm_eq_abs, abs_of_pos hN, norm_sub_rev]
  have h := (le_div_iff₀ hN).mp hm'
  nlinarith

/-- Uniform Hessian control gives a global Lipschitz constant for velocity. -/
theorem continuedPhase_velocity_bound {φ : Phase} (h : ContinuedPhase φ) :
    ∃ H : ℝ, 0 ≤ H ∧ ∀ x y : Plane,
      ‖velocity φ y - velocity φ x‖ ≤ H * ‖y-x‖ := by
  obtain ⟨ρ, ζ, hρ, hρ', hζ, hcζ, hbζ, hζone, hsζ, he, hφ, hell, hder⟩ := h
  obtain ⟨H, hH⟩ := hder 2 le_rfl
  refine ⟨H, (norm_nonneg _).trans (hH 0), ?_⟩
  intro x y
  have heq : ‖velocity φ y - velocity φ x‖ = ‖fderiv ℝ φ y - fderiv ℝ φ x‖ := by
    simp only [velocity, gradient, ← map_sub]
    exact (InnerProductSpace.toDual ℝ Plane).symm.norm_map _
  rw [heq]
  exact derivative_difference_bound φ convex_univ
    (fun z _ => (hφ.fderiv_right (m := 1) (by norm_cast)).differentiable (by norm_num) z)
    (fun z _ => by rw [hessian_norm_eq_iterated]; exact hH z) (Set.mem_univ x) (Set.mem_univ y)

/-- Sum the position-density estimate over all fine frequencies. No factor
proportional to the number of fine frequencies is lost: only the uniformly
bounded number meeting a fixed original frequency occurs. -/
theorem changedCoefficient_global_density {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c d A C E L : ℝ}
    (hN : 0 < N) (hc : 0 < c) (hd : 0 < d) (hE : 0 ≤ E) (hL : 2 < L)
    (s : Finset ι) (pbox q : Finset IntPlane) (qpos : IntPlane → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν Vν : ι → Plane) (r : Plane)
    (Vμ : IntPlane → Plane) (y : Space) (K : ℕ)
    (hoverlap : ∀ m ∈ q, FrequencyOverlap N A s ν (latticePoint N⁻¹ m) K)
    (hvel : ∀ m ∈ q, ∀ i ∈ s, ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N →
      ‖Vμ m - Vν i‖ ≤ E/N)
    (hcut : ∀ m ∈ q, ∀ (w : Plane) (i : ι), i ∈ s →
      A/N < ‖latticePoint N⁻¹ m - ν i‖ → ∀ p ∈ pbox,
      windowMatrix b χ N (latticePoint N⁻¹ m) w (ν i) (r + N • latticePoint c p) = 0)
    (hdecay : ∀ m ∈ q, ∀ (w : Plane) (i : ι), i ∈ s → ∀ p ∈ pbox,
      ‖windowMatrix b χ N (latticePoint N⁻¹ m) w (ν i) (r + N • latticePoint c p)‖ ≤
        C * bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L))
    (hcore : ∀ m ∈ q, ∀ n ∈ qpos m, y ∈ coreTube N (N^2) (Vμ m) (N • latticePoint d n)) :
    (∑ m ∈ q, ∑ n ∈ qpos m,
      ‖changedCoefficient b χ N c s pbox a ν r (latticePoint N⁻¹ m) (N • latticePoint d n)‖^2) ≤
      (((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) *
          ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)) *
            ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖^2 *
              spatialWeight N L (Vν i) (r + N • latticePoint c p) y := by
  classical
  let T : ℝ := ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
    (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L)
  let F : ι → ℝ := fun i => ∑ p ∈ pbox, ‖a i p‖^2 *
    spatialWeight N L (Vν i) (r + N • latticePoint c p) y
  have hF : ∀ i ∈ s, 0 ≤ F i := fun i _ => Finset.sum_nonneg
    (fun p _ => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  have hconst : 0 ≤ scaledLatticeSumConstant c L := by
    unfold scaledLatticeSumConstant latticeSumConstant
    exact mul_nonneg (Real.rpow_nonneg (by positivity) _)
      (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (tsum_nonneg fun _ =>
        Real.rpow_nonneg (bracket_pos _).le _))
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have hsum := sum_near_frequency_le s q
    (fun m i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N) F
    (integerPlaneBox ⌈A+2⌉₊).card hF
    (fun i _ => canonical_frequency_near_count hN (ν i) q)
  calc
    _ ≤ ∑ m ∈ q, T * ∑ i ∈ s.filter (fun i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N), F i := by
      apply Finset.sum_le_sum
      intro m hm
      exact changedCoefficient_position_density_near b χ hN hc hd hE hL s pbox (qpos m) a ν Vν r
        (latticePoint N⁻¹ m) (Vμ m) y K (hoverlap m hm) (hvel m hm)
        (hcut m hm) (hdecay m hm) (hcore m hm)
    _ = T * ∑ m ∈ q, ∑ i ∈ s.filter (fun i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N), F i :=
      (Finset.mul_sum ..).symm
    _ ≤ T * (((integerPlaneBox ⌈A+2⌉₊).card : ℝ) * ∑ i ∈ s, F i) :=
      mul_le_mul_of_nonneg_left hsum hT
    _ = _ := by dsimp [T, F]; ring


/-- Density transport for arbitrary finite fine-frame truncations, with a
constant uniform in scale, translations, and both finite coefficient arrays.
All matrix, packing, and velocity assumptions have been discharged. In the
saved manuscript this is the density display (4.12), following the matrix
bound (4.11); earlier project reports called this step (4.11). -/
theorem fine_frame_density_transport {ι : Type*} {φ : Phase}
    (hφ : ContinuedPhase φ) (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ)
    (hχs : HasCompactSupport χ) {c d σ : ℝ} (hc : 0 < c) (hd : 0 < d) (hσ : 0 < σ)
    (L : ℕ) (hL : 2 < L) :
    ∃ B : ℝ, 0 < B ∧ ∀ {N : ℝ}, 0 < N →
      ∀ (s : Finset ι) (pbox q nbox : Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane),
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i - ν j‖) → ∀ y : Space,
      coreDensity (q ×ˢ nbox)
        (fun mn => changedCoefficient b χ N c s pbox a ν r
          (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2))
        (fun mn => velocity φ (latticePoint N⁻¹ mn.1))
        (fun mn => N • latticePoint d mn.2) N (N^2) y ≤
      B * spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1))
        (fun ip => r + N • latticePoint c ip.2) N (L : ℝ) y := by
  classical
  obtain ⟨A, hA, hcut⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hdecay⟩ := windowMatrix_decay b hb hbs χ hχ hχs L
  obtain ⟨H, hH, hvelocity⟩ := continuedPhase_velocity_bound hφ
  let K := (integerPlaneBox ⌈(5/σ)*A+4⌉₊).card
  let B := ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
    (C^2 * ((K : ℝ) * scaledLatticeSumConstant c (L : ℝ)) * (2+H*A)^(L : ℝ)) *
      ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)
  refine ⟨max B 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _), ?_⟩
  intro N hN s pbox q nbox a ν r hsep y
  let qpos := fun m => nbox.filter (fun n =>
    y ∈ coreTube N (N^2) (velocity φ (latticePoint N⁻¹ m)) (N • latticePoint d n))
  have hglobal := changedCoefficient_global_density (L := (L : ℝ)) b χ hN hc hd (mul_nonneg hH hA.le)
    (by exact_mod_cast hL) s pbox q qpos a ν (fun i => velocity φ (ν i)) r
    (fun m => velocity φ (latticePoint N⁻¹ m)) y K
    (fun m _ => frequencyOverlap_of_separated s ν hN hσ hsep _)
    (by
      intro m hm i hi hnear
      calc
        _ ≤ H * ‖latticePoint N⁻¹ m - ν i‖ := hvelocity (ν i) _
        _ ≤ H * (A/N) := mul_le_mul_of_nonneg_left hnear hH
        _ = (H*A)/N := by ring)
    (by intro m hm w i hi hfar p hp; exact hcut N hN _ w _ _ hfar)
    (by intro m hm w i hi p hp; exact hdecay N hN _ w _ _)
    (by intro m hm n hn; exact (Finset.mem_filter.mp hn).2)
  have he : coreDensity (q ×ˢ nbox)
        (fun mn => changedCoefficient b χ N c s pbox a ν r
          (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2))
        (fun mn => velocity φ (latticePoint N⁻¹ mn.1))
        (fun mn => N • latticePoint d mn.2) N (N^2) y =
      ∑ m ∈ q, ∑ n ∈ qpos m, ‖changedCoefficient b χ N c s pbox a ν r
        (latticePoint N⁻¹ m) (N • latticePoint d n)‖^2 := by
    simp only [coreDensity, Finset.sum_product, Set.indicator_apply, qpos, Finset.sum_filter]
  rw [he]
  apply hglobal.trans
  change B * _ ≤ max B 1 * _
  rw [spatialDensity, Finset.sum_product]
  exact mul_le_mul_of_nonneg_right (le_max_left B 1)
    (Finset.sum_nonneg fun i _ => Finset.sum_nonneg fun p _ =>
      mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))

end EllipticSquareFunction
