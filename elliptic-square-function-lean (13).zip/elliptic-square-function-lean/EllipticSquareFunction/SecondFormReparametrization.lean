import EllipticSquareFunction.NormalSecondFundamentalForm

noncomputable section
namespace EllipticSquareFunction

/-- The normal second fundamental form transforms by pullback under a
smooth change of surface parameters. The derivative-of-parameters term is
killed by normality. -/
theorem euclidean_second_form_reparametrization
    {F : Plane → EuclideanThree} {g : Plane → Plane} {a : Plane}
    (hF : ContDiffAt ℝ 2 F (g a)) (hg : ContDiffAt ℝ 2 g a)
    (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F (g a) v)=0)
    (v w : Plane) :
    euclideanSecondFundamentalForm (F ∘ g) N a v w =
      euclideanSecondFundamentalForm F N (g a) (fderiv ℝ g a v) (fderiv ℝ g a w) := by
  let h : Phase := fun b => @inner ℝ EuclideanThree _ N (F b)
  have hh : ContDiffAt ℝ 2 h (g a) := (innerSL ℝ N).contDiff.contDiffAt.comp (g a) hF
  have hz : fderiv ℝ h (g a)=0 := by
    change fderiv ℝ ((innerSL ℝ N) ∘ F) (g a)=0
    rw [((innerSL ℝ N).hasFDerivAt.comp (g a)
      (hF.differentiableAt (by norm_num)).hasFDerivAt).fderiv]
    apply ContinuousLinearMap.ext
    intro u
    exact horth u
  rw [← euclidean_normal_height_hessian (hF.comp a hg) N v w]
  change fderiv ℝ (fderiv ℝ (h ∘ g)) a v w=_
  rw [critical_hessian_comp hh hg hz]
  exact euclidean_normal_height_hessian hF N _ _

theorem euclidean_normal_reparametrization
    {F : Plane → EuclideanThree} {g : Plane → Plane} {a : Plane}
    (hF : DifferentiableAt ℝ F (g a)) (hg : DifferentiableAt ℝ g a)
    (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F (g a) v)=0) :
    ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ (F ∘ g) a v)=0 := by
  intro v
  rw [fderiv_comp a hF hg]
  exact horth _

/-- Positive definiteness is invariant under a change of parameters whose
differential is an equivalence. -/
theorem euclidean_second_form_positive_reparametrization_iff
    {F : Plane → EuclideanThree} {g : Plane → Plane} {a : Plane}
    (hF : ContDiffAt ℝ 2 F (g a)) (hg : ContDiffAt ℝ 2 g a)
    (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F (g a) v)=0)
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a) :
    (∀ v : Plane, v ≠ 0 → 0 < euclideanSecondFundamentalForm (F ∘ g) N a v v) ↔
      ∀ v : Plane, v ≠ 0 → 0 < euclideanSecondFundamentalForm F N (g a) v v := by
  have he : ∀ v, euclideanSecondFundamentalForm (F ∘ g) N a v v =
      euclideanSecondFundamentalForm F N (g a) (L v) (L v) := by
    intro v
    rw [euclidean_second_form_reparametrization hF hg N horth,hL.fderiv]
    rfl
  constructor
  · intro hp v hv
    have hn : L.symm v ≠ 0 := fun hz => hv (L.symm.injective (hz.trans (map_zero _).symm))
    have hh := hp (L.symm v) hn
    simpa only [he,L.apply_symm_apply] using hh
  · intro hp v hv
    rw [he]
    exact hp (L v) (fun hz => hv (L.injective (hz.trans (map_zero _).symm)))

end EllipticSquareFunction
