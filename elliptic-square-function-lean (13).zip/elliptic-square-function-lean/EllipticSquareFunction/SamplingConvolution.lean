import EllipticSquareFunction.ScaledLattice
import EllipticSquareFunction.TimeLattice
import EllipticSquareFunction.Coordinates

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

def scaledTimeSumConstant (a b : ℝ) : ℝ :=
  (1+a⁻¹)^b * timeLatticeSumConstant b

theorem scaled_time_majorant {a b : ℝ} (ha : 0<a) (hb : 0≤b)
    (t : ℝ) (k : ℤ) :
    bracket (t-a*k)^(-b) ≤ (1+a⁻¹)^b * bracket (a⁻¹*t-k)^(-b) := by
  have he : a⁻¹*t-k=a⁻¹*(t-a*k) := by field_simp
  have hc : bracket (a⁻¹*t-k) ≤ (1+a⁻¹)*bracket (t-a*k) := by
    rw [he]
    simp only [bracket,Real.norm_eq_abs,abs_mul,abs_of_pos (inv_pos.mpr ha)]
    nlinarith [abs_nonneg (t-a*k),inv_pos.mpr ha]
  have hp : 0<1+a⁻¹ := by positivity
  have hh := Real.rpow_le_rpow_of_nonpos (bracket_pos _) hc (neg_nonpos.mpr hb)
  rw [Real.mul_rpow hp.le (bracket_pos _).le,Real.rpow_neg hp.le] at hh
  have hpow : 0<(1+a⁻¹)^b := Real.rpow_pos_of_pos hp _
  have hh' := mul_le_mul_of_nonneg_left hh hpow.le
  have he' : (1+a⁻¹)^b*((((1+a⁻¹)^b)⁻¹)*bracket (t-a*k)^(-b))=
      bracket (t-a*k)^(-b) := by field_simp
  rwa [he'] at hh'

theorem scaled_time_summable {a b : ℝ} (ha : 0<a) (hb : 1<b) (t : ℝ) :
    Summable (fun k : ℤ => bracket (t-a*k)^(-b)) :=
  ((translated_time_lattice_summable (a⁻¹*t) hb).mul_left ((1+a⁻¹)^b)).of_nonneg_of_le
    (fun _ => Real.rpow_nonneg (bracket_pos _).le _)
    (fun k => scaled_time_majorant ha (by linarith) t k)

theorem scaled_time_sum_le {a b : ℝ} (ha : 0<a) (hb : 1<b) (t : ℝ) :
    (∑' k : ℤ, bracket (t-a*k)^(-b)) ≤ scaledTimeSumConstant a b := by
  calc
    _ ≤ ∑' k : ℤ, (1+a⁻¹)^b*bracket (a⁻¹*t-k)^(-b) :=
      (scaled_time_summable ha hb t).tsum_le_tsum
        (fun k => scaled_time_majorant ha (by linarith) t k)
        ((translated_time_lattice_summable (a⁻¹*t) hb).mul_left _)
    _ = (1+a⁻¹)^b*∑' k : ℤ, bracket (a⁻¹*t-k)^(-b) := tsum_mul_left
    _ ≤ _ := mul_le_mul_of_nonneg_left (translated_time_lattice_sum_le (a⁻¹*t) hb)
      (by positivity)

theorem scaled_time_convolution {c a b : ℝ} (hc : 0<c) (ha : 0≤a)
    (hab : 1<b-a) (t s : ℝ) :
    (∑' k : ℤ, bracket (t-c*k)^(-b)*bracket (c*k-s)^(-a)) ≤
      scaledTimeSumConstant c (b-a)*bracket (t-s)^(-a) :=
  infinite_weight_convolution (fun k : ℤ => c*k) t s ha
    (scaled_time_summable hc hab t) (scaled_time_sum_le hc hab t)

/-- The product version of (2.2) at arbitrary fixed spatial and time mesh.
This is the discrete convolution used after the sampling estimate (6.12). -/
theorem sampling_lattice_convolution {c d M L : ℝ} (hc : 0<c) (hd : 0<d)
    (hM : 0≤M) (hLM : 2<L-M) (u v : Space) :
    (∑' i : IntPlane × ℤ,
      (bracket (u.1-latticePoint c i.1)^(-L)*bracket (latticePoint c i.1-v.1)^(-M))*
      (bracket (u.2-d*i.2)^(-L)*bracket (d*i.2-v.2)^(-M))) ≤
      (scaledLatticeSumConstant c (L-M)*scaledTimeSumConstant d (L-M))*
        (bracket (u.1-v.1)^(-M)*bracket (u.2-v.2)^(-M)) := by
  have hs := summable_weight_convolution (latticePoint c) u.1 v.1 hM
    (scaled_translated_lattice_summable hc hLM u.1)
  have ht := summable_weight_convolution (fun k : ℤ => d*k) u.2 v.2 hM
    (scaled_time_summable hd (by linarith) u.2)
  have hn₁ (i : IntPlane) : 0≤bracket (u.1-latticePoint c i)^(-L)*
      bracket (latticePoint c i-v.1)^(-M) :=
    mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (Real.rpow_nonneg (bracket_pos _).le _)
  have hn₂ (k : ℤ) : 0≤bracket (u.2-d*k)^(-L)*bracket (d*k-v.2)^(-M) :=
    mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (Real.rpow_nonneg (bracket_pos _).le _)
  rw [← hs.tsum_mul_tsum ht (hs.mul_of_nonneg ht hn₁ hn₂)]
  have hh := mul_le_mul (scaled_spatial_lattice_convolution hc hM hLM u.1 v.1)
    (scaled_time_convolution hd hM (by linarith) u.2 v.2) (tsum_nonneg hn₂)
    ((tsum_nonneg hn₁).trans (scaled_spatial_lattice_convolution hc hM hLM u.1 v.1))
  convert hh using 1 <;> ring

theorem sampling_lattice_convolution_finite {c d M L : ℝ} (hc : 0<c) (hd : 0<d)
    (hM : 0≤M) (hLM : 2<L-M) (u v : Space) (T : Finset (IntPlane × ℤ)) :
    (∑ i ∈ T,
      (bracket (u.1-latticePoint c i.1)^(-L)*bracket (latticePoint c i.1-v.1)^(-M))*
      (bracket (u.2-d*i.2)^(-L)*bracket (d*i.2-v.2)^(-M))) ≤
      (scaledLatticeSumConstant c (L-M)*scaledTimeSumConstant d (L-M))*
        (bracket (u.1-v.1)^(-M)*bracket (u.2-v.2)^(-M)) := by
  have hs := summable_weight_convolution (latticePoint c) u.1 v.1 hM
    (scaled_translated_lattice_summable hc hLM u.1)
  have ht := summable_weight_convolution (fun k : ℤ => d*k) u.2 v.2 hM
    (scaled_time_summable hd (by linarith) u.2)
  have hn₁ (i : IntPlane) : 0≤bracket (u.1-latticePoint c i)^(-L)*
      bracket (latticePoint c i-v.1)^(-M) :=
    mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (Real.rpow_nonneg (bracket_pos _).le _)
  have hn₂ (k : ℤ) : 0≤bracket (u.2-d*k)^(-L)*bracket (d*k-v.2)^(-M) :=
    mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (Real.rpow_nonneg (bracket_pos _).le _)
  exact ((hs.mul_of_nonneg ht hn₁ hn₂).sum_le_tsum T
    (fun i _ => mul_nonneg (hn₁ i.1) (hn₂ i.2))).trans
      (sampling_lattice_convolution hc hd hM hLM u v)

end EllipticSquareFunction
