import EllipticSquareFunction.SpatialTranslation
import EllipticSquareFunction.SpatialTiles

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- The cubic integral identity in extended nonnegative reals requires no
prior integrability assumption. -/
theorem l3_cube_eq_lintegral (μ : Measure Space) (F : Space → ℂ) :
    (l3 F μ)^3 = ∫⁻ y, ENNReal.ofReal (‖F y‖^3) ∂μ := by
  rw [l3,eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3:ℝ≥0∞)≠0)
    (by norm_num : (3:ℝ≥0∞)≠∞)]
  simp only [ENNReal.toReal_ofNat]
  rw [← ENNReal.rpow_natCast _ 3,← ENNReal.rpow_mul]
  norm_num
  apply lintegral_congr
  intro y
  rw [ENNReal.ofReal_pow (norm_nonneg _),ofReal_norm_eq_enorm]

/-- Cubing the precise local estimate is legitimate even before proving a
finite global integral. -/
theorem cubic_lintegral_le_of_l3 (μ : Measure Space) (F : Space → ℂ)
    {A : ℝ≥0∞} {D : ℝ≥0∞} (h : l3 F μ ≤ A*D^(1/3:ℝ)) :
    (∫⁻ y, ENNReal.ofReal (‖F y‖^3) ∂μ) ≤ A^3*D := by
  have hh := pow_le_pow_left' h 3
  have hd : (D^(1/3:ℝ))^3=D := by
    rw [← ENNReal.rpow_natCast _ 3,← ENNReal.rpow_mul]
    norm_num
  rw [l3_cube_eq_lintegral,mul_pow,hd] at hh
  exact hh

/-- Convert the far squared bound to the cubic bound used in tile assembly. -/
theorem norm_cube_le_of_norm_sq {z : ℂ} {C D : ℝ}
    (hC : 0≤C) (hD : 0≤D) (h : ‖z‖^2≤C*D) :
    ‖z‖^3≤C^(3/2:ℝ)*D^(3/2:ℝ) := by
  have hh := Real.rpow_le_rpow (sq_nonneg ‖z‖) h (by norm_num : (0:ℝ)≤3/2)
  rw [Real.mul_rpow hC hD] at hh
  have he : (‖z‖^2)^(3/2:ℝ)=‖z‖^3 := by
    rw [← Real.rpow_natCast,← Real.rpow_mul (norm_nonneg _)]
    norm_num
    exact Real.rpow_natCast _ 3
  rwa [he] at hh

/-- The per-frequency near filter agrees exactly with the filter of the full
sigma array used in the density-overlap theorem. -/
theorem sigma_filter_near_positions {ι : Type*} (s : Finset ι)
    (pbox : ι → Finset IntPlane) (v : ι → IntPlane → Plane) (m : Plane) (A N : ℝ) :
    s.sigma (fun i => (pbox i).filter (fun p => ‖v i p-m‖≤A*N^2)) =
      (s.sigma pbox).filter (fun ip => ‖v ip.1 ip.2-m‖≤A*N^2) := by
  classical
  ext ip
  simp only [Finset.mem_sigma,Finset.mem_filter,and_assoc]

/-- Exact near/far decomposition of the actual finite packet sum. -/
theorem packet_sum_near_far {ι : Type*} (φ : Phase) (b : Plane → ℂ)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (N A : ℝ) (m : Plane) (y : Space) :
    (∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket φ b N (ν i) (v i p) y) =
      (∑ i ∈ s, ∑ p ∈ (pbox i).filter (fun p => ‖v i p-m‖≤A*N^2),
        a i p*freePacket φ b N (ν i) (v i p) y) +
      (∑ i ∈ s, ∑ p ∈ (pbox i).filter (fun p => A*N^2<‖v i p-m‖),
        a i p*freePacket φ b N (ν i) (v i p) y) := by
  classical
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  simpa only [not_le] using
    (Finset.sum_filter_add_sum_filter_not (pbox i) (fun p => ‖v i p-m‖≤A*N^2)
      (fun p => a i p*freePacket φ b N (ν i) (v i p) y)).symm

end EllipticSquareFunction
