import EllipticSquareFunction.ConstructedDiscreteSetup

noncomputable section
namespace EllipticSquareFunction

/-- External placement and compactness give finitely many fixed continued
graph charts with a positive uniform neighborhood radius. Neither the charts
nor this radius depend on the scale R or on a cap family. -/
theorem finite_placement_cover (hplacement : PlacementInput) (G : GraphSetup)
    (hG : GraphHypotheses G) :
    ∃ (s : Finset G.K) (W O : G.K → Set Plane)
      (A : G.K → Space ≃ᵃ[ℝ] Space) (Φ : G.K → Phase) (r : ℝ), 0<r ∧
      (∀ i∈s, IsOpen (W i) ∧ IsOpen (O i) ∧ ContinuedPhase (Φ i) ∧
        A i '' graphOver G.φ (W i)=graphOver (Φ i) (O i)) ∧
      (∀ x∈G.K, ∃ i∈s, Metric.ball x r⊆W i) := by
  classical
  have hp (i : G.K) := hplacement G hG i i.property
  choose W O A Φ hW hmem hO hΦ hmap using hp
  have hcover : G.K⊆⋃ i : G.K, W i := by
    intro x hx
    exact Set.mem_iUnion.mpr ⟨⟨x,hx⟩,hmem ⟨x,hx⟩⟩
  obtain ⟨s,hs⟩ := G.compact_K.elim_finite_subcover W hW hcover
  have hs' : G.K⊆⋃ i : s, W i := by
    intro x hx
    obtain ⟨i,hi,hxW⟩ := Set.mem_iUnion₂.mp (hs hx)
    exact Set.mem_iUnion.mpr ⟨⟨i,hi⟩,hxW⟩
  obtain ⟨r,hr,hball⟩ := lebesgue_number_lemma_of_metric G.compact_K
    (fun i : s => hW i) hs'
  refine ⟨s,W,O,A,Φ,r,hr,?_,?_⟩
  · intro i hi
    exact ⟨hW i,hO i,hΦ i,hmap i⟩
  · intro x hx
    obtain ⟨i,hi⟩ := hball x hx
    exact ⟨i,i.property,hi⟩

end EllipticSquareFunction
