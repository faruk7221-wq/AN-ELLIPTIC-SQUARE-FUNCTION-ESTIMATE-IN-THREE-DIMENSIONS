import EllipticSquareFunction.SurfaceAtlasTheorem

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1800000

/-- Distance caps are stable under a fixed linear change of ambient norm. -/
theorem linear_image_surfaceCap {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (e : E ≃L[ℝ] F)
    {K : Set E} (hK : IsCompact K) {p : E} {δ C : ℝ} (hδ : 0 < δ) (hC : 0 < C) :
    e '' surfaceCap K p δ C ⊆
      surfaceCap (e '' K) (e p) δ ((‖e.toContinuousLinearMap‖+1)*C) := by
  rintro _ ⟨z,hz,rfl⟩
  obtain ⟨q,hq,hqp,hzq⟩ := surfaceCap_nearby_point hK hC.le hz
  have hbase : e q ∈ (e '' K) ∩ Metric.ball (e p) (((‖e.toContinuousLinearMap‖+1)*C)*δ) := by
    refine ⟨⟨q,hq,rfl⟩,?_⟩
    rw [Metric.mem_ball,dist_eq_norm]
    have hh : ‖e q-e p‖ ≤ ‖e.toContinuousLinearMap‖*(C*δ) := by
      rw [← map_sub]
      exact (e.toContinuousLinearMap.le_opNorm _).trans
        (mul_le_mul_of_nonneg_left hqp (norm_nonneg _))
    have hp := mul_pos hC hδ
    nlinarith
  have hoff : e z ∈ Metric.closedBall (e q) (((‖e.toContinuousLinearMap‖+1)*C)*δ^2) := by
    rw [Metric.mem_closedBall,dist_eq_norm]
    have hh : ‖e z-e q‖ ≤ ‖e.toContinuousLinearMap‖*(C*δ^2) := by
      rw [← map_sub]
      exact (e.toContinuousLinearMap.le_opNorm _).trans
        (mul_le_mul_of_nonneg_left hzq (norm_nonneg _))
    nlinarith [mul_nonneg hC.le (sq_nonneg δ)]
  exact Metric.closedBall_subset_cthickening hbase _ hoff

theorem linear_lower_separation {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [NormedAddCommGroup F] [NormedSpace ℝ F] (e : E ≃L[ℝ] F) (p q : E) :
    ‖p-q‖/(‖e.symm.toContinuousLinearMap‖+1) ≤ ‖e p-e q‖ := by
  have h := e.symm.toContinuousLinearMap.le_opNorm (e p-e q)
  have hh : ‖p-q‖ ≤ ‖e.symm.toContinuousLinearMap‖*‖e p-e q‖ := by
    simpa using h
  apply (div_le_iff₀ (show 0 < ‖e.symm.toContinuousLinearMap‖+1 by positivity)).mpr
  nlinarith [norm_nonneg (e p-e q)]

def schwartzEuclideanToSpace (f : SchwartzMap EuclideanThree ℂ) : SchwartzMap Space ℂ :=
  SchwartzMap.compCLMOfContinuousLinearEquiv ℂ spaceEuclideanEquiv.symm f

theorem schwartzEuclideanToSpace_apply (f : SchwartzMap EuclideanThree ℂ) (y : Space) :
    schwartzEuclideanToSpace f y=f (spaceEuclideanEquiv.symm y) := rfl

theorem fourierTransform_schwartzEuclideanToSpace (f : SchwartzMap EuclideanThree ℂ) (ζ : Space) :
    fourierTransform (schwartzEuclideanToSpace f) ζ = Real.fourierIntegral f (spaceEuclideanEquiv.symm ζ) := by
  have hh := fourierTransform_spaceEuclidean (schwartzEuclideanToSpace f) (spaceEuclideanEquiv.symm ζ)
  simpa only [schwartzEuclideanToSpace_apply,ContinuousLinearEquiv.symm_apply_apply,
    ContinuousLinearEquiv.apply_symm_apply] using hh

/-- Surface square functions in ordinary Euclidean three-space, with the
actual Euclidean distance caps and Mathlib's Fourier integral. The explicit
graph-atlas hypothesis is the remaining geometric interface. -/
theorem euclidean_surface_reverse_square_function {K : Set EuclideanThree} (hK : IsCompact K)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hatlas : LocalEllipticGraphAtlas (spaceEuclideanEquiv '' K))
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (p : Fin n → EuclideanThree) (f : Fin n → SchwartzMap EuclideanThree ℂ),
      (∀ i, p i ∈ K) →
      (∀ i j, i ≠ j → c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
      (∀ i, Function.support (Real.fourierIntegral (f i)) ⊆ surfaceCap K (p i) (Real.sqrt R)⁻¹ C₀) →
      eLpNorm (fun y => ∑ i, f i y) 3 volume ≤ ENNReal.ofReal (C*R^ε)*
        eLpNorm (fun y => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume := by
  let a := ‖spaceEuclideanEquiv.toContinuousLinearMap‖+1
  let b := ‖spaceEuclideanEquiv.symm.toContinuousLinearMap‖+1
  have ha : 0 < a := by dsimp [a]; positivity
  have hb : 0 < b := by dsimp [b]; positivity
  let S : SurfaceSetup :=
    { carrier := spaceEuclideanEquiv '' K
      compact_carrier := hK.image spaceEuclideanEquiv.continuous
      c₀ := c₀/b, C₀ := a*C₀
      c₀_pos := div_pos hc₀ hb, C₀_pos := mul_pos ha hC₀ }
  have hmain := surface_atlas_reverse_square_function S hatlas hplacement hnikodym hdiscrete
  intro ε hε
  obtain ⟨C,hC,hbound⟩ := hmain ε hε
  refine ⟨C,hC,?_⟩
  intro R hR n p f hp hsep hsupp
  let g : Fin n → SchwartzMap Space ℂ := fun i => schwartzEuclideanToSpace (f i)
  have hδ : 0 < (Real.sqrt R)⁻¹ := inv_pos.mpr (Real.sqrt_pos.mpr (by linarith))
  have had : SurfaceAdmissibleFamily S R (fun i => spaceEuclideanEquiv (p i)) g := by
    refine ⟨fun i => ⟨p i,hp i,rfl⟩,?_,?_⟩
    · intro i j hij
      change (c₀/b)*(Real.sqrt R)⁻¹ ≤ _
      calc
        _ = (c₀*(Real.sqrt R)⁻¹)/b := by ring
        _ ≤ ‖p i-p j‖/b := div_le_div_of_nonneg_right (hsep i j hij) hb.le
        _ ≤ _ := linear_lower_separation spaceEuclideanEquiv _ _
    · intro i ζ hζ
      have he : Real.fourierIntegral (f i) (spaceEuclideanEquiv.symm ζ) ≠ 0 := by
        simpa only [Function.mem_support,g,fourierTransform_schwartzEuclideanToSpace] using hζ
      exact linear_image_surfaceCap spaceEuclideanEquiv hK hδ hC₀
        ⟨spaceEuclideanEquiv.symm ζ,hsupp i he,spaceEuclideanEquiv.apply_symm_apply ζ⟩
  have hresult := hbound R hR n _ g had
  have hsum : eLpNorm (fun y : EuclideanThree => ∑ i, f i y) 3 volume =
      l3 (fun y => ∑ i, g i y) := by
    have hm : AEStronglyMeasurable (fun y : Space => ∑ i, g i y) volume :=
      (continuous_finset_sum Finset.univ (fun i _ => (g i).continuous)).aestronglyMeasurable
    have hh := eLpNorm_comp_measurePreserving (p := (3 : ℝ≥0∞)) hm measurePreserving_spaceEuclideanEquiv
    simpa only [Function.comp_def,g,schwartzEuclideanToSpace_apply,ContinuousLinearEquiv.symm_apply_apply,l3] using hh
  have hsq : eLpNorm (fun y : EuclideanThree => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume =
      l3Real (squareFunction Finset.univ (fun i => g i)) := by
    have hm : Continuous (squareFunction Finset.univ (fun i => (g i : Space → ℂ))) := by
      unfold squareFunction
      exact Real.continuous_sqrt.comp (continuous_finset_sum Finset.univ (fun i _ => (g i).continuous.norm.pow 2))
    have hh := eLpNorm_comp_measurePreserving (p := (3 : ℝ≥0∞)) hm.aestronglyMeasurable measurePreserving_spaceEuclideanEquiv
    simpa only [Function.comp_def,squareFunction,g,schwartzEuclideanToSpace_apply,
      ContinuousLinearEquiv.symm_apply_apply,l3Real] using hh
  rw [hsum,hsq]
  exact hresult

end EllipticSquareFunction
