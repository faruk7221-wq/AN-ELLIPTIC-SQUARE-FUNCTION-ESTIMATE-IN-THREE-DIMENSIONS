import EllipticSquareFunction.SeeleyTensorSeries

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem seeley_reflection_curry (k m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin (m+1) => ℝ × X) E) :
    (A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)).curryLeft =
      (ContinuousMultilinearMap.compContinuousLinearMapL
        (fun _ : Fin m => (seeleyReflection (X := X) k : (ℝ × X) →L[ℝ] (ℝ × X)))).comp
          (A.curryLeft.comp (seeleyReflection (X := X) k)) := by
  apply ContinuousLinearMap.ext
  intro x
  apply ContinuousMultilinearMap.ext
  intro v
  simp only [ContinuousMultilinearMap.curryLeft_apply,ContinuousLinearMap.comp_apply,
    ContinuousMultilinearMap.compContinuousLinearMapL_apply,
    ContinuousMultilinearMap.compContinuousLinearMap_apply]
  congr 1
  funext i
  exact Fin.cases rfl (fun j => rfl) i

theorem seeley_tensor_term_hasFDerivAt (m k : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E}
    {J' : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin (m+1) => ℝ × X) E}
    (hd : ∀ p : ℝ × X, 0 < p.1 → HasFDerivAt J (J' p).curryLeft p)
    {p : ℝ × X} (hp : p.1 < 0) :
    HasFDerivAt (fun q => seeleyCoeff k •
      (J (seeleyReflection (X := X) k q)).compContinuousLinearMap (fun _ => seeleyReflection (X := X) k))
      (seeleyCoeff k • (J' (seeleyReflection (X := X) k p)).compContinuousLinearMap
        (fun _ => seeleyReflection (X := X) k)).curryLeft p := by
  have hr : 0 < (seeleyReflection (X := X) k p).1 := mul_pos_of_neg_of_neg (seeley_node_neg k) hp
  have h := ((ContinuousMultilinearMap.compContinuousLinearMapL
      (fun _ : Fin m => (seeleyReflection (X := X) k : (ℝ × X) →L[ℝ] (ℝ × X)))).hasFDerivAt.comp p
      ((hd _ hr).comp p (seeleyReflection (X := X) k).hasFDerivAt)).const_smul (seeleyCoeff k)
  have he : (seeleyCoeff k • (J' (seeleyReflection (X := X) k p)).compContinuousLinearMap
      (fun _ => seeleyReflection (X := X) k)).curryLeft =
      seeleyCoeff k • ((J' (seeleyReflection (X := X) k p)).compContinuousLinearMap
        (fun _ => seeleyReflection (X := X) k)).curryLeft :=
    (continuousMultilinearCurryLeftEquiv ℝ (fun _ : Fin (m+1) => ℝ × X) E).map_smul _ _
  rw [he,seeley_reflection_curry]
  exact h

theorem seeley_tensor_series_hasFDerivAt (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E}
    {J' : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin (m+1) => ℝ × X) E}
    {B B' : ℝ} (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B)
    (hJ' : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J' p‖ ≤ B')
    (hd : ∀ p : ℝ × X, 0 < p.1 → HasFDerivAt J (J' p).curryLeft p)
    {p : ℝ × X} (hp : p.1 < 0) :
    HasFDerivAt (seeleyTensorSeries m J) (seeleyTensorSeries (m+1) J' p).curryLeft p := by
  have hc : Convex ℝ {q : ℝ × X | q.1 < 0} :=
    (convex_Iio (0 : ℝ)).linear_preimage (ContinuousLinearMap.fst ℝ ℝ X).toLinearMap
  have h := hasFDerivAt_tsum_of_isPreconnected
    ((seeley_coeff_weighted_summable (m+1)).mul_right B')
    (isOpen_lt continuous_fst continuous_const) hc.isPreconnected
    (fun k q hq => seeley_tensor_term_hasFDerivAt m k hd hq)
    (fun k q hq => by
      rw [ContinuousMultilinearMap.curryLeft_norm]
      exact seeley_tensor_term_bound (m+1) hJ' (le_of_lt hq) k)
    hp (seeley_tensor_series_summable m hJ (le_of_lt hp)) hp
  have he := (continuousMultilinearCurryLeftEquiv ℝ
    (fun _ : Fin (m+1) => ℝ × X) E).toContinuousLinearEquiv.map_tsum
      (f := fun k : ℕ => seeleyCoeff k • (J' (seeleyReflection (X := X) k p)).compContinuousLinearMap
        (fun _ => seeleyReflection (X := X) k))
  change (seeleyTensorSeries (m+1) J' p).curryLeft = _ at he
  rw [he]
  exact h

end EllipticSquareFunction
