import EllipticSquareFunction.CurvedMultiplier

noncomputable section
open MeasureTheory Set
namespace EllipticSquareFunction

/-- The exact curved frequency change of variables has Jacobian r⁻² R⁻¹.
Continuity and compact support suffice, with no derivative bounds on the phase. -/
theorem integral_curved_frequency_inverse (φ : Phase) (hφ : Continuous φ)
    {r R : ℝ} (hr : 0<r) (hR : 0<R) (ν : Plane)
    (f : Space → ℂ) (hf : Continuous f) (hfs : HasCompactSupport f) :
    (∫ z : Space, f ((curvedFrequencyHomeomorph φ hφ hr.ne' hR.ne' ν).symm z)) =
      ((r^2*R:ℝ):ℂ)*(∫ ζ : Space, f ζ) := by
  let e := curvedFrequencyHomeomorph φ hφ hr.ne' hR.ne' ν
  have hi : Integrable f := hf.integrable_of_hasCompactSupport hfs
  have hec : Continuous (fun z : Space => f (e.symm z)) := hf.comp e.symm.continuous
  have hei : Integrable (fun z : Space => f (e.symm z)) :=
    hec.integrable_of_hasCompactSupport (hfs.comp_homeomorph e.symm)
  change (∫ z : Space, f (e.symm z) ∂volume.prod volume)=_
  rw [integral_prod _ hei]
  have ht (ξ : Plane) :
      (∫ t : ℝ, f (ξ,φ ξ+R⁻¹*t))=(R:ℂ)*(∫ t : ℝ, f (ξ,t)) := by
    have hh := Measure.integral_comp_inv_mul_left (fun t : ℝ => f (ξ,φ ξ+t)) R
    rw [abs_of_pos hR,Complex.real_smul,
      integral_add_left_eq_self (fun t => f (ξ,t)) (φ ξ)] at hh
    exact hh
  change (∫ η : Plane, ∫ t : ℝ, f (ν+r⁻¹ • η,φ (ν+r⁻¹ • η)+R⁻¹*t))=_
  simp_rw [ht]
  rw [integral_const_mul]
  have hx : (∫ η : Plane, ∫ t : ℝ, f (ν+r⁻¹ • η,t))=
      (r^2:ℝ) • (∫ ξ : Plane, ∫ t : ℝ, f (ξ,t)) := by
    have hh := Measure.integral_comp_inv_smul (volume : Measure Plane)
      (fun ξ : Plane => ∫ t : ℝ, f (ν+ξ,t)) r
    simp only [finrank_euclideanSpace, Fintype.card_fin,
      abs_of_pos (sq_pos_of_pos hr)] at hh
    rw [integral_add_left_eq_self (fun ξ => ∫ t : ℝ, f (ξ,t)) ν] at hh
    exact hh
  rw [hx,Complex.real_smul,← integral_prod f hi]
  change (R:ℂ)*((r^2:ℝ)*(∫ ζ : Space, f ζ))=_
  push_cast
  ring

end EllipticSquareFunction
