import EllipticSquareFunction.SeeleyHalfSpaceTheorem
import EllipticSquareFunction.SmoothBoundaryTheorem

noncomputable section
open Filter
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {D E : Type*} [NormedAddCommGroup D] [NormedSpace ℝ D]
  [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Every order of the jet of an open smooth extension is fixed by its
values on a set with unique derivatives, including its boundary points. -/
theorem extension_iterated_fderivWithin {F G : D → E} {U S : Set D} {a : D}
    (hU : IsOpen U) (ha : a ∈ U) (has : a ∈ S)
    (hs : UniqueDiffOn ℝ S) (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U)
    (heq : Set.EqOn F G (U ∩ S)) (m : ℕ) :
    iteratedFDerivWithin ℝ m G S a = iteratedFDeriv ℝ m F a := by
  have he : F =ᶠ[𝓝[S] a] G := by
    filter_upwards [mem_nhdsWithin_of_mem_nhds (hU.mem_nhds ha),self_mem_nhdsWithin]
      with b hbU hbS
    exact heq ⟨hbU,hbS⟩
  rw [← he.iteratedFDerivWithin_eq (heq ⟨ha,has⟩) m]
  exact iteratedFDerivWithin_eq_iteratedFDeriv hs
    ((hF.contDiffAt (hU.mem_nhds ha)).of_le (by exact_mod_cast le_top)) has

/-- Two smooth extensions of the same data have the same full jet.
The open neighborhoods of the two extensions need not agree. -/
theorem smooth_extension_all_jets_unique {F G f : D → E} {U V S : Set D} {a : D}
    (hU : IsOpen U) (hV : IsOpen V) (haU : a ∈ U) (haV : a ∈ V) (has : a ∈ S)
    (hs : UniqueDiffOn ℝ S)
    (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U) (hG : ContDiffOn ℝ (⊤ : ℕ∞) G V)
    (heF : Set.EqOn F f (U ∩ S)) (heG : Set.EqOn G f (V ∩ S)) (m : ℕ) :
    iteratedFDeriv ℝ m F a = iteratedFDeriv ℝ m G a := by
  rw [← extension_iterated_fderivWithin hU haU has hs hF heF m,
    extension_iterated_fderivWithin hV haV has hs hG heG m]

/-- The global half-space extension matches every normal, tangential and
mixed derivative simultaneously, expressed as multilinear maps. -/
theorem smooth_halfspace_extension_with_jets
    {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] [FiniteDimensional ℝ X]
    [CompleteSpace E] {f : ℝ × X → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1}) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧
      Set.EqOn F f {p : ℝ × X | 0 ≤ p.1} ∧
      ∀ (m : ℕ) (p : ℝ × X), 0 ≤ p.1 →
        iteratedFDeriv ℝ m F p =
          iteratedFDerivWithin ℝ m f {q : ℝ × X | 0 ≤ q.1} p := by
  obtain ⟨F,hF,heq⟩ := smooth_halfspace_extension hf
  refine ⟨F,hF,heq,fun m p hp => ?_⟩
  exact (extension_iterated_fderivWithin isOpen_univ (Set.mem_univ p) hp
    seeley_halfspace_uniqueDiffOn hF.contDiffOn (fun q hq => heq hq.2) m).symm

/-- Canonical manifold parametrizations have extension-independent jets of
all orders; this includes the actual Mathlib boundary model. -/
theorem model_surface_param_all_jets_eq_extension
    {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
    (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]
    {f : M → EuclideanThree} (x : M) {F : Plane → EuclideanThree} {U : Set Plane}
    (hU : IsOpen U) (ha : extChartAt I x x ∈ U)
    (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U)
    (heq : Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target))
    (m : ℕ) :
    iteratedFDerivWithin ℝ m (modelSurfaceParam I f x) (extChartAt I x).target
      (extChartAt I x x) = iteratedFDeriv ℝ m F (extChartAt I x x) :=
  extension_iterated_fderivWithin hU ha (mem_extChartAt_target x)
    (uniqueDiffOn_extChartAt_target x) hF heq m

end EllipticSquareFunction
