import EllipticSquareFunction.UniformKernels
import EllipticSquareFunction.TerminalCoefficients
import EllipticSquareFunction.LabelCounting

/-! # The scaled window-change matrix in equation (4.10) -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

def windowMatrix (b : Plane → ℂ) (χ : Plane → ℝ) (N : ℝ)
    (μ w ν v : Plane) : ℂ :=
  N^2 • ∫ ξ, b (N • (ξ-ν)) * (χ (N • (ξ-μ)) : ℂ) *
    oscillation (@inner ℝ Plane _ (w-v) ξ)

/-- Exact change of variables in the matrix coefficient, including the
cancellation of `N²` and the Jacobian and the harmless constant phase. -/
theorem windowMatrix_normalization (b : Plane → ℂ) (χ : Plane → ℝ)
    {N : ℝ} (hN : 0 < N) (μ w ν v : Plane) :
    windowMatrix b χ N μ w ν v = oscillation (@inner ℝ Plane _ (w-v) ν) *
      ∫ ζ, b ζ * (χ (ζ + N • (ν-μ)) : ℂ) *
        oscillation (@inner ℝ Plane _ (N⁻¹ • (w-v)) ζ) := by
  let f := fun ξ => b (N • (ξ-ν)) * (χ (N • (ξ-μ)) : ℂ) *
    oscillation (@inner ℝ Plane _ (w-v) ξ)
  have hscale := Measure.integral_comp_smul_of_nonneg volume (fun ξ => f (ξ+ν))
    N⁻¹ (hR := (inv_pos.mpr hN).le)
  have he : (∫ ζ, f (N⁻¹ • ζ + ν)) = windowMatrix b χ N μ w ν v := by
    rw [integral_add_right_eq_self] at hscale
    simpa [windowMatrix, f, inv_pow] using hscale
  rw [← he, ← integral_const_mul]
  apply integral_congr_ae
  filter_upwards with ζ
  have hfirst : N • (N⁻¹ • ζ + ν - ν) = ζ := by simp [smul_smul, hN.ne']
  have hsecond : N • (N⁻¹ • ζ + ν - μ) = ζ + N • (ν-μ) := by
    rw [add_sub_assoc, smul_add, smul_smul, mul_inv_cancel₀ hN.ne', one_smul]
  have hphase : @inner ℝ Plane _ (w-v) (N⁻¹ • ζ + ν) =
      @inner ℝ Plane _ (N⁻¹ • (w-v)) ζ + @inner ℝ Plane _ (w-v) ν := by
    simp only [inner_add_right, inner_smul_right, real_inner_smul_left]
  dsimp only [f]
  rw [hfirst, hsecond, hphase, oscillation_add]
  ring

/-- The full scaled decay bound in (4.10) for interacting frequency windows. -/
theorem windowMatrix_uniform_decay (b : Plane → ℂ)
    (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (A : ℝ) (L : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : ℝ, 0 < N → ∀ μ w ν v : Plane,
      ‖N • (ν-μ)‖ ≤ A →
      ‖windowMatrix b χ N μ w ν v‖ ≤ C * bracket (N⁻¹ • (w-v)) ^ (-(L : ℝ)) := by
  obtain ⟨C, hC, hc⟩ := translated_window_uniform_decay b hb hbs χ hχ A L
  refine ⟨C, hC, ?_⟩
  intro N hN μ w ν v hμν
  rw [windowMatrix_normalization b χ hN, norm_mul, norm_oscillation, one_mul]
  exact hc (N • (ν-μ)) (by simpa [Metric.mem_closedBall, dist_zero_right] using hμν) _

/-- Compact supports force the exact finite frequency-interaction cutoff. -/
theorem windowMatrix_frequency_cutoff (b : Plane → ℂ) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχs : HasCompactSupport χ) :
    ∃ A : ℝ, 0 < A ∧ ∀ N : ℝ, 0 < N → ∀ μ w ν v : Plane,
      A / N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0 := by
  obtain ⟨B, hB⟩ := hbs.exists_bound_of_continuousOn continuous_id.continuousOn
  obtain ⟨C, hC⟩ := hχs.exists_bound_of_continuousOn continuous_id.continuousOn
  let A := max B 0 + max C 0 + 1
  refine ⟨A, by dsimp [A]; positivity, ?_⟩
  intro N hN μ w ν v hfar
  rw [windowMatrix_normalization b χ hN]
  have hz : (∫ ζ, b ζ * (χ (ζ + N • (ν-μ)) : ℂ) *
      oscillation (@inner ℝ Plane _ (N⁻¹ • (w-v)) ζ)) = 0 := by
    apply integral_eq_zero_of_ae
    filter_upwards with ζ
    by_cases hbζ : b ζ = 0
    · simp [hbζ]
    by_cases hχζ : χ (ζ + N • (ν-μ)) = 0
    · simp [hχζ]
    have hb' := hB ζ (subset_closure hbζ)
    have hc' := hC (ζ+N • (ν-μ)) (subset_closure hχζ)
    simp only [id_eq] at hb' hc'
    have htri : ‖N • (ν-μ)‖ ≤ B+C := by
      calc
        _ = ‖(ζ+N • (ν-μ))-ζ‖ := by congr 1; abel
        _ ≤ ‖ζ+N • (ν-μ)‖+‖ζ‖ := norm_sub_le _ _
        _ ≤ B+C := by linarith
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos hN, norm_sub_rev] at htri
    have hf : A < N*‖μ-ν‖ := by
      have := (div_lt_iff₀ hN).mp hfar
      nlinarith
    have hBC : B+C < A := by dsimp [A]; linarith [le_max_left B 0, le_max_left C 0]
    exact (not_lt_of_ge htri) (hBC.trans hf) |>.elim
  rw [hz, mul_zero]

theorem profile_window_integrable (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : Continuous χ)
    {N : ℝ} (hN : 0 < N) (μ w ν v : Plane) :
    Integrable (fun ξ => b (N • (ξ-ν)) * (χ (N • (ξ-μ)) : ℂ) *
      oscillation (@inner ℝ Plane _ (w-v) ξ)) := by
  have he : HasCompactSupport (fun ξ => b (N • (ξ-ν))) :=
    (hbs.comp_homeomorph (Homeomorph.smulOfNeZero N hN.ne')).comp_homeomorph (Homeomorph.subRight ν)
  have hc : Continuous (fun ξ => b (N • (ξ-ν)) * (χ (N • (ξ-μ)) : ℂ) *
      oscillation (@inner ℝ Plane _ (w-v) ξ)) := by
    apply Continuous.mul
    · exact (hb.comp (continuous_const.smul (continuous_id.sub continuous_const))).mul
        (Complex.continuous_ofReal.comp (hχ.comp (continuous_const.smul (continuous_id.sub continuous_const))))
    · exact continuous_oscillation.comp (continuous_const.inner continuous_id)
  exact hc.integrable_of_hasCompactSupport (he.mul_right.mul_right)

def profileFrequency {ι : Type*} (b : Plane → ℂ) (N : ℝ) (s : Finset ι)
    (a : ι → ℂ) (ν v : ι → Plane) (ξ : Plane) : ℂ :=
  N^2 • ∑ i ∈ s, a i * b (N • (ξ-ν i)) * oscillation (-@inner ℝ Plane _ (v i) ξ)

/-- The fine-frame coefficient is the finite matrix applied to the original
profile coefficients. All exchanges of integration and summation are justified. -/
theorem profile_coefficient_eq_matrix {ι : Type*} (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : Continuous χ)
    {N : ℝ} (hN : 0 < N) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane) (μ w : Plane) :
    (∫ ξ, profileFrequency b N s a ν v ξ * (χ (N • (ξ-μ)) : ℂ) *
      oscillation (@inner ℝ Plane _ w ξ)) =
      ∑ i ∈ s, windowMatrix b χ N μ w (ν i) (v i) * a i := by
  classical
  have he (ξ : Plane) : profileFrequency b N s a ν v ξ * (χ (N • (ξ-μ)) : ℂ) *
      oscillation (@inner ℝ Plane _ w ξ) =
      N^2 • ∑ i ∈ s, a i * (b (N • (ξ-ν i)) * (χ (N • (ξ-μ)) : ℂ) *
        oscillation (@inner ℝ Plane _ (w-v i) ξ)) := by
    rw [profileFrequency, smul_mul_assoc, smul_mul_assoc]
    congr 1
    rw [Finset.sum_mul, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i _
    have hp : @inner ℝ Plane _ (w-v i) ξ =
        -@inner ℝ Plane _ (v i) ξ + @inner ℝ Plane _ w ξ := by
      rw [inner_sub_left]
      ring
    rw [hp, oscillation_add]
    ring
  simp_rw [he]
  rw [integral_smul, integral_finset_sum s (fun i _ =>
    (profile_window_integrable b hb hbs χ hχ hN μ w (ν i) (v i)).const_mul (a i)), Finset.smul_sum]
  apply Finset.sum_congr rfl
  intro i _
  rw [integral_const_mul, windowMatrix, smul_mul_assoc]
  congr 1
  ring

/-- The unrestricted decay estimate in (4.10), using exact vanishing outside
the interaction region. -/
theorem windowMatrix_decay (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ)
    (hχs : HasCompactSupport χ) (L : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : ℝ, 0 < N → ∀ μ w ν v : Plane,
      ‖windowMatrix b χ N μ w ν v‖ ≤ C * bracket (N⁻¹ • (w-v)) ^ (-(L : ℝ)) := by
  obtain ⟨A, hA, ha⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hc⟩ := windowMatrix_uniform_decay b hb hbs χ hχ A L
  refine ⟨C, hC, ?_⟩
  intro N hN μ w ν v
  by_cases hfar : A/N < ‖μ-ν‖
  · rw [ha N hN μ w ν v hfar, norm_zero]
    exact mul_nonneg hC.le (Real.rpow_nonneg (bracket_pos _).le _)
  · apply hc N hN μ w ν v
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos hN, norm_sub_rev]
    have h := (le_div_iff₀ hN).mp (le_of_not_gt hfar)
    nlinarith

/-- Uniformly many canonical fine frequency windows interact with each
original profile, independently of scale and of the frequency center. -/
theorem windowMatrix_interaction_count (b : Plane → ℂ) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχs : HasCompactSupport χ) :
    ∃ K : ℕ, ∀ N : ℝ, 0 < N → ∀ ν v w : Plane, ∀ q : Finset IntPlane,
      (q.filter (fun m => windowMatrix b χ N (latticePoint N⁻¹ m) w ν v ≠ 0)).card ≤ K := by
  classical
  obtain ⟨A, hA, ha⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  refine ⟨(integerPlaneBox ⌈A+2⌉₊).card, ?_⟩
  intro N hN ν v w q
  apply translated_lattice_card_bound (N • ν) A
  intro m hm
  have hm' := (Finset.mem_filter.mp hm).2
  have hnear : ‖latticePoint N⁻¹ m-ν‖ ≤ A/N := by
    by_contra hn
    exact hm' (ha N hN _ w ν v (lt_of_not_ge hn))
  have he : N • ν-latticePoint 1 m = N • (ν-latticePoint N⁻¹ m) := by
    rw [smul_sub, ← latticePoint_mul, mul_inv_cancel₀ hN.ne']
  rw [he, norm_smul, Real.norm_eq_abs, abs_of_pos hN, norm_sub_rev]
  have h := (le_div_iff₀ hN).mp hnear
  nlinarith

/-- Uniform size control for every synthesized free packet. This is the
bound used after summing the omitted fine-frame coefficients. -/
theorem freePacket_uniform_bound (φ : Phase) (b : Plane → ℂ)
    (hb : Integrable b) {N : ℝ} (hN : 0 < N) (ν v : Plane) (y : Space) :
    ‖freePacket φ b N ν v y‖ ≤ ∫ ζ, ‖b ζ‖ := by
  have hi : Integrable (fun ξ => ‖b (N • (ξ-ν))‖) := by
    simpa only [sub_eq_add_neg] using (hb.norm.comp_smul hN.ne').comp_add_right (-ν)
  have hm : (∫ ξ, ‖b (N • (ξ-ν))‖) = (N^2)⁻¹ * ∫ ζ, ‖b ζ‖ := by
    have ht : (∫ ξ, ‖b (N • (ξ-ν))‖) = ∫ ξ, ‖b (N • ξ)‖ := by
      simpa only [sub_eq_add_neg] using integral_add_right_eq_self (fun ξ => ‖b (N • ξ)‖) (-ν)
    rw [ht]
    simpa [smul_eq_mul] using Measure.integral_comp_smul_of_nonneg volume (fun ξ => ‖b ξ‖) N (hR := hN.le)
  have hbound : ‖∫ ξ, b (N • (ξ-ν)) *
      oscillation (@inner ℝ Plane _ (y.1-v) ξ + y.2*φ ξ)‖ ≤ ∫ ξ, ‖b (N • (ξ-ν))‖ := by
    apply norm_integral_le_of_norm_le hi
    filter_upwards with ξ
    simp only [norm_mul, norm_oscillation, mul_one, le_refl]
  unfold freePacket
  rw [norm_mul, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (sq_nonneg N)]
  calc
    _ ≤ N^2 * ∫ ξ, ‖b (N • (ξ-ν))‖ := mul_le_mul_of_nonneg_left hbound (sq_nonneg N)
    _ = _ := by rw [hm]; field_simp

end EllipticSquareFunction
