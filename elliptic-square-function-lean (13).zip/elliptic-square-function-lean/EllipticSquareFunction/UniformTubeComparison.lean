import EllipticSquareFunction.TubeEndpoints

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- An axis extension whose Euclidean length is independent of the slope. -/
def uniformTubeHalfTime (T F : ℝ) (V : Plane) : ℝ :=
  (1+F)*T/Real.sqrt (1+‖V‖^2)

theorem uniformTubeHalfTime_bounds {T F : ℝ} (hT : 0<T) (hF : 0≤F)
    (V : Plane) (hV : ‖V‖≤F) :
    T≤uniformTubeHalfTime T F V ∧ uniformTubeHalfTime T F V≤(1+F)*T := by
  have hs : 0<Real.sqrt (1+‖V‖^2) := Real.sqrt_pos.mpr (by positivity)
  have hs₁ : 1≤Real.sqrt (1+‖V‖^2) := (Real.one_le_sqrt).mpr (by nlinarith [sq_nonneg ‖V‖])
  have hs₂ : Real.sqrt (1+‖V‖^2)≤1+F := by
    apply (Real.sqrt_le_iff).mpr
    constructor
    · linarith
    · nlinarith [norm_nonneg V]
  unfold uniformTubeHalfTime
  constructor
  · apply (le_div_iff₀ hs).mpr
    nlinarith
  · exact div_le_self (by positivity) hs₁

theorem uniform_tube_axis_length {T F : ℝ} (hT : 0<T) (hF : 0≤F)
    (V : Plane) (hV : ‖V‖≤F) :
    let U := uniformTubeHalfTime T F V
    euclideanLength ((-U • V,U)-(U • V,-U))=2*(1+F)*T := by
  intro U
  have hU : 0≤U := hT.le.trans (uniformTubeHalfTime_bounds hT hF V hV).1
  rw [tube_axis_length hU]
  dsimp [U,uniformTubeHalfTime]
  have hs : Real.sqrt (1+‖V‖^2)≠0 := (Real.sqrt_pos.mpr (by positivity : 0<1+‖V‖^2)).ne'
  field_simp
  ring

/-- A family of sheared boxes with bounded slopes is enclosed in genuine
Euclidean tubes all having one common length. -/
theorem symmetricTube_subset_uniform_geometricTube {r T F : ℝ}
    (hT : 0<T) (hF : 0≤F) (V : Plane) (hV : ‖V‖≤F) :
    let U := uniformTubeHalfTime T F V
    symmetricTube r T V ⊆ geometricTube (U • V,-U) (-U • V,U) r := by
  intro U
  have hTU := (uniformTubeHalfTime_bounds hT hF V hV).1
  apply Set.Subset.trans _ (symmetricTube_subset_geometricTube (hT.trans_le hTU) V)
  intro y hy
  exact ⟨hy.1.trans hTU,hy.2⟩

/-- Uniform volume comparison with the enclosing Euclidean tube. The factor
is independent of the scale and the individual direction. -/
theorem volume_uniform_geometricTube_le {r T F : ℝ} (hr : 0≤r)
    (hT : 0<T) (hrT : r≤T) (hF : 0≤F) (V : Plane) (hV : ‖V‖≤F) :
    let U := uniformTubeHalfTime T F V
    volume (geometricTube (U • V,-U) (-U • V,U) r) ≤
      ENNReal.ofReal (2*(1+F)^3)*volume (symmetricTube r T V) := by
  intro U
  obtain ⟨hTU,hUT⟩ := uniformTubeHalfTime_bounds hT hF V hV
  have hU : 0<U := hT.trans_le hTU
  apply (volume_geometricTube_le_box_multiple hr hU (hrT.trans hTU) hF V hV).trans
  have hvol : volume (symmetricTube r U V) ≤
      ENNReal.ofReal (1+F)*volume (symmetricTube r T V) := by
    rw [volume_symmetricTube,volume_symmetricTube]
    have hh := ENNReal.ofReal_le_ofReal (show 2*U≤(1+F)*(2*T) by nlinarith)
    rw [ENNReal.ofReal_mul (by positivity : 0≤1+F)] at hh
    convert mul_le_mul_left' hh (ENNReal.ofReal r^2*ENNReal.ofReal Real.pi) using 1 <;> ac_rfl
  apply (mul_le_mul_left' hvol (ENNReal.ofReal (2*(1+F)^2))).trans
  rw [← mul_assoc,← ENNReal.ofReal_mul (by positivity : 0≤2*(1+F)^2)]
  exact le_of_eq (by congr 2; ring)

end EllipticSquareFunction
