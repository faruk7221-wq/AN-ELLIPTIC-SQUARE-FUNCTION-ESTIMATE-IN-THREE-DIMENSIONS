import EllipticSquareFunction.ScaleComparison

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- A polynomial radial weight is bounded by a summable dyadic ball expansion. -/
theorem dyadic_bracket_majorant {E : Type*} [NormedAddCommGroup E]
    {M : ℝ} (hM : 0<M) (u : E) :
    Summable (fun m : ℕ => if ‖u‖≤(2:ℝ)^m then ((2:ℝ)^m)^(-M) else 0) ∧
    bracket u^(-M) ≤ (2:ℝ)^M*
      ∑' m : ℕ, if ‖u‖≤(2:ℝ)^m then ((2:ℝ)^m)^(-M) else 0 := by
  classical
  have hgeom : Summable (fun m : ℕ => ((2:ℝ)^m)^(-M)) := by
    simpa only [Real.rpow_pow_comm (by norm_num : (0:ℝ)≤2)] using
      summable_geometric_of_lt_one (Real.rpow_nonneg (by norm_num : (0:ℝ)≤2) (-M))
        (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : (1:ℝ)<2) (by linarith : -M<0))
  have hn (m : ℕ) : 0≤(if ‖u‖≤(2:ℝ)^m then ((2:ℝ)^m)^(-M) else 0) := by
    split_ifs <;> positivity
  have hs : Summable (fun m : ℕ => if ‖u‖≤(2:ℝ)^m then ((2:ℝ)^m)^(-M) else 0) :=
    hgeom.of_nonneg_of_le hn (fun m => by split_ifs <;> first | exact le_rfl | positivity)
  refine ⟨hs,?_⟩
  obtain ⟨k,hlo,hhi⟩ := exists_nat_pow_near
    (show (1:ℝ)≤bracket u by unfold bracket; linarith [norm_nonneg u]) (by norm_num : (1:ℝ)<2)
  have hinside : ‖u‖≤(2:ℝ)^(k+1) := by dsimp [bracket] at hhi; linarith
  have hscale : (2:ℝ)^(k+1)≤2*bracket u := by rw [pow_succ]; linarith
  have hp := negative_power_comparison (pow_pos (by norm_num : (0:ℝ)<2) (k+1))
    (bracket_pos u) (by norm_num : (0:ℝ)<2) hM.le hscale
  have hterm := hs.le_tsum (k+1) (fun m _ => hn m)
  rw [if_pos hinside] at hterm
  exact hp.trans (mul_le_mul_of_nonneg_left hterm (Real.rpow_nonneg (by norm_num) _))

/-- The product packet weight is bounded by one radial weight in the sheared
product norm. This is the first step in the annular decomposition of Lemma 5. -/
theorem packetWeight_le_radial {R M : ℝ} (hM : 0≤M) (V : Plane) (y : Space) :
    packetWeight R M V 0 0 y ≤
      bracket (shearScale (Real.sqrt R) R V y)^(-M) := by
  let z := shearScale (Real.sqrt R) R V y
  have hx : 0≤‖z.1‖ := norm_nonneg _
  have ht : 0≤‖z.2‖ := norm_nonneg _
  have hh : bracket z≤bracket z.1*bracket z.2 := by
    simp only [bracket,Prod.norm_def]
    rcases le_total ‖z.1‖ ‖z.2‖ with h | h
    · rw [max_eq_right h]; nlinarith
    · rw [max_eq_left h]; nlinarith
  have hp := Real.rpow_le_rpow_of_nonpos (bracket_pos z) hh (neg_nonpos.mpr hM)
  rw [Real.mul_rpow (bracket_pos z.1).le (bracket_pos z.2).le] at hp
  simpa only [z,shearScale,packetWeight,sub_zero] using hp

/-- A dyadic positive majorant for the actual normalized tube kernel. -/
theorem tubeKernel_dyadic_majorant {R M : ℝ} (hM : 0<M) (V : Plane) (y : Space) :
    tubeKernel R M V y ≤ (R^2)⁻¹*(2:ℝ)^M*
      ∑' m : ℕ, if ‖shearScale (Real.sqrt R) R V y‖≤(2:ℝ)^m
        then ((2:ℝ)^m)^(-M) else 0 := by
  have hh := (packetWeight_le_radial hM.le V y).trans
    (dyadic_bracket_majorant hM (shearScale (Real.sqrt R) R V y)).2
  simpa only [tubeKernel,mul_assoc] using
    mul_le_mul_of_nonneg_left hh (by positivity : 0≤(R^2)⁻¹)

end EllipticSquareFunction
