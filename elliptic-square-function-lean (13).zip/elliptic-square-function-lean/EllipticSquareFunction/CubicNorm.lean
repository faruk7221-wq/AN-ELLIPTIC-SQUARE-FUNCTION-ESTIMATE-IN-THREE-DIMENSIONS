import EllipticSquareFunction.LocalStatements
import EllipticSquareFunction.WeightIntegrals

/-! # Passing from cubic integrals to the precise local L³ statement -/

noncomputable section
open MeasureTheory Set
open scoped ENNReal
namespace EllipticSquareFunction

theorem l3_eq_cubic_integral (μ : Measure Space) (F : Space → ℂ)
    (hF : Integrable (fun y => ‖F y‖^3) μ) :
    l3 F μ = (ENNReal.ofReal (∫ y, ‖F y‖^3 ∂μ)) ^ (1/3 : ℝ) := by
  rw [l3, eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3 : ℝ≥0∞) ≠ 0)
    (by norm_num : (3 : ℝ≥0∞) ≠ ∞)]
  simp only [ENNReal.toReal_ofNat]
  congr 1
  rw [ofReal_integral_eq_lintegral_ofReal hF (Filter.Eventually.of_forall (fun _ => by positivity))]
  apply lintegral_congr
  intro y
  rw [ENNReal.ofReal_pow (norm_nonneg _), ofReal_norm_eq_enorm]
  exact ENNReal.rpow_natCast _ 3

theorem l3_le_of_cubic_integral (μ : Measure Space) (F : Space → ℂ)
    (hF : Integrable (fun y => ‖F y‖^3) μ) {C D : ℝ} (hC : 0 ≤ C)
    (h : (∫ y, ‖F y‖^3 ∂μ) ≤ C^3*D) :
    l3 F μ ≤ ENNReal.ofReal C * (ENNReal.ofReal D) ^ (1/3 : ℝ) := by
  rw [l3_eq_cubic_integral μ F hF]
  calc
    _ ≤ (ENNReal.ofReal (C^3*D)) ^ (1/3 : ℝ) :=
      ENNReal.rpow_le_rpow (ENNReal.ofReal_le_ofReal h) (by norm_num)
    _ = _ := by
      rw [ENNReal.ofReal_mul (pow_nonneg hC 3), ENNReal.ofReal_pow hC,
        ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1/3),
        ← ENNReal.rpow_natCast _ 3, ← ENNReal.rpow_mul]
      norm_num

/-- The core density vanishes outside the full time slab, so the density
factor in corrected (4.9) is exactly the cube root of its total integral. -/
theorem discrete_densityCubeRoot_eq_integral (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) :
    densityCubeRoot (discreteCoreDensity S N s d) (N^2) =
      (ENNReal.ofReal (∫ y : Space, (discreteCoreDensity S N s d y)^(3/2 : ℝ))) ^ (1/3 : ℝ) := by
  have hn (y : Space) : 0 ≤ discreteCoreDensity S N s d y := coreDensity_nonneg s d _ _ N (N^2) y
  have hi : Integrable (fun y : Space => (discreteCoreDensity S N s d y)^(3/2 : ℝ)) volume :=
    coreDensity_integrable_rpow s d _ _ N (N^2)
  unfold densityCubeRoot
  simp_rw [ENNReal.ofReal_rpow_of_nonneg (hn _) (by norm_num : (0 : ℝ) ≤ 3/2)]
  rw [← ofReal_integral_eq_lintegral_ofReal hi.restrict
    (Filter.Eventually.of_forall (fun y => Real.rpow_nonneg (hn y) _))]
  congr 2
  apply setIntegral_eq_integral_of_forall_compl_eq_zero
  intro y hy
  have hz : discreteCoreDensity S N s d y = 0 :=
    coreDensity_eq_zero_off_slab s d _ _ N (N^2) hy
  rw [hz]
  norm_num

/-- The spatial density factor is the cube root of its slab integral. -/
theorem spatial_densityCubeRoot_eq_integral {ι : Type*}
    (s : Finset ι) (a : ι → ℂ) (V v : ι → Plane) {N M : ℝ}
    (hN : N ≠ 0) (hM : 2 < M*(3/2)) :
    densityCubeRoot (spatialDensity s a V v N M) (N^2) =
      (ENNReal.ofReal (∫ y : Space in spatialSlab (N^2),
        (spatialDensity s a V v N M y)^(3/2:ℝ)))^(1/3:ℝ) := by
  have hn (y : Space) : 0 ≤ spatialDensity s a V v N M y :=
    Finset.sum_nonneg (fun i hi => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  have hi := spatialDensity_integrable_rpow_on_slab s a V v hN hM (N^2)
  unfold densityCubeRoot
  simp_rw [ENNReal.ofReal_rpow_of_nonneg (hn _) (by norm_num : (0:ℝ)≤3/2)]
  congr 1
  simpa only [timeSlab, spatialSlab, Set.mem_Icc] using
    (ofReal_integral_eq_lintegral_ofReal hi
      (Filter.Eventually.of_forall (fun y => Real.rpow_nonneg (hn y) _))).symm

end EllipticSquareFunction
