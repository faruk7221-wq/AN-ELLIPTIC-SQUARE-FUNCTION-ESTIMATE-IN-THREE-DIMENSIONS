import EllipticSquareFunction.UniformAffineCaps
import EllipticSquareFunction.FiniteSubfamilies

noncomputable section
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1400000

theorem continuedPhase_contDiff {φ : Phase} (h : ContinuedPhase φ) :
    ContDiff ℝ (⊤ : ℕ∞) φ := by
  obtain ⟨ρ,ζ,hρ,hρ',hζ,hcζ,hbζ,hζone,hsζ,he,hφ,hell,hder⟩ := h
  exact hφ

/-- The actual reverse square-function estimate on one fixed affine chart.
All geometry, Fourier transport, and norm covariance are discharged. Only the
article's external continued-phase analytic inputs remain. -/
theorem placed_chart_estimate (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) {Φ : Phase} (hΦ : ContinuedPhase Φ)
    {W O : Set Plane} (hmap : A '' graphOver G.φ W = graphOver Φ O)
    (hnikodym : NikodymInput)
    (hdiscrete : ∀ S : DiscreteSetup, S.φ=Φ → DiscreteDensityInput S)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ r C : ℝ, 0 < r ∧ 0 < C ∧ ∀ R : ℝ, 2 ≤ R → G.C₀*(Real.sqrt R)⁻¹ < r →
      ∀ {ι : Type} (s : Finset ι) (ν : ι → Plane) (f : ι → SchwartzMap Space ℂ),
      (∀ i ∈ s, ν i ∈ G.K) → (∀ i ∈ s, ν i ∈ W) →
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → G.c₀*(Real.sqrt R)⁻¹ ≤ ‖ν i-ν j‖) →
      (∀ i ∈ s, Function.support (fourierTransform (f i)) ⊆ cap G.φ (ν i) (Real.sqrt R)⁻¹ G.C₀) →
      (∀ i ∈ s, ∀ z ∈ Function.support (fourierTransform (f i)), z.1 ∈ W) →
      l3 (fun y => ∑ i ∈ s, f i y) ≤ ENNReal.ofReal (C*R^ε)*
        l3Real (squareFunction s (fun i => f i)) := by
  obtain ⟨r,c,D,hr,hc,hD,hsep,hcap⟩ := uniform_affine_caps G hG A (continuedPhase_contDiff hΦ) hmap
  let G' : GraphSetup :=
    { φ := Φ, K := graphCenterMap A G.φ '' G.K
      compact_K := graphCenterMap_compact G hG A
      c₀ := c*G.c₀, C₀ := D
      c₀_pos := mul_pos hc G.c₀_pos, C₀_pos := hD }
  have hmain : ReverseSquareFunction G' :=
    continued_graph_reverse_square_function G' hΦ hnikodym hdiscrete
  obtain ⟨C,hC,hbound⟩ := reverse_square_function_finset G' hmain hε
  refine ⟨r,C,hr,hC,?_⟩
  intro R hR hsmall ι s ν f hν hW hνsep hsupp hsuppW
  have hδ : 0 ≤ (Real.sqrt R)⁻¹ := inv_nonneg.mpr (Real.sqrt_nonneg _)
  have hδ1 : (Real.sqrt R)⁻¹ ≤ 1 :=
    inv_le_one_of_one_le₀ (Real.one_le_sqrt.mpr (by linarith))
  apply (reverse_square_function_affine_schwartz_iff s A f _).mp
  apply hbound R hR s (fun i => graphCenterMap A G.φ (ν i)) (fun i => schwartzAffineFrequency A (f i))
  · intro i hi
    exact ⟨ν i,hν i hi,rfl⟩
  · intro i hi j hj hij
    change c*G.c₀*(Real.sqrt R)⁻¹ ≤ _
    calc
      _ = c*(G.c₀*(Real.sqrt R)⁻¹) := by ring
      _ ≤ c*‖ν i-ν j‖ := mul_le_mul_of_nonneg_left (hνsep i hi j hj hij) hc.le
      _ ≤ _ := hsep _ (hν i hi) _ (hν j hj) (hW i hi) (hW j hj)
  · intro i hi η hη
    rw [support_fourier_schwartzAffineFrequency] at hη
    obtain ⟨z,hz,rfl⟩ := hη
    exact hcap _ hδ hδ1 hsmall _ (hν i hi) z (hsupp i hi hz) (hsuppW i hi z hz)

end EllipticSquareFunction
