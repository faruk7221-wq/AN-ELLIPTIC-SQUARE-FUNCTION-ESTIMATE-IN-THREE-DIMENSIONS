import EllipticSquareFunction.NikodymDilation

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Exact finite-exponent norm scaling, without measurability of the function.
This applies to the extended-real Nikodym supremum itself. -/
theorem eLpNorm_space_smul {E : Type*} [ENorm E] {c : ℝ} (hc : 0<c)
    (g : Space → E) {p : ℝ≥0∞} (hp₀ : p≠0) (hpfin : p≠⊤) :
    eLpNorm (fun y => g (c • y)) p volume =
      ((ENNReal.ofReal (c^3))⁻¹)^(1/p.toReal)*eLpNorm g p volume := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm hp₀ hpfin]
  rw [lintegral_space_smul hc (fun y => ‖g y‖ₑ ^ p.toReal)]
  exact ENNReal.mul_rpow_of_nonneg _ _ (by positivity)

/-- Membership in Lp is preserved under a positive spacetime dilation. -/
theorem memLp_space_smul {c : ℝ} (hc : 0<c) {p : ℝ≥0∞}
    {h : Space → ℝ} (hh : MemLp h p volume) :
    MemLp (fun y => h (c • y)) p volume := by
  have hm : MemLp h p (Measure.map (fun y : Space => c • y) volume) := by
    rw [space_volume_map_smul hc]
    exact hh.smul_measure (ENNReal.inv_ne_top.mpr (ENNReal.ofReal_pos.mpr (pow_pos hc 3)).ne')
  exact hm.comp_of_map (measurable_const_smul c).aemeasurable

/-- External input 3 at unit length implies the identical quantitative
Nikodym bound at every positive length. No measurability hypothesis on the
maximal operator is added. -/
theorem nikodymInput_all_lengths (hinput : NikodymInput) :
    ∀ γ : ℝ, 0<γ → γ≤1 → ∃ C : ℝ, 1≤C ∧
      ∀ τ : ℝ, 0<τ → τ<1 → ∀ L : ℝ, 0<L → ∀ h : Space → ℝ,
      MemLp h 3 volume → eLpNorm (nikodym τ L h) 3 volume ≤
        ENNReal.ofReal (C*τ^(-γ))*eLpNorm h 3 volume := by
  intro γ hγ hγ₁
  obtain ⟨C,hC,hbound⟩ := hinput γ hγ hγ₁
  refine ⟨C,hC,?_⟩
  intro τ hτ hτ₁ L hL h hh
  have hb := hbound τ hτ hτ₁ (fun y => h (L • y)) (memLp_space_smul hL hh)
  have he : nikodym τ 1 (fun y => h (L • y))=(fun x => nikodym τ L h (L • x)) := by
    funext x
    exact (nikodym_unit_rescale hL τ h x).symm
  rw [he,eLpNorm_space_smul hL _ (by norm_num) (by norm_num),
    eLpNorm_space_smul hL _ (by norm_num) (by norm_num)] at hb
  let d : ℝ≥0∞ := ((ENNReal.ofReal (L^3))⁻¹)^(1/(3:ℝ≥0∞).toReal)
  have hd₀ : d≠0 := by
    dsimp [d]
    rw [ENNReal.rpow_eq_zero_iff_of_pos (by norm_num : 0<1/(3:ℝ≥0∞).toReal)]
    exact ENNReal.inv_ne_zero.mpr ENNReal.ofReal_ne_top
  have hdfin : d≠⊤ := by
    dsimp [d]
    exact ENNReal.rpow_ne_top_of_nonneg (by positivity)
      (ENNReal.inv_ne_top.mpr (ENNReal.ofReal_pos.mpr (pow_pos hL 3)).ne')
  apply (ENNReal.mul_le_mul_left hd₀ hdfin).mp
  simpa only [d,mul_assoc,mul_left_comm] using hb

end EllipticSquareFunction
