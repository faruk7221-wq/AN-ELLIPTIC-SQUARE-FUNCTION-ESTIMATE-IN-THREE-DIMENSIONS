import EllipticSquareFunction.FrequencyPacking

/-! # Weighted sums on arbitrary separated planar position sets

These estimates remove dependence on an exact isotropic original lattice.
They supply the original-position geometry used by the bounded-profile
theorem for independently separated finite position families.
-/
noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

/-- Nearby centers give uniformly comparable negative bracket weights. -/
theorem bracket_weight_nearby {u v z : Plane} {R L : ℝ}
    (hR : 0≤R) (hL : 0≤L) (hvz : ‖v-z‖≤R) :
    bracket (u-v)^(-L) ≤ (1+R)^L * bracket (u-z)^(-L) := by
  have ht : ‖u-z‖ ≤ ‖u-v‖+R := by
    have hh := norm_add_le (u-v) (v-z)
    have he : (u-v)+(v-z)=u-z := by abel
    rw [he] at hh
    linarith
  have hcomp : bracket (u-z) ≤ (1+R)*bracket (u-v) := by
    dsimp [bracket]
    nlinarith [norm_nonneg (u-v)]
  have hh := Real.rpow_le_rpow_of_nonpos (bracket_pos _) hcomp (neg_nonpos.mpr hL)
  rw [Real.mul_rpow (by linarith : 0≤1+R) (bracket_pos _).le,
    Real.rpow_neg (by linarith : 0≤1+R)] at hh
  have hp : 0<(1+R)^L := Real.rpow_pos_of_pos (by linarith) _
  have hh' := mul_le_mul_of_nonneg_left hh hp.le
  have he : (1+R)^L*((((1+R)^L)⁻¹)*bracket (u-v)^(-L)) = bracket (u-v)^(-L) := by field_simp
  rwa [he] at hh'

/-- Quantization at spacing δ/5 is injective on any δ-separated finite set. -/
theorem separated_floor_injective {ι : Type*} (s : Finset ι) (v : ι → Plane)
    {δ : ℝ} (hδ : 0<δ)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → δ≤‖v i-v j‖) :
    Set.InjOn (fun i => floorPoint ((5/δ) • v i)) ↑s := by
  intro i hi j hj heq
  dsimp only at heq
  by_contra hij
  let f := fun i => floorPoint ((5/δ) • v i)
  have ht : ‖(5/δ) • v i-(5/δ) • v j‖≤4 := by
    calc
      _ = ‖((5/δ) • v i-latticePoint 1 (f i))-((5/δ) • v j-latticePoint 1 (f j))‖ := by
        change ‖_‖ = ‖((5/δ) • v i-latticePoint 1 (floorPoint ((5/δ) • v i)))-
          ((5/δ) • v j-latticePoint 1 (floorPoint ((5/δ) • v j)))‖
        rw [heq]; congr 1; abel
      _ ≤ ‖(5/δ) • v i-latticePoint 1 (f i)‖+‖(5/δ) • v j-latticePoint 1 (f j)‖ := norm_sub_le _ _
      _ ≤ 4 := by linarith [norm_sub_floorPoint_le ((5/δ) • v i),norm_sub_floorPoint_le ((5/δ) • v j)]
  rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos (div_pos (by norm_num) hδ)] at ht
  have hh := mul_le_mul_of_nonneg_left (hsep i hi j hj hij) (div_pos (by norm_num : (0:ℝ)<5) hδ).le
  have hc : (5/δ)*δ=5 := by field_simp
  rw [hc] at hh
  linarith

def separatedPlaneSumConstant (δ L : ℝ) : ℝ :=
  (1+2*(δ/5))^L * scaledLatticeSumConstant (δ/5) L

/-- Uniform summability of decaying weights for arbitrary separated positions. -/
theorem separated_plane_weight_sum {ι : Type*} (s : Finset ι) (v : ι → Plane)
    {δ L : ℝ} (hδ : 0<δ) (hL : 2<L)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → δ≤‖v i-v j‖) (u : Plane) :
    (∑ i ∈ s, bracket (u-v i)^(-L)) ≤ separatedPlaneSumConstant δ L := by
  classical
  let f := fun i => floorPoint ((5/δ) • v i)
  have hf := separated_floor_injective s v hδ hsep
  have hv (i : ι) : ‖v i-latticePoint (δ/5) (f i)‖≤2*(δ/5) := by
    have he : v i-latticePoint (δ/5) (f i) =
        (δ/5) • ((5/δ) • v i-latticePoint 1 (f i)) := by
      rw [smul_sub,smul_smul,← latticePoint_mul]
      have hh : δ/5*(5/δ)=1 := by field_simp
      rw [hh,one_smul,mul_one]
    rw [he,norm_smul,Real.norm_eq_abs,abs_of_pos (div_pos hδ (by norm_num))]
    have hh := mul_le_mul_of_nonneg_left (norm_sub_floorPoint_le ((5/δ) • v i))
      (div_pos hδ (by norm_num : (0:ℝ)<5)).le
    simpa only [mul_comm] using hh
  calc
    _ ≤ ∑ i ∈ s, (1+2*(δ/5))^L * bracket (u-latticePoint (δ/5) (f i))^(-L) :=
      Finset.sum_le_sum (fun i hi => bracket_weight_nearby (by positivity) (by linarith) (hv i))
    _ = (1+2*(δ/5))^L * ∑ m ∈ s.image f, bracket (u-latticePoint (δ/5) m)^(-L) := by
      rw [Finset.mul_sum,Finset.sum_image]
      exact hf
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (scaled_lattice_finite_sum_le (div_pos hδ (by norm_num)) hL u (s.image f)) (by positivity)

/-- The weighted finite tail estimate also extends to arbitrary separated sets. -/
theorem separated_plane_weight_tail {ι : Type*} (s : Finset ι) (v : ι → Plane)
    {δ L b R : ℝ} (hδ : 0<δ) (hb : 2<b) (hLb : b≤L) (hR : 0≤R)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → δ≤‖v i-v j‖) (u : Plane) :
    (∑ i ∈ s.filter (fun i => R≤‖u-v i‖), bracket (u-v i)^(-L)) ≤
      (1+R)^(-(L-b))*separatedPlaneSumConstant δ b := by
  classical
  calc
    _ ≤ ∑ i ∈ s.filter (fun i => R≤‖u-v i‖),
        (1+R)^(-(L-b))*bracket (u-v i)^(-b) :=
      Finset.sum_le_sum (fun i hi => bracket_tail_majorant hLb hR _ (Finset.mem_filter.mp hi).2)
    _ = (1+R)^(-(L-b)) * ∑ i ∈ s.filter (fun i => R≤‖u-v i‖), bracket (u-v i)^(-b) :=
      (Finset.mul_sum ..).symm
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (separated_plane_weight_sum _ v hδ hb
        (fun i hi j hj hij => hsep i (Finset.mem_filter.mp hi).1 j (Finset.mem_filter.mp hj).1 hij) u)
      (by positivity)

theorem separatedPlaneSumConstant_nonneg {δ L : ℝ} (hδ : 0<δ) (hL : 2<L) :
    0 ≤ separatedPlaneSumConstant δ L := by
  simpa using separated_plane_weight_sum (∅ : Finset ℕ) (fun _ => (0:Plane)) hδ hL
    (by simp) (0:Plane)

/-- Scale-normalized separated positions have a bound independent of N. -/
theorem separated_scaled_plane_weight_sum {ι : Type*} (s : Finset ι) (v : ι → Plane)
    {N δ L : ℝ} (hN : 0<N) (hδ : 0<δ) (hL : 2<L)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → δ*N≤‖v i-v j‖) (u : Plane) :
    (∑ i ∈ s, bracket (N⁻¹ • (u-v i))^(-L)) ≤ separatedPlaneSumConstant δ L := by
  have hs : ∀ i ∈ s, ∀ j ∈ s, i≠j → δ≤‖N⁻¹ • v i-N⁻¹ • v j‖ := by
    intro i hi j hj hij
    rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN)]
    have hh := mul_le_mul_of_nonneg_left (hsep i hi j hj hij) (inv_pos.mpr hN).le
    have he : N⁻¹*(δ*N)=δ := by field_simp
    rwa [he] at hh
  simpa only [smul_sub] using separated_plane_weight_sum s (fun i => N⁻¹ • v i) hδ hL hs (N⁻¹ • u)

end EllipticSquareFunction
