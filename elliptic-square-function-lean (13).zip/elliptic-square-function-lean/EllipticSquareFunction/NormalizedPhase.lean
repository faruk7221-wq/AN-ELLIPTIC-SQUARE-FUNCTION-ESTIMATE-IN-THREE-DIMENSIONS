import EllipticSquareFunction.Taylor

/-! # First derivative of the normalized packet phase

This is a step toward the all-order derivative estimates needed for (4.15).
It does not by itself prove the uniform packet decay.
-/
noncomputable section
open Set
namespace EllipticSquareFunction

theorem phaseRemainder_hasFDerivAt (φ : Phase) (ν η : Plane) {N : ℝ}
    (hN : N ≠ 0) (hφ : DifferentiableAt ℝ φ (ν+N⁻¹ • η)) :
    HasFDerivAt (phaseRemainder φ ν (velocity φ ν) N (N^2))
      (N • (fderiv ℝ φ (ν+N⁻¹ • η)-fderiv ℝ φ ν)) η := by
  have ha := (hasFDerivAt_const (𝕜 := ℝ) ν η).add ((hasFDerivAt_id (𝕜 := ℝ) η).const_smul N⁻¹)
  have hb := (hφ.hasFDerivAt.comp η ha).sub_const (φ ν)
  have hc := hb.sub ((fderiv ℝ φ ν).hasFDerivAt.const_smul N⁻¹)
  have hd := hc.const_smul (N^2)
  convert hd using 1
  · ext ζ
    simp only [phaseRemainder,smul_eq_mul,fderiv_eq_inner_velocity,Function.comp_apply,id_eq]
  · ext ζ
    simp only [ContinuousLinearMap.smul_apply,ContinuousLinearMap.sub_apply,
      ContinuousLinearMap.add_apply,ContinuousLinearMap.zero_apply,zero_add,
      ContinuousLinearMap.comp_apply,ContinuousLinearMap.id_apply,map_smul,smul_eq_mul]
    field_simp
    ring

/-- The first spatial derivative of the normalized phase remainder is
uniform in both scale and cap center, with linear growth in the profile variable. -/
theorem phaseRemainder_fderiv_bound {φ : Phase} (hphase : ContinuedPhase φ) :
    ∃ H : ℝ, 0≤H ∧ ∀ N : ℝ, 0<N → ∀ ν η : Plane,
      ‖fderiv ℝ (phaseRemainder φ ν (velocity φ ν) N (N^2)) η‖ ≤ H*‖η‖ := by
  obtain ⟨ρ, ζ, hρ, hρ', hζ, hcζ, hbζ, hζone, hsζ, he, hφ, hell, hder⟩ := hphase
  obtain ⟨H,hH⟩ := hder 2 le_rfl
  have hH0 : 0≤H := (norm_nonneg _).trans (hH 0)
  refine ⟨H,hH0,?_⟩
  intro N hN ν η
  rw [(phaseRemainder_hasFDerivAt φ ν η hN.ne' (hφ.differentiable (by norm_num) _)).fderiv]
  rw [norm_smul_of_nonneg hN.le (fderiv ℝ φ (ν+N⁻¹ • η)-fderiv ℝ φ ν)]
  have hh := derivative_difference_bound φ convex_univ
    (fun z _ => (hφ.fderiv_right (m := 1) (by norm_cast)).differentiable (by norm_num) z)
    (fun z _ => by rw [hessian_norm_eq_iterated]; exact hH z)
    (mem_univ ν) (mem_univ (ν+N⁻¹ • η))
  simp only [add_sub_cancel_left,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN)] at hh
  have hh' := mul_le_mul_of_nonneg_left hh hN.le
  convert hh' using 1 <;> field_simp <;> ring

end EllipticSquareFunction
