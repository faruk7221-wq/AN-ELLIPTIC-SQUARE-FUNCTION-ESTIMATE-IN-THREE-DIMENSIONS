import EllipticSquareFunction.BoundaryManifoldDerivatives
import EllipticSquareFunction.LocalImmersionEmbedding

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
  (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]

/-- The precise remaining extension property. It asks only for a smooth
extension of each canonical parametrization to an open subset of the plane.
Immersion, embeddedness and curvature are NOT part of this property. -/
def HasSmoothModelExtensions (f : M → EuclideanThree) : Prop :=
  ∀ x : M, ∃ (F : Plane → EuclideanThree) (U : Set Plane),
    IsOpen U ∧ extChartAt I x x ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
      Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target)

/-- An embedded manifold model with smooth extensions yields the local
elliptic extensions required by the proved estimate. The extensions are
shown to be locally embedded using injectivity of the manifold derivative. -/
theorem model_embedding_surface_extensions {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f) (hext : HasSmoothModelExtensions I f)
    (himm : ∀ x, Function.Injective (mfderiv I 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm I f x N) :
    EuclideanEllipticSurfaceExtensions (Set.range f) := by
  intro p hp
  obtain ⟨x,rfl⟩ := hp
  obtain ⟨F,U,hU,ha,hF,heq⟩ := hext x
  have hD := model_mfderiv_eq_extension I x ((hf.mdifferentiable (by norm_cast)) x)
    hU ha ((hF.contDiffAt (hU.mem_nhds ha)).differentiableAt (by norm_cast)) heq
  have hDF : Function.Injective (fderiv ℝ F (extChartAt I x x)) := by
    rw [← hD]
    exact himm x
  obtain ⟨V,hV,haV,hVU,hFV⟩ := immersion_locally_embedding hU ha hF hDF
  let O := (extChartAt I x).source ∩ (extChartAt I x) ⁻¹' V
  have hO : IsOpen O :=
    (continuousOn_extChartAt x).isOpen_inter_preimage (isOpen_extChartAt_source x) hV
  have hxO : x ∈ O := ⟨mem_extChartAt_source x,haV⟩
  obtain ⟨W,hW,hWpre⟩ := hemb.isInducing.isOpen_iff.mp hO
  have hxW : f x ∈ W := by
    have hh : x ∈ f ⁻¹' W := by rw [hWpre]; exact hxO
    exact hh
  obtain ⟨N,hN,hnormal,hdef⟩ := hcurv x
  refine ⟨F,V,extChartAt I x x,W,N,hV,haV,hF.mono hVU,hFV,?_,hW,hxW,?_,hDF,hN,?_,?_⟩
  · rw [heq ⟨ha,mem_extChartAt_target x⟩]
    exact congrArg f (extChartAt_to_inv x)
  · rintro y ⟨⟨z,rfl⟩,hzW⟩
    have hzO : z ∈ O := by rw [← hWpre]; exact hzW
    refine ⟨extChartAt I x z,hzO.2,?_⟩
    rw [heq ⟨hVU hzO.2,(extChartAt I x).map_source hzO.1⟩]
    exact congrArg f ((extChartAt I x).left_inv hzO.1)
  · simpa only [hD] using hnormal
  · exact (model_definite_second_form_iff_extension I x hU ha
      (hF.of_le (by norm_cast)) heq N).mp hdef

/-- Conditional estimate for compact Mathlib manifolds with corners,
including manifolds with boundary. The sole geometric extension obligation
is exposed as HasSmoothModelExtensions. -/
theorem compact_model_surface_estimate [CompactSpace M] {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f) (hext : HasSmoothModelExtensions I f)
    (himm : ∀ x, Function.Injective (mfderiv I 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm I f x N)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ :=
  article_extension_surface_theorem (isCompact_range hf.continuous)
    (model_embedding_surface_extensions I hf hemb hext himm hcurv)
    hc₀ hC₀ hplacement hnikodym hdiscrete

end EllipticSquareFunction
