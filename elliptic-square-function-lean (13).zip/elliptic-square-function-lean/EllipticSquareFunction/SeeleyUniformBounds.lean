import EllipticSquareFunction.SeeleyCoefficientBounds

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

theorem seeley_finite_coeff_tail_bound (k n : ℕ) :
    |seeleyFiniteCoeff (k+n) k| ≤ seeleyMajorant k *
      Real.exp (∑ j ∈ Finset.range n, (4/(2 : ℝ)^(j+1))) := by
  induction n with
  | zero => simpa using seeley_diagonal_bound k
  | succ n ih =>
    have hd : 0 < (2 : ℝ)^(k+n+1)-2^k := sub_pos.mpr
      ((pow_right_strictMono₀ (by norm_num : (1 : ℝ)<2)) (by omega))
    have hr : 0 ≤ (1+(2 : ℝ)^(k+n+1))/(2^(k+n+1)-2^k) := le_of_lt (div_pos (by positivity) hd)
    have he : (1+(2 : ℝ)^(k+n+1))/(2^(k+n+1)-2^k) ≤ Real.exp (4/(2 : ℝ)^(n+1)) :=
      (seeley_upper_factor_bound k n).trans (by simpa only [add_comm] using Real.add_one_le_exp (4/(2 : ℝ)^(n+1)))
    rw [show k+(n+1)=k+n+1 by omega,seeley_finite_coeff_succ (by omega),abs_mul,abs_of_nonneg hr]
    calc
      _ ≤ (seeleyMajorant k * Real.exp (∑ j ∈ Finset.range n, (4/(2 : ℝ)^(j+1)))) *
          Real.exp (4/(2 : ℝ)^(n+1)) :=
        mul_le_mul ih he hr (le_of_lt (mul_pos (seeley_majorant_pos k) (Real.exp_pos _)))
      _ = _ := by rw [Finset.sum_range_succ,Real.exp_add]; ring

/-- One summable majorant controls every truncation order. -/
theorem seeley_finite_coeff_uniform_bound (N k : ℕ) :
    |seeleyFiniteCoeff N k| ≤ Real.exp 4 * seeleyMajorant k := by
  by_cases hk : k ≤ N
  · obtain ⟨n,rfl⟩ := Nat.exists_eq_add_of_le hk
    exact (seeley_finite_coeff_tail_bound k n).trans
      (by simpa only [mul_comm] using (mul_le_mul_of_nonneg_left
        (Real.exp_le_exp.mpr (seeley_geometric_sum_bound n)) (le_of_lt (seeley_majorant_pos k))))
  · rw [seeley_finite_coeff_zero (Nat.lt_of_not_ge hk),abs_zero]
    exact le_of_lt (mul_pos (Real.exp_pos _) (seeley_majorant_pos k))

/-- The majorant is summable after multiplication by every derivative
weight 2^(km), the key quantitative input for a smooth extension series. -/
theorem seeley_weighted_majorant_summable (m : ℕ) :
    Summable (fun k : ℕ => seeleyMajorant k * (2 : ℝ)^(k*m)) := by
  apply summable_of_ratio_norm_eventually_le (r := (1/2 : ℝ)) (by norm_num)
  filter_upwards [eventually_ge_atTop (m+2)] with k hk
  have hp : (2 : ℝ)^(m+3) ≤ 2^(k+1) :=
    pow_le_pow_right₀ (by norm_num) (by omega)
  have hfac : (4/(2 : ℝ)^(k+1))*2^m ≤ 1/2 := by
    rw [div_mul_eq_mul_div,div_le_iff₀ (by positivity)]
    have hpow : (2 : ℝ)^(m+3)=2^m*8 := by rw [pow_add]; norm_num
    rw [hpow] at hp
    linarith
  have hrec : seeleyMajorant (k+1)*(2 : ℝ)^((k+1)*m) =
      (seeleyMajorant k*2^(k*m))*((4/2^(k+1))*2^m) := by
    rw [seeley_majorant_succ,Nat.add_mul,one_mul,pow_add]
    ring
  rw [Real.norm_eq_abs,Real.norm_eq_abs,
    abs_of_pos (mul_pos (seeley_majorant_pos _) (by positivity)),
    abs_of_pos (mul_pos (seeley_majorant_pos _) (by positivity)),hrec]
  have hn : 0 ≤ seeleyMajorant k*(2 : ℝ)^(k*m) :=
    mul_nonneg (le_of_lt (seeley_majorant_pos k)) (by positivity)
  simpa only [mul_comm] using (mul_le_mul_of_nonneg_left hfac hn)

end EllipticSquareFunction
