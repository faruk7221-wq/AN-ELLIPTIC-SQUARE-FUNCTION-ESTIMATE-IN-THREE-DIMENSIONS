import EllipticSquareFunction.SchwartzSamplingExpansion

noncomputable section
open MeasureTheory Set
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Multiplication on the Fourier side becomes convolution with the inverse
multiplier. Fubini is justified by the product of two integrable norms. -/
theorem convolution_inverse_multiplier (f : SchwartzMap Space ℂ)
    (m : Space → ℂ) (hm : Continuous m) (hms : HasCompactSupport m) (y : Space) :
    (∫ z : Space, f z*inverseSpaceTransform m (y-z)) =
      inverseSpaceTransform (fun ζ => fourierTransform f ζ*m ζ) y := by
  let H := fun w : Space × Space => f w.1*(m w.2*oscillation (spacePair (y-w.1) w.2))
  have hc : Continuous H := by
    apply (f.continuous.comp continuous_fst).mul
    apply (hm.comp continuous_snd).mul
    apply continuous_oscillation.comp
    unfold spacePair
    fun_prop
  have hmi : Integrable m := hm.integrable_of_hasCompactSupport hms
  let g := SchwartzMap.compCLMOfContinuousLinearEquiv ℂ spaceEuclideanEquiv f
  have hfi : Integrable (f : Space → ℂ) := by
    exact (measurePreserving_spaceEuclideanEquiv.integrable_comp f.continuous.aestronglyMeasurable).mp
      g.integrable
  have hi : Integrable H (volume.prod volume) := by
    apply (hfi.norm.mul_prod hmi.norm).mono' hc.aestronglyMeasurable
    apply Filter.Eventually.of_forall
    intro w
    simp only [H,norm_mul,norm_oscillation,mul_one,le_refl]
  have hswap := integral_integral_swap (f := fun z ζ : Space => H (z,ζ)) hi
  have hleft : (∫ z : Space, f z*inverseSpaceTransform m (y-z))=
      ∫ z : Space, ∫ ζ : Space, H (z,ζ) := by
    apply integral_congr_ae
    filter_upwards with z
    unfold inverseSpaceTransform
    rw [← integral_const_mul]
    rfl
  rw [hleft,hswap]
  have hright (ζ : Space) : (∫ z : Space, H (z,ζ))=
      fourierTransform f ζ*m ζ*oscillation (spacePair y ζ) := by
    have he (z : Space) : H (z,ζ)=
        (f z*oscillation (-spacePair z ζ))*(m ζ*oscillation (spacePair y ζ)) := by
      change f z*(m ζ*oscillation (spacePair (y-z) ζ))=_
      rw [spacePair_sub_left,sub_eq_add_neg,oscillation_add]
      ring
    simp_rw [he]
    rw [integral_mul_const]
    change fourierTransform f ζ*(m ζ*oscillation (spacePair y ζ))=_
    ring
  simp_rw [hright]
  rfl

/-- The reproducing identity for a smooth compact Fourier cutoff equal to one
on the datum's Fourier support. No kernel decay estimate is assumed here. -/
theorem reproducing_integral_of_multiplier_one (f : SchwartzMap Space ℂ)
    (m : Space → ℂ) (hm : Continuous m) (hms : HasCompactSupport m)
    (hone : ∀ ζ ∈ Function.support (fourierTransform f), m ζ=1) (y : Space) :
    (∫ z : Space, f z*inverseSpaceTransform m (y-z))=f y := by
  rw [convolution_inverse_multiplier f m hm hms]
  have he : (fun ζ => fourierTransform f ζ*m ζ)=fourierTransform f := by
    funext ζ
    by_cases hz : fourierTransform f ζ=0
    · simp only [hz,zero_mul]
    · rw [hone ζ hz,mul_one]
  rw [he,space_fourier_inversion]

end EllipticSquareFunction
