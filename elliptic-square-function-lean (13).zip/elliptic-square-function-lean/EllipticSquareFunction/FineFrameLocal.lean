import EllipticSquareFunction.FineFrameTruncation
import EllipticSquareFunction.CorrectedLocalEstimate
import EllipticSquareFunction.ProfileLabelCounting

/-! # Integrated fine-frame transport toward the bounded profile estimate -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

/-- Integrate the proved pointwise density transport. The original density is
integrated on the whole spatial plane and only the relevant time slab. -/
theorem fine_frame_integrated_density {ι : Type*}
    (S : DiscreteSetup) (hφ : ContinuedPhase S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ : ℝ} (hc : 0 < c) (hσ : 0 < σ) (L : ℕ) (hL : 2 < L) :
    ∃ B : ℝ, 0 < B ∧ ∀ {N : ℝ}, 0 < N →
      ∀ (s : Finset ι) (pbox q nbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (r : Plane),
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖) →
      (∫ y : Space, (discreteCoreDensity S N (q ×ˢ nbox)
        (profileFineCoefficient S b N c s pbox a ν r) y)^(3/2 : ℝ)) ≤
      B * ∫ y : Space in spatialSlab (N^2),
        (spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2)
          N (L : ℝ) y)^(3/2 : ℝ) := by
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨B,hB,ht⟩ := fine_frame_density_transport (ι := ι) hφ b hb hbs S.χ
    S.χ_smooth S.χ_compact hc (inv_pos.mpr hD) hσ L hL
  refine ⟨B^(3/2 : ℝ), Real.rpow_pos_of_pos hB _, ?_⟩
  intro N hN s pbox q nbox a ν r hsep
  let d := profileFineCoefficient S b N c s pbox a ν r
  let H := spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2) N (L : ℝ)
  have he (n : IntPlane) : N • latticePoint (S.D : ℝ)⁻¹ n = latticePoint (N/S.D) n := by
    rw [← latticePoint_mul, div_eq_mul_inv]
  have hp (y : Space) : (discreteCoreDensity S N (q ×ˢ nbox) d y)^(3/2 : ℝ) ≤
      B^(3/2 : ℝ) * (H y)^(3/2 : ℝ) := by
    have hh := ht hN s pbox q nbox a ν r hsep y
    simp only [he] at hh
    have hn : 0 ≤ discreteCoreDensity S N (q ×ˢ nbox) d y := coreDensity_nonneg (q ×ˢ nbox) d _ _ N (N^2) y
    have hm := Real.rpow_le_rpow hn hh (by norm_num : (0 : ℝ) ≤ 3/2)
    have hH : 0 ≤ H y := Finset.sum_nonneg (fun k hk =>
      mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
    rw [Real.mul_rpow hB.le hH] at hm
    exact hm
  have hi := coreDensity_integrable_rpow (q ×ˢ nbox) d
    (fun k => velocity S.φ (latticePoint N⁻¹ k.1)) (fun k => latticePoint (N/S.D) k.2) N (N^2)
  have hLr : (2 : ℝ) < L := by exact_mod_cast hL
  have hiH := spatialDensity_integrable_rpow_on_slab (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2)
    hN.ne' (by nlinarith : (2 : ℝ) < (L : ℝ)*(3/2)) (N^2)
  have hh := integral_mono hi.restrict (hiH.const_mul (B^(3/2 : ℝ))) hp
  rw [integral_const_mul, setIntegral_eq_integral_of_forall_compl_eq_zero] at hh
  · exact hh
  · intro y hy
    change (discreteCoreDensity S N (q ×ˢ nbox) d y)^(3/2 : ℝ) = 0
    rw [show discreteCoreDensity S N (q ×ˢ nbox) d y = 0 from
      coreDensity_eq_zero_off_slab (q ×ˢ nbox) d _ _ N (N^2) hy]
    norm_num

/-- Continuity of a free packet with a compact continuous complex window. -/
theorem continuous_freePacket (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : N ≠ 0) (ν v : Plane) :
    Continuous (freePacket φ b N ν v) := by
  let g := fun ξ : Plane => b (N • (ξ-ν))
  have hg : Continuous g := hb.comp (continuous_const.smul (continuous_id.sub continuous_const))
  have hgs : HasCompactSupport g :=
    (hbs.comp_homeomorph (Homeomorph.smulOfNeZero N hN)).comp_homeomorph (Homeomorph.subRight ν)
  have hi : Continuous (fun y : Space => ∫ ξ, g ξ *
      oscillation (@inner ℝ Plane _ (y.1-v) ξ + y.2*φ ξ)) := by
    apply continuous_iff_continuousOn_univ.mpr
    apply continuousOn_integral_of_compact_support (μ := volume) hgs
    · apply Continuous.continuousOn
      exact (hg.comp continuous_snd).mul (continuous_oscillation.comp
        (((continuous_fst.fst.sub continuous_const).inner continuous_snd).add
          (continuous_fst.snd.mul (hφ.comp continuous_snd))))
    · intro y ξ hy hξ
      rw [image_eq_zero_of_nmem_tsupport hξ, zero_mul]
  exact continuous_const.mul hi

/-- Uniform remainder bounds integrate with the exact local volume. -/
theorem local_uniform_remainder_cubed {N Q T : ℝ} (hN : 0 ≤ N) (hQ : 0 ≤ Q)
    (hT : 0 ≤ T) (E : Space → ℂ) (hE : ∀ y, ‖E y‖ ≤ T) :
    (∫ y in Metric.closedBall (0 : Plane) (Q*N^2) ×ˢ Icc 0 (N^2), ‖E y‖^3) ≤
      Real.pi * Q^2 * N^6 * T^3 := by
  let U := coreTube (Q*N^2) (N^2) 0 0
  have hc : IntegrableOn (fun _ : Space => T^3) U volume :=
    integrableOn_const.mpr (Or.inr (volume_coreTube_ne_top _ _ _ _).lt_top)
  have hm : volume.real U = Real.pi * Q^2 * N^6 := by
    have hh := integral_core_indicator (Q*N^2) (N^2) 0 0 (by positivity) (sq_nonneg N)
    rw [integral_indicator (measurableSet_coreTube _ _ _ _), setIntegral_const] at hh
    simp only [smul_eq_mul, mul_one] at hh
    dsimp [U]
    rw [hh]
    ring
  have hh : (∫ y in U, ‖E y‖^3) ≤ ∫ _y in U, T^3 :=
    integral_mono_of_nonneg (Filter.Eventually.of_forall (fun _ => by positivity)) hc
      (Filter.Eventually.of_forall (fun y => pow_le_pow_left₀ (norm_nonneg _) (hE y) 3))
  rw [setIntegral_const, hm, smul_eq_mul] at hh
  simpa only [U, coreTube_zero_eq_product] using hh

/-- Decay order seven suffices after the O(N⁴) label count and local volume. -/
theorem fine_tail_scale_absorption {N : ℝ} (hN : 1 ≤ N) :
    N^14 * ((1+N)^(-(4:ℝ)))^3 ≤ N^4 := by
  have hN0 : 0<N := by linarith
  have he : (1+N)^(-(4:ℝ)) = ((1+N)^(4:ℕ))⁻¹ := by
    rw [Real.rpow_neg (by linarith : 0 ≤ 1+N)]
    exact congrArg Inv.inv (Real.rpow_natCast (1+N) 4)
  rw [he, inv_pow]
  have hp : N^12 ≤ ((1+N)^4)^3 := by
    have hh := pow_le_pow_left₀ hN0.le (by linarith : N≤1+N) 12
    simpa only [← pow_mul] using hh
  have hn : N^10 ≤ N^12 := pow_le_pow_right₀ hN (by norm_num)
  apply (mul_le_mul_right (by positivity : 0 < ((1+N)^4)^3)).mp
  rw [mul_assoc, inv_mul_cancel₀ (by positivity : ((1+N)^4)^3 ≠ 0), mul_one]
  calc
    N^14 = N^4 * N^10 := by ring
    _ ≤ N^4 * ((1+N)^4)^3 := mul_le_mul_of_nonneg_left (hn.trans hp) (by positivity)

/-- The fine-frame truncation error is absorbed into the original density,
using only proved counting, tail, volume, and density-lower-bound estimates. -/
theorem fine_remainder_absorbed {ι : Type*} (φ : Phase)
    (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r : Plane) {N c σ F A Q B M : ℝ}
    (hN : 1 ≤ N) (hc : 0 < c) (hσ : 0 < σ) (hF : 0 ≤ F) (hA : 0 ≤ A)
    (hQ : 0 ≤ Q) (hB : 0 ≤ B) (hM : 2 < M*(3/2))
    (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖)
    (hv : ∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2)
    (E : Space → ℂ)
    (hE : ∀ y, ‖E y‖ ≤ B*(1+N)^(-(4:ℝ))*(∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖)) :
    (∫ y in Metric.closedBall (0 : Plane) (Q*N^2) ×ˢ Icc 0 (N^2), ‖E y‖^3) ≤
      (Real.pi * Q^2 * B^3 * (profileLabelCountConstant c σ F A)^2 /
        (Real.pi * (2 : ℝ)^(-(M*(3/2))))) *
      ∫ y : Space in spatialSlab (N^2),
        (spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2) N M y)^(3/2 : ℝ) := by
  have hN0 : 0<N := by linarith
  let H := ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖
  let J := ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖^3
  let K := profileLabelCountConstant c σ F A
  let t := (1+N)^(-(4:ℝ))
  let C := Real.pi * Q^2 * B^3 * K^2
  let k := Real.pi * (2 : ℝ)^(-(M*(3/2)))
  have hH : 0≤H := Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => norm_nonneg _))
  have hJ : 0≤J := Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => by positivity))
  have ht : 0≤t := Real.rpow_nonneg (by linarith) _
  have hC : 0≤C := by dsimp [C]; positivity
  have hk : 0<k := mul_pos Real.pi_pos (Real.rpow_pos_of_pos (by norm_num) _)
  have hcub := profileLabels_l1_cubed_bound s pbox a ν r hN hc hσ hF hA hν hsep hv
  have hlow := equation_4_13 (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2) hN0 hM
  simp only [Finset.sum_product] at hlow
  have hvol := local_uniform_remainder_cubed hN0.le hQ (mul_nonneg (mul_nonneg hB ht) hH) E hE
  calc
    _ ≤ Real.pi * Q^2 * N^6 * (B*t*H)^3 := hvol
    _ = (Real.pi * Q^2 * B^3 * (N^6*t^3))*H^3 := by ring
    _ ≤ (Real.pi * Q^2 * B^3 * (N^6*t^3))*(K^2*N^8*J) :=
      mul_le_mul_of_nonneg_left hcub (by positivity)
    _ = C*(N^14*t^3)*J := by dsimp [C]; ring
    _ ≤ C*N^4*J := mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_left (fine_tail_scale_absorption hN) hC) hJ
    _ = (C/k)*(k*N^4*J) := by field_simp; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left hlow (div_nonneg hC hk.le)

end EllipticSquareFunction
