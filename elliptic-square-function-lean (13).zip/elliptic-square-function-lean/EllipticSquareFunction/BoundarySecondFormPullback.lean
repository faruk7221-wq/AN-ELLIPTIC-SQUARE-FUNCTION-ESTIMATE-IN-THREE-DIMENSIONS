import EllipticSquareFunction.SmoothExtensionJets
import EllipticSquareFunction.SecondFormReparametrization

noncomputable section
open scoped Topology
namespace EllipticSquareFunction

/-- The normal second derivative obeys the tensor pullback rule on model
sets with boundary. Smooth open extensions of both maps suffice; no claim
of an ordinary derivative of the original functions outside their model
sets is used. -/
theorem boundary_second_form_pullback
    {f : Plane → EuclideanThree} {g : Plane → Plane}
    {F : Plane → EuclideanThree} {G : Plane → Plane}
    {U V S T : Set Plane} {a : Plane}
    (hU : IsOpen U) (hV : IsOpen V) (haV : a ∈ V) (haS : a ∈ S)
    (hgaU : g a ∈ U) (hgaT : g a ∈ T)
    (hS : UniqueDiffOn ℝ S) (hT : UniqueDiffOn ℝ T)
    (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U)
    (hG : ContDiffOn ℝ (⊤ : ℕ∞) G V)
    (heF : Set.EqOn F f (U ∩ T)) (heG : Set.EqOn G g (V ∩ S))
    (hgST : Set.MapsTo g S T) (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N (fderivWithin ℝ f T (g a) v)=0)
    (v w : Plane) :
    @inner ℝ EuclideanThree _ N
      (fderivWithin ℝ (fderivWithin ℝ (f ∘ g) S) S a v w) =
    @inner ℝ EuclideanThree _ N
      (fderivWithin ℝ (fderivWithin ℝ f T) T (g a)
        (fderivWithin ℝ g S a v) (fderivWithin ℝ g S a w)) := by
  have hGa : G a = g a := heG ⟨haV,haS⟩
  have hdF : DifferentiableAt ℝ F (g a) :=
    (hF.contDiffAt (hU.mem_nhds hgaU)).differentiableAt (by norm_cast)
  have hdG : DifferentiableAt ℝ G a :=
    (hG.contDiffAt (hV.mem_nhds haV)).differentiableAt (by norm_cast)
  have heD := extension_fderivWithin hU hgaU hgaT (hT _ hgaT) hdF heF
  have heDG := extension_fderivWithin hV haV haS (hS _ haS) hdG heG
  let W := V ∩ G ⁻¹' U
  have hW : IsOpen W := hG.continuousOn.isOpen_inter_preimage hV hU
  have haW : a ∈ W := ⟨haV,by change G a ∈ U; rwa [hGa]⟩
  have hcomp : ContDiffOn ℝ (⊤ : ℕ∞) (F ∘ G) W :=
    hF.comp (hG.mono Set.inter_subset_left) (fun p hp => hp.2)
  have hecomp : Set.EqOn (F ∘ G) (f ∘ g) (W ∩ S) := by
    intro p hp
    have hGp := heG ⟨hp.1.1,hp.2⟩
    change F (G p) = f (g p)
    rw [hGp]
    exact heF ⟨by have hh : G p ∈ U := hp.1.2; rwa [hGp] at hh,hgST hp.2⟩
  rw [extension_second_fderivWithin hW haW haS hS (hcomp.of_le (by norm_cast)) hecomp,
    extension_second_fderivWithin hU hgaU hgaT hT (hF.of_le (by norm_cast)) heF,
    heDG]
  change euclideanSecondFundamentalForm (F ∘ G) N a v w = _
  have hhF : ContDiffAt ℝ 2 F (G a) := by
    rw [hGa]
    exact (hF.contDiffAt (hU.mem_nhds hgaU)).of_le (by norm_cast)
  have ho : ∀ z, @inner ℝ EuclideanThree _ N (fderiv ℝ F (G a) z)=0 := by
    intro z
    rw [hGa,← heD]
    exact horth z
  rw [euclidean_second_form_reparametrization hhF
    ((hG.contDiffAt (hV.mem_nhds haV)).of_le (by norm_cast)) N ho,hGa]
  rfl

end EllipticSquareFunction
