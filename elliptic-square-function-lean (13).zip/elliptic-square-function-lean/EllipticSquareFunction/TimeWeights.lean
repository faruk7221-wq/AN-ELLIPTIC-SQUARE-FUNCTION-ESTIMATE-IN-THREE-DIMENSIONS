import EllipticSquareFunction.TimeTiles

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

def timeInteraction (A : ℝ) (j k : ℤ) : ℝ := bracket ((j:ℝ)-(k:ℝ))^(-A)

theorem timeInteraction_pos (A : ℝ) (j k : ℤ) : 0<timeInteraction A j k :=
  Real.rpow_pos_of_pos (bracket_pos _) _

theorem timeInteraction_sum_bound {A : ℝ} (hA : 1<A) (j : ℤ) (s : Finset ℤ) :
    (∑ k ∈ s, timeInteraction A j k) ≤ timeLatticeSumConstant A := by
  exact (Summable.sum_le_tsum s (fun k _ => (timeInteraction_pos A j k).le)
    (translated_time_lattice_summable (j:ℝ) hA)).trans (translated_time_lattice_sum_le (j:ℝ) hA)

theorem timeInteraction_ennreal_sum {A : ℝ} (hA : 1<A) (j : ℤ) (s : Finset ℤ) :
    (∑ k ∈ s, ENNReal.ofReal (timeInteraction A j k)) ≤ ENNReal.ofReal (timeLatticeSumConstant A) := by
  rw [← ENNReal.ofReal_sum_of_nonneg (fun k _ => (timeInteraction_pos A j k).le)]
  exact ENNReal.ofReal_le_ofReal (timeInteraction_sum_bound hA j s)

theorem temporal_weight_comparison {u a M : ℝ} (hM : 0≤M) (h : 0≤u-a ∧ u-a≤1) :
    bracket a^(-M) ≤ 2^M*bracket u^(-M) := by
  have hh := Real.rpow_le_rpow_of_nonpos (bracket_pos u)
    (bracket_time_slab_comparison h).1 (neg_nonpos.mpr hM)
  rw [Real.mul_rpow (by norm_num : (0:ℝ)≤2) (bracket_pos a).le,
    Real.rpow_neg (by norm_num : (0:ℝ)≤2)] at hh
  have h2 : 0<(2:ℝ)^M := Real.rpow_pos_of_pos (by norm_num) _
  have hh' := mul_le_mul_of_nonneg_left hh h2.le
  have he : (2:ℝ)^M*((2^M)⁻¹*bracket a^(-M))=bracket a^(-M) := by
    rw [← mul_assoc,mul_inv_cancel₀ h2.ne',one_mul]
  rw [he] at hh'
  exact hh'

theorem timeInteraction_density_bound {A M R : ℝ} (hM : 0≤M) (hAM : M≤2*A/3)
    (j k : ℤ) {y : Space} (hy : y∈timeTile R j) :
    timeInteraction A j k^(2/3:ℝ) ≤ 2^M*bracket (y.2/R-(k:ℝ))^(-M) := by
  have hu := timeTile_normalized j hy
  have hshift : 0≤(y.2/R-(k:ℝ))-((j:ℝ)-(k:ℝ)) ∧
      (y.2/R-(k:ℝ))-((j:ℝ)-(k:ℝ))≤1 := by constructor <;> linarith [hu.1,hu.2]
  unfold timeInteraction
  rw [← Real.rpow_mul (bracket_pos _).le]
  exact (Real.rpow_le_rpow_of_exponent_le (by dsimp [bracket]; exact le_add_of_nonneg_right (abs_nonneg _))
    (by linarith : -A*(2/3)≤-M)).trans (temporal_weight_comparison hM hshift)

end EllipticSquareFunction
