import EllipticSquareFunction.SamplingDensityReal
import EllipticSquareFunction.PositiveDualNorm

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000
attribute [local instance] space_volume_neg_invariant space_volume_add_left_invariant
local instance : (volume : Measure Space).IsAddHaarMeasure :=
  Measure.prod.instIsAddHaarMeasure (volume : Measure Plane) (volume : Measure ℝ)

/-- A bounded integrable nonnegative density belongs to L^(3/2). -/
theorem memLp_three_halves_of_integrable_bounded {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (g : α → ℝ) (hg : Integrable g μ) (hpos : ∀ x, 0≤g x)
    {B : ℝ} (hB : 0≤B) (hbound : ∀ x, g x≤B) : MemLp g (3/2) μ := by
  apply (integrable_norm_rpow_iff hg.1 (by norm_num)
    (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne).mp
  simp only [ENNReal.toReal_div, ENNReal.toReal_ofNat]
  have hr : AEStronglyMeasurable (fun x => ‖g x‖^(3/2:ℝ)) μ :=
    (Real.continuous_rpow_const (by norm_num)).comp_aestronglyMeasurable hg.1.norm
  apply (hg.mul_const (Real.sqrt B)).mono' hr
  filter_upwards with x
  rw [Real.norm_eq_abs,abs_of_nonneg (Real.rpow_nonneg (norm_nonneg _) _)]
  simp only [ENNReal.toReal_div,ENNReal.toReal_ofNat,Real.norm_eq_abs,abs_of_nonneg (hpos x)]
  have he : g x^(3/2:ℝ)=g x*Real.sqrt (g x) := by
    rw [Real.sqrt_eq_rpow]
    have hh := Real.rpow_add_of_nonneg (hpos x) (by norm_num : (0:ℝ)≤1) (by norm_num : (0:ℝ)≤1/2)
    norm_num at hh
    exact hh
  rw [he]
  exact mul_le_mul_of_nonneg_left (Real.sqrt_le_sqrt (hbound x)) (hpos x)

/-- Pointwise uniform bound used only to justify the dual test; its constant
may depend on the individual Schwartz datum. -/
theorem schwartz_square_convolution_bound (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) (y : Space) :
    positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V) y ≤
      (SchwartzMap.seminorm ℝ 0 0 f)^2*(∫ z, tubeKernel R M V z) := by
  rw [positiveConvolution,← integral_const_mul]
  apply integral_mono
  · simpa only [sub_sub_cancel] using
      (schwartz_square_tube_integrable f hR hM V y).comp_sub_left y
  · exact (tubeKernel_integrable hR hM V).const_mul _
  · intro z
    exact mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (norm_nonneg _) (SchwartzMap.norm_le_seminorm ℝ f (y-z)) 2)
      (tubeKernel_nonneg ..)

/-- The convolution is continuous and integrable for actual squared Schwartz data. -/
theorem schwartz_square_convolution_regular (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) :
    Continuous (positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V)) ∧
    Integrable (positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V)) volume := by
  let L := ContinuousLinearMap.mul ℝ ℝ
  have he : positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V)=
      MeasureTheory.convolution (tubeKernel R M V) (fun z => ‖f z‖^2) L volume := by
    funext y
    simp only [positiveConvolution,MeasureTheory.convolution_def,L,ContinuousLinearMap.mul_apply',mul_comm]
  rw [he]
  have hb : BddAbove (Set.range (fun z => ‖‖f z‖^2‖)) := by
    refine ⟨(SchwartzMap.seminorm ℝ 0 0 f)^2,?_⟩
    rintro _ ⟨z,rfl⟩
    dsimp only
    rw [Real.norm_eq_abs,abs_of_nonneg (sq_nonneg _)]
    exact pow_le_pow_left₀ (norm_nonneg _) (SchwartzMap.norm_le_seminorm ℝ f z) 2
  exact ⟨hb.continuous_convolution_right_of_integrable L (tubeKernel_integrable hR hM V)
      (f.continuous.norm.pow 2),
    (tubeKernel_integrable hR hM V).integrable_convolution L
      ((f.memLp 2 volume).integrable_norm_pow (by norm_num))⟩

/-- No smoothing estimate is needed to establish finiteness of the density norm. -/
theorem schwartz_square_convolution_memLp (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) :
    MemLp (positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V)) (3/2) volume := by
  exact memLp_three_halves_of_integrable_bounded volume _
    (schwartz_square_convolution_regular f hR hM V).2
    (fun y => integral_nonneg (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..)))
    (mul_nonneg (sq_nonneg _) (integral_nonneg (fun z => tubeKernel_nonneg R M V z)))
    (schwartz_square_convolution_bound f hR hM V)

end EllipticSquareFunction
