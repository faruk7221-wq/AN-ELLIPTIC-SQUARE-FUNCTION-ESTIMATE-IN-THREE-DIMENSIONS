import EllipticSquareFunction.MatrixSchur

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Uniform row sum for frequency-truncated spatial decay. -/
theorem separated_interaction_row_sum {ι : Type*} (s : Finset ι)
    (pbox : ι → Finset IntPlane) (ν : ι → Plane) (v : ι → IntPlane → Plane)
    {N c A L : ℝ} (hN : 0<N) (hc : 0<c) (hL : 2<L) (μ w : Plane) (K : ℕ)
    (hpos : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hoverlap : FrequencyOverlap N A s ν μ K) :
    (∑ ip ∈ s.sigma pbox,
      if ‖μ-ν ip.1‖≤A/N then bracket (N⁻¹ • (w-v ip.1 ip.2))^(-L) else 0) ≤
      (K:ℝ)*separatedPlaneSumConstant c L := by
  classical
  rw [Finset.sum_sigma]
  have he : (∑ i ∈ s, ∑ p ∈ pbox i,
      if ‖μ-ν i‖≤A/N then bracket (N⁻¹ • (w-v i p))^(-L) else 0) =
      ∑ i ∈ s.filter (fun i => ‖μ-ν i‖≤A/N),
        ∑ p ∈ pbox i, bracket (N⁻¹ • (w-v i p))^(-L) := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro i hi
    split_ifs <;> simp_all
  rw [he]
  calc
    _ ≤ ∑ i ∈ s.filter (fun i => ‖μ-ν i‖≤A/N), separatedPlaneSumConstant c L :=
      Finset.sum_le_sum (fun i hi => separated_scaled_plane_weight_sum (pbox i) (v i)
        hN hc hL (hpos i (Finset.mem_filter.mp hi).1) w)
    _ = ((s.filter (fun i => ‖μ-ν i‖≤A/N)).card:ℝ)*separatedPlaneSumConstant c L := by simp
    _ ≤ _ := mul_le_mul_of_nonneg_right (by exact_mod_cast hoverlap)
      (separatedPlaneSumConstant_nonneg hc hL)

/-- Uniform weighted column sum, using both full spatial convolution and
the bounded number of fine frequencies near a given original frequency. -/
theorem separated_interaction_column_sum (q : Finset IntPlane)
    (qpos : IntPlane → Finset IntPlane) {N d A E M L : ℝ}
    (hN : 0<N) (hd : 0<d) (hE : 0≤E) (hM : 0≤M) (hLM : 2<L-M)
    (ν V v : Plane) (Vμ : IntPlane → Plane) (y : Space) (ht : |y.2|≤N^2)
    (hvel : ∀ m ∈ q, ‖latticePoint N⁻¹ m-ν‖≤A/N → ‖Vμ m-V‖≤E/N) :
    (∑ mn ∈ q.sigma qpos,
      (if ‖latticePoint N⁻¹ mn.1-ν‖≤A/N then
        bracket (N⁻¹ • (N • latticePoint d mn.2-v))^(-L) else 0)*
        spatialWeight N M (Vμ mn.1) (N • latticePoint d mn.2) y) ≤
      ((integerPlaneBox ⌈A+2⌉₊).card:ℝ)*
        (scaledLatticeSumConstant d (L-M)*(1+E)^M)*spatialWeight N M V v y := by
  classical
  let C := scaledLatticeSumConstant d (L-M)*(1+E)^M
  have hscale : 0≤scaledLatticeSumConstant d (L-M) := by
    simpa using scaled_lattice_finite_sum_le hd hLM (0:Plane) ∅
  have hC : 0≤C := mul_nonneg hscale (Real.rpow_nonneg (by linarith) _)
  have he : (∑ mn ∈ q.sigma qpos,
      (if ‖latticePoint N⁻¹ mn.1-ν‖≤A/N then
        bracket (N⁻¹ • (N • latticePoint d mn.2-v))^(-L) else 0)*
        spatialWeight N M (Vμ mn.1) (N • latticePoint d mn.2) y) =
      ∑ m ∈ q.filter (fun m => ‖latticePoint N⁻¹ m-ν‖≤A/N),
        ∑ n ∈ qpos m, bracket (N⁻¹ • (N • latticePoint d n-v))^(-L)*
          spatialWeight N M (Vμ m) (N • latticePoint d n) y := by
    rw [Finset.sum_sigma,Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro m hm
    split_ifs <;> simp_all
  rw [he]
  calc
    _ ≤ ∑ m ∈ q.filter (fun m => ‖latticePoint N⁻¹ m-ν‖≤A/N), C*spatialWeight N M V v y := by
      apply Finset.sum_le_sum
      intro m hm
      apply (matrix_spatial_weight_convolution (qpos m) hN hd hM hLM (Vμ m) v y).trans
      have hh := mul_le_mul_of_nonneg_left
        (spatialWeight_velocity_comparison hN hE hM (Vμ m) V v y ht
          (hvel m (Finset.mem_filter.mp hm).1 (Finset.mem_filter.mp hm).2)) hscale
      simpa only [C,mul_assoc] using hh
    _ = ((q.filter (fun m => ‖latticePoint N⁻¹ m-ν‖≤A/N)).card:ℝ)*(C*spatialWeight N M V v y) := by simp
    _ ≤ _ := by
      have hh := mul_le_mul_of_nonneg_right
        (show ((q.filter (fun m => ‖latticePoint N⁻¹ m-ν‖≤A/N)).card:ℝ)≤
          ((integerPlaneBox ⌈A+2⌉₊).card:ℝ) by exact_mod_cast canonical_frequency_near_count hN ν q)
        (mul_nonneg hC (spatialWeight_nonneg N M V v y))
      simpa only [C,mul_assoc] using hh

/-- Whole spatial-weight density transport for any matrix with the stated
cutoff and decay. This is the geometric Schur estimate used in (5.9). -/
theorem separated_matrix_weighted_density {ι : Type*} (s : Finset ι)
    (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (qpos : IntPlane → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν V : ι → Plane) (v : ι → IntPlane → Plane)
    (Vμ : IntPlane → Plane) (Kmat : (Σ _ : IntPlane, IntPlane) → (Σ _ : ι, IntPlane) → ℂ)
    {N c d A E M L C : ℝ} (hN : 0<N) (hc : 0<c) (hd : 0<d) (hE : 0≤E)
    (hM : 0≤M) (hLM : 2<L-M) (y : Space) (ht : |y.2|≤N^2) (K : ℕ)
    (hpos : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v i p-v i r‖)
    (hoverlap : ∀ m ∈ q, FrequencyOverlap N A s ν (latticePoint N⁻¹ m) K)
    (hvel : ∀ m ∈ q, ∀ i ∈ s, ‖latticePoint N⁻¹ m-ν i‖≤A/N → ‖Vμ m-V i‖≤E/N)
    (hcut : ∀ mn ∈ q.sigma qpos, ∀ ip ∈ s.sigma pbox,
      A/N<‖latticePoint N⁻¹ mn.1-ν ip.1‖ → Kmat mn ip=0)
    (hdecay : ∀ mn ∈ q.sigma qpos, ∀ ip ∈ s.sigma pbox,
      ‖latticePoint N⁻¹ mn.1-ν ip.1‖≤A/N →
      ‖Kmat mn ip‖≤C*bracket (N⁻¹ • (N • latticePoint d mn.2-v ip.1 ip.2))^(-L)) :
    (∑ mn ∈ q.sigma qpos, ‖∑ ip ∈ s.sigma pbox, Kmat mn ip*a ip.1 ip.2‖^2*
      spatialWeight N M (Vμ mn.1) (N • latticePoint d mn.2) y) ≤
      C^2*((K:ℝ)*separatedPlaneSumConstant c L)*
        (((integerPlaneBox ⌈A+2⌉₊).card:ℝ)*(scaledLatticeSumConstant d (L-M)*(1+E)^M))*
        spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => V ip.1) (fun ip => v ip.1 ip.2) N M y := by
  classical
  let W := fun (mn : Σ _ : IntPlane, IntPlane) (ip : Σ _ : ι, IntPlane) =>
    if ‖latticePoint N⁻¹ mn.1-ν ip.1‖≤A/N then
      bracket (N⁻¹ • (N • latticePoint d mn.2-v ip.1 ip.2))^(-L) else 0
  have hL : 2<L := by linarith
  refine finite_weighted_schur_density (s.sigma pbox) (q.sigma qpos)
    (fun ip => a ip.1 ip.2) Kmat W
    (fun mn => spatialWeight N M (Vμ mn.1) (N • latticePoint d mn.2) y)
    (fun ip => spatialWeight N M (V ip.1) (v ip.1 ip.2) y)
    (mul_nonneg (Nat.cast_nonneg K) (separatedPlaneSumConstant_nonneg hc hL))
    (fun mn hmn => spatialWeight_nonneg ..) ?_ ?_ ?_ ?_
  · intro mn hmn ip hip
    dsimp [W]
    split_ifs
    · exact Real.rpow_nonneg (bracket_pos _).le _
    · exact le_rfl
  · intro mn hmn ip hip
    dsimp [W]
    split_ifs with hnear
    · exact hdecay mn hmn ip hip hnear
    · rw [hcut mn hmn ip hip (lt_of_not_ge hnear),norm_zero,mul_zero]
  · intro mn hmn
    exact separated_interaction_row_sum s pbox ν v hN hc hL
      (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2) K hpos
      (hoverlap mn.1 (Finset.mem_sigma.mp hmn).1)
  · intro ip hip
    exact separated_interaction_column_sum q qpos hN hd hE hM hLM (ν ip.1)
      (V ip.1) (v ip.1 ip.2) Vμ y ht
      (fun m hm => hvel m hm ip.1 (Finset.mem_sigma.mp hip).1)

end EllipticSquareFunction
