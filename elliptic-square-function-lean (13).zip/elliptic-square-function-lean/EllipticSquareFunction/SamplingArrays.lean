import EllipticSquareFunction.LemmaFour
import EllipticSquareFunction.UniformCapCount
import EllipticSquareFunction.Oversampling

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Distinct integer spatial lattice points are at least unit distance apart. -/
theorem unit_lattice_separation {p q : IntPlane} (hpq : p≠q) :
    1≤‖latticePoint 1 p-latticePoint 1 q‖ := by
  obtain ⟨j,hj⟩ := Function.ne_iff.mp hpq
  have hz : p j-q j≠0 := sub_ne_zero.mpr hj
  have hh : (1:ℝ)≤|(p j:ℝ)-(q j:ℝ)| := by exact_mod_cast Int.one_le_abs hz
  have hn := PiLp.norm_apply_le (latticePoint 1 p-latticePoint 1 q) j
  exact hh.trans (by simpa only [latticePoint,PiLp.sub_apply,
    one_mul,Real.norm_eq_abs] using hn)

def samplingPositions (Q : Finset (IntPlane × ℤ)) (k : ℤ) : Finset IntPlane :=
  (Q.filter (fun i => i.2=k)).image Prod.fst

/-- Decompose any finite lattice truncation into its time fibers. -/
theorem sampling_fiber_sum {E : Type*} [AddCommMonoid E]
    (Q : Finset (IntPlane × ℤ)) (f : IntPlane × ℤ → E) :
    (∑ k ∈ Q.image Prod.snd, ∑ ℓ ∈ samplingPositions Q k, f (ℓ,k))=∑ i ∈ Q, f i := by
  classical
  calc
    _ = ∑ k ∈ Q.image Prod.snd, ∑ i ∈ Q.filter (fun i => i.2=k), f i := by
      apply Finset.sum_congr rfl
      intro k hk
      rw [samplingPositions,Finset.sum_image]
      · apply Finset.sum_congr rfl
        intro i hi
        have h := (Finset.mem_filter.mp hi).2
        simp only [← h,Prod.mk.eta]
      · intro i hi j hj hij
        exact Prod.ext hij ((Finset.mem_filter.mp hi).2.trans (Finset.mem_filter.mp hj).2.symm)
    _ = _ := Finset.sum_fiberwise_of_maps_to (fun i hi => Finset.mem_image.mpr ⟨i,hi,rfl⟩) f

def samplingArray {n : ℕ} (φ : Phase) (R D : ℝ) (ν : Fin n → Plane)
    (a : Fin n → IntPlane × ℤ → ℂ) (Q : Finset (IntPlane × ℤ)) (k : ℤ) : FinitePacketArray (Fin n) where
  labels := Finset.univ
  positions := fun _ => samplingPositions Q k
  coefficient := fun θ ℓ => a θ (ℓ,k)
  frequency := ν
  position := fun θ ℓ => (samplePoint (Real.sqrt R) R D D (velocity φ (ν θ)) (latticePoint 1 ℓ) k).1

/-- The sheared sampling centers satisfy exactly the separation required by
Proposition 3, without restricting their distance from the origin. -/
theorem samplingArray_separated {n : ℕ} (φ : Phase) {N D σ F : ℝ}
    (hN : 0<N) (hD : 0<D) (ν : Fin n → Plane)
    (hν : ∀ θ, ‖ν θ‖≤F) (hsep : ∀ θ θ', θ≠θ' → σ/N≤‖ν θ-ν θ'‖)
    (a : Fin n → IntPlane × ℤ → ℂ) (Q : Finset (IntPlane × ℤ)) (k : ℤ) :
    SeparatedPacketArray (samplingArray φ (N^2) D ν a Q k) N D⁻¹ σ F := by
  refine ⟨fun θ _ => hν θ,fun θ _ θ' _ hh => hsep θ θ' hh,?_⟩
  intro θ hθ p hp q hq hpq
  have he : (samplingArray φ (N^2) D ν a Q k).position θ p-
      (samplingArray φ (N^2) D ν a Q k).position θ q =
      (N/D) • (latticePoint 1 p-latticePoint 1 q) := by
    simp only [samplingArray,samplePoint,Real.sqrt_sq hN.le]
    module
  rw [he,norm_smul,Real.norm_eq_abs,abs_of_pos (div_pos hN hD)]
  have hh := mul_le_mul_of_nonneg_left (unit_lattice_separation hpq) (div_pos hN hD).le
  simpa only [mul_one,div_eq_inv_mul] using hh

/-- A finite sample synthesis is exactly the oversampled time-array synthesis. -/
theorem samplingArray_synthesis {n : ℕ} (φ : Phase) (b : Plane → ℂ) (ψ : ℝ → ℂ)
    {N : ℝ} (hN : 0≤N) (D : ℝ) (ν : Fin n → Plane)
    (a : Fin n → IntPlane × ℤ → ℂ) (Q : Finset (IntPlane × ℤ)) (y : Space) :
    (∑ k ∈ Q.image Prod.snd, arrayTimePacket (samplingArray φ (N^2) D ν a Q k)
      φ b ψ N ((k:ℝ)*(N^2/D)) y) =
      ∑ i ∈ Q, ∑ θ, a θ i*timePacket φ b ψ (N^2) (ν θ)
        (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).1
        (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).2 y := by
  simp_rw [arrayTimePacket_eq_packets _ _ _ _ hN]
  simp only [samplingArray,Real.sqrt_sq hN]
  simp_rw [Finset.sum_comm (s := Finset.univ)]
  convert sampling_fiber_sum Q (fun i => ∑ θ, a θ i*timePacket φ b ψ (N^2) (ν θ)
    (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).1
    (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).2 y) using 1 <;>
    simp only [samplePoint,mul_div_assoc]

/-- The matching finite-array density has exactly the sampling weights. -/
theorem samplingArray_density {n : ℕ} (φ : Phase) {N : ℝ} (hN : 0≤N)
    (D M : ℝ) (ν : Fin n → Plane) (a : Fin n → IntPlane × ℤ → ℂ)
    (Q : Finset (IntPlane × ℤ)) (y : Space) :
    (∑ k ∈ Q.image Prod.snd, arrayPacketDensity (samplingArray φ (N^2) D ν a Q k)
      φ N M ((k:ℝ)*(N^2/D)) y) =
      ∑ i ∈ Q, ∑ θ, ‖a θ i‖^2*packetWeight (N^2) M (velocity φ (ν θ))
        (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).1
        (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).2 y := by
  simp_rw [arrayPacketDensity_eq_packets _ _ hN M]
  simp only [packetDensity,Finset.sum_sigma,samplingArray,Real.sqrt_sq hN]
  simp_rw [Finset.sum_comm (s := Finset.univ)]
  convert sampling_fiber_sum Q (fun i => ∑ θ, ‖a θ i‖^2*packetWeight (N^2) M (velocity φ (ν θ))
    (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).1
    (samplePoint N (N^2) D D (velocity φ (ν θ)) (latticePoint 1 i.1) i.2).2 y) using 1 <;>
    simp only [samplePoint,mul_div_assoc]

end EllipticSquareFunction
