import EllipticSquareFunction.EuclideanEmbeddedSurface

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- The two local parameter models for a smooth surface with boundary. -/
inductive SurfaceParameterModel where
  | interior
  | boundary

def SurfaceParameterModel.domain : SurfaceParameterModel → Set Plane
  | .interior => Set.univ
  | .boundary => {b | 0 ≤ b 1}

/-- A chart-based definition of a smooth embedded elliptic surface, allowing
smooth boundary. The parametrization extends smoothly to an open planar
domain. Near p the carrier is exactly its interior or half-plane portion.
The second fundamental form is definite for a unit normal at p.

This is an explicit extrinsic definition, independent of Mathlib's abstract
manifold API. It records the smooth extension used in Section 8. -/
def SmoothEllipticSurfaceWithBoundary (K : Set EuclideanThree) : Prop :=
  ∀ p ∈ K, ∃ (F : Plane → EuclideanThree) (U : Set Plane) (a : Plane)
      (W : Set EuclideanThree) (N : EuclideanThree) (model : SurfaceParameterModel),
    IsOpen U ∧ a ∈ U ∧ a ∈ model.domain ∧
    (model = .boundary → a 1=0) ∧
    ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
    Topology.IsEmbedding (fun b : U => F b) ∧ F a=p ∧
    IsOpen W ∧ p ∈ W ∧ K ∩ W=(F '' (U ∩ model.domain)) ∩ W ∧
    Function.Injective (fderiv ℝ F a) ∧ ‖N‖=1 ∧
    (∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F a v)=0) ∧
    EuclideanDefiniteSecondForm F N a

theorem surface_with_boundary_has_extensions {K : Set EuclideanThree}
    (hs : SmoothEllipticSurfaceWithBoundary K) : EuclideanEllipticSurfaceExtensions K := by
  intro p hp
  obtain ⟨F,U,a,W,N,model,hU,ha,_,_,hF,hemb,hFa,hW,hpW,hpatch,hD,hN,horth,hdef⟩ := hs p hp
  refine ⟨F,U,a,W,N,hU,ha,hF,hemb,hFa,hW,hpW,?_,hD,hN,horth,hdef⟩
  rw [hpatch]
  exact Set.Subset.trans Set.inter_subset_left (Set.image_mono Set.inter_subset_left)

/-- The surface assertion of Theorem 1 under the explicit smooth embedded
chart definition, including boundary charts and the stated external inputs. -/
theorem article_surface_theorem {K : Set EuclideanThree} (hK : IsCompact K)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hsurface : SmoothEllipticSurfaceWithBoundary K)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (p : Fin n → EuclideanThree) (f : Fin n → SchwartzMap EuclideanThree ℂ),
      (∀ i, p i ∈ K) →
      (∀ i j, i ≠ j → c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
      (∀ i, Function.support (Real.fourierIntegral (f i)) ⊆ surfaceCap K (p i) (Real.sqrt R)⁻¹ C₀) →
      eLpNorm (fun y => ∑ i, f i y) 3 volume ≤ ENNReal.ofReal (C*R^ε)*
        eLpNorm (fun y => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume :=
  euclidean_embedded_surface_estimate hK hc₀ hC₀ (surface_with_boundary_has_extensions hsurface)
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
