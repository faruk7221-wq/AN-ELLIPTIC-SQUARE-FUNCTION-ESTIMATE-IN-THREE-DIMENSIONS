import EllipticSquareFunction.Lattice

/-! # Uniform bounds for the rescaled lattices used in the frames -/

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

theorem latticePoint_mul (a b : ℝ) (m : IntPlane) :
    latticePoint (a * b) m = a • latticePoint b m := by
  ext i
  simp [latticePoint, mul_assoc]

theorem scaled_lattice_majorant {a b : ℝ} (ha : 0 < a) (hb : 0 ≤ b)
    (u : Plane) (m : IntPlane) :
    bracket (u - latticePoint a m) ^ (-b) ≤
      (1 + a⁻¹) ^ b * bracket (a⁻¹ • u - latticePoint 1 m) ^ (-b) := by
  let q := 1 + a⁻¹
  have hq : 0 < q := by dsimp [q]; positivity
  have he : a⁻¹ • (u - latticePoint a m) = a⁻¹ • u - latticePoint 1 m := by
    rw [smul_sub, ← latticePoint_mul, inv_mul_cancel₀ ha.ne']
  have hcomp : bracket (a⁻¹ • u - latticePoint 1 m) ≤ q * bracket (u - latticePoint a m) := by
    rw [← he]
    simp only [bracket, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr ha)]
    dsimp [q]
    nlinarith [norm_nonneg (u - latticePoint a m), inv_pos.mpr ha]
  have h := Real.rpow_le_rpow_of_nonpos (bracket_pos _) hcomp (neg_nonpos.mpr hb)
  rw [Real.mul_rpow hq.le (bracket_pos _).le, Real.rpow_neg hq.le] at h
  have hpow : 0 < q ^ b := Real.rpow_pos_of_pos hq _
  have h' := mul_le_mul_of_nonneg_left h hpow.le
  have hc : q ^ b * ((q ^ b)⁻¹ * bracket (u - latticePoint a m) ^ (-b)) =
      bracket (u - latticePoint a m) ^ (-b) := by field_simp
  rw [hc] at h'
  exact h'

def scaledLatticeSumConstant (a b : ℝ) : ℝ := (1 + a⁻¹) ^ b * latticeSumConstant b

theorem scaled_translated_lattice_summable {a b : ℝ} (ha : 0 < a) (hb : 2 < b)
    (u : Plane) : Summable (fun m : IntPlane => bracket (u - latticePoint a m) ^ (-b)) := by
  apply ((translated_lattice_summable (a⁻¹ • u) hb).mul_left ((1 + a⁻¹) ^ b)).of_nonneg_of_le
  · intro m
    exact Real.rpow_nonneg (bracket_pos _).le _
  · intro m
    exact scaled_lattice_majorant ha (by linarith) u m

theorem scaled_translated_lattice_sum_le {a b : ℝ} (ha : 0 < a) (hb : 2 < b) (u : Plane) :
    (∑' m : IntPlane, bracket (u - latticePoint a m) ^ (-b)) ≤ scaledLatticeSumConstant a b := by
  calc
    _ ≤ ∑' m : IntPlane, (1 + a⁻¹) ^ b * bracket (a⁻¹ • u - latticePoint 1 m) ^ (-b) :=
      Summable.tsum_le_tsum (fun m => scaled_lattice_majorant ha (by linarith) u m)
        (scaled_translated_lattice_summable ha hb u)
        ((translated_lattice_summable (a⁻¹ • u) hb).mul_left _)
    _ = (1 + a⁻¹) ^ b * ∑' m : IntPlane, bracket (a⁻¹ • u - latticePoint 1 m) ^ (-b) := tsum_mul_left
    _ ≤ scaledLatticeSumConstant a b := mul_le_mul_of_nonneg_left
      (translated_lattice_sum_le (a⁻¹ • u) hb) (by positivity)

theorem scaled_lattice_finite_sum_le {a b : ℝ} (ha : 0 < a) (hb : 2 < b)
    (u : Plane) (s : Finset IntPlane) :
    (∑ m ∈ s, bracket (u - latticePoint a m) ^ (-b)) ≤ scaledLatticeSumConstant a b := by
  apply le_trans _ (scaled_translated_lattice_sum_le ha hb u)
  exact Summable.sum_le_tsum s (fun _ _ => Real.rpow_nonneg (bracket_pos _).le _)
    (scaled_translated_lattice_summable ha hb u)

/-- The weight convolution inequality on every fixed positive lattice scale. -/
theorem scaled_spatial_lattice_convolution {c a b : ℝ} (hc : 0 < c)
    (ha : 0 ≤ a) (hab : 2 < b - a) (u v : Plane) :
    (∑' m : IntPlane, bracket (u - latticePoint c m) ^ (-b) *
      bracket (latticePoint c m - v) ^ (-a)) ≤
      scaledLatticeSumConstant c (b - a) * bracket (u - v) ^ (-a) :=
  infinite_weight_convolution (latticePoint c) u v ha
    (scaled_translated_lattice_summable hc hab u) (scaled_translated_lattice_sum_le hc hab u)

/-- A pointwise tail majorant that reserves an integrable power `b` for
the lattice sum. For instance, `b = 3` gives decay `R^(3-L)` in dimension two. -/
theorem bracket_tail_majorant {L b R : ℝ} (hLb : b ≤ L) (hR : 0 ≤ R)
    (v : Plane) (hv : R ≤ ‖v‖) :
    bracket v ^ (-L) ≤ (1 + R) ^ (-(L - b)) * bracket v ^ (-b) := by
  have hp : 0 < 1 + R := by linarith
  have h := Real.rpow_le_rpow_of_nonpos hp
    (by dsimp [bracket]; linarith : 1 + R ≤ bracket v) (by linarith : -(L - b) ≤ 0)
  calc
    bracket v ^ (-L) = bracket v ^ (-(L - b)) * bracket v ^ (-b) := by
      rw [← Real.rpow_add (bracket_pos v)]
      congr 1
      ring
    _ ≤ _ := mul_le_mul_of_nonneg_right h (Real.rpow_nonneg (bracket_pos v).le _)

def latticeTailWeight (a L R : ℝ) (u : Plane) (m : IntPlane) : ℝ :=
  if R ≤ ‖u - latticePoint a m‖ then bracket (u - latticePoint a m) ^ (-L) else 0

theorem scaled_lattice_tail_summable {a L b R : ℝ} (ha : 0 < a) (hb : 2 < b)
    (hLb : b ≤ L) (hR : 0 ≤ R) (u : Plane) :
    Summable (latticeTailWeight a L R u) := by
  apply ((scaled_translated_lattice_summable ha hb u).mul_left ((1 + R) ^ (-(L - b)))).of_nonneg_of_le
  · intro m
    unfold latticeTailWeight
    split_ifs
    · exact Real.rpow_nonneg (bracket_pos _).le _
    · exact le_rfl
  · intro m
    unfold latticeTailWeight
    split_ifs with hm
    · exact bracket_tail_majorant hLb hR _ hm
    · dsimp [bracket]
      positivity

theorem scaled_lattice_tail_sum_le {a L b R : ℝ} (ha : 0 < a) (hb : 2 < b)
    (hLb : b ≤ L) (hR : 0 ≤ R) (u : Plane) :
    (∑' m, latticeTailWeight a L R u m) ≤
      (1 + R) ^ (-(L - b)) * scaledLatticeSumConstant a b := by
  have hp : 0 ≤ (1 + R) ^ (-(L - b)) := Real.rpow_nonneg (by linarith) _
  calc
    _ ≤ ∑' m : IntPlane, (1 + R) ^ (-(L - b)) * bracket (u - latticePoint a m) ^ (-b) := by
      apply Summable.tsum_le_tsum _ (scaled_lattice_tail_summable ha hb hLb hR u)
        ((scaled_translated_lattice_summable ha hb u).mul_left _)
      intro m
      unfold latticeTailWeight
      split_ifs with hm
      · exact bracket_tail_majorant hLb hR _ hm
      · dsimp [bracket]
        positivity
    _ = (1 + R) ^ (-(L - b)) * ∑' m : IntPlane, bracket (u - latticePoint a m) ^ (-b) := tsum_mul_left
    _ ≤ _ := mul_le_mul_of_nonneg_left (scaled_translated_lattice_sum_le ha hb u) hp

theorem far_position_distance {A R : ℝ} {x w : Plane}
    (hx : ‖x‖ ≤ A * R) (hw : (A + 1) * R < ‖w‖) : R < ‖x - w‖ := by
  have h := norm_sub_norm_le w x
  rw [norm_sub_rev] at h
  nlinarith

/-- The omitted-position lattice tail for points in a bounded spatial region.
The bound is uniform in the observation point and uses no counting assumption. -/
theorem scaled_lattice_position_tail {a L b A R : ℝ} (ha : 0 < a) (hb : 2 < b)
    (hLb : b ≤ L) (hR : 0 ≤ R) (x : Plane) (hx : ‖x‖ ≤ A * R) :
    let f := fun m : IntPlane => if (A + 1) * R < ‖latticePoint a m‖
      then bracket (x - latticePoint a m) ^ (-L) else 0
    Summable f ∧ (∑' m, f m) ≤ (1 + R) ^ (-(L - b)) * scaledLatticeSumConstant a b := by
  classical
  dsimp only
  have htail := scaled_lattice_tail_summable ha hb hLb hR x
  have hnonneg (m : IntPlane) : 0 ≤ (if (A + 1) * R < ‖latticePoint a m‖
      then bracket (x - latticePoint a m) ^ (-L) else 0) := by
    split_ifs
    · exact Real.rpow_nonneg (bracket_pos _).le _
    · exact le_rfl
  have hle (m : IntPlane) : (if (A + 1) * R < ‖latticePoint a m‖
      then bracket (x - latticePoint a m) ^ (-L) else 0) ≤ latticeTailWeight a L R x m := by
    split_ifs with hm
    · rw [latticeTailWeight, if_pos (far_position_distance hx hm).le]
    · unfold latticeTailWeight
      split_ifs
      · exact Real.rpow_nonneg (bracket_pos _).le _
      · exact le_rfl
  have hs := htail.of_nonneg_of_le hnonneg hle
  exact ⟨hs, (hs.tsum_le_tsum hle htail).trans (scaled_lattice_tail_sum_le ha hb hLb hR x)⟩

/-- Absolute convergence and a norm bound for any complex synthesis tail
with the verified polynomial kernel majorant. -/
theorem complex_position_tail_bound {a L b A R C : ℝ} (ha : 0 < a) (hb : 2 < b)
    (hLb : b ≤ L) (hR : 0 ≤ R) (hC : 0 ≤ C) (x : Plane) (hx : ‖x‖ ≤ A * R)
    (F : IntPlane → ℂ) (hF : ∀ m, ‖F m‖ ≤ C * bracket (x - latticePoint a m) ^ (-L)) :
    let f := fun m => if (A + 1) * R < ‖latticePoint a m‖ then F m else 0
    Summable f ∧ ‖∑' m, f m‖ ≤
      C * ((1 + R) ^ (-(L - b)) * scaledLatticeSumConstant a b) := by
  classical
  let w := fun m : IntPlane => if (A + 1) * R < ‖latticePoint a m‖
    then bracket (x - latticePoint a m) ^ (-L) else 0
  let f := fun m => if (A + 1) * R < ‖latticePoint a m‖ then F m else 0
  obtain ⟨hw, hsum⟩ := scaled_lattice_position_tail ha hb hLb hR x hx
  have hmajor (m : IntPlane) : ‖f m‖ ≤ C * w m := by
    dsimp only [f, w]
    split_ifs
    · exact hF m
    · simp
  have hn : Summable (fun m => ‖f m‖) :=
    (hw.mul_left C).of_nonneg_of_le (fun m => norm_nonneg _) hmajor
  refine ⟨Summable.of_norm_bounded (fun m => C * w m) (hw.mul_left C) hmajor, ?_⟩
  calc
    ‖∑' m, f m‖ ≤ ∑' m, ‖f m‖ := norm_tsum_le_tsum_norm hn
    _ ≤ ∑' m, C * w m := hn.tsum_le_tsum hmajor (hw.mul_left C)
    _ = C * ∑' m, w m := tsum_mul_left
    _ ≤ _ := mul_le_mul_of_nonneg_left hsum hC

end EllipticSquareFunction
