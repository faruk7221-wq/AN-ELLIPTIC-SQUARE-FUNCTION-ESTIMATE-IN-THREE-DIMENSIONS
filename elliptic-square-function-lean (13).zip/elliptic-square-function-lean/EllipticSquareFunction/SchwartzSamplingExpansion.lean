import EllipticSquareFunction.SpaceFourierInversion

noncomputable section
open MeasureTheory Set
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- Cap support is compact because it lies in the support of a constructed
compact curved multiplier which equals one there. -/
theorem compactSupport_of_cap_support (φ : Phase) (hφ : Continuous φ)
    {C₀ R : ℝ} (hC₀ : 0≤C₀) (hR : 0<R) (ν : Plane) (f : Space → ℂ)
    (hs : Function.support f ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀) : HasCompactSupport f := by
  obtain ⟨χ,hχ,hχs,hχone,ρ,hρs,hρone⟩ := exists_sampling_cutoffs hC₀
  let m := curvedMultiplier φ χ ρ (Real.sqrt R) R ν
  have hm : HasCompactSupport m := compactSupport_curvedMultiplier φ hφ χ hχs ρ hρs
    (Real.sqrt_pos.mpr hR).ne' hR.ne' ν
  apply HasCompactSupport.of_support_subset_isCompact hm
  intro ζ hz
  apply subset_tsupport m
  have hh := curvedMultiplier_one_on_cap φ χ ρ (Real.sqrt_pos.mpr hR) hχone hρone ν (hs hz)
  simp only [Real.sq_sqrt hR.le] at hh
  change m ζ≠0
  change curvedMultiplier φ χ ρ (Real.sqrt R) R ν ζ≠0
  rw [hh]
  norm_num

/-- The packet expansion (6.1) for the article's actual physical Schwartz
functions, with coefficients (6.10), fixed profiles, and integer oversampling.
The coefficient-density estimate (6.2) is NOT part of this theorem. -/
theorem uniform_schwartz_cap_packet_expansion {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ : ℝ} (hC₀ : 0≤C₀) :
    ∃ χ : Plane → ℂ, ∃ ρ : SchwartzMap ℝ ℂ, ∃ D : ℕ,
      ContDiff ℝ (⊤ : ℕ∞) χ ∧ HasCompactSupport χ ∧
      HasCompactSupport (ρ : ℝ → ℂ) ∧ 0<D ∧
      ∀ R : ℝ, 0<R → ∀ ν : Plane, ∀ f : SchwartzMap Space ℂ,
      Function.support (fourierTransform f) ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀ → ∀ y : Space,
      let p := fun i : IntPlane × ℤ => samplePoint (Real.sqrt R) R D D
        (velocity φ ν) (latticePoint 1 i.1) i.2
      HasSum (fun i : IntPlane × ℤ =>
        ((((D:ℝ)^3)⁻¹:ℝ)*f (p i))*
          timePacket φ χ (inverseTimeProfile ρ) R ν (p i).1 (p i).2 y) (f y) := by
  obtain ⟨χ,ρ,D,hχ,hχs,hρs,hD,hexpand⟩ := uniform_inverse_cap_packet_expansion hphase hC₀
  have hφ : Continuous φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  refine ⟨χ,ρ,D,hχ,hχs,hρs,hD,?_⟩
  intro R hR ν f hs y
  have hh := hexpand R hR ν (fourierTransform f) (continuous_fourierTransform_schwartz f)
    (compactSupport_of_cap_support φ hφ hC₀ hR ν (fourierTransform f) hs) hs y
  simpa only [space_fourier_inversion] using hh

end EllipticSquareFunction
