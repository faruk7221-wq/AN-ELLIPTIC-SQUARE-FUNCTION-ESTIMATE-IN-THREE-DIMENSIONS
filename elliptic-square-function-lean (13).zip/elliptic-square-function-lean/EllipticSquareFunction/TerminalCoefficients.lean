import EllipticSquareFunction.CanonicalFrame
import EllipticSquareFunction.ScaledLattice

/-! # Uniform bounds for terminal coefficients -/

noncomputable section
open MeasureTheory
open scoped BigOperators
namespace EllipticSquareFunction

def cutoffMass (S : DiscreteSetup) : ℝ := ∫ ξ, S.χ ξ

theorem integrable_scaled_cutoff (S : DiscreteSetup) {N : ℝ} (hN : 0 < N) (ν : Plane) :
    Integrable (fun ξ => S.χ (N • (ξ - ν))) := by
  simpa only [sub_eq_add_neg] using
    ((S.χ_smooth.continuous.integrable_of_hasCompactSupport S.χ_compact).comp_smul hN.ne').comp_add_right (-ν)

theorem integral_scaled_cutoff (S : DiscreteSetup) {N : ℝ} (hN : 0 < N) (ν : Plane) :
    (∫ ξ, S.χ (N • (ξ - ν))) = (N ^ 2)⁻¹ * cutoffMass S := by
  have he : (∫ ξ, S.χ (N • (ξ - ν))) = ∫ ξ, S.χ (N • ξ) := by
    simpa only [sub_eq_add_neg] using integral_add_right_eq_self (fun ξ => S.χ (N • ξ)) (-ν)
  rw [he]
  simpa [cutoffMass, smul_eq_mul] using
    Measure.integral_comp_smul_of_nonneg volume S.χ N (hR := hN.le)

theorem discreteFrequency_norm_majorant (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (ξ : Plane) :
    ‖discreteFrequency S N s d ξ‖ ≤ (((S.D : ℝ) / N) ^ 2)⁻¹ *
      ∑ i ∈ s, ‖d i‖ * S.χ (N • (ξ - latticePoint N⁻¹ i.1)) := by
  have hnorm (i : PacketIndex) :
      ‖d i * (S.χ (N • (ξ - latticePoint N⁻¹ i.1)) : ℂ) *
        oscillation (-@inner ℝ Plane _ (latticePoint (N / S.D) i.2) ξ)‖ =
        ‖d i‖ * S.χ (N • (ξ - latticePoint N⁻¹ i.1)) := by
    simp only [norm_mul, norm_oscillation, mul_one, Complex.norm_real, Real.norm_eq_abs,
      abs_of_nonneg (S.χ_nonneg _)]
  rw [discreteFrequency, norm_mul]
  have hs := norm_sum_le s (fun i => d i * (S.χ (N • (ξ - latticePoint N⁻¹ i.1)) : ℂ) *
    oscillation (-@inner ℝ Plane _ (latticePoint (N / S.D) i.2) ξ))
  simp only [hnorm] at hs
  simp only [Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (inv_nonneg.mpr (sq_nonneg ((S.D : ℝ) / N)))]
  exact mul_le_mul_of_nonneg_left hs (inv_nonneg.mpr (sq_nonneg ((S.D : ℝ) / N)))

/-- Uniform L¹ control of the actual discrete frequency datum. The scale
factors cancel exactly, and no spatial-label restriction is needed. -/
theorem discreteFrequency_l1_bound (S : DiscreteSetup) {N : ℝ} (hN : 0 < N)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) :
    Integrable (discreteFrequency S N s d) ∧
      (∫ ξ, ‖discreteFrequency S N s d ξ‖) ≤
        ((S.D : ℝ) ^ 2)⁻¹ * cutoffMass S * ∑ i ∈ s, ‖d i‖ := by
  let H := fun ξ => (((S.D : ℝ) / N) ^ 2)⁻¹ *
    ∑ i ∈ s, ‖d i‖ * S.χ (N • (ξ - latticePoint N⁻¹ i.1))
  have hi : Integrable H := (integrable_finset_sum s (fun i _ =>
    (integrable_scaled_cutoff S hN (latticePoint N⁻¹ i.1)).const_mul ‖d i‖)).const_mul _
  have hb : ∀ ξ, ‖discreteFrequency S N s d ξ‖ ≤ H ξ :=
    discreteFrequency_norm_majorant S N s d
  refine ⟨hi.mono' (continuous_discreteFrequency S N s d).aestronglyMeasurable
    (Filter.Eventually.of_forall hb), ?_⟩
  calc
    _ ≤ ∫ ξ, H ξ := integral_mono_of_nonneg (Filter.Eventually.of_forall (fun _ => norm_nonneg _))
      hi (Filter.Eventually.of_forall hb)
    _ = ((S.D : ℝ) ^ 2)⁻¹ * cutoffMass S * ∑ i ∈ s, ‖d i‖ := by
      rw [integral_const_mul, integral_finset_sum s (fun i _ =>
        (integrable_scaled_cutoff S hN (latticePoint N⁻¹ i.1)).const_mul ‖d i‖)]
      simp_rw [integral_const_mul, integral_scaled_cutoff S hN]
      rw [← Finset.sum_mul]
      have hD : (S.D : ℝ) ≠ 0 := by exact_mod_cast S.D_pos.ne'
      field_simp [hN.ne', hD]
      ring

theorem windowCoefficient_norm_bound (φ : Phase) (g : Plane → ℂ) (χ : Plane → ℝ)
    (hg : Integrable g) {A : ℝ} (hχ : ∀ ξ, ‖χ ξ‖ ≤ A) (w : Plane) (j : ℝ) :
    ‖windowCoefficient φ g χ w j‖ ≤ A * ∫ ξ, ‖g ξ‖ := by
  unfold windowCoefficient
  calc
    _ ≤ ∫ ξ, A * ‖g ξ‖ := by
      apply norm_integral_le_of_norm_le (hg.norm.const_mul A)
      filter_upwards with ξ
      simp only [norm_mul, norm_oscillation, mul_one, Complex.norm_real]
      exact (mul_le_mul_of_nonneg_left (hχ ξ) (norm_nonneg _)).trans_eq (mul_comm _ _)
    _ = _ := integral_const_mul _ _

/-- Terminal coefficients are uniformly bounded by the ℓ¹ norm of the
initial coefficients, at every positive scale and every terminal label. -/
theorem terminalCoefficient_uniform_bound (S : DiscreteSetup) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : ℝ, 0 < N →
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ) (i : TerminalIndex),
      ‖terminalCoefficient S N s d i‖ ≤ C * ∑ k ∈ s, ‖d k‖ := by
  obtain ⟨A₀, hA₀⟩ := S.χ_compact.exists_bound_of_continuous S.χ_smooth.continuous
  let A := max A₀ 0 + 1
  have hA : 0 < A := by dsimp [A]; positivity
  have ha : ∀ ξ, ‖S.χ ξ‖ ≤ A := fun ξ => (hA₀ ξ).trans (by dsimp [A]; linarith [le_max_left A₀ 0])
  have hm : 0 ≤ cutoffMass S := integral_nonneg S.χ_nonneg
  let C := A * (((S.D : ℝ) ^ 2)⁻¹ * cutoffMass S) + 1
  refine ⟨C, by dsimp [C]; positivity, ?_⟩
  intro N hN s d i
  obtain ⟨hg, hmass⟩ := discreteFrequency_l1_bound S hN s d
  have h := windowCoefficient_norm_bound S.φ (discreteFrequency S N s d) (canonicalWindow S i.1)
    hg (fun ξ => ha (ξ - latticePoint 1 i.1)) (latticePoint (S.D : ℝ)⁻¹ i.2.1) i.2.2
  change ‖terminalCoefficient S N s d i‖ ≤ A * ∫ ξ, ‖discreteFrequency S N s d ξ‖ at h
  apply h.trans
  have h' := mul_le_mul_of_nonneg_left hmass hA.le
  have hs : 0 ≤ ∑ k ∈ s, ‖d k‖ := Finset.sum_nonneg (fun _ _ => norm_nonneg _)
  dsimp [C]
  nlinarith

/-- Absolute convergence and a quantitative bound for the actual omitted
terminal synthesis at one frequency window. The exponent `3-L` reserves
the summable spatial lattice power three. -/
theorem terminal_synthesis_tail_bound (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane) (L : ℕ) (hL : 3 ≤ L) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : ℝ, 0 < N →
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ) (m : IntPlane), m ∈ q →
      ∀ (j : ℕ) (u : ℝ), u ∈ Set.Icc (0 : ℝ) 1 →
      ∀ (A R : ℝ), 0 ≤ R → ∀ x : Plane, ‖x‖ ≤ A * R →
      let f := fun n : IntPlane => if (A + 1) * R < ‖latticePoint (S.D : ℝ)⁻¹ n‖ then
        terminalCoefficient S N s d (m, n, j) *
          windowKernel S.φ (canonicalWindow S m) (x - latticePoint (S.D : ℝ)⁻¹ n) u else 0
      Summable f ∧ ‖∑' n, f n‖ ≤ C * (∑ k ∈ s, ‖d k‖) *
        ((1 + R) ^ (-((L : ℝ) - 3)) * scaledLatticeSumConstant (S.D : ℝ)⁻¹ 3) := by
  classical
  obtain ⟨B, hB, hb⟩ := terminalCoefficient_uniform_bound S
  obtain ⟨K, hK, hk⟩ := finite_window_kernel_decay q S.φ hφ (canonicalWindow S)
    (canonicalWindow_smooth S) (canonicalWindow_compact S) L
  refine ⟨B * K, mul_pos hB hK, ?_⟩
  intro N hN s d m hm j u hu A R hR x hx
  have hD : 0 < (S.D : ℝ)⁻¹ := inv_pos.mpr (by exact_mod_cast S.D_pos)
  apply complex_position_tail_bound hD (by norm_num : (2 : ℝ) < 3)
    (by exact_mod_cast hL) hR (by positivity) x hx
  intro n
  rw [norm_mul]
  have h := mul_le_mul (hb N hN s d (m, n, j)) (hk m hm u hu (x - latticePoint (S.D : ℝ)⁻¹ n))
    (norm_nonneg _) (by positivity : 0 ≤ B * ∑ k ∈ s, ‖d k‖)
  convert h using 1
  ring

end EllipticSquareFunction
