import EllipticSquareFunction.RebasedFrequencyCutoff
import EllipticSquareFunction.InfinitePacketLimit

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem densityCubeRoot_const_mul (D : Space → ℝ) (R : ℝ) {C : ℝ}
    (hC : 0≤C) (hD : ∀ y, 0≤D y) :
    densityCubeRoot (fun y => C*D y) R=ENNReal.ofReal (Real.sqrt C)*densityCubeRoot D R := by
  rw [densityCubeRoot_eq_norm _ _ (fun y => mul_nonneg hC (hD y)),
    densityCubeRoot_eq_norm _ _ hD]
  simp only [Real.sqrt_mul hC,l3Real]
  exact eLpNorm_nonneg_const_mul _ _ _ (Real.sqrt_nonneg C)

/-- Passing the finite-array packet estimate through the rebased frame.
The only analytic premise is the precise finite canonical packet bound,
which is supplied by Proposition 2 once its fixed margins are met. -/
theorem rebased_slab_estimate_of_packet_bound {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ M : ℝ} (hc : 0<c) (hσ : 0<σ) (hM : 0≤M) :
    ∃ Z C : ℝ, 0<Z ∧ 0<C ∧ ∃ B : ℕ,
      ∀ N F A : ℝ, 1≤N → 0≤A →
      (∀ (q p : Finset IntPlane) (d : IntPlane → IntPlane → ℂ),
        (∀ m ∈ q, ‖latticePoint N⁻¹ m‖≤F+Z) →
        l3 (fun y => ∑ m ∈ q, ∑ n ∈ p, d m n*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y)
          (volume.restrict (timeSlab (N^2))) ≤ ENNReal.ofReal A*
        densityCubeRoot (spatialDensity (q ×ˢ p) (fun mn => d mn.1 mn.2)
          (fun mn => velocity S.φ (latticePoint N⁻¹ mn.1))
          (fun mn => latticePoint (N/S.D) mn.2) N M) (N^2)) →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖≤F) →
      (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v i p-v i r‖) →
      ∀ Δ : ℝ,
      l3 (fun y => ∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p)
        (y.1,y.2+Δ*N^2)) (volume.restrict (timeSlab (N^2))) ≤
      ENNReal.ofReal (A*Real.sqrt (C*(1+|Δ|)^B))*
        densityCubeRoot (fun y => spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M
          (y.1,y.2+Δ*N^2)) (N^2) := by
  classical
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨Z,hZ,hrecon⟩ := rebased_profile_bounded_frequencies (ι := ι) S hφ.continuous b hb.continuous hbs
  have hD : 0<(S.D:ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨C,hC,B,hdensity⟩ := equation_5_9_finite hphase b hb hbs S.χ S.χ_smooth S.χ_compact
    hc (inv_pos.mpr hD) hσ hM
  let u : ℝ := ((S.D:ℝ)^2)⁻¹
  have hu : 0<u := by dsimp [u]; positivity
  refine ⟨Z,u^2*C,hZ,by positivity,B,?_⟩
  intro N F A hN hA hpacket s pbox a ν v hν hfreq hpos Δ
  have hN0 : 0<N := by linarith
  obtain ⟨q,hq,hrecon⟩ := hrecon N F hN s pbox a ν v hν
  let d := fun m n => (u:ℂ)*rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
    (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)
  let H := fun y : Space => spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M (y.1,y.2+Δ*N^2)
  let G := u^2*C*(1+|Δ|)^B
  have hG : 0≤G := by dsimp [G]; positivity
  have hH (y : Space) : 0≤H y := spatialDensity_nonneg_global ..
  have hd (p : Finset IntPlane) (y : Space) (hy : y ∈ timeSlab (N^2)) :
      spatialDensity (q ×ˢ p) (fun mn => d mn.1 mn.2)
        (fun mn => velocity S.φ (latticePoint N⁻¹ mn.1))
        (fun mn => latticePoint (N/S.D) mn.2) N M y ≤ G*H y := by
    have ht : |y.2|≤N^2 := by rw [abs_of_nonneg hy.1]; exact hy.2
    have hh := hdensity N hN Δ s pbox q (fun _ => p) a ν v hfreq hpos y ht
    have he (n : IntPlane) : N • latticePoint (S.D:ℝ)⁻¹ n=latticePoint (N/S.D) n := by
      rw [← latticePoint_mul,div_eq_mul_inv]
    simp only [he] at hh
    have heq : spatialDensity (q ×ˢ p) (fun mn => d mn.1 mn.2)
        (fun mn => velocity S.φ (latticePoint N⁻¹ mn.1))
        (fun mn => latticePoint (N/S.D) mn.2) N M y =
        u^2*(∑ m ∈ q, ∑ n ∈ p,
          ‖rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
            (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)‖^2*
            spatialWeight N M (velocity S.φ (latticePoint N⁻¹ m)) (latticePoint (N/S.D) n) y) := by
      simp only [spatialDensity,Finset.sum_product,d,norm_mul,Complex.norm_real,
        Real.norm_eq_abs,abs_of_pos hu,mul_pow,Finset.mul_sum,mul_assoc]
    rw [heq]
    simpa only [G,H,mul_assoc] using mul_le_mul_of_nonneg_left hh (sq_nonneg u)
  have htruncate (p : Finset IntPlane) :
      l3 (fun y => ∑ n ∈ p, ∑ m ∈ q, (u:ℝ) •
        (rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y))
        (volume.restrict (timeSlab (N^2))) ≤
        ENNReal.ofReal (A*Real.sqrt G)*densityCubeRoot H (N^2) := by
    have hh := hpacket q p d hq
    have hroot : densityCubeRoot (spatialDensity (q ×ˢ p) (fun mn => d mn.1 mn.2)
        (fun mn => velocity S.φ (latticePoint N⁻¹ mn.1))
        (fun mn => latticePoint (N/S.D) mn.2) N M) (N^2) ≤ densityCubeRoot (fun y => G*H y) (N^2) := by
      unfold densityCubeRoot
      apply ENNReal.rpow_le_rpow _ (by norm_num)
      apply setLIntegral_mono' (measurableSet_Icc.preimage measurable_snd)
      intro y hy
      exact ENNReal.rpow_le_rpow (ENNReal.ofReal_le_ofReal (hd p y hy)) (by norm_num)
    have hh' := hh.trans (mul_le_mul_left' hroot _)
    rw [densityCubeRoot_const_mul H (N^2) hG hH,← mul_assoc,← ENNReal.ofReal_mul hA] at hh'
    have he (y : Space) : (∑ n ∈ p, ∑ m ∈ q, (u:ℝ) •
        (rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y)) =
        ∑ m ∈ q, ∑ n ∈ p, d m n*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y := by
      rw [Finset.sum_comm]
      simp only [d,Complex.real_smul,mul_assoc]
    simp_rw [he]
    exact hh'
  apply l3_hasSum_bound _ _ _ _ _ (hrecon Δ) htruncate
  intro n
  exact continuous_finset_sum q (fun m hm =>
    (continuous_const.mul (continuous_freePacket S.φ hφ.continuous _
      (Complex.continuous_ofReal.comp S.χ_smooth.continuous)
      (S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero) hN0.ne' _ _)).const_smul u)

end EllipticSquareFunction
