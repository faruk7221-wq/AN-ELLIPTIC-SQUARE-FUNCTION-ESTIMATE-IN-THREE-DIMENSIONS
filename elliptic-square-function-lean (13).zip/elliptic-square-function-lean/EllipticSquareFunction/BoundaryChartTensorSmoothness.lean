import EllipticSquareFunction.BoundarySecondFormSmoothness

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- The within-target smooth coordinate expression is exactly the form
used by the boundary-chart compatibility theorems. -/
theorem boundary_chart_second_form_coordinate_eq (f : M → EuclideanThree)
    (x : M) {p : Plane} (hp : p ∈ (extChartAt (𝓡∂ 2) x).target)
    (N : EuclideanThree) (v w : Plane) :
    boundaryChartSecondForm f x ((extChartAt (𝓡∂ 2) x).symm p) N v w =
      @inner ℝ EuclideanThree _ N
        (fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x)
          (extChartAt (𝓡∂ 2) x).target) (extChartAt (𝓡∂ 2) x).target p v w) := by
  have hs := extChartAt_target_eventuallyEq_of_mem hp
  have hd := fderivWithin_eventually_congr_set (𝕜 := ℝ)
    (f := modelSurfaceParam (𝓡∂ 2) f x) hs
  have he : fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x)
      (extChartAt (𝓡∂ 2) x).target) (extChartAt (𝓡∂ 2) x).target p =
      fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x)
        (Set.range (𝓡∂ 2))) (Set.range (𝓡∂ 2)) p := by
    rw [hd.fderivWithin_eq_nhds,fderivWithin_congr_set hs]
  unfold boundaryChartSecondForm
  rw [(extChartAt (𝓡∂ 2) x).right_inv hp,he]

/-- The actual boundary-chart scalar form has smooth local contractions. -/
theorem boundary_chart_second_form_coordinate_smooth {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f) (x : M)
    {N : Plane → EuclideanThree} {v w : Plane → Plane}
    (hN : ContDiffOn ℝ (⊤ : ℕ∞) N (extChartAt (𝓡∂ 2) x).target)
    (hv : ContDiffOn ℝ (⊤ : ℕ∞) v (extChartAt (𝓡∂ 2) x).target)
    (hw : ContDiffOn ℝ (⊤ : ℕ∞) w (extChartAt (𝓡∂ 2) x).target) :
    ContDiffOn ℝ (⊤ : ℕ∞)
      (fun p => boundaryChartSecondForm f x ((extChartAt (𝓡∂ 2) x).symm p)
        (N p) (v p) (w p)) (extChartAt (𝓡∂ 2) x).target :=
  (boundary_second_form_coordinate_smooth hf x hN hv hw).congr
    (fun p hp => boundary_chart_second_form_coordinate_eq f x hp (N p) (v p) (w p))

/-- The corresponding actual normal-valued coordinate contraction is smooth. -/
theorem boundary_chart_normal_form_coordinate_smooth {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f) (x : M)
    {N : Plane → EuclideanThree} {v w : Plane → Plane}
    (hN : ContDiffOn ℝ (⊤ : ℕ∞) N (extChartAt (𝓡∂ 2) x).target)
    (hv : ContDiffOn ℝ (⊤ : ℕ∞) v (extChartAt (𝓡∂ 2) x).target)
    (hw : ContDiffOn ℝ (⊤ : ℕ∞) w (extChartAt (𝓡∂ 2) x).target) :
    ContDiffOn ℝ (⊤ : ℕ∞)
      (fun p => boundaryChartSecondForm f x ((extChartAt (𝓡∂ 2) x).symm p)
        (N p) (v p) (w p) • N p) (extChartAt (𝓡∂ 2) x).target :=
  (boundary_chart_second_form_coordinate_smooth hf x hN hv hw).smul hN

end EllipticSquareFunction
