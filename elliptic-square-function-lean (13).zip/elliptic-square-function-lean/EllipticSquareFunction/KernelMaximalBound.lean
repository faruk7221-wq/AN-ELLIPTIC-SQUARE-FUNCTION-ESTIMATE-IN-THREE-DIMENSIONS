import EllipticSquareFunction.DyadicMaximalNorm

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- The common tube aspect ratio produces exactly the scale loss in (7.4). -/
theorem tube_aspect_power {R c : ℝ} (hR : 0<R) (hc : 0<c) (γ : ℝ) :
    (Real.sqrt R/(c*R))^(-γ)=c^γ*R^(γ/2) := by
  have he : Real.sqrt R/(c*R)=(c*Real.sqrt R)⁻¹ := by
    have hs : (Real.sqrt R)^2=R := Real.sq_sqrt hR.le
    field_simp
    nlinarith
  rw [he,Real.inv_rpow (by positivity) (-γ),Real.rpow_neg (by positivity),inv_inv,
    Real.mul_rpow hc.le (Real.sqrt_nonneg R),Real.sqrt_eq_rpow,← Real.rpow_mul hR.le]
  congr 2
  ring

/-- Equation (7.4) for the actual finite-family positive adjoint kernel
maximum. The fixed constant precedes R, cap count, directions and datum.
Only the article's unit-length Nikodym input is assumed. -/
theorem finiteKernelMax_l3_bound (hinput : NikodymInput)
    {M F γ : ℝ} (hM : 3<M) (hF : 0≤F) (hγ : 0<γ) (hγ₁ : γ≤1) :
    ∃ A : ℝ, 0<A ∧ ∀ {ι : Type*} (s : Finset ι) (R : ℝ), 1≤R →
      ∀ V : ι → Plane, (∀ i∈s, ‖V i‖≤F) → ∀ h : Space → ℝ,
      Measurable h → MemLp h 3 volume →
      eLpNorm (finiteKernelMax s R M V h) 3 volume ≤
        ENNReal.ofReal (A*R^(γ/2))*eLpNorm h 3 volume := by
  obtain ⟨C,hC,hbound⟩ := finiteKernelMax_l3_aspect_bound hinput hγ hγ₁
  let D : ℝ := ((2*Real.pi)*(2:ℝ)^M)*((2*(1+F)^3)*C*(2*(1+F))^γ)
  have hD : 0≤D := by dsimp [D]; positivity
  let S : ℝ≥0∞ := ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))
  let K : ℝ≥0∞ := ENNReal.ofReal D*S
  have hKfin : K≠⊤ := ENNReal.mul_ne_top ENNReal.ofReal_ne_top (dyadic_tube_ennreal_sum_ne_top hM)
  have hKle : K≤ENNReal.ofReal (K.toReal+1) := by
    calc
      K = ENNReal.ofReal K.toReal := (ENNReal.ofReal_toReal hKfin).symm
      _ ≤ ENNReal.ofReal (K.toReal+1) := ENNReal.ofReal_le_ofReal (by linarith)
  refine ⟨K.toReal+1,by positivity,?_⟩
  intro ι s R hR V hV h hh hlp
  have hR₀ : 0<R := by linarith
  have hb := hbound s R M F hR hM hF V hV h hh hlp
  have he : ((2*Real.pi)*(2:ℝ)^M)*((2*(1+F)^3)*C*
      (Real.sqrt R/(2*(1+F)*R))^(-γ))=D*R^(γ/2) := by
    rw [tube_aspect_power hR₀ (by positivity) γ]
    dsimp [D]
    ring
  rw [he,ENNReal.ofReal_mul hD] at hb
  have hb' : eLpNorm (finiteKernelMax s R M V h) 3 volume ≤
      K*ENNReal.ofReal (R^(γ/2))*eLpNorm h 3 volume := by
    simpa only [K,S,mul_assoc,mul_left_comm,mul_comm] using hb
  apply hb'.trans
  have ht := mul_le_mul_right' (mul_le_mul_right' hKle (ENNReal.ofReal (R^(γ/2)))) (eLpNorm h 3 volume)
  simpa only [ENNReal.ofReal_mul (by positivity : 0≤K.toReal+1)] using ht

end EllipticSquareFunction
