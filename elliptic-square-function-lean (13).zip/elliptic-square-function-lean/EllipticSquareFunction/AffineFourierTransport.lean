import EllipticSquareFunction.SpaceTranspose

noncomputable section
open MeasureTheory
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

theorem spacePair_comm (y z : Space) : spacePair y z=spacePair z y := by
  simp only [spacePair,real_inner_comm,mul_comm]

theorem spacePair_sub_right (y z w : Space) : spacePair y (z-w)=spacePair y z-spacePair y w := by
  simp only [spacePair,Prod.fst_sub,Prod.snd_sub,inner_sub_right]
  ring

/-- Bochner change of variables for the physical linear map, including its
exact real Jacobian. No compact-support or integrability premise is hidden. -/
theorem integral_space_linearEquiv (L : Space ≃L[ℝ] Space) (g : Space → ℂ) :
    (∫ y, g (L y))=((|(LinearMap.det L.toLinearMap)⁻¹|:ℝ):ℂ)*(∫ y, g y) := by
  have hh := integral_map_equiv (μ := (volume : Measure Space)) L.toHomeomorph.toMeasurableEquiv g
  change (∫ y, g y ∂Measure.map L volume)=(∫ y, g (L y)) at hh
  rw [space_volume_map_linearEquiv,integral_smul_measure,ENNReal.toReal_ofReal (abs_nonneg _),
    Complex.real_smul] at hh
  exact hh.symm

/-- Exact affine Fourier covariance for the article's Fourier convention.
The frequency map is the inverse transpose of the physical map, and b is
the frequency translation. -/
theorem fourierTransform_modulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : Space → ℂ) (η : Space) :
    fourierTransform (modulatedLinearPullback L b f) η=
      ((|(LinearMap.det L.toLinearMap)⁻¹|:ℝ):ℂ)*
        fourierTransform f (spaceTranspose L.symm (η-b)) := by
  let ξ := spaceTranspose L.symm (η-b)
  have hp (y : Space) : spacePair (L y) ξ=spacePair y (η-b) := by
    rw [spacePair_comm]
    change spacePair (spaceTranspose L.symm (η-b)) (L y)=_
    rw [spaceTranspose_pair,L.symm_apply_apply,spacePair_comm]
  have he (y : Space) : modulatedLinearPullback L b f y*oscillation (-spacePair y η)=
      f (L y)*oscillation (-spacePair (L y) ξ) := by
    change (oscillation (spacePair b y)*f (L y))*oscillation (-spacePair y η)=_
    rw [hp,spacePair_sub_right]
    have hh : spacePair b y+ -spacePair y η= -(spacePair y η-spacePair y b) := by
      rw [spacePair_comm b y]
      ring
    rw [mul_right_comm,← oscillation_add,hh,mul_comm]
  change (∫ y, modulatedLinearPullback L b f y*oscillation (-spacePair y η))=_
  simp_rw [he]
  exact integral_space_linearEquiv L (fun y => f y*oscillation (-spacePair y ξ))

end EllipticSquareFunction
