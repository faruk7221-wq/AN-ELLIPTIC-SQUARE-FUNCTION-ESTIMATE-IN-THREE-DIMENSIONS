import EllipticSquareFunction.BoundaryTangentSecondForm
import EllipticSquareFunction.CompactSurfacePortions

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

theorem boundary_chart_second_form_negative_iff {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    (∀ v : TangentSpace (𝓡∂ 2) z, v ≠ 0 → boundarySecondFundamentalForm f N z v v < 0) ↔
      ∀ v : Plane, v ≠ 0 → boundaryChartSecondForm f x z N v v < 0 := by
  have hn : ∀ v, @inner ℝ EuclideanThree _ (-N)
      (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0 := by
    intro v
    rw [inner_neg_left,hN v,neg_zero]
  simpa only [boundarySecondFundamentalForm,LinearMap.coe_mk,AddHom.coe_mk,
    modelSecondForm,boundaryChartSecondForm,inner_neg_left,neg_pos] using
    boundary_chart_second_form_positive_iff hf x z hz (-N) hn

/-- The definiteness premise of the main theorem may be checked in any
boundary chart containing the point, independently at each point. -/
theorem boundary_chart_definite_second_form_iff {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    ModelDefiniteSecondForm (𝓡∂ 2) f z N ↔
      ((∀ v : Plane, v ≠ 0 → 0 < boundaryChartSecondForm f x z N v v) ∨
        (∀ v : Plane, v ≠ 0 → boundaryChartSecondForm f x z N v v < 0)) :=
  or_congr (boundary_chart_second_form_positive_iff hf x z hz N hN)
    (boundary_chart_second_form_negative_iff hf x z hz N hN)

/-- Compact portions of smooth boundary manifolds satisfy the surface
estimate with curvature checked in arbitrary overlapping boundary charts.
Neither extensions nor a preferred curvature chart are extra hypotheses. -/
theorem compact_smooth_boundary_portion_estimate_of_chart_curvature
    {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f)
    (himm : ∀ z, Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z))
    (hcurv : ∀ z, ∃ (x : M) (N : EuclideanThree),
      z ∈ (extChartAt (𝓡∂ 2) x).source ∧ ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) ∧
      ((∀ v : Plane, v ≠ 0 → 0 < boundaryChartSecondForm f x z N v v) ∨
        (∀ v : Plane, v ≠ 0 → boundaryChartSecondForm f x z N v v < 0)))
    {K : Set EuclideanThree} (hK : IsCompact K) (hKf : K ⊆ Set.range f)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ := by
  apply compact_smooth_boundary_portion_estimate hf hemb himm _ hK hKf hc₀ hC₀
    hplacement hnikodym hdiscrete
  intro z
  obtain ⟨x,N,hzx,hN,hn,hdef⟩ := hcurv z
  exact ⟨N,hN,hn,(boundary_chart_definite_second_form_iff hf x z hzx N hn).mpr hdef⟩

end EllipticSquareFunction
