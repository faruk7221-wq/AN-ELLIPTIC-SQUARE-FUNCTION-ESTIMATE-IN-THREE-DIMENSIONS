import EllipticSquareFunction.SeeleyOpenHalfSpace
import EllipticSquareFunction.HalfSpaceBoundaryTheorem

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

def planeHalfspaceEquiv : Plane ≃L[ℝ] ℝ × ℝ :=
  (EuclideanSpace.equiv (Fin 2) ℝ).trans
    (LinearEquiv.finTwoArrow ℝ ℝ).toContinuousLinearEquiv

theorem plane_halfspace_equiv_fst (p : Plane) : (planeHalfspaceEquiv p).1 = p 0 := rfl

/-- Local extension for a smooth parametrization on a relatively open planar half-space. -/
theorem smooth_plane_halfspace_extension {f : Plane → EuclideanThree} {V : Set Plane}
    (hV : IsOpen V) {a : Plane} (ha : a ∈ V)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f ({p : Plane | 0 ≤ p 0} ∩ V)) :
    ∃ (F : Plane → EuclideanThree) (U : Set Plane), IsOpen U ∧ a ∈ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Set.EqOn F f (U ∩ {p : Plane | 0 ≤ p 0}) := by
  let L := planeHalfspaceEquiv
  have hs : ∀ q : ℝ × ℝ, (L.symm q) 0 = q.1 := by
    intro q
    rw [← plane_halfspace_equiv_fst (L.symm q)]
    exact congrArg Prod.fst (L.apply_symm_apply q)
  have hg : ContDiffOn ℝ (⊤ : ℕ∞) (f ∘ L.symm)
      ({q : ℝ × ℝ | 0 ≤ q.1} ∩ L.symm ⁻¹' V) := by
    apply hf.comp L.symm.contDiff.contDiffOn
    intro q hq
    exact ⟨by change 0 ≤ (L.symm q) 0; rw [hs]; exact hq.1,hq.2⟩
  obtain ⟨F,U,hU,haU,hF,heq⟩ := smooth_open_halfspace_extension
    (hV.preimage L.symm.continuous) (a := L a) (by simpa using ha) hg
  refine ⟨F ∘ L,L ⁻¹' U,hU.preimage L.continuous,haU,
    hF.comp L.contDiff.contDiffOn (fun _ h => h),?_⟩
  intro p hp
  have hh := heq ⟨hp.1,by change 0 ≤ (L p).1; exact hp.2⟩
  simpa only [Function.comp_apply,L.symm_apply_apply] using hh

end EllipticSquareFunction
