import EllipticSquareFunction.SchwartzTubeSmoothing
import EllipticSquareFunction.GraphReductionAfterSampling

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- The internal smoothing bridge follows from the external unit-length
Nikodym input. The graph's compact parameter set bounds all cap slopes. -/
theorem tubeSmoothingEstimates_from_nikodym (G : GraphSetup)
    (hphase : ContinuedPhase G.φ) (hinput : NikodymInput)
    {M : ℝ} (hM : 3<M) : TubeSmoothingEstimates G M := by
  obtain ⟨F,hF⟩ := G.compact_K.exists_bound_of_continuousOn
    (continuous_id : Continuous (id : Plane → Plane)).continuousOn
  obtain ⟨B,hB,hvel⟩ := continuedPhase_velocity_on_ball hphase (show 0 ≤ max F 0 from le_max_right _ _)
  intro γ hγ hγ₁
  obtain ⟨A,hA,hbound⟩ := schwartz_tube_smoothing_bound hinput hM hB hγ hγ₁
  refine ⟨A,hA,?_⟩
  intro R hR n ν f hf
  have hv : ∀ i∈(Finset.univ : Finset (Fin n)), ‖velocity G.φ (ν i)‖≤B := by
    intro i hi
    exact hvel (ν i) ((hF (ν i) (hf.1 i)).trans (le_max_left _ _))
  exact hbound Finset.univ R (by linarith) (fun i => velocity G.φ (ν i)) hv f

/-- Both internal analytic bridges are discharged for a supplied continued
phase and initial partition setup. Only the stated external analytic inputs
remain; constructing that geometric setup is a separate obligation. -/
theorem reverseSquareFunction_of_external_analytic_inputs (G : GraphSetup)
    (T₀ : DiscreteSetup) (heφ : T₀.φ=G.φ) (hphase : ContinuedPhase G.φ)
    (hnikodym : NikodymInput) :
    ∃ S : DiscreteSetup, S.φ=G.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      (DiscreteDensityInput S → ReverseSquareFunction G) := by
  exact reverseSquareFunction_of_discrete_and_smoothing G T₀ heφ hphase
    (M := 4) (by norm_num)
    (tubeSmoothingEstimates_from_nikodym G hphase hnikodym (by norm_num))

end EllipticSquareFunction
