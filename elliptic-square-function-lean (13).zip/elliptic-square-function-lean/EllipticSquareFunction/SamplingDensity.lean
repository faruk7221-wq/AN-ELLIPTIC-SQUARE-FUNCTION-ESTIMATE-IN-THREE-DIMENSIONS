import EllipticSquareFunction.SamplingWeightTransport
import Mathlib.MeasureTheory.Integral.Lebesgue.Add

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

/-- Finite Tonelli transport of sample bounds. The sample estimate is explicit;
the theorem proves the summation/integration step, not that estimate. -/
theorem finite_density_of_sample_majorants {ι : Type*} (T : Finset ι)
    (μ : Measure Space) (a W : ι → ℝ≥0∞) (F H : Space → ℝ≥0∞)
    (K : ι → Space → ℝ≥0∞) (hF : AEMeasurable F μ)
    (hK : ∀ i ∈ T, AEMeasurable (K i) μ)
    (ha : ∀ i ∈ T, a i ≤ ∫⁻ z, F z*K i z ∂μ)
    (hconv : ∀ z, (∑ i ∈ T, K i z*W i) ≤ H z) :
    (∑ i ∈ T, a i*W i) ≤ ∫⁻ z, F z*H z ∂μ := by
  calc
    _ ≤ ∑ i ∈ T, (∫⁻ z, F z*K i z ∂μ)*W i :=
      Finset.sum_le_sum (fun i hi => mul_le_mul_right' (ha i hi) _)
    _ = ∫⁻ z, ∑ i ∈ T, F z*K i z*W i ∂μ := by
      rw [lintegral_finset_sum' T (fun i hi => (hF.mul (hK i hi)).mul_const _)]
      exact Finset.sum_congr rfl (fun i hi => (lintegral_mul_const'' _ (hF.mul (hK i hi))).symm)
    _ ≤ _ := lintegral_mono (fun z => by
      simpa only [Finset.mul_sum,mul_assoc] using mul_le_mul_left' (hconv z) (F z))

/-- Finite packet-density domination from the local sample majorants in (6.12).
The inverse-Fourier kernel and sample bounds themselves remain hypotheses. -/
theorem sampling_density_from_local_majorants {R A B M L : ℝ}
    (hR : 0<R) (hA : 0<A) (hB : 0<B) (hM : 0≤M) (hLM : 2<L-M)
    (V : Plane) (T : Finset (IntPlane × ℤ)) (a : IntPlane × ℤ → ℝ≥0∞)
    (F : Space → ℝ≥0∞) (hF : AEMeasurable F volume)
    (ha : ∀ i ∈ T, a i ≤ ∫⁻ z, F z*ENNReal.ofReal
      (packetWeight R L V
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).1
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).2 z))
    (y : Space) :
    let p := fun i : IntPlane × ℤ =>
      samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2
    (∑ i ∈ T, a i*ENNReal.ofReal (packetWeight R M V (p i).1 (p i).2 y)) ≤
      ∫⁻ z, F z*ENNReal.ofReal
        ((scaledLatticeSumConstant A⁻¹ (L-M)*scaledTimeSumConstant B⁻¹ (L-M))*
          packetWeight R M V 0 0 (y-z)) := by
  dsimp only
  refine finite_density_of_sample_majorants T volume a _ F _ _ hF ?_ ha ?_
  · intro i _
    apply Measurable.aemeasurable
    apply Measurable.ennreal_ofReal
    unfold packetWeight bracket
    fun_prop
  · intro z
    simp_rw [← ENNReal.ofReal_mul (packetWeight_nonneg ..)]
    rw [← ENNReal.ofReal_sum_of_nonneg (fun i _ =>
      mul_nonneg (packetWeight_nonneg ..) (packetWeight_nonneg ..))]
    exact ENNReal.ofReal_le_ofReal (sampling_packet_weight_convolution hR hA hB hM hLM V y z T)

end EllipticSquareFunction
