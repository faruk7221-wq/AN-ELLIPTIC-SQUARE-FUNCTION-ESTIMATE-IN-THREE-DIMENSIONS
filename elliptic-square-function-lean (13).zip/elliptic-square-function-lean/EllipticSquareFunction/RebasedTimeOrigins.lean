import EllipticSquareFunction.TemporalCutoff
import EllipticSquareFunction.TimeWeights
import EllipticSquareFunction.RebasedUniformEstimate

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem shifted_slab_from_rebased (F : Space → ℂ) (hF : Continuous F) (D : Space → ℝ)
    (R K Cd : ℝ) (B : ℕ)
    (h : ∀ Δ : ℝ, l3 (fun y => F (y.1,y.2+Δ*R)) (volume.restrict (timeSlab R)) ≤
      ENNReal.ofReal (K*Real.sqrt (Cd*bracket Δ^B))*
        densityCubeRoot (fun y => D (y.1,y.2+Δ*R)) R)
    (j k : ℤ) :
    l3 (fun y => F (y.1,y.2-(k:ℝ)*R)) (volume.restrict (shiftedTimeSlab ((j:ℝ)*R) R)) ≤
      ENNReal.ofReal (K*Real.sqrt (Cd*bracket ((j:ℝ)-(k:ℝ))^B))*
        (∫⁻ y in shiftedTimeSlab ((j:ℝ)*R) R,
          (ENNReal.ofReal (D (y.1,y.2-(k:ℝ)*R)))^(3/2:ℝ))^(1/3:ℝ) := by
  let Δ : ℝ := (j:ℝ)-(k:ℝ)
  have he (t : ℝ) : t-(j:ℝ)*R+Δ*R=t-(k:ℝ)*R := by dsimp [Δ]; ring
  have hn := time_translation_l3 (fun y => F (y.1,y.2+Δ*R))
    (hF.comp (continuous_fst.prodMk (continuous_snd.add continuous_const))) ((j:ℝ)*R) R
  have hd := time_translation_densityCubeRoot (fun y => D (y.1,y.2+Δ*R)) ((j:ℝ)*R) R
  dsimp only at hn hd
  simp_rw [he] at hn hd
  rw [hn,hd]
  exact h Δ

/-- A single time-origin slice after the Schwartz cutoff. The theorem's
constant is uniform over both integer time origins and the slab length. -/
theorem cutoff_time_slice (ψ : SchwartzMap ℝ ℂ) (A B : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ (F : Space → ℂ) (D : Space → ℝ) (R K Cd : ℝ),
      Continuous F → 0<R → 0≤K → 0≤Cd →
      (∀ Δ : ℝ, l3 (fun y => F (y.1,y.2+Δ*R)) (volume.restrict (timeSlab R)) ≤
        ENNReal.ofReal (K*Real.sqrt (Cd*bracket Δ^B))*
          densityCubeRoot (fun y => D (y.1,y.2+Δ*R)) R) →
      ∀ j k : ℤ,
      l3 (fun y => ψ ((y.2-(k:ℝ)*R)/R)*F (y.1,y.2-(k:ℝ)*R))
        (volume.restrict (timeTile R j)) ≤
      ENNReal.ofReal (C*K*Real.sqrt Cd)*ENNReal.ofReal (timeInteraction (A:ℝ) j k)*
        (∫⁻ y in timeTile R j, (ENNReal.ofReal (D (y.1,y.2-(k:ℝ)*R)))^(3/2:ℝ))^(1/3:ℝ) := by
  obtain ⟨C,hC,hcut⟩ := cutoff_slab_norm_bound ψ A B
  refine ⟨C,hC,?_⟩
  intro F D R K Cd hF hR hK hCd h j k
  have hnorm := shifted_slab_from_rebased F hF D R K Cd B h j k
  rw [← timeTile_restrict_eq_slab hR j] at hnorm
  apply hcut (volume.restrict (timeTile R j)) (fun y => F (y.1,y.2-(k:ℝ)*R))
    (fun y => (y.2-(k:ℝ)*R)/R) ((j:ℝ)-(k:ℝ)) K Cd _ hK hCd _ hnorm
  filter_upwards [ae_restrict_mem (measurableSet_timeTile R j)] with y hy
  have hh := timeTile_normalized j hy
  have he : (y.2-(k:ℝ)*R)/R-((j:ℝ)-(k:ℝ))=y.2/R-(j:ℝ) := by field_simp; ring
  rwa [he]

end EllipticSquareFunction
