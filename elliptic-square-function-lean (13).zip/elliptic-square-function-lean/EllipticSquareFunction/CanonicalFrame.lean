import EllipticSquareFunction.FrameReconstruction
import EllipticSquareFunction.UniformKernels
import EllipticSquareFunction.Lattice

/-! # The canonical finite window system

Compact support and discreteness of the integer lattice give a finite set
of relevant frequency windows. The infinite square partition therefore
reduces to the finite partition needed by the synthesis theorem.
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators Pointwise
namespace EllipticSquareFunction

theorem continuous_windowKernel (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℝ) (hχ : Continuous χ) (hχs : HasCompactSupport χ) :
    Continuous (fun y : Space => windowKernel φ χ y.1 y.2) := by
  apply continuous_iff_continuousOn_univ.mpr
  apply continuousOn_integral_of_compact_support (μ := volume) hχs
  · apply Continuous.continuousOn
    exact (Complex.continuous_ofReal.comp (hχ.comp continuous_snd)).mul
      (continuous_oscillation.comp
        ((continuous_fst.fst.inner continuous_snd).add
          (continuous_fst.snd.mul (hφ.comp continuous_snd))))
  · intro p ξ _ hξ
    have hz : χ ξ = 0 := image_eq_zero_of_nmem_tsupport hξ
    simp [hz]

theorem finite_bounded_integer_lattice (B : ℝ) :
    {m : IntPlane | ‖m‖ ≤ B}.Finite := by
  simpa only [Metric.closedBall, dist_zero_right] using
    (isCompact_closedBall (0 : IntPlane) B).finite_of_discrete

/-- Only finitely many integer translates of a compactly supported window
can intersect a fixed compact set. -/
theorem finite_relevant_windows (χ : Plane → ℝ) (hχ : HasCompactSupport χ)
    {K : Set Plane} (hK : IsCompact K) :
    {m : IntPlane | ∃ ξ ∈ K, χ (ξ - latticePoint 1 m) ≠ 0}.Finite := by
  obtain ⟨A, hA⟩ := hK.exists_bound_of_continuousOn (continuous_id.continuousOn)
  obtain ⟨B, hB⟩ := hχ.exists_bound_of_continuousOn (continuous_id.continuousOn)
  apply (finite_bounded_integer_lattice (A + B)).subset
  rintro m ⟨ξ, hξ, hm⟩
  have hχξ := hB (ξ - latticePoint 1 m) (subset_closure hm)
  calc
    ‖m‖ ≤ ‖latticePoint 1 m‖ := lattice_sup_norm_le m
    _ = ‖ξ - (ξ - latticePoint 1 m)‖ := by congr 1; abel
    _ ≤ ‖ξ‖ + ‖ξ - latticePoint 1 m‖ := norm_sub_le _ _
    _ ≤ A + B := add_le_add (hA ξ hξ) hχξ

/-- A finite selection from the canonical square partition, with no added
partition hypothesis. The selection depends only on the compact region. -/
theorem canonical_finite_partition (S : DiscreteSetup) {K : Set Plane} (hK : IsCompact K) :
    ∃ s : Finset IntPlane,
      (∀ ξ ∈ K, ∑ m ∈ s, S.χ (ξ - latticePoint 1 m) ^ 2 = 1) ∧
      (∀ m ∉ s, ∀ ξ ∈ K, S.χ (ξ - latticePoint 1 m) = 0) := by
  classical
  let s := (finite_relevant_windows S.χ S.χ_compact hK).toFinset
  have hout (m : IntPlane) (hm : m ∉ s) (ξ : Plane) (hξ : ξ ∈ K) :
      S.χ (ξ - latticePoint 1 m) = 0 := by
    by_contra hn
    exact hm (by simpa only [s, Set.Finite.mem_toFinset] using ⟨ξ, hξ, hn⟩)
  refine ⟨s, ?_, hout⟩
  intro ξ hξ
  calc
    _ = ∑' m : IntPlane, S.χ (ξ - latticePoint 1 m) ^ 2 := by
      symm
      apply tsum_eq_sum
      intro m hm
      rw [hout m hm ξ hξ, zero_pow (by decide : 2 ≠ 0)]
    _ = 1 := S.χ_partition ξ

def canonicalWindow (S : DiscreteSetup) (m : IntPlane) (ξ : Plane) : ℝ :=
  S.χ (ξ - latticePoint 1 m)

theorem canonicalWindow_smooth (S : DiscreteSetup) (m : IntPlane) :
    ContDiff ℝ (⊤ : ℕ∞) (canonicalWindow S m) :=
  S.χ_smooth.comp (contDiff_id.sub contDiff_const)

theorem canonicalWindow_compact (S : DiscreteSetup) (m : IntPlane) :
    HasCompactSupport (canonicalWindow S m) := by
  exact S.χ_compact.comp_homeomorph (Homeomorph.subRight (latticePoint 1 m))

def canonicalBoxOrigin (S : DiscreteSetup) (m : IntPlane) : Fin 2 → ℝ :=
  fun i => ((m i : ℝ) - (S.D : ℝ) / 2) / (S.D : ℝ)

theorem canonicalWindow_support_box (S : DiscreteSetup) (m : IntPlane) :
    Function.support (canonicalWindow S m) ⊆ euclideanBox (canonicalBoxOrigin S m) S.D := by
  intro ξ hξ
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have hc (i : Fin 2) : |ξ i - (m i : ℝ)| < (S.D : ℝ) / 2 := by
    simpa only [PiLp.sub_apply, latticePoint, WithLp.equiv_symm_pi_apply, one_mul] using
      S.χ_support (ξ - latticePoint 1 m) (subset_closure hξ) i
  change (WithLp.equiv 2 (Fin 2 → ℝ)) ξ ∈ (S.D : ℝ) • unitBox (canonicalBoxOrigin S m)
  refine ⟨fun i => ξ i / (S.D : ℝ), ?_, ?_⟩
  · intro i _
    change ((m i : ℝ) - (S.D : ℝ) / 2) / S.D < ξ i / S.D ∧
      ξ i / S.D ≤ ((m i : ℝ) - (S.D : ℝ) / 2) / S.D + 1
    have hl : (m i : ℝ) - (S.D : ℝ) / 2 < ξ i := by linarith [(abs_lt.mp (hc i)).1]
    have hr : ξ i ≤ (m i : ℝ) + (S.D : ℝ) / 2 := by linarith [(abs_lt.mp (hc i)).2]
    constructor
    · exact (div_lt_div_iff_of_pos_right hD).mpr hl
    · calc
        ξ i / S.D ≤ ((m i : ℝ) + (S.D : ℝ) / 2) / S.D := div_le_div_of_nonneg_right hr hD.le
        _ = ((m i : ℝ) - (S.D : ℝ) / 2) / S.D + 1 := by field_simp; ring
  · funext i
    simp only [Pi.smul_apply, smul_eq_mul, WithLp.equiv_pi_apply]
    exact mul_div_cancel₀ _ hD.ne'

/-- Canonical extension reconstruction on a compact frequency region.
The finite window family depends only on the region and the fixed setup,
not on the datum, spatial point, or time labels. -/
theorem canonical_reconstruction (S : DiscreteSetup) (hφ : Continuous S.φ)
    {K : Set Plane} (hK : IsCompact K) :
    ∃ s : Finset IntPlane, ∀ (g : Plane → ℂ), Continuous g →
      tsupport g ⊆ K → ∀ (x : Plane) (j u : ℝ),
      HasSum (fun n : IntPlane => ∑ m ∈ s, (((S.D : ℝ) ^ 2)⁻¹ : ℝ) •
        (windowCoefficient S.φ g (canonicalWindow S m) (latticePoint (S.D : ℝ)⁻¹ n) j *
          windowKernel S.φ (canonicalWindow S m) (x - latticePoint (S.D : ℝ)⁻¹ n) u))
        (∫ ξ, g ξ * oscillation (@inner ℝ Plane _ x ξ + (j + u) * S.φ ξ)) := by
  obtain ⟨s, hp, _⟩ := canonical_finite_partition S hK
  refine ⟨s, ?_⟩
  intro g hg hgs x j u
  apply finite_window_reconstruction s S.φ hφ g hg
    (hK.of_isClosed_subset isClosed_closure hgs) (canonicalWindow S)
    (fun m _ => (canonicalWindow_smooth S m).continuous)
    (canonicalBoxOrigin S) (by exact_mod_cast S.D_pos)
    (fun m _ => canonicalWindow_support_box S m)
  intro ξ hξ
  exact hp ξ (hgs (subset_closure hξ))

theorem continuous_discreteFrequency (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) : Continuous (discreteFrequency S N s d) := by
  unfold discreteFrequency
  apply continuous_const.mul
  apply continuous_finset_sum
  intro i _
  apply Continuous.mul
  · exact continuous_const.mul (Complex.continuous_ofReal.comp
      (S.χ_smooth.continuous.comp (continuous_const.smul (continuous_id.sub continuous_const))))
  · exact continuous_oscillation.comp ((continuous_const.inner continuous_id).neg)

/-- The frequency supports of all allowed data lie in one fixed compact
set, uniformly in `N ≥ 1`, the finite labels, and the coefficients. -/
theorem discreteFrequency_uniform_support (S : DiscreteSetup) :
    ∃ K : Set Plane, IsCompact K ∧ ∀ N : ℝ, 1 ≤ N →
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ), discreteLabelsAllowed S N s →
        tsupport (discreteFrequency S N s d) ⊆ K := by
  classical
  obtain ⟨B₀, hB₀⟩ := S.χ_compact.exists_bound_of_continuousOn continuous_id.continuousOn
  let B := max B₀ 0
  have hB : 0 ≤ B := le_max_right _ _
  have hb : ∀ ξ ∈ tsupport S.χ, ‖ξ‖ ≤ B := fun ξ hξ => (hB₀ ξ hξ).trans (le_max_left _ _)
  refine ⟨Metric.closedBall 0 (S.frequencyBound + B), isCompact_closedBall _ _, ?_⟩
  intro N hN s d hs
  apply closure_minimal _ Metric.isClosed_closedBall
  intro ξ hξ
  by_contra hn
  have hx : S.frequencyBound + B < ‖ξ‖ := by
    simpa only [Metric.mem_closedBall, dist_zero_right, not_le] using hn
  have hz (i : PacketIndex) (hi : i ∈ s) : S.χ (N • (ξ - latticePoint N⁻¹ i.1)) = 0 := by
    by_contra hc
    have hb' := hb (N • (ξ - latticePoint N⁻¹ i.1)) (subset_closure hc)
    rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (by linarith : 0 ≤ N)] at hb'
    have hd : ‖ξ - latticePoint N⁻¹ i.1‖ ≤ B := by
      nlinarith [norm_nonneg (ξ - latticePoint N⁻¹ i.1)]
    have ht : ‖ξ‖ ≤ S.frequencyBound + B := by
      calc
        ‖ξ‖ = ‖latticePoint N⁻¹ i.1 + (ξ - latticePoint N⁻¹ i.1)‖ := by congr 1; abel
        _ ≤ ‖latticePoint N⁻¹ i.1‖ + ‖ξ - latticePoint N⁻¹ i.1‖ := norm_add_le _ _
        _ ≤ S.frequencyBound + B := add_le_add (hs i hi).1 hd
    exact (not_le.mpr hx) ht
  apply hξ
  simp only [discreteFrequency]
  have he : ∑ i ∈ s, d i * (S.χ (N • (ξ - latticePoint N⁻¹ i.1)) : ℂ) *
      oscillation (-@inner ℝ Plane _ (latticePoint (N / S.D) i.2) ξ) = 0 := by
    apply Finset.sum_eq_zero
    intro i hi
    simp [hz i hi]
  rw [he, mul_zero]

/-- The canonical synthesis identity for the actual datum in external
input 2. A single finite frequency-window set works at every scale. -/
theorem discreteExtension_reconstruction (S : DiscreteSetup) (hφ : Continuous S.φ) :
    ∃ q : Finset IntPlane, ∀ N : ℝ, 1 ≤ N →
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ), discreteLabelsAllowed S N s →
      ∀ (x : Plane) (j : ℕ) (u : ℝ),
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ) ^ 2)⁻¹ : ℝ) •
        (terminalCoefficient S N s d (m, n, j) *
          windowKernel S.φ (canonicalWindow S m) (x - latticePoint (S.D : ℝ)⁻¹ n) u))
        (discreteExtension S N s d (x, (j : ℝ) + u)) := by
  obtain ⟨K, hK, hsupport⟩ := discreteFrequency_uniform_support S
  obtain ⟨q, hq⟩ := canonical_reconstruction S hφ hK
  refine ⟨q, ?_⟩
  intro N hN s d hs x j u
  exact hq (discreteFrequency S N s d) (continuous_discreteFrequency S N s d)
    (hsupport N hN s d hs) x j u

end EllipticSquareFunction
