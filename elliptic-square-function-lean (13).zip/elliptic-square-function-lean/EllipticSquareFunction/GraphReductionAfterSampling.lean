import EllipticSquareFunction.PacketSamplingBridge

noncomputable section
namespace EllipticSquareFunction

/-- After deriving the packet/sampling bridge, only the smoothing estimate
remains as an internal analytic hypothesis for the continued-graph theorem.
The initial discrete partition setup T₀ is still explicit. -/
theorem reverseSquareFunction_of_discrete_and_smoothing (G : GraphSetup)
    (T₀ : DiscreteSetup) (heφ : T₀.φ=G.φ) (hphase : ContinuedPhase G.φ)
    {M : ℝ} (hM : 2<M) (hsmooth : TubeSmoothingEstimates G M) :
    ∃ S : DiscreteSetup, S.φ=G.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      (DiscreteDensityInput S → ReverseSquareFunction G) := by
  obtain ⟨S,hφ,hχ,hD,hpacket⟩ := packetSamplingEstimates_from_discrete G T₀ heφ hphase hM
  exact ⟨S,hφ,hχ,hD,fun hinput => reverseSquareFunction_of_bridges G M (hpacket hinput) hsmooth⟩

end EllipticSquareFunction
