import EllipticSquareFunction.PropositionThree

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Embed a finite packet array into a fixed ambient label type. This makes
uniformity in the number of frequency caps explicit. -/
def relabelArray {ι κ : Type*} (e : ι ↪ κ) (d : FinitePacketArray ι) : FinitePacketArray κ where
  labels := d.labels.map e
  positions := Function.extend e d.positions (fun _ => ∅)
  coefficient := Function.extend e d.coefficient (fun _ _ => 0)
  frequency := Function.extend e d.frequency (fun _ => 0)
  position := Function.extend e d.position (fun _ _ => 0)

theorem relabelArray_separated {ι κ : Type*} (e : ι ↪ κ) (d : FinitePacketArray ι)
    {N c σ F : ℝ} (hd : SeparatedPacketArray d N c σ F) :
    SeparatedPacketArray (relabelArray e d) N c σ F := by
  classical
  refine ⟨?_,?_,?_⟩
  · intro i hi
    obtain ⟨i,hmemi,rfl⟩ := Finset.mem_map.mp hi
    simpa only [relabelArray,e.injective.extend_apply] using hd.1 i hmemi
  · intro i hi j hj hij
    obtain ⟨i,hmemi,rfl⟩ := Finset.mem_map.mp hi
    obtain ⟨j,hmemj,rfl⟩ := Finset.mem_map.mp hj
    simpa only [relabelArray,e.injective.extend_apply] using
      hd.2.1 i hmemi j hmemj (fun he => hij (congrArg e he))
  · intro i hi p hp q hq hpq
    obtain ⟨i,hmemi,rfl⟩ := Finset.mem_map.mp hi
    simp only [relabelArray,e.injective.extend_apply] at hp hq ⊢
    exact hd.2.2 i hmemi p hp q hq hpq

theorem relabelArray_timePacket {ι κ : Type*} (e : ι ↪ κ) (d : FinitePacketArray ι)
    (φ : Phase) (b : Plane → ℂ) (ψ : ℝ → ℂ) (N s : ℝ) (y : Space) :
    arrayTimePacket (relabelArray e d) φ b ψ N s y=arrayTimePacket d φ b ψ N s y := by
  simp only [arrayTimePacket,arrayPacketSum,relabelArray,Finset.sum_map,e.injective.extend_apply]

theorem relabelArray_packetDensity {ι κ : Type*} (e : ι ↪ κ) (d : FinitePacketArray ι)
    (φ : Phase) (N M s : ℝ) (y : Space) :
    arrayPacketDensity (relabelArray e d) φ N M s y=arrayPacketDensity d φ N M s y := by
  simp only [arrayPacketDensity,arraySpatialDensity,spatialDensity,Finset.sum_sigma,
    relabelArray,Finset.sum_map,e.injective.extend_apply]

/-- An estimate for one ambient label type also holds for every embedded
family, with exactly the same constants. -/
theorem uniformTimeProfileBound_of_embedding {ι κ : Type*} (e : ι ↪ κ)
    (φ : Phase) (b : Plane → ℂ) (ψ : ℝ → ℂ) (c σ F M C P κ₀ η : ℝ)
    (h : UniformTimeProfileBound κ φ b ψ c σ F M C P κ₀ η) :
    UniformTimeProfileBound ι φ b ψ c σ F M C P κ₀ η := by
  intro j hj T d hd s
  have hh := h j hj T (fun k => relabelArray e (d k))
    (fun k hk => relabelArray_separated e (d k) (hd k hk)) s
  simpa only [relabelArray_timePacket,relabelArray_packetDensity] using hh

end EllipticSquareFunction
