import EllipticSquareFunction.Finite

/-!
# Integrating the finite reconstruction and density inequalities

The analytic hypotheses (kernel integrability and uniform bounds) are explicit.
They have to be proved for the particular oscillatory kernels of the article.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open MeasureTheory

namespace EllipticSquareFunction

/-- Integrability of the cubed reconstruction, so the subsequent Bochner
integral inequality is a genuine finite L³ bound. -/
theorem integrable_reconstruction_cubed {α ι : Type*} [MeasurableSpace α]
    (μ : Measure α) (s : Finset ι) (c : ι → ℂ)
    (K : ι → α → ℂ) (k : ι → α → ℝ) {B : ℝ}
    (hF : AEStronglyMeasurable (fun x => ∑ i ∈ s, c i * K i x) μ)
    (hk : ∀ᵐ x ∂μ, ∀ i ∈ s, ‖K i x‖ ≤ k i x)
    (hsum : ∀ᵐ x ∂μ, ∑ i ∈ s, k i x ≤ B)
    (hint : ∀ i ∈ s, Integrable (k i) μ) :
    Integrable (fun x => ‖∑ i ∈ s, c i * K i x‖ ^ 3) μ := by
  classical
  have hmajor : Integrable (fun x => B ^ 2 * ∑ i ∈ s, k i x * ‖c i‖ ^ 3) μ :=
    (integrable_finset_sum s (fun i hi => (hint i hi).mul_const _)).const_mul _
  apply hmajor.mono' (hF.norm.pow 3)
  filter_upwards [hk, hsum] with x hx hxs
  simp only [Pi.pow_apply]
  rw [Real.norm_eq_abs, abs_of_nonneg (pow_nonneg (norm_nonneg _) _)]
  have hk0 : ∀ i ∈ s, 0 ≤ k i x := fun i hi => (norm_nonneg _).trans (hx i hi)
  exact (norm_reconstruction_cubed s c (fun i => K i x) (fun i => k i x) hx).trans
    (mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (Finset.sum_nonneg hk0) hxs 2)
      (Finset.sum_nonneg (fun i hi => mul_nonneg (hk0 i hi)
        (pow_nonneg (norm_nonneg _) 3))))

/-- The integrated reconstruction bound with almost-everywhere kernel
hypotheses. This form applies directly to a restricted time slab. -/
theorem integral_reconstruction_cubed_ae {α ι : Type*} [MeasurableSpace α]
    (μ : Measure α) (s : Finset ι) (c : ι → ℂ)
    (K : ι → α → ℂ) (k : ι → α → ℝ) {B C : ℝ}
    (hk : ∀ᵐ x ∂μ, ∀ i ∈ s, ‖K i x‖ ≤ k i x)
    (hsum : ∀ᵐ x ∂μ, ∑ i ∈ s, k i x ≤ B)
    (hint : ∀ i ∈ s, Integrable (k i) μ)
    (hmass : ∀ i ∈ s, ∫ x, k i x ∂μ ≤ C) :
    (∫ x, ‖∑ i ∈ s, c i * K i x‖ ^ 3 ∂μ) ≤
      B ^ 2 * C * ∑ i ∈ s, ‖c i‖ ^ 3 := by
  classical
  have hmajor : Integrable (fun x => B ^ 2 * ∑ i ∈ s, k i x * ‖c i‖ ^ 3) μ :=
    (integrable_finset_sum s (fun i hi => (hint i hi).mul_const _)).const_mul _
  calc
    _ ≤ ∫ x, B ^ 2 * ∑ i ∈ s, k i x * ‖c i‖ ^ 3 ∂μ := by
      apply integral_mono_of_nonneg
        (Filter.Eventually.of_forall (fun x => pow_nonneg (norm_nonneg _) _)) hmajor
      filter_upwards [hk, hsum] with x hx hxs
      have hk0 : ∀ i ∈ s, 0 ≤ k i x := fun i hi => (norm_nonneg _).trans (hx i hi)
      exact (norm_reconstruction_cubed s c (fun i => K i x) (fun i => k i x) hx).trans
        (mul_le_mul_of_nonneg_right
          (pow_le_pow_left₀ (Finset.sum_nonneg hk0) hxs 2)
          (Finset.sum_nonneg (fun i hi => mul_nonneg (hk0 i hi)
            (pow_nonneg (norm_nonneg _) 3))))
    _ = B ^ 2 * ∑ i ∈ s, (∫ x, k i x ∂μ) * ‖c i‖ ^ 3 := by
      rw [integral_const_mul, integral_finset_sum s
        (fun i hi => (hint i hi).mul_const _)]
      simp_rw [integral_mul_const]
    _ ≤ B ^ 2 * ∑ i ∈ s, C * ‖c i‖ ^ 3 := by
      apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
      exact Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_right
        (hmass i hi) (pow_nonneg (norm_nonneg _) 3))
    _ = _ := by rw [← Finset.mul_sum]; ring

/-- The integrated finite version of (4.7). `B` bounds the sum of the kernel
majorants and `C` bounds each majorant's integral. -/
theorem integral_reconstruction_cubed {α ι : Type*} [MeasurableSpace α]
    (μ : Measure α) (s : Finset ι) (c : ι → ℂ)
    (K : ι → α → ℂ) (k : ι → α → ℝ) {B C : ℝ}
    (hk : ∀ x, ∀ i ∈ s, ‖K i x‖ ≤ k i x)
    (hsum : ∀ x, ∑ i ∈ s, k i x ≤ B)
    (hint : ∀ i ∈ s, Integrable (k i) μ)
    (hmass : ∀ i ∈ s, ∫ x, k i x ∂μ ≤ C) :
    (∫ x, ‖∑ i ∈ s, c i * K i x‖ ^ 3 ∂μ) ≤
      B ^ 2 * C * ∑ i ∈ s, ‖c i‖ ^ 3 := by
  classical
  have hk0 : ∀ x, ∀ i ∈ s, 0 ≤ k i x :=
    fun x i hi => (norm_nonneg _).trans (hk x i hi)
  have hmajor : Integrable (fun x => B ^ 2 * ∑ i ∈ s, k i x * ‖c i‖ ^ 3) μ :=
    (integrable_finset_sum s (fun i hi => (hint i hi).mul_const _)).const_mul _
  calc
    _ ≤ ∫ x, B ^ 2 * ∑ i ∈ s, k i x * ‖c i‖ ^ 3 ∂μ := by
      apply integral_mono_of_nonneg
        (Filter.Eventually.of_forall (fun x => pow_nonneg (norm_nonneg _) _)) hmajor
      apply Filter.Eventually.of_forall
      intro x
      exact (norm_reconstruction_cubed s c (fun i => K i x) (fun i => k i x)
        (hk x)).trans (mul_le_mul_of_nonneg_right
          (pow_le_pow_left₀ (Finset.sum_nonneg (hk0 x)) (hsum x) 2)
          (Finset.sum_nonneg (fun i hi => mul_nonneg (hk0 x i hi)
            (pow_nonneg (norm_nonneg _) 3))))
    _ = B ^ 2 * ∑ i ∈ s, (∫ x, k i x ∂μ) * ‖c i‖ ^ 3 := by
      rw [integral_const_mul, integral_finset_sum s
        (fun i hi => (hint i hi).mul_const _)]
      simp_rw [integral_mul_const]
    _ ≤ B ^ 2 * ∑ i ∈ s, C * ‖c i‖ ^ 3 := by
      apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
      exact Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_right
        (hmass i hi) (pow_nonneg (norm_nonneg _) 3))
    _ = _ := by rw [← Finset.mul_sum]; ring

/-- Algebra behind the power of a squared coefficient in (4.8) and (4.13). -/
theorem square_rpow_three_halves {a : ℝ} (ha : 0 ≤ a) :
    (a ^ 2) ^ (3 / 2 : ℝ) = a ^ 3 := by
  rw [← Real.rpow_natCast a 2, ← Real.rpow_mul ha]
  norm_num
  exact Real.rpow_natCast a 3

/-- A general density lower bound. The geometric statement that the packet
weights have uniform mass is the separate hypothesis `hmass`. -/
theorem density_integral_lower_bound {α ι : Type*} [MeasurableSpace α]
    (μ : Measure α) (s : Finset ι) (a : ι → ℂ) (ρ : ι → α → ℝ) {v : ℝ}
    (hρ : ∀ x, ∀ i ∈ s, 0 ≤ ρ i x)
    (hint : ∀ i ∈ s, Integrable (fun x => (ρ i x) ^ (3 / 2 : ℝ)) μ)
    (hD : Integrable (fun x => (∑ i ∈ s, ‖a i‖ ^ 2 * ρ i x) ^ (3 / 2 : ℝ)) μ)
    (hmass : ∀ i ∈ s, v ≤ ∫ x, (ρ i x) ^ (3 / 2 : ℝ) ∂μ) :
    v * ∑ i ∈ s, ‖a i‖ ^ 3 ≤
      ∫ x, (∑ i ∈ s, ‖a i‖ ^ 2 * ρ i x) ^ (3 / 2 : ℝ) ∂μ := by
  classical
  calc
    _ = ∑ i ∈ s, ‖a i‖ ^ 3 * v := by rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intros; ring
    _ ≤ ∑ i ∈ s, ‖a i‖ ^ 3 * ∫ x, (ρ i x) ^ (3 / 2 : ℝ) ∂μ := by
      exact Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_left
        (hmass i hi) (pow_nonneg (norm_nonneg _) 3))
    _ = ∫ x, ∑ i ∈ s, ‖a i‖ ^ 3 * (ρ i x) ^ (3 / 2 : ℝ) ∂μ := by
      rw [integral_finset_sum s (fun i hi => (hint i hi).const_mul _)]
      simp_rw [integral_const_mul]
    _ ≤ _ := by
      apply integral_mono
        (integrable_finset_sum s (fun i hi => (hint i hi).const_mul _)) hD
      intro x
      calc
        _ = ∑ i ∈ s, (‖a i‖ ^ 2 * ρ i x) ^ (3 / 2 : ℝ) := by
          apply Finset.sum_congr rfl
          intro i hi
          rw [Real.mul_rpow (sq_nonneg _) (hρ x i hi),
            square_rpow_three_halves (norm_nonneg _)]
        _ ≤ _ := sum_rpow_le_rpow_sum s _
          (fun i hi => mul_nonneg (sq_nonneg _) (hρ x i hi)) (by norm_num)

/-- The omitted terminal coefficients in Section 4.1 have an absorbable power. -/
theorem terminal_tail_power {N L : ℝ} (hN : 1 ≤ N) (hL : 5 ≤ L) :
    N ^ (26 - 6 * L) ≤ N ^ (4 : ℝ) :=
  Real.rpow_le_rpow_of_exponent_le hN (by linarith)

/-- The frame-change tail in Section 4.2 has an absorbable power. -/
theorem frame_tail_power {N L : ℝ} (hN : 1 ≤ N) (hL : 6 ≤ L) :
    N ^ (20 - 3 * L) ≤ N ^ (4 : ℝ) :=
  Real.rpow_le_rpow_of_exponent_le hN (by linarith)

end EllipticSquareFunction
