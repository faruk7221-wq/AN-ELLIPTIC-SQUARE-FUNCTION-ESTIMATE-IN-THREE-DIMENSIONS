import EllipticSquareFunction.SeeleyLocalHalfLine

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- The full one-dimensional half-line extension theorem, for arbitrary
Banach-valued smooth data. No boundedness or analyticity hypothesis is needed. -/
theorem smooth_halfline_extension {f : ℝ → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0)) :
    ∃ F : ℝ → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F f (Set.Ici 0) := by
  obtain ⟨G,hG,hGf⟩ := smooth_halfline_local_extension hf
  let F : ℝ → E := fun t => if 0 ≤ t then f t else G t
  refine ⟨F,?_,fun t ht => by change 0 ≤ t at ht; simp only [F,if_pos ht]⟩
  rw [contDiff_iff_contDiffAt]
  intro t
  rcases lt_trichotomy t 0 with ht | ht | ht
  · apply hG.contDiffAt.congr_of_eventuallyEq
    filter_upwards [Iio_mem_nhds ht] with s hs
    change s < 0 at hs
    simp only [F,if_neg (not_le_of_gt hs)]
  · subst t
    apply hG.contDiffAt.congr_of_eventuallyEq
    filter_upwards [Iio_mem_nhds (by norm_num : (0 : ℝ) < 1)] with s hs
    dsimp only [F]
    split_ifs with h
    · exact (hGf ⟨h,le_of_lt hs⟩).symm
    · rfl
  · apply (hf.contDiffAt (Ici_mem_nhds ht)).congr_of_eventuallyEq
    filter_upwards [Ioi_mem_nhds ht] with s hs
    change 0 < s at hs
    simp only [F,if_pos (le_of_lt hs)]

end EllipticSquareFunction
