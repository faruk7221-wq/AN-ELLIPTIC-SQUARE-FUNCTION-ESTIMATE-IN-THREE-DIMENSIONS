import EllipticSquareFunction.DyadicKernelDomination

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The symmetric sheared tube used in the positive kernel decomposition. -/
def symmetricTube (r T : ℝ) (V : Plane) : Set Space :=
  {y | |y.2|≤T ∧ ‖y.1+y.2 • V‖≤r}

theorem measurableSet_symmetricTube (r T : ℝ) (V : Plane) : MeasurableSet (symmetricTube r T V) := by
  apply MeasurableSet.inter
  · exact (isClosed_le (by fun_prop : Continuous (fun y : Space => |y.2|)) continuous_const).measurableSet
  · exact (isClosed_le (by fun_prop : Continuous (fun y : Space => ‖y.1+y.2 • V‖)) continuous_const).measurableSet

theorem symmetricTube_section (r T t : ℝ) (V : Plane) :
    (fun x : Plane => (x,t)) ⁻¹' symmetricTube r T V =
      if |t|≤T then Metric.closedBall (-t • V) r else ∅ := by
  ext x
  by_cases ht : |t|≤T
  · simp only [symmetricTube,mem_preimage,mem_setOf_eq,ht,true_and,if_pos,
      Metric.mem_closedBall,dist_eq_norm,neg_smul,sub_neg_eq_add]
  · simp [symmetricTube,ht]

/-- Exact volume of a symmetric sheared tube, including the factor 2. -/
theorem volume_symmetricTube (r T : ℝ) (V : Plane) :
    volume (symmetricTube r T V)=ENNReal.ofReal r^2*ENNReal.ofReal Real.pi*ENNReal.ofReal (2*T) := by
  change (volume.prod volume) (symmetricTube r T V)=_
  rw [Measure.prod_apply_symm (measurableSet_symmetricTube r T V)]
  simp_rw [symmetricTube_section]
  have he : (fun t : ℝ => volume (if |t|≤T then Metric.closedBall (-t • V) r else ∅))=
      (Icc (-T) T).indicator (fun _ => ENNReal.ofReal r^2*ENNReal.ofReal Real.pi) := by
    funext t
    by_cases ht : |t|≤T
    · simp [ht,abs_le.mp ht]
    · have hh : t∉Icc (-T) T := by simpa only [mem_Icc,← abs_le] using ht
      simp [ht,hh]
  rw [he,lintegral_indicator_const measurableSet_Icc]
  simp only [Real.volume_Icc]
  congr 2
  ring

theorem normalized_ball_eq_symmetricTube {r T a : ℝ} (hr : 0<r) (hT : 0<T)
    (V : Plane) :
    {y : Space | ‖shearScale r T V y‖≤a}=symmetricTube (a*r) (a*T) V := by
  ext y
  simp only [mem_setOf_eq,shearScale,Prod.norm_def,max_le_iff,symmetricTube,
    norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hr),abs_div,abs_of_pos hT]
  rw [← div_eq_inv_mul,div_le_iff₀ hr,div_le_iff₀ hT]
  exact and_comm

theorem spatial_norm_le_euclideanLength (y : Space) : ‖y.1‖≤euclideanLength y := by
  unfold euclideanLength
  exact (Real.le_sqrt (norm_nonneg _) (by positivity)).mpr (by nlinarith [sq_nonneg y.2])

theorem abs_time_le_euclideanLength (y : Space) : |y.2|≤euclideanLength y := by
  unfold euclideanLength
  exact (Real.le_sqrt (abs_nonneg _) (by positivity)).mpr (by nlinarith [sq_nonneg ‖y.1‖,sq_abs y.2])

/-- A Euclidean tube around the slanted segment stays inside a controlled
sheared box. This yields the volume comparison needed for Nikodym averages. -/
theorem geometricTube_subset_symmetricTube {r T : ℝ} (hT : 0≤T) (V : Plane) :
    geometricTube (T • V,-T) (-T • V,T) r ⊆
      symmetricTube (r*(1+‖V‖)) (T+r) V := by
  intro y hy
  obtain ⟨s,hs,hd⟩ := hy
  let t := (2*s-1)*T
  have hc : (1-s) • (T • V,-T)+s • (-T • V,T)=(-t • V,t) := by
    apply Prod.ext
    · dsimp [t]
      module
    · dsimp [t]
      ring
  rw [hc] at hd
  have hx := (spatial_norm_le_euclideanLength (y-(-t • V,t))).trans hd
  have ht := (abs_time_le_euclideanLength (y-(-t • V,t))).trans hd
  have htt : |t|≤T := by
    rw [abs_le]
    dsimp [t]
    constructor <;> nlinarith [hs.1,hs.2]
  refine ⟨?_,?_⟩
  · have hh := abs_add (y.2-t) t
    simp only [sub_add_cancel] at hh
    exact hh.trans (by dsimp only [Prod.snd_sub] at ht; linarith)
  · have he : y.1+y.2 • V=(y.1+t • V)+(y.2-t) • V := by module
    rw [he]
    have hh := norm_add_le (y.1+t • V) ((y.2-t) • V)
    simp only [norm_smul,Real.norm_eq_abs] at hh
    simp only [Prod.fst_sub,neg_smul,sub_neg_eq_add] at hx
    simp only [Prod.snd_sub] at ht
    nlinarith [mul_le_mul_of_nonneg_right ht (norm_nonneg V)]

end EllipticSquareFunction
