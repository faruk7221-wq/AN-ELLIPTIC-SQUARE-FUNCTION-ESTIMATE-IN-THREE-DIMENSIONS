import EllipticSquareFunction.SamplingCutoffs

noncomputable section
open MeasureTheory Set
open scoped Pointwise
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- A single positive integer box side covers prescribed normalized bounds. -/
theorem exists_integer_spaceBox (A B : ℝ) :
    ∃ D : ℕ, 0<D ∧ ∀ z : Space, ‖z.1‖≤A → |z.2|≤B →
      z ∈ spaceBox (fun _ => -(1/2:ℝ)) (D:ℝ) := by
  let L := max (max A B) 0
  let D : ℕ := ⌈2*(L+1)⌉₊+1
  have hDnat : 0<D := by dsimp [D]; omega
  have hD : 0<(D:ℝ) := by exact_mod_cast hDnat
  have hDL : 2*(L+1)<(D:ℝ) := by
    have hc := Nat.le_ceil (2*(L+1))
    dsimp [D]
    push_cast
    linarith
  refine ⟨D,hDnat,?_⟩
  intro z hz ht
  let x := spaceCoordinateEquiv.symm z
  have he := spaceCoordinateEquiv_apply x
  have hxe : spaceCoordinateEquiv x=z := spaceCoordinateEquiv.apply_symm_apply z
  rw [hxe] at he
  have hx (i : Fin 3) : |x i|≤L := by
    refine Fin.cases ?_ (fun j => ?_) i
    · have hh := congrArg Prod.snd he
      change z.2=x 0 at hh
      rw [← hh]
      exact ht.trans ((le_max_right A B).trans (le_max_left _ _))
    · have hh := congrArg (fun w : Space => w.1 j) he
      change z.1 j=x j.succ at hh
      rw [← hh,← Real.norm_eq_abs]
      exact (PiLp.norm_apply_le z.1 j).trans (hz.trans ((le_max_left A B).trans (le_max_left _ _)))
  refine ⟨x,?_,hxe⟩
  change x ∈ (D:ℝ) • unitBox (fun _ => -(1/2:ℝ))
  refine ⟨(D:ℝ)⁻¹ • x,?_,?_⟩
  · intro i hi
    change -(1/2:ℝ)<(D:ℝ)⁻¹*x i ∧ (D:ℝ)⁻¹*x i≤-(1/2:ℝ)+1
    have hb := abs_le.mp (hx i)
    constructor
    · have hh : -(D:ℝ)/2<x i := by linarith
      rw [inv_mul_eq_div,lt_div_iff₀ hD]
      linarith
    · rw [inv_mul_eq_div,div_le_iff₀ hD]
      linarith
  · simp [smul_smul,hD.ne']

/-- The new homeomorphism uses the same tangent coordinates as the Taylor bounds. -/
theorem tangent_homeomorph_eq_coordinates (φ : Phase) (ν : Plane)
    {r R : ℝ} (hr : r≠0) (hR : R≠0) (ζ : Space) :
    curvedFrequencyHomeomorph (tangentPhase ν (velocity φ ν) (φ ν))
      (continuous_tangentPhase ν (velocity φ ν) (φ ν)) hr hR ν ζ =
      affineFrequencyCoordinates φ ν r R ζ := by
  apply Prod.ext
  · rfl
  · dsimp [curvedFrequencyHomeomorph,tangentPhase,affineFrequencyCoordinates]
    ring

end EllipticSquareFunction
