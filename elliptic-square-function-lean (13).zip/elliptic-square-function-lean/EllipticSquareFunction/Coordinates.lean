import EllipticSquareFunction.Definitions

/-!
# Exact coordinate identities in Sections 5 and 6

These algebraic identities are independent of the analytic estimates.
In particular, proving the identity for a sampling lattice is not a proof
of the Fourier-series sampling theorem.
-/

noncomputable section
namespace EllipticSquareFunction

def shearScale (r R : ℝ) (V : Plane) (y : Space) : Space :=
  (r⁻¹ • (y.1 + y.2 • V), y.2 / R)

def unshearScale (r R : ℝ) (V : Plane) (z : Space) : Space :=
  (r • z.1 - (R * z.2) • V, R * z.2)

theorem shearScale_unshearScale {r R : ℝ} (hr : r ≠ 0) (hR : R ≠ 0)
    (V : Plane) (z : Space) :
    shearScale r R V (unshearScale r R V z) = z := by
  ext <;> simp [shearScale, unshearScale, smul_smul, hr, hR]

theorem unshearScale_shearScale {r R : ℝ} (hr : r ≠ 0) (hR : R ≠ 0)
    (V : Plane) (y : Space) :
    unshearScale r R V (shearScale r R V y) = y := by
  have ht : R * (y.2 / R) = y.2 := by field_simp
  ext <;> simp [shearScale, unshearScale, ht, smul_smul, hr]

/-- The sheared physical sampling lattice from Lemma 4. -/
def samplePoint (r R A B : ℝ) (V ℓ : Plane) (k : ℝ) : Space :=
  ((r / A) • ℓ - (k * R / B) • V, k * R / B)

theorem shearScale_samplePoint {r R A B : ℝ} (hr : r ≠ 0) (hR : R ≠ 0)
    (V ℓ : Plane) (k : ℝ) :
    shearScale r R V (samplePoint r R A B V ℓ k) =
      (A⁻¹ • ℓ, k / B) := by
  have hspace : r⁻¹ * (r / A) = A⁻¹ := by field_simp
  have htime : k * R / B / R = k / B := by
    by_cases hB : B = 0
    · simp [hB]
    · field_simp
      ring
  ext <;> simp [shearScale, samplePoint, smul_smul, hspace, htime]

/-- A time origin changes the tube center by `sV`. -/
theorem transported_center (x v V : Plane) (t s : ℝ) :
    x - v + (t - s) • V = x - (v + s • V) + t • V := by
  module

/-- The normalized phase remainder in (5.7). -/
def phaseRemainder (φ : Phase) (ν V : Plane) (r R : ℝ) (η : Plane) : ℝ :=
  R * (φ (ν + r⁻¹ • η) - φ ν - r⁻¹ * @inner ℝ Plane _ V η)

/-- Exact phase separation used when rebasing a packet at a new time.
No Taylor bound for the remainder is asserted here. -/
theorem rebase_phase_identity (φ : Phase) (ν V w v η : Plane) (r R Δ : ℝ) :
    @inner ℝ Plane _ (w - v) (ν + r⁻¹ • η) + Δ * R * φ (ν + r⁻¹ • η) =
      @inner ℝ Plane _ (w - v) ν + Δ * R * φ ν +
      @inner ℝ Plane _ (r⁻¹ • (w - v + (Δ * R) • V)) η +
      Δ * phaseRemainder φ ν V r R η := by
  simp only [phaseRemainder, inner_add_right, inner_smul_right,
    inner_smul_left, inner_add_left, map_mul, starRingEnd_apply, star_trivial]
  ring

/-- The volume of the Fourier box, provided the frequency-coordinate
change-of-variables has been justified: `A² B R⁻²`. -/
def fourierBoxVolume (A B R : ℝ) : ℝ := A ^ 2 * B * (R ^ 2)⁻¹

/-- Cancellation of the sampling normalization in (6.5). -/
theorem sampling_coefficient_normalization {A B R : ℝ}
    (hA : A ≠ 0) (hB : B ≠ 0) (hR : R ≠ 0) (fval : ℂ) :
    ((R ^ 2)⁻¹ : ℝ) * ((fourierBoxVolume A B R)⁻¹ : ℝ) * fval =
      ((A ^ 2 * B)⁻¹ : ℝ) * fval := by
  have h : (R ^ 2)⁻¹ * (fourierBoxVolume A B R)⁻¹ = (A ^ 2 * B)⁻¹ := by
    unfold fourierBoxVolume
    field_simp
  rw [← Complex.ofReal_mul, h]

/-- Spatial dimension two and time scale `N²` give the factor `N⁴`. -/
theorem tube_volume_scale (N : ℝ) : N ^ 2 * N ^ 2 = N ^ 4 := by ring

/-- The Jacobian cancellation discussed after the external discrete input. -/
theorem discrete_jacobian_cancellation {N : ℝ} (hN : N ≠ 0) (I : ℝ) :
    N ^ 6 * (N⁻¹ ^ 6 * I) = I := by field_simp

end EllipticSquareFunction
