import EllipticSquareFunction.SchwartzAffineTransport
import EllipticSquareFunction.FinitePlacementCover

noncomputable section
namespace EllipticSquareFunction

theorem spaceTranspose_involutive (L : Space ≃L[ℝ] Space) :
    spaceTranspose (spaceTranspose L) = L := by
  apply ContinuousLinearEquiv.ext
  funext x
  apply spacePairLinear_injective
  apply LinearMap.ext
  intro y
  change spacePair (spaceTranspose (spaceTranspose L) x) y = spacePair (L x) y
  rw [spaceTranspose_pair, spacePair_comm x, spaceTranspose_pair, spacePair_comm y]

theorem spaceTranspose_symm (L : Space ≃L[ℝ] Space) :
    spaceTranspose L.symm = (spaceTranspose L).symm := by
  apply ContinuousLinearEquiv.ext
  funext x
  apply (spaceTranspose L).injective
  rw [ContinuousLinearEquiv.apply_symm_apply]
  apply spacePairLinear_injective
  apply LinearMap.ext
  intro y
  change spacePair (spaceTranspose L (spaceTranspose L.symm x)) y = spacePair x y
  rw [spaceTranspose_pair, spaceTranspose_pair, ContinuousLinearEquiv.symm_apply_apply]

/-- The coordinate change induced on the base of a graph. -/
def graphCenterMap (A : Space ≃ᵃ[ℝ] Space) (φ : Phase) (ξ : Plane) : Plane :=
  (A (ξ, φ ξ)).1

theorem affine_apply_eq_linear_add (A : Space ≃ᵃ[ℝ] Space) (z : Space) :
    A z = A.linear z + A 0 := by
  simpa using A.map_vadd (0 : Space) z

theorem affine_sub_eq_linear (A : Space ≃ᵃ[ℝ] Space) (z w : Space) :
    A z - A w = A.linear (z-w) := by
  simpa using ((A : Space →ᵃ[ℝ] Space).linearMap_vsub z w).symm

theorem placed_graph_point {A : Space ≃ᵃ[ℝ] Space} {φ Φ : Phase}
    {W O : Set Plane} (hmap : A '' graphOver φ W = graphOver Φ O)
    {ξ : Plane} (hξ : ξ ∈ W) :
    graphCenterMap A φ ξ ∈ O ∧
      A (ξ,φ ξ) = (graphCenterMap A φ ξ, Φ (graphCenterMap A φ ξ)) := by
  have hm : A (ξ,φ ξ) ∈ graphOver Φ O := by
    rw [← hmap]
    exact ⟨(ξ,φ ξ), ⟨ξ,hξ,rfl⟩,rfl⟩
  obtain ⟨η,hη,he⟩ := hm
  have hfst : η=graphCenterMap A φ ξ := congrArg Prod.fst he
  subst η
  exact ⟨hη,he.symm⟩

theorem placed_graph_inverse {A : Space ≃ᵃ[ℝ] Space} {φ Φ : Phase}
    {W O : Set Plane} (hmap : A '' graphOver φ W = graphOver Φ O)
    {ξ : Plane} (hξ : ξ ∈ W) :
    graphCenterMap A.symm Φ (graphCenterMap A φ ξ) = ξ := by
  obtain ⟨_,he⟩ := placed_graph_point hmap hξ
  change (A.symm (graphCenterMap A φ ξ, Φ (graphCenterMap A φ ξ))).1 = ξ
  rw [← he, A.symm_apply_apply]

/-- The Schwartz pullback realizing the *given* affine frequency map. -/
def schwartzAffineFrequency (A : Space ≃ᵃ[ℝ] Space) (f : SchwartzMap Space ℂ) :
    SchwartzMap Space ℂ :=
  schwartzModulatedLinearPullback (spaceTranspose A.linear.toContinuousLinearEquiv) (A 0) f

theorem affine_frequency_inverse (A : Space ≃ᵃ[ℝ] Space) (η : Space) :
    spaceTranspose (spaceTranspose A.linear.toContinuousLinearEquiv).symm (η-A 0) =
      A.symm η := by
  rw [← spaceTranspose_symm, spaceTranspose_involutive]
  apply A.linear.injective
  change A.linear (A.linear.symm (η-A 0)) = A.linear (A.symm η)
  rw [A.linear.apply_symm_apply]
  have h := affine_apply_eq_linear_add A (A.symm η)
  rw [A.apply_symm_apply] at h
  exact sub_eq_iff_eq_add.mpr h

theorem support_fourier_schwartzAffineFrequency (A : Space ≃ᵃ[ℝ] Space)
    (f : SchwartzMap Space ℂ) :
    Function.support (fourierTransform (schwartzAffineFrequency A f)) =
      A '' Function.support (fourierTransform f) := by
  have he : (schwartzAffineFrequency A f : Space → ℂ) =
      modulatedLinearPullback (spaceTranspose A.linear.toContinuousLinearEquiv) (A 0) f := by
    funext y
    exact schwartzModulatedLinearPullback_apply _ _ _ _
  rw [he,support_fourier_modulatedLinearPullback]
  simp_rw [affine_frequency_inverse]
  ext η
  constructor
  · intro h
    exact ⟨A.symm η,h,A.apply_symm_apply η⟩
  · rintro ⟨z,hz,rfl⟩
    simpa using hz

end EllipticSquareFunction
