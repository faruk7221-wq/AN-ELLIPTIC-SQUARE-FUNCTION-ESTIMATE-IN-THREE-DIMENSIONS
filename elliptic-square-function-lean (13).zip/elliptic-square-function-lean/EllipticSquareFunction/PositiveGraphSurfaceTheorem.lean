import EllipticSquareFunction.LocalEllipticity

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Local smooth graph extensions with positive-definite Hessian at the
center. Uniform bounds, compact chart domains, and finite covers are derived.
This is a graph-coordinate geometric hypothesis, not an intrinsic manifold
definition or an assertion that graph charts have already been constructed
from the second fundamental form. -/
def LocalPositiveGraphExtensions (carrier : Set Space) : Prop :=
  ∀ p ∈ carrier, ∃ (W : Set Space) (A : Space ≃ᵃ[ℝ] Space) (φ : Phase) (U : Set Plane),
    IsOpen W ∧ p ∈ W ∧ IsOpen U ∧ ContDiffOn ℝ (⊤ : ℕ∞) φ U ∧
      (∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ φ) (A p).1 v v) ∧
      ∀ q ∈ carrier ∩ W, (A q).1 ∈ U ∧ (A q).2=φ (A q).1

theorem local_smooth_graphs_of_positive_extensions {carrier : Set Space}
    (hlocal : LocalPositiveGraphExtensions carrier) : LocalSmoothEllipticGraphs carrier := by
  intro p hp
  obtain ⟨W,A,φ,U,hW,hpW,hU,hφ,hpos,hgraph⟩ := hlocal p hp
  obtain ⟨V,hV,hpV,hVU,hell⟩ := local_uniform_ellipticity hU hφ (hgraph p ⟨hp,hpW⟩).1 hpos
  let W' := W ∩ (fun q : Space => (A q).1) ⁻¹' V
  refine ⟨W',A,φ,V,hW.inter (hV.preimage (affine_space_continuous A).fst),
    ⟨hpW,hpV⟩,hV,hφ.mono hVU,hell,?_⟩
  intro q hq
  exact ⟨hq.2.2,(hgraph q ⟨hq.1,hq.2.1⟩).2⟩

theorem local_atlas_of_positive_extensions {carrier : Set Space}
    (hlocal : LocalPositiveGraphExtensions carrier) : LocalEllipticGraphAtlas carrier :=
  local_elliptic_atlas_of_local_smooth_graphs (local_smooth_graphs_of_positive_extensions hlocal)

theorem surface_reverse_square_function_of_positive_extensions (S : SurfaceSetup)
    (hlocal : LocalPositiveGraphExtensions S.carrier)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    SurfaceReverseSquareFunction S :=
  surface_atlas_reverse_square_function S (local_atlas_of_positive_extensions hlocal)
    hplacement hnikodym hdiscrete

/-- Euclidean version of the surface theorem, from local positive graph
extensions and exactly the three external input propositions. -/
theorem euclidean_surface_estimate_of_positive_graphs {K : Set EuclideanThree} (hK : IsCompact K)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hlocal : LocalPositiveGraphExtensions (spaceEuclideanEquiv '' K))
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (p : Fin n → EuclideanThree) (f : Fin n → SchwartzMap EuclideanThree ℂ),
      (∀ i, p i ∈ K) →
      (∀ i j, i ≠ j → c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
      (∀ i, Function.support (Real.fourierIntegral (f i)) ⊆ surfaceCap K (p i) (Real.sqrt R)⁻¹ C₀) →
      eLpNorm (fun y => ∑ i, f i y) 3 volume ≤ ENNReal.ofReal (C*R^ε)*
        eLpNorm (fun y => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume :=
  euclidean_surface_reverse_square_function hK hc₀ hC₀ (local_atlas_of_positive_extensions hlocal)
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
