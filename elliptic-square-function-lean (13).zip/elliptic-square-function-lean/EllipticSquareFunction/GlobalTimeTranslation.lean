import EllipticSquareFunction.PropositionThreeUnit

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

theorem global_time_translation_l3 (F : Space → ℂ) (hF : Continuous F) (s : ℝ) :
    l3 (fun y : Space => F (y.1,y.2-s)) volume=l3 F volume := by
  have hm : MeasurePreserving (fun y : Space => y+(0,-s)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) 0).prod
      (measurePreserving_add_right (volume : Measure ℝ) (-s))
  simpa only [l3,Function.comp_def,Prod.add_def,add_zero,sub_eq_add_neg] using
    eLpNorm_comp_measurePreserving hF.aestronglyMeasurable hm (p := (3:ℝ≥0∞))

theorem global_time_translation_density (D : Space → ℝ) (s : ℝ) :
    (∫⁻ y : Space, (ENNReal.ofReal (D (y.1,y.2-s)))^(3/2:ℝ))^(1/3:ℝ) =
      (∫⁻ y : Space, (ENNReal.ofReal (D y))^(3/2:ℝ))^(1/3:ℝ) := by
  have hm : MeasurePreserving (fun y : Space => y+(0,-s)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) 0).prod
      (measurePreserving_add_right (volume : Measure ℝ) (-s))
  have he := (Homeomorph.addRight ((0:Plane),-s)).measurableEmbedding
  have hh := hm.setLIntegral_comp_preimage_emb he
    (fun y => (ENNReal.ofReal (D y))^(3/2:ℝ)) univ
  congr 1
  simpa only [preimage_univ,Measure.restrict_univ,Prod.add_def,add_zero,sub_eq_add_neg] using hh

theorem continuous_arrayTimePacket {ι : Type*} (d : FinitePacketArray ι)
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    {N : ℝ} (hN : N≠0) (s : ℝ) : Continuous (arrayTimePacket d φ b ψ N s) := by
  exact (hψ.comp ((continuous_snd.sub continuous_const).div_const (N^2))).mul
    ((continuous_arrayPacketSum d φ hφ b hb hbs hN).comp
      (continuous_fst.prodMk (continuous_snd.sub continuous_const)))

theorem arrayPacketDensity_nonneg {ι : Type*} (d : FinitePacketArray ι)
    (φ : Phase) (N M s : ℝ) (y : Space) : 0≤arrayPacketDensity d φ N M s y :=
  mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (spatialDensity_nonneg_global ..)

/-- A common translation of a complete time lattice preserves the global
estimate, independently of the lattice origin. -/
theorem translate_time_packet_estimate {ι : Type*} (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    (ψ : ℝ → ℂ) (hψ : Continuous ψ) {N : ℝ} (hN : N≠0)
    (T : Finset ℤ) (d : ℤ → FinitePacketArray ι) (M C : ℝ)
    (h : l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) φ b ψ N ((k:ℝ)*N^2) y) volume ≤
      ENNReal.ofReal C*(∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
        arrayPacketDensity (d k) φ N M ((k:ℝ)*N^2) y))^(3/2:ℝ))^(1/3:ℝ))
    (s : ℝ) :
    l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) φ b ψ N (s+(k:ℝ)*N^2) y) volume ≤
      ENNReal.ofReal C*(∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
        arrayPacketDensity (d k) φ N M (s+(k:ℝ)*N^2) y))^(3/2:ℝ))^(1/3:ℝ) := by
  let F := fun y => ∑ k ∈ T, arrayTimePacket (d k) φ b ψ N ((k:ℝ)*N^2) y
  let D := fun y => ∑ k ∈ T, arrayPacketDensity (d k) φ N M ((k:ℝ)*N^2) y
  have hF : Continuous F := continuous_finset_sum T (fun k _ =>
    continuous_arrayTimePacket (d k) φ hφ b hb hbs ψ hψ hN _)
  have hh : l3 (fun y => F (y.1,y.2-s)) volume ≤
      ENNReal.ofReal C*(∫⁻ y : Space, (ENNReal.ofReal (D (y.1,y.2-s)))^(3/2:ℝ))^(1/3:ℝ) := by
    rw [global_time_translation_l3 F hF,global_time_translation_density D]
    exact h
  have he (t u : ℝ) : t-s-u=t-(s+u) := by ring
  simpa only [F,D,arrayTimePacket,arrayPacketDensity,he] using hh

theorem global_finite_profile_bound {τ : Type*} (T : Finset τ)
    (F : τ → Space → ℂ) (D : τ → Space → ℝ) (C : τ → ℝ) (K : ℝ)
    (hF : ∀ r ∈ T, Continuous (F r)) (hD : ∀ r ∈ T, ∀ y, 0≤D r y)
    (hC : ∀ r ∈ T, 0≤C r) (hK : 0≤K)
    (hbound : ∀ r ∈ T, l3 (F r) volume ≤ ENNReal.ofReal (C r*K)*
      (∫⁻ y, (ENNReal.ofReal (D r y))^(3/2:ℝ))^(1/3:ℝ)) :
    l3 (fun y => ∑ r ∈ T, F r y) volume ≤ ENNReal.ofReal ((∑ r ∈ T, C r)*K)*
      (∫⁻ y, (ENNReal.ofReal (∑ r ∈ T, D r y))^(3/2:ℝ))^(1/3:ℝ) := by
  have hsum : l3 (fun y => ∑ r ∈ T, F r y) volume≤∑ r ∈ T, l3 (F r) volume := by
    have hh := eLpNorm_sum_le (fun r hr => (hF r hr).aestronglyMeasurable
      (μ := (volume : Measure Space))) (by norm_num : (1:ℝ≥0∞)≤3)
    have he : (∑ r ∈ T, F r)=(fun y => ∑ r ∈ T, F r y) := by ext y; simp
    rwa [he] at hh
  calc
    _ ≤ ∑ r ∈ T, ENNReal.ofReal (C r*K)*
        (∫⁻ y, (ENNReal.ofReal (∑ q ∈ T, D q y))^(3/2:ℝ))^(1/3:ℝ) := by
      apply hsum.trans
      apply Finset.sum_le_sum
      intro r hr
      apply (hbound r hr).trans
      apply mul_le_mul_left'
      apply ENNReal.rpow_le_rpow _ (by norm_num)
      apply lintegral_mono
      intro y
      apply ENNReal.rpow_le_rpow _ (by norm_num)
      exact ENNReal.ofReal_le_ofReal (Finset.single_le_sum (fun q hq => hD q hq y) hr)
    _ = _ := by
      rw [← Finset.sum_mul,← ENNReal.ofReal_sum_of_nonneg (fun r hr => mul_nonneg (hC r hr) hK),
        Finset.sum_mul]

end EllipticSquareFunction
