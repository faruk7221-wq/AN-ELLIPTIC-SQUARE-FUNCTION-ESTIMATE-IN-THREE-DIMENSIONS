import EllipticSquareFunction.UniformSamplingExpansion

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

abbrev EuclideanThree := EuclideanSpace ℝ (Fin 3)

/-- A linear coordinate change, with the physical product norm retained on Space. -/
def spaceEuclideanEquiv : EuclideanThree ≃L[ℝ] Space :=
  LinearEquiv.toContinuousLinearEquiv
  { toFun := fun x => ((WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => x i.succ),x 0)
    invFun := fun y => (WithLp.equiv 2 (Fin 3 → ℝ)).symm (Fin.cons y.2 (fun i => y.1 i))
    left_inv := by
      intro x
      ext i
      refine Fin.cases ?_ (fun j => ?_) i <;> simp
    right_inv := by
      intro y
      apply Prod.ext
      · ext i
        simp
      · simp
    map_add' := by
      intro x y
      apply Prod.ext
      · ext i
        simp
      · rfl
    map_smul' := by
      intro c x
      apply Prod.ext
      · ext i
        simp
      · rfl }

theorem spaceEuclideanEquiv_coordinates (x : EuclideanThree) :
    spaceEuclideanEquiv x=spaceCoordinateEquiv ((EuclideanSpace.measurableEquiv (Fin 3)) x) := by
  rw [spaceCoordinateEquiv_apply]
  rfl

theorem measurePreserving_spaceEuclideanEquiv : MeasurePreserving spaceEuclideanEquiv := by
  have hh := measurePreserving_spaceCoordinateEquiv.comp
    (EuclideanSpace.volume_preserving_measurableEquiv (Fin 3))
  simpa only [Function.comp_def,← spaceEuclideanEquiv_coordinates] using hh

theorem integral_space_euclidean (f : Space → ℂ) :
    (∫ x : EuclideanThree, f (spaceEuclideanEquiv x))=∫ y : Space, f y :=
  measurePreserving_spaceEuclideanEquiv.integral_comp
    spaceEuclideanEquiv.toHomeomorph.measurableEmbedding f

theorem spaceEuclideanEquiv_pair (x z : EuclideanThree) :
    spacePair (spaceEuclideanEquiv x) (spaceEuclideanEquiv z)=@inner ℝ EuclideanThree _ x z := by
  change @inner ℝ Plane _ ((WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => x i.succ))
    ((WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => z i.succ))+x 0*z 0=_
  simp only [PiLp.inner_apply,WithLp.equiv_symm_pi_apply,RCLike.inner_apply,conj_trivial]
  rw [Fin.sum_univ_succ (fun i : Fin 3 => z i*x i)]
  ring

/-- The explicitly defined Fourier integral agrees with Mathlib's transform. -/
theorem fourierTransform_spaceEuclidean (f : Space → ℂ) (z : EuclideanThree) :
    fourierTransform f (spaceEuclideanEquiv z)=
      Real.fourierIntegral (fun x : EuclideanThree => f (spaceEuclideanEquiv x)) z := by
  change (∫ y : Space, f y*oscillation (-spacePair y (spaceEuclideanEquiv z)))=_
  rw [← integral_space_euclidean (fun y => f y*oscillation (-spacePair y (spaceEuclideanEquiv z)))]
  rw [Real.fourierIntegral_eq']
  apply integral_congr_ae
  filter_upwards with x
  rw [spaceEuclideanEquiv_pair]
  simp only [oscillation,smul_eq_mul]
  have he : (2*Real.pi*(-@inner ℝ EuclideanThree _ x z)) = -2*Real.pi*@inner ℝ EuclideanThree _ x z := by ring
  rw [he,mul_comm]

theorem inverseSpaceTransform_spaceEuclidean (f : Space → ℂ) (z : EuclideanThree) :
    inverseSpaceTransform f (spaceEuclideanEquiv z)=
      Real.fourierIntegralInv (fun x : EuclideanThree => f (spaceEuclideanEquiv x)) z := by
  change (∫ y : Space, f y*oscillation (spacePair (spaceEuclideanEquiv z) y))=_
  rw [← integral_space_euclidean (fun y => f y*oscillation (spacePair (spaceEuclideanEquiv z) y))]
  rw [Real.fourierIntegralInv_eq']
  apply integral_congr_ae
  filter_upwards with x
  rw [spaceEuclideanEquiv_pair,real_inner_comm z x]
  simp only [oscillation,smul_eq_mul,mul_comm]

/-- Fourier inversion for the article's physical Schwartz functions. -/
theorem space_fourier_inversion (f : SchwartzMap Space ℂ) (y : Space) :
    inverseSpaceTransform (fourierTransform f) y=f y := by
  let g := SchwartzMap.compCLMOfContinuousLinearEquiv ℂ spaceEuclideanEquiv f
  have hg : (g : EuclideanThree → ℂ)=fun x => f (spaceEuclideanEquiv x) := rfl
  have hi := g.continuous.fourier_inversion g.integrable
    (SchwartzMap.fourierTransformCLM ℂ g).integrable
  have hy : spaceEuclideanEquiv (spaceEuclideanEquiv.symm y)=y := spaceEuclideanEquiv.apply_symm_apply y
  rw [← hy,inverseSpaceTransform_spaceEuclidean]
  simp_rw [fourierTransform_spaceEuclidean]
  exact congrFun hi (spaceEuclideanEquiv.symm y)

theorem continuous_fourierTransform_schwartz (f : SchwartzMap Space ℂ) :
    Continuous (fourierTransform f) := by
  let g := SchwartzMap.compCLMOfContinuousLinearEquiv ℂ spaceEuclideanEquiv f
  have he : fourierTransform f=fun y => (SchwartzMap.fourierTransformCLM ℂ g)
      (spaceEuclideanEquiv.symm y) := by
    funext y
    have hh := fourierTransform_spaceEuclidean f (spaceEuclideanEquiv.symm y)
    simpa only [spaceEuclideanEquiv.apply_symm_apply] using hh
  rw [he]
  exact (SchwartzMap.fourierTransformCLM ℂ g).continuous.comp spaceEuclideanEquiv.symm.continuous

end EllipticSquareFunction
