import EllipticSquareFunction.ImmersionGraphConstruction

noncomputable section
open scoped Topology
namespace EllipticSquareFunction

/-- A definite normal Hessian; either local orientation is allowed. -/
def DefiniteNormalHessian (F : Plane → Space) (N : Space) (a : Plane) : Prop :=
  (∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ (normalHeight F N)) a v v) ∨
  (∀ v : Plane, v ≠ 0 → fderiv ℝ (fderiv ℝ (normalHeight F N)) a v v < 0)

/-- Choose the sign of the local normal; no global orientation is needed. -/
theorem positive_normal_of_definite {F : Plane → Space} {a : Plane}
    (hF : ContDiffAt ℝ 2 F a) (N : Space) (hN : N ≠ 0)
    (horth : ∀ v, spacePair N (fderiv ℝ F a v)=0)
    (hdef : DefiniteNormalHessian F N a) :
    ∃ M : Space, M ≠ 0 ∧ (∀ v, spacePair M (fderiv ℝ F a v)=0) ∧
      ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ (normalHeight F M)) a v v := by
  rcases hdef with hp | hn
  · exact ⟨N,hN,horth,hp⟩
  · refine ⟨-N,neg_ne_zero.mpr hN,?_,?_⟩
    · intro v
      rw [spacePair_neg_left,horth,neg_zero]
    · intro v hv
      have he : normalHeight F (-N) = fun b => (-1 : ℝ)*normalHeight F N b := by
        funext b
        simp [normalHeight,spacePair,inner_neg_left]
        ring
      have hh : ContDiffAt ℝ 2 (normalHeight F N) a :=
        (spacePairLinear N).toContinuousLinearMap.contDiff.contDiffAt.comp a hF
      rw [he,hessian_const_smul hh]
      linarith [hn v hv]

/-- Local embedded smooth extensions of an elliptic surface. The carrier
may be any subset of each extended patch, so smooth boundary portions are
allowed. Smoothness, immersion, embeddedness, and definite curvature are
explicit; graph coordinates and ellipticity constants are not assumed. -/
def LocalEllipticSurfaceExtensions (carrier : Set Space) : Prop :=
  ∀ p ∈ carrier, ∃ (F : Plane → Space) (U : Set Plane) (a : Plane)
      (W : Set Space) (N : Space),
    IsOpen U ∧ a ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
    Topology.IsEmbedding (fun b : U => F b) ∧ F a=p ∧
    IsOpen W ∧ p ∈ W ∧ carrier ∩ W ⊆ F '' U ∧
    Function.Injective (fderiv ℝ F a) ∧ N ≠ 0 ∧
    (∀ v, spacePair N (fderiv ℝ F a v)=0) ∧ DefiniteNormalHessian F N a

/-- Restrict an embedded parametrization to any smaller open parameter
neighborhood by shrinking an ambient neighborhood. -/
theorem embedded_patch_shrink {F : Plane → Space} {U V : Set Plane} {a : Plane}
    (hemb : Topology.IsEmbedding (fun b : U => F b)) (ha : a ∈ U)
    (hV : IsOpen V) (haV : a ∈ V) :
    ∃ W : Set Space, IsOpen W ∧ F a ∈ W ∧
      ∀ b ∈ U, F b ∈ W → b ∈ V := by
  have hs : IsOpen ((Subtype.val : U → Plane) ⁻¹' V) := hV.preimage continuous_subtype_val
  obtain ⟨W,hW,he⟩ := hemb.isInducing.isOpen_iff.mp hs
  refine ⟨W,hW,?_,?_⟩
  · have hm : (⟨a,ha⟩ : U) ∈ (Subtype.val : U → Plane) ⁻¹' V := haV
    rw [← he] at hm
    exact hm
  · intro b hb hFb
    have hm : (⟨b,hb⟩ : U) ∈ (fun c : U => F c) ⁻¹' W := hFb
    rw [he] at hm
    exact hm

/-- All local positive graph hypotheses are derived from embedded elliptic
surface extensions, using the inverse function theorem. -/
theorem positive_graph_extensions_of_embedded_surface {carrier : Set Space}
    (hsurface : LocalEllipticSurfaceExtensions carrier) : LocalPositiveGraphExtensions carrier := by
  intro p hp
  obtain ⟨F,U,a,W,N,hU,ha,hF,hemb,hFa,hW,hpW,hcover,hD,hN,horth,hdef⟩ := hsurface p hp
  obtain ⟨M,hM,hMort,hMpos⟩ := positive_normal_of_definite
    ((hF.contDiffAt (hU.mem_nhds ha)).of_le (by norm_cast)) N hN horth hdef
  obtain ⟨A,e,φ,hae,heU,hφ,hpos,hgraph⟩ := positive_graph_of_immersion
    hU ha hF hD M hM hMort hMpos
  obtain ⟨W',hW',haW',hshrink⟩ := embedded_patch_shrink hemb ha e.open_source hae
  refine ⟨W ∩ W',A,φ,e.target,hW.inter hW',⟨hpW,by simpa only [hFa] using haW'⟩,
    e.open_target,hφ,by simpa only [hFa] using hpos,?_⟩
  intro q hq
  obtain ⟨b,hb,hFb⟩ := hcover ⟨hq.1,hq.2.1⟩
  have hbs := hshrink b hb (by simpa only [hFb] using hq.2.2)
  simpa only [hFb] using hgraph b hbs

/-- Surface estimate with graph construction discharged. The three external
analytic input propositions remain the hypotheses of the article. -/
theorem embedded_surface_reverse_square_function (S : SurfaceSetup)
    (hsurface : LocalEllipticSurfaceExtensions S.carrier)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    SurfaceReverseSquareFunction S :=
  surface_reverse_square_function_of_positive_extensions S
    (positive_graph_extensions_of_embedded_surface hsurface) hplacement hnikodym hdiscrete

end EllipticSquareFunction
