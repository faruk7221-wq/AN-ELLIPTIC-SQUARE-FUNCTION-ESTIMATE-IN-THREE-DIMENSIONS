import EllipticSquareFunction.LpReduction

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction

/-- Positive Hölder at the conjugate exponents 3/2 and 3. -/
theorem positive_holder_three_halves {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f g : α → ℝ≥0∞)
    (hf : AEMeasurable f μ) (hg : AEMeasurable g μ) :
    (∫⁻ x, f x*g x ∂μ) ≤ eLpNorm f (3/2) μ*eLpNorm g 3 μ := by
  have hh := ENNReal.lintegral_mul_le_Lp_mul_Lq μ
    (Real.holderConjugate_iff.mpr (by norm_num : 1<(3/2:ℝ) ∧ (3/2:ℝ)⁻¹+(3:ℝ)⁻¹=1)) hf hg
  simpa only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3/2:ℝ≥0∞)≠0)
    (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne, eLpNorm_eq_lintegral_rpow_enorm
    (by norm_num : (3:ℝ≥0∞)≠0) (by norm_num : (3:ℝ≥0∞)≠⊤),
    ENNReal.toReal_div, ENNReal.toReal_ofNat, enorm_eq_self, Pi.mul_apply] using hh

/-- Nonnegative real and extended-real versions have the same Lp norm. -/
theorem eLpNorm_ofReal_nonneg {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f : α → ℝ) (hf : ∀ x, 0≤f x) (p : ℝ≥0∞) :
    eLpNorm (fun x => ENNReal.ofReal (f x)) p μ=eLpNorm f p μ := by
  apply eLpNorm_congr_enorm_ae
  filter_upwards with x
  simp only [enorm_eq_self, ← ofReal_norm_eq_enorm, Real.norm_eq_abs, abs_of_nonneg (hf x)]

/-- The square-root dual test has exactly the conjugate integrability. -/
theorem memLp_sqrt_of_nonneg {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f : α → ℝ) (hf : ∀ x, 0≤f x)
    (hm : Measurable f) (hlp : MemLp f (3/2) μ) :
    MemLp (fun x => Real.sqrt (f x)) 3 μ := by
  refine ⟨hm.sqrt.aestronglyMeasurable, ?_⟩
  rw [eLpNorm_sqrt μ f hf]
  exact ENNReal.rpow_lt_top_of_nonneg (by norm_num) hlp.2.ne

/-- Pairing a density with its square root gives its 3/2 norm to the 3/2 power. -/
theorem lintegral_self_sqrt {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f : α → ℝ) (hf : ∀ x, 0≤f x) :
    (∫⁻ x, ENNReal.ofReal (f x)*ENNReal.ofReal (Real.sqrt (f x)) ∂μ)=
      eLpNorm f (3/2) μ^(3/2:ℝ) := by
  rw [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3/2:ℝ≥0∞)≠0)
    (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne, ← ENNReal.rpow_mul]
  norm_num only [ENNReal.toReal_div, ENNReal.toReal_ofNat, one_div, inv_div,
    div_mul_div_cancel, ENNReal.rpow_one]
  apply lintegral_congr
  intro x
  rw [← ofReal_norm_eq_enorm, Real.norm_eq_abs, abs_of_nonneg (hf x), Real.sqrt_eq_rpow,
    ← ENNReal.ofReal_rpow_of_nonneg (hf x) (by norm_num)]
  conv_lhs => lhs; rw [← ENNReal.rpow_one (ENNReal.ofReal (f x))]
  rw [← ENNReal.rpow_add_of_nonneg _ _ (by norm_num) (by norm_num)]
  norm_num

/-- A bound against every nonnegative L3 test gives the L^(3/2) bound.
The density's finiteness is explicit and is used only for cancellation. -/
theorem lThreeHalves_le_of_positive_tests {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f : α → ℝ) (hf : ∀ x, 0≤f x)
    (hm : Measurable f) (hlp : MemLp f (3/2) μ) (B : ℝ≥0∞)
    (htest : ∀ h : α → ℝ, (∀ x, 0≤h x) → Measurable h → MemLp h 3 μ →
      (∫⁻ x, ENNReal.ofReal (f x)*ENNReal.ofReal (h x) ∂μ) ≤ B*eLpNorm h 3 μ) :
    eLpNorm f (3/2) μ≤B := by
  have ht := htest (fun x => Real.sqrt (f x)) (fun x => Real.sqrt_nonneg _)
    hm.sqrt (memLp_sqrt_of_nonneg μ f hf hm hlp)
  rw [lintegral_self_sqrt μ f hf, eLpNorm_sqrt μ f hf] at ht
  by_cases hz : eLpNorm f (3/2) μ=0
  · simp [hz]
  have he : (3/2:ℝ)=1+1/2 := by norm_num
  rw [he,ENNReal.rpow_add_of_nonneg _ _ (by norm_num) (by norm_num),ENNReal.rpow_one] at ht
  exact (ENNReal.mul_le_mul_right
    (fun h => hz ((ENNReal.rpow_eq_zero_iff_of_pos (by norm_num : (0:ℝ)<1/2)).mp h))
    (ENNReal.rpow_ne_top_of_nonneg (by norm_num) hlp.2.ne)).mp ht

end EllipticSquareFunction
