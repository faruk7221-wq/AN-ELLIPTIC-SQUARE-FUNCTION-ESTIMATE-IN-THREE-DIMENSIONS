import EllipticSquareFunction.PropositionTwo
import EllipticSquareFunction.EnlargedSetup

/-! Finite-profile Proposition 2 with an actual enlarged setup. -/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem proposition_two_enlarged_setup {ι : Type*} {n : ℕ}
    (T₀ : DiscreteSetup) (hphase : ContinuedPhase T₀.φ)
    (b : Fin n → Plane → ℂ) (hb : ∀ r, ContDiff ℝ (⊤ : ℕ∞) (b r))
    (hbs : ∀ r, HasCompactSupport (b r))
    {c σ F : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F)
    (M : ℝ) (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=T₀.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      T₀.frequencyBound≤S.frequencyBound ∧ T₀.C₁≤S.C₁ ∧ T₀.C₂≤S.C₂ ∧
      (DiscreteDensityInput S →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
        ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ d : Fin n → FinitePacketArray ι,
          (∀ r, SeparatedPacketArray (d r) ((2:ℝ)^j) c σ F) →
          l3 (fun y => ∑ r, arrayPacketSum (d r) T₀.φ (b r) ((2:ℝ)^j) y)
            (volume.restrict (timeSlab (((2:ℝ)^j)^2))) ≤
          ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
            densityCubeRoot (fun y => ∑ r, arraySpatialDensity (d r) T₀.φ ((2:ℝ)^j) M y)
              (((2:ℝ)^j)^2)) := by
  classical
  have hsing (r : Fin n) := global_packets_uniform_setup_margins (ι := ι)
    T₀ hphase (b r) (hb r) (hbs r) hc hσ hF M hM
  choose A Z hA hZ hsing using hsing
  let Fmax := ∑ r, (F+Z r)
  let Amax := ∑ r, (A r+1)
  have hfreq (r : Fin n) : F+Z r≤Fmax :=
    Finset.single_le_sum (fun q (_ : q∈(Finset.univ : Finset (Fin n))) =>
      (by linarith [hZ q] : 0≤F+Z q)) (Finset.mem_univ r)
  have hpos (r : Fin n) : A r+1≤Amax :=
    Finset.single_le_sum (fun q (_ : q∈(Finset.univ : Finset (Fin n))) =>
      (by linarith [hA q] : 0≤A q+1)) (Finset.mem_univ r)
  let S := enlargeSetup T₀ Fmax Amax 3
  refine ⟨S,rfl,rfl,rfl,le_max_left _ _,le_max_left _ _,le_max_left _ _,?_⟩
  intro hinput
  have hφ : ContDiff ℝ (⊤ : ℕ∞) T₀.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩
    exact hφ
  apply uniform_finite_profiles_of_single T₀.φ hφ.continuous b (fun r => (hb r).continuous)
    hbs c σ F M
  intro r
  obtain ⟨C,hC,hbound⟩ := hsing r S rfl rfl hinput (le_max_right _ _)
    ((hpos r).trans (le_max_right _ _)) ((hfreq r).trans (le_max_right _ _))
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj d hd
  exact hbound j hj d.labels d.positions d.coefficient d.frequency d.position hd.1 hd.2.1 hd.2.2


end EllipticSquareFunction
