import EllipticSquareFunction.SeparatedPositions

/-! # Separation of independently translated rectangular lattices -/
noncomputable section
namespace EllipticSquareFunction

def rectangularLatticePoint (a : Fin 2 → ℝ) (m : IntPlane) : Plane :=
  (WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun k => a k * (m k : ℝ))

theorem rectangular_lattice_separated (a : Fin 2 → ℝ) {c : ℝ}
    (hc : 0<c) (ha : ∀ k, c≤a k) {p q : IntPlane} (hpq : p≠q) :
    c≤‖rectangularLatticePoint a p-rectangularLatticePoint a q‖ := by
  have hex : ∃ k, p k≠q k := by
    by_contra h
    push_neg at h
    exact hpq (funext h)
  obtain ⟨k,hk⟩ := hex
  have hi : (1:ℤ)≤|p k-q k| := by
    have hh : (0:ℤ) < |p k-q k| := abs_pos.mpr (sub_ne_zero.mpr hk)
    omega
  have hi' : (1:ℝ)≤|(p k:ℝ)-(q k:ℝ)| := by exact_mod_cast hi
  have hh := PiLp.norm_apply_le (rectangularLatticePoint a p-rectangularLatticePoint a q) k
  have ha0 : 0<a k := hc.trans_le (ha k)
  have hcoord : ‖(rectangularLatticePoint a p-rectangularLatticePoint a q) k‖ =
      a k * |(p k:ℝ)-(q k:ℝ)| := by
    simp only [rectangularLatticePoint,PiLp.sub_apply,WithLp.equiv_symm_pi_apply,Real.norm_eq_abs]
    rw [← mul_sub,abs_mul,abs_of_pos ha0]
  rw [hcoord] at hh
  nlinarith [ha k]

/-- The separated-family theorem allows a different lattice and translate
for each frequency; neither affects this lower separation bound. -/
theorem translated_rectangular_positions_separated (a : Fin 2 → ℝ) {c N : ℝ}
    (hc : 0<c) (hN : 0<N) (ha : ∀ k, c≤a k) (r : Plane)
    {p q : IntPlane} (hpq : p≠q) :
    c*N≤‖(r+N • rectangularLatticePoint a p)-(r+N • rectangularLatticePoint a q)‖ := by
  rw [add_sub_add_left_eq_sub,← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos hN]
  have hh := mul_le_mul_of_nonneg_left (rectangular_lattice_separated a hc ha hpq) hN.le
  simpa only [mul_comm] using hh

end EllipticSquareFunction
