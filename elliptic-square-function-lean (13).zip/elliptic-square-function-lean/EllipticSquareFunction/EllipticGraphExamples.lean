import EllipticSquareFunction.EuclideanGraphGeometry
import EllipticSquareFunction.SurfaceWithBoundary
import EllipticSquareFunction.ArticleMainTheorem

noncomputable section
namespace EllipticSquareFunction

/-- The geometric extension hypotheses hold for every portion of a smooth
positive-Hessian graph. This does not require a regular boundary of K. -/
theorem euclidean_positive_graph_extensions {φ : Phase} (hφ : ContDiff ℝ (⊤ : ℕ∞) φ)
    (K : Set Plane)
    (hpos : ∀ a ∈ K, ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ φ) a v v) :
    EuclideanEllipticSurfaceExtensions (euclideanGraph φ '' K) := by
  intro p hp
  obtain ⟨a,ha,rfl⟩ := hp
  refine ⟨euclideanGraph φ,Set.univ,a,Set.univ,euclideanGraphNormal φ a,
    isOpen_univ,Set.mem_univ _,(euclideanGraph_contDiff hφ).contDiffOn,
    (euclideanGraph_isEmbedding hφ.continuous).comp Topology.IsEmbedding.subtypeVal,
    rfl,isOpen_univ,Set.mem_univ _,?_,
    euclideanGraph_fderiv_injective (hφ.differentiable (by norm_cast) a),
    euclideanGraphNormal_unit φ a,
    euclideanGraphNormal_orthogonal (hφ.differentiable (by norm_cast) a),?_⟩
  · exact Set.Subset.trans Set.inter_subset_left (Set.image_mono (Set.subset_univ K))
  · left
    intro v hv
    rw [euclidean_graph_second_form (hφ.of_le (by norm_cast))]
    exact div_pos (hpos a ha v hv) (graphNormalLength_pos φ a)

theorem norm_square_hessian (a v w : Plane) :
    fderiv ℝ (fderiv ℝ (fun b : Plane => ‖b‖^2)) a v w=2* @inner ℝ Plane _ v w := by
  have he : fderiv ℝ (fun b : Plane => ‖b‖^2) = fun b => (2 : ℝ) • innerSL ℝ b := by
    funext b
    simpa only [two_smul] using (hasStrictFDerivAt_norm_sq b).hasFDerivAt.fderiv
  rw [he]
  have hd := ((innerSL ℝ (E := Plane)).hasFDerivAt (x := a)).const_smul (2 : ℝ)
  rw [hd.fderiv]
  rfl

theorem norm_square_hessian_positive (a : Plane) (v : Plane) (hv : v ≠ 0) :
    0 < fderiv ℝ (fderiv ℝ (fun b : Plane => ‖b‖^2)) a v v := by
  rw [norm_square_hessian,real_inner_self_eq_norm_sq]
  exact mul_pos (by norm_num) (sq_pos_of_pos (norm_pos_iff.mpr hv))

/-- A concrete nonvacuous family of the geometric surface hypotheses:
every paraboloid portion, including compact ones. -/
theorem paraboloid_surface_extensions (K : Set Plane) :
    EuclideanEllipticSurfaceExtensions (euclideanGraph (fun b : Plane => ‖b‖^2) '' K) :=
  euclidean_positive_graph_extensions (contDiff_norm_sq ℝ) K
    (fun a _ v hv => norm_square_hessian_positive a v hv)

/-- The complete estimate for an arbitrary compact paraboloid portion;
only the article's external input propositions are assumed. -/
theorem compact_paraboloid_estimate {K : Set Plane} (hK : IsCompact K)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (euclideanGraph (fun b : Plane => ‖b‖^2) '' K) c₀ C₀ :=
  article_extension_surface_theorem
    (hK.image (euclideanGraph_contDiff (contDiff_norm_sq ℝ (n := 1))).continuous)
    (paraboloid_surface_extensions K) hc₀ hC₀ hplacement hnikodym hdiscrete

end EllipticSquareFunction
