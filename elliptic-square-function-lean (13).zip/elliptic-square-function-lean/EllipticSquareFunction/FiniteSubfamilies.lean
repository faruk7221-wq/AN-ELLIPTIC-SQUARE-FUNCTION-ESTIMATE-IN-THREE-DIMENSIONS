import EllipticSquareFunction.FiniteChartAssembly
import EllipticSquareFunction.AffineGraphCoordinates

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

theorem squareFunction_mono_subfamily {ι : Type*} {s t : Finset ι} (hst : s ⊆ t)
    (f : ι → Space → ℂ) (y : Space) : squareFunction s f y ≤ squareFunction t f y := by
  apply Real.sqrt_le_sqrt
  exact Finset.sum_le_sum_of_subset_of_nonneg hst (fun i hi his => sq_nonneg _)

theorem l3_squareFunction_mono_subfamily {ι : Type*} {s t : Finset ι} (hst : s ⊆ t)
    (f : ι → Space → ℂ) : l3Real (squareFunction s f) ≤ l3Real (squareFunction t f) := by
  apply eLpNorm_mono
  intro y
  simp only [Real.norm_eq_abs,abs_of_nonneg (show 0 ≤ squareFunction s f y from Real.sqrt_nonneg _),
    abs_of_nonneg (show 0 ≤ squareFunction t f y from Real.sqrt_nonneg _)]
  exact squareFunction_mono_subfamily hst f y

theorem squareFunction_equiv {ι κ : Type*} [Fintype ι] [Fintype κ]
    (e : ι ≃ κ) (f : κ → Space → ℂ) :
    squareFunction Finset.univ (fun i => f (e i)) = squareFunction Finset.univ f := by
  funext y
  unfold squareFunction
  exact congrArg Real.sqrt (e.sum_comp (fun i => ‖f i y‖^2))

theorem squareFunction_subtype {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) :
    squareFunction Finset.univ (fun i : s => f i) = squareFunction s f := by
  classical
  funext y
  unfold squareFunction
  exact congrArg Real.sqrt (Finset.sum_subtype s (fun _ => Iff.rfl) (fun i => ‖f i y‖^2)).symm

/-- Reindex a finite subfamily without changing its estimate or introducing
a cardinality loss. The same constant works for every finite index type. -/
theorem reverse_square_function_finset (G : GraphSetup) (hG : ReverseSquareFunction G)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R → ∀ {ι : Type} (s : Finset ι)
      (ν : ι → Plane) (f : ι → SchwartzMap Space ℂ),
      (∀ i ∈ s, ν i ∈ G.K) →
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → G.c₀*(Real.sqrt R)⁻¹ ≤ ‖ν i-ν j‖) →
      (∀ i ∈ s, Function.support (fourierTransform (f i)) ⊆ cap G.φ (ν i) (Real.sqrt R)⁻¹ G.C₀) →
      l3 (fun y => ∑ i ∈ s, f i y) ≤ ENNReal.ofReal (C*R^ε)*
        l3Real (squareFunction s (fun i => f i)) := by
  classical
  obtain ⟨C,hC,hbound⟩ := hG ε hε
  refine ⟨C,hC,?_⟩
  intro R hR ι s ν f hν hsep hsupp
  let e := (Fintype.equivFin s).symm
  have had : AdmissibleFamily G R (fun i => ν (e i)) (fun i => f (e i)) := by
    refine ⟨fun i => hν _ (e i).property,?_,fun i => hsupp _ (e i).property⟩
    intro i j hij
    exact hsep _ (e i).property _ (e j).property (fun he => hij (e.injective (Subtype.ext he)))
  have hb := hbound R hR (Fintype.card s) _ _ had
  have hsum : (fun y => ∑ i, f (e i) y) = fun y => ∑ i ∈ s, f i y := by
    funext y
    exact (e.sum_comp (fun i : s => f i y)).trans
      (Finset.sum_subtype s (fun _ => Iff.rfl) (fun i => f i y)).symm
  have hsq : squareFunction Finset.univ (fun i => (f (e i) : Space → ℂ)) =
      squareFunction s (fun i => (f i : Space → ℂ)) := by
    exact (squareFunction_equiv e (fun i : s => (f i : Space → ℂ))).trans
      (squareFunction_subtype s (fun i => (f i : Space → ℂ)))
  simpa only [hsum,hsq] using hb

theorem reverse_square_function_affine_schwartz_iff {ι : Type*} (s : Finset ι)
    (A : Space ≃ᵃ[ℝ] Space) (f : ι → SchwartzMap Space ℂ) (C : ℝ≥0∞) :
    (l3 (fun y => ∑ i ∈ s, schwartzAffineFrequency A (f i) y) ≤
        C*l3Real (squareFunction s (fun i => schwartzAffineFrequency A (f i)))) ↔
    (l3 (fun y => ∑ i ∈ s, f i y) ≤ C*l3Real (squareFunction s (fun i => f i))) := by
  have hf (i : ι) : (schwartzAffineFrequency A (f i) : Space → ℂ) =
      modulatedLinearPullback (spaceTranspose A.linear.toContinuousLinearEquiv) (A 0) (f i) := by
    funext y
    exact schwartzModulatedLinearPullback_apply _ _ _ _
  simp_rw [hf]
  exact
    reverse_square_function_affine_norm_iff s
      (spaceTranspose A.linear.toContinuousLinearEquiv) (A 0) (fun i => (f i : Space → ℂ)) C

end EllipticSquareFunction
