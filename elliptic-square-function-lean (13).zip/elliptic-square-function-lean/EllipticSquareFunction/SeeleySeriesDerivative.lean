import EllipticSquareFunction.SeeleySeries
import Mathlib.Analysis.Calculus.SmoothSeries

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem seeley_jet_series_continuousOn (m : ℕ) {g : ℝ → E} {B : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hc : ContinuousOn g (Set.Ici 0)) :
    ContinuousOn (seeleyJetSeries m g) (Set.Iic 0) := by
  apply continuousOn_tsum _ ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k t ht => seeley_jet_term_bound m hg ht k)
  intro k
  exact (hc.comp (continuous_const.mul continuous_id).continuousOn
    (fun t ht => seeley_reflected_nonneg ht k)).const_smul _

theorem seeley_jet_term_hasDerivAt (m k : ℕ) {g g' : ℝ → E}
    (hg : ∀ s : ℝ, 0 < s → HasDerivAt g (g' s) s) {t : ℝ} (ht : t < 0) :
    HasDerivAt (fun t => (seeleyCoeff k * seeleyNode k ^ m) • g (seeleyNode k*t))
      ((seeleyCoeff k * seeleyNode k ^ (m+1)) • g' (seeleyNode k*t)) t := by
  have hs : 0 < seeleyNode k*t := mul_pos_of_neg_of_neg (seeley_node_neg k) ht
  have h := ((hg _ hs).scomp t ((hasDerivAt_id t).const_mul (seeleyNode k))).const_smul
    (seeleyCoeff k * seeleyNode k ^ m)
  simpa only [mul_one, smul_smul, pow_succ, mul_assoc] using h

/-- On the negative half-line, differentiation increases the Seeley weight
and replaces the data by its derivative. Boundedness is an explicit premise. -/
theorem seeley_jet_series_hasDerivAt (m : ℕ) {g g' : ℝ → E} {B B' : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hg' : ∀ s : ℝ, 0 ≤ s → ‖g' s‖ ≤ B')
    (hd : ∀ s : ℝ, 0 < s → HasDerivAt g (g' s) s)
    {t : ℝ} (ht : t < 0) :
    HasDerivAt (seeleyJetSeries m g) (seeleyJetSeries (m+1) g' t) t := by
  exact hasDerivAt_tsum_of_isPreconnected
    ((seeley_coeff_weighted_summable (m+1)).mul_right B') isOpen_Iio
    (convex_Iio (0 : ℝ)).isPreconnected
    (fun k s hs => seeley_jet_term_hasDerivAt m k hd hs)
    (fun k s hs => seeley_jet_term_bound (m+1) hg' (le_of_lt hs) k)
    ht (seeley_jet_series_summable m hg (le_of_lt ht)) ht

end EllipticSquareFunction
