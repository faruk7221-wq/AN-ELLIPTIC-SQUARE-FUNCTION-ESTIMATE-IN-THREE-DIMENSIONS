import EllipticSquareFunction.SeeleyCoefficientLimit
import Mathlib.Analysis.Normed.Group.Tannery

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

theorem seeley_node_power_abs (k m : ℕ) :
    |seeleyNode k ^ m| = (2 : ℝ)^(k*m) := by
  simp [seeleyNode, abs_pow, pow_mul]

theorem seeley_coeff_weighted_summable (m : ℕ) :
    Summable (fun k : ℕ => |seeleyCoeff k| * (2 : ℝ)^(k*m)) := by
  apply ((seeley_weighted_majorant_summable m).mul_left (Real.exp 4)).of_norm_bounded
  intro k
  rw [Real.norm_eq_abs, abs_of_nonneg (mul_nonneg (abs_nonneg _) (by positivity))]
  simpa only [mul_assoc] using (mul_le_mul_of_nonneg_right (seeley_coeff_bound k)
    (by positivity : 0 ≤ (2 : ℝ)^(k*m)))

theorem seeley_finite_moment_tsum (N m : ℕ) (hm : m ≤ N) :
    (∑' k : ℕ, seeleyFiniteCoeff N k * seeleyNode k ^ m) = 1 := by
  rw [tsum_eq_sum (s := Finset.range (N+1))]
  · exact seeley_finite_moment N m hm
  · intro k hk
    have hn : N < k := by simp only [Finset.mem_range] at hk; omega
    simp [seeley_finite_coeff_zero hn]

theorem seeley_moment (m : ℕ) :
    (∑' k : ℕ, seeleyCoeff k * seeleyNode k ^ m) = 1 := by
  have ht : Tendsto (fun N => ∑' k : ℕ, seeleyFiniteCoeff N k * seeleyNode k ^ m)
      atTop (𝓝 (∑' k : ℕ, seeleyCoeff k * seeleyNode k ^ m)) := by
    apply tendsto_tsum_of_dominated_convergence
      ((seeley_weighted_majorant_summable m).mul_left (Real.exp 4))
    · intro k
      exact (seeley_finite_coeff_tendsto k).mul_const _
    · apply Filter.Eventually.of_forall
      intro N k
      rw [Real.norm_eq_abs, abs_mul, seeley_node_power_abs]
      simpa only [mul_assoc] using (mul_le_mul_of_nonneg_right
        (seeley_finite_coeff_uniform_bound N k) (by positivity : 0 ≤ (2 : ℝ)^(k*m)))
  have he : (fun N => ∑' k : ℕ, seeleyFiniteCoeff N k * seeleyNode k ^ m)
      =ᶠ[atTop] (fun _ => (1 : ℝ)) := by
    filter_upwards [eventually_ge_atTop m] with N hN
    exact seeley_finite_moment_tsum N m hN
  exact tendsto_nhds_unique ht (tendsto_const_nhds.congr' he.symm)

/-- A concrete rapidly decreasing coefficient sequence with every Seeley moment.
This is the coefficient construction only, not yet the smooth extension theorem. -/
theorem seeley_coefficients_exist : ∃ a : ℕ → ℝ,
    (∀ m : ℕ, Summable (fun k : ℕ => |a k| * (2 : ℝ)^(k*m))) ∧
    (∀ m : ℕ, (∑' k : ℕ, a k * (-(2 : ℝ)^k)^m) = 1) := by
  exact ⟨seeleyCoeff, seeley_coeff_weighted_summable, seeley_moment⟩

end EllipticSquareFunction
