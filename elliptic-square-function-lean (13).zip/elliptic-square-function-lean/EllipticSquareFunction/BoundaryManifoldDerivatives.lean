import EllipticSquareFunction.SmoothExtensionDerivatives
import EllipticSquareFunction.ManifoldDerivativeInterface
import Mathlib.Geometry.Manifold.Instances.Real

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
  (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]

def modelSurfaceParam (f : M → EuclideanThree) (x : M) : Plane → EuclideanThree :=
  f ∘ (extChartAt I x).symm

/-- Curvature in canonical model coordinates, computed by derivatives
within the chart target. This does not choose a smooth extension. -/
def modelSecondForm (f : M → EuclideanThree) (x : M) (N : EuclideanThree)
    (v w : Plane) : ℝ :=
  @inner ℝ EuclideanThree _ N
    (fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam I f x) (extChartAt I x).target)
      (extChartAt I x).target (extChartAt I x x) v w)

def ModelDefiniteSecondForm (f : M → EuclideanThree) (x : M) (N : EuclideanThree) : Prop :=
  (∀ v : Plane, v ≠ 0 → 0 < modelSecondForm I f x N v v) ∨
  (∀ v : Plane, v ≠ 0 → modelSecondForm I f x N v v < 0)

theorem model_second_form_eq_extension {f : M → EuclideanThree} (x : M)
    {F : Plane → EuclideanThree} {U : Set Plane}
    (hU : IsOpen U) (ha : extChartAt I x x ∈ U) (hF : ContDiffOn ℝ 2 F U)
    (heq : Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target))
    (N : EuclideanThree) (v w : Plane) :
    modelSecondForm I f x N v w = euclideanSecondFundamentalForm F N (extChartAt I x x) v w := by
  unfold modelSecondForm euclideanSecondFundamentalForm
  rw [extension_second_fderivWithin hU ha (mem_extChartAt_target x)
    (uniqueDiffOn_extChartAt_target x) hF heq]

theorem model_definite_second_form_iff_extension {f : M → EuclideanThree} (x : M)
    {F : Plane → EuclideanThree} {U : Set Plane}
    (hU : IsOpen U) (ha : extChartAt I x x ∈ U) (hF : ContDiffOn ℝ 2 F U)
    (heq : Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target))
    (N : EuclideanThree) :
    ModelDefiniteSecondForm I f x N ↔ EuclideanDefiniteSecondForm F N (extChartAt I x x) := by
  unfold ModelDefiniteSecondForm EuclideanDefiniteSecondForm
  simp only [model_second_form_eq_extension I x hU ha hF heq]

theorem model_mfderiv_eq_extension {f : M → EuclideanThree} (x : M)
    (hf : MDifferentiableAt I 𝓘(ℝ, EuclideanThree) f x)
    {F : Plane → EuclideanThree} {U : Set Plane}
    (hU : IsOpen U) (ha : extChartAt I x x ∈ U) (hF : DifferentiableAt ℝ F (extChartAt I x x))
    (heq : Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target)) :
    mfderiv I 𝓘(ℝ, EuclideanThree) f x = fderiv ℝ F (extChartAt I x x) := by
  rw [hf.mfderiv]
  simp only [writtenInExtChartAt,mfld_simps]
  change fderivWithin ℝ (modelSurfaceParam I f x) (Set.range I) (extChartAt I x x)=_
  rw [← fderivWithin_congr_set (extChartAt_target_eventuallyEq (I := I) (x := x))]
  exact extension_fderivWithin hU ha (mem_extChartAt_target x)
    (uniqueDiffWithinAt_extChartAt_target x) hF heq

end EllipticSquareFunction
