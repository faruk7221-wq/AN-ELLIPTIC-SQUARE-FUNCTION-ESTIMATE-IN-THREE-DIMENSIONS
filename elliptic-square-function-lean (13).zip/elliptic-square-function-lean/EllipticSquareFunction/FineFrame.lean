import EllipticSquareFunction.FrequencyPacking
import EllipticSquareFunction.CanonicalFrame

/-! # Exact fine-frame synthesis at scale N

These identities include the normalization D⁻² multiplying the analyzed
coefficients when synthesis is written in terms of the free packets (4.1).
-/
noncomputable section
open MeasureTheory Set
open scoped BigOperators Pointwise
namespace EllipticSquareFunction

def fineWindow (S : DiscreteSetup) (N : ℝ) (m : IntPlane) (ξ : Plane) : ℝ :=
  S.χ (N • (ξ - latticePoint N⁻¹ m))

theorem fineWindow_eq (S : DiscreteSetup) {N : ℝ} (hN : 0 < N)
    (m : IntPlane) (ξ : Plane) :
    fineWindow S N m ξ = S.χ (N • ξ - latticePoint 1 m) := by
  rw [fineWindow, smul_sub, ← latticePoint_mul, mul_inv_cancel₀ hN.ne']

theorem fineWindow_continuous (S : DiscreteSetup) (N : ℝ) (m : IntPlane) :
    Continuous (fineWindow S N m) :=
  S.χ_smooth.continuous.comp (continuous_const.smul (continuous_id.sub continuous_const))

theorem fineWindow_support_box (S : DiscreteSetup) {N : ℝ} (hN : 0 < N) (m : IntPlane) :
    Function.support (fineWindow S N m) ⊆
      euclideanBox (canonicalBoxOrigin S m) ((S.D : ℝ)/N) := by
  intro ξ hξ
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have hc (i : Fin 2) : |N * ξ i - (m i : ℝ)| < (S.D : ℝ)/2 := by
    have hs := S.χ_support (N • ξ - latticePoint 1 m)
      (subset_closure (by
        change S.χ (N • ξ - latticePoint 1 m) ≠ 0
        change fineWindow S N m ξ ≠ 0 at hξ
        rwa [fineWindow_eq S hN] at hξ)) i
    simpa only [PiLp.sub_apply, PiLp.smul_apply, smul_eq_mul,
      latticePoint, WithLp.equiv_symm_pi_apply, one_mul] using hs
  change (WithLp.equiv 2 (Fin 2 → ℝ)) ξ ∈ ((S.D : ℝ)/N) • unitBox (canonicalBoxOrigin S m)
  refine ⟨fun i => N * ξ i / (S.D : ℝ), ?_, ?_⟩
  · intro i _
    change ((m i : ℝ) - (S.D : ℝ)/2)/S.D < N*ξ i/S.D ∧
      N*ξ i/S.D ≤ ((m i : ℝ) - (S.D : ℝ)/2)/S.D + 1
    constructor
    · apply (div_lt_div_iff_of_pos_right hD).mpr
      linarith [(abs_lt.mp (hc i)).1]
    · calc
        N*ξ i/S.D ≤ ((m i : ℝ)+(S.D : ℝ)/2)/S.D := by
          apply div_le_div_of_nonneg_right _ hD.le
          linarith [(abs_lt.mp (hc i)).2]
        _ = _ := by field_simp; ring
  · funext i
    simp only [Pi.smul_apply, smul_eq_mul, WithLp.equiv_pi_apply]
    field_simp
    ring

/-- Compact frequency data admit a finite selection of fine windows. -/
theorem fine_finite_partition (S : DiscreteSetup) {N : ℝ} (hN : 0 < N)
    {K : Set Plane} (hK : IsCompact K) :
    ∃ q : Finset IntPlane,
      (∀ ξ ∈ K, ∑ m ∈ q, fineWindow S N m ξ ^ 2 = 1) ∧
      (∀ m ∉ q, ∀ ξ ∈ K, fineWindow S N m ξ = 0) := by
  obtain ⟨q, hp, hz⟩ := canonical_finite_partition S
    (hK.image (show Continuous (fun ξ : Plane => N • ξ) from
      continuous_const.smul continuous_id))
  refine ⟨q, ?_, ?_⟩
  · intro ξ hξ
    simpa only [fineWindow_eq S hN] using hp (N • ξ) ⟨ξ,hξ,rfl⟩
  · intro m hm ξ hξ
    simpa only [fineWindow_eq S hN] using hz m hm (N • ξ) ⟨ξ,hξ,rfl⟩

/-- Window synthesis on the fine scale, written directly as a sum of the
free packets. This proves the factor D⁻² rather than assuming it. -/
theorem fine_frame_reconstruction (S : DiscreteSetup) (hφ : Continuous S.φ)
    {N : ℝ} (hN : 0 < N) (g : Plane → ℂ) (hg : Continuous g)
    (hgs : HasCompactSupport g) (q : Finset IntPlane)
    (hp : ∀ ξ ∈ Function.support g, ∑ m ∈ q, fineWindow S N m ξ ^ 2 = 1)
    (y : Space) :
    HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
      ((∫ ξ, g ξ * (fineWindow S N m ξ : ℂ) *
        oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ)) *
      freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
        (latticePoint (N/S.D) n) y))
      (∫ ξ, g ξ * oscillation (@inner ℝ Plane _ y.1 ξ + y.2*S.φ ξ)) := by
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  have h := finite_window_reconstruction q S.φ hφ g hg hgs (fineWindow S N)
    (fun m _ => fineWindow_continuous S N m) (canonicalBoxOrigin S)
    (div_pos hD hN) (fun m _ => fineWindow_support_box S hN m) hp y.1 0 y.2
  have hlat : ((S.D : ℝ)/N)⁻¹ = N/S.D := by field_simp
  have hc (m n : IntPlane) :
      windowCoefficient S.φ g (fineWindow S N m) (latticePoint (N/S.D) n) 0 =
        ∫ ξ, g ξ * (fineWindow S N m ξ : ℂ) *
          oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ) := by
    simp [windowCoefficient]
  have hk (m n : IntPlane) :
      freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
        (latticePoint (N/S.D) n) y =
      (N^2 : ℝ) • windowKernel S.φ (fineWindow S N m)
        (y.1-latticePoint (N/S.D) n) y.2 := by
    rfl
  have hn (n : IntPlane) :
      (∑ m ∈ q, (((S.D : ℝ)/N)^2)⁻¹ •
        (windowCoefficient S.φ g (fineWindow S N m) (latticePoint (N/S.D) n) 0 *
          windowKernel S.φ (fineWindow S N m) (y.1-latticePoint (N/S.D) n) y.2)) =
      ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
        ((∫ ξ, g ξ * (fineWindow S N m ξ : ℂ) *
          oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ)) *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
          (latticePoint (N/S.D) n) y) := by
    apply Finset.sum_congr rfl
    intro m hm
    rw [hc, hk, mul_smul_comm, smul_smul]
    congr 1
    field_simp
  simpa only [hlat, hn, zero_add] using h

/-- The finite profile datum is continuous. -/
theorem profileFrequency_continuous {ι : Type*} (b : Plane → ℂ) (hb : Continuous b)
    (N : ℝ) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane) :
    Continuous (profileFrequency b N s a ν v) := by
  unfold profileFrequency
  apply Continuous.const_smul
  apply continuous_finset_sum
  intro i hi
  exact (continuous_const.mul (hb.comp
    (continuous_const.smul (continuous_id.sub continuous_const)))).mul
    (continuous_oscillation.comp (continuous_const.inner continuous_id).neg)

/-- Finite profile data have compact frequency support at every positive scale. -/
theorem profileFrequency_compact {ι : Type*} (b : Plane → ℂ) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : 0 < N) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane) :
    HasCompactSupport (profileFrequency b N s a ν v) := by
  classical
  have ht (i : ι) : HasCompactSupport (fun ξ => a i * b (N • (ξ-ν i)) *
      oscillation (-@inner ℝ Plane _ (v i) ξ)) := by
    have hb : HasCompactSupport (fun ξ => b (N • (ξ-ν i))) :=
      (hbs.comp_homeomorph (Homeomorph.smulOfNeZero N hN.ne')).comp_homeomorph
        (Homeomorph.subRight (ν i))
    exact hb.mul_left.mul_right
  have hs : HasCompactSupport (fun ξ => ∑ i ∈ s, a i * b (N • (ξ-ν i)) *
      oscillation (-@inner ℝ Plane _ (v i) ξ)) := by
    induction s using Finset.induction_on with
    | empty => simpa using (HasCompactSupport.zero : HasCompactSupport (0 : Plane → ℂ))
    | @insert i s hi ih =>
      simpa only [Finset.sum_insert hi] using (ht i).add ih
  exact hs.smul_left

/-- Extension of the frequency datum is exactly the finite sum of free
packets, with every exchange of integral and sum justified. -/
theorem profileFrequency_extension {ι : Type*} (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : 0 < N) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane) (y : Space) :
    (∫ ξ, profileFrequency b N s a ν v ξ *
      oscillation (@inner ℝ Plane _ y.1 ξ + y.2*φ ξ)) =
      ∑ i ∈ s, a i * freePacket φ b N (ν i) (v i) y := by
  have hi (i : ι) : Integrable (fun ξ => a i * b (N • (ξ-ν i)) *
      oscillation (@inner ℝ Plane _ (y.1-v i) ξ + y.2*φ ξ)) := by
    have hs : HasCompactSupport (fun ξ => b (N • (ξ-ν i))) :=
      (hbs.comp_homeomorph (Homeomorph.smulOfNeZero N hN.ne')).comp_homeomorph
        (Homeomorph.subRight (ν i))
    apply Continuous.integrable_of_hasCompactSupport _ hs.mul_left.mul_right
    exact (continuous_const.mul (hb.comp (continuous_const.smul
      (continuous_id.sub continuous_const)))).mul (continuous_oscillation.comp
        ((continuous_const.inner continuous_id).add (continuous_const.mul hφ)))
  have he (ξ : Plane) : profileFrequency b N s a ν v ξ *
      oscillation (@inner ℝ Plane _ y.1 ξ + y.2*φ ξ) =
      N^2 • ∑ i ∈ s, a i * b (N • (ξ-ν i)) *
        oscillation (@inner ℝ Plane _ (y.1-v i) ξ + y.2*φ ξ) := by
    rw [profileFrequency, smul_mul_assoc, Finset.sum_mul]
    congr 1
    apply Finset.sum_congr rfl
    intro i hi
    rw [mul_assoc, ← oscillation_add, inner_sub_left]
    congr 2
    ring
  simp_rw [he]
  rw [integral_smul, integral_finset_sum s (fun i _ => hi i), Finset.smul_sum]
  apply Finset.sum_congr rfl
  intro i hi'
  simp_rw [mul_assoc]
  rw [integral_const_mul, freePacket, Complex.real_smul]
  ring

/-- Fine-frame reconstruction of the actual finite profile family, with the
analysis coefficients identified as the window-change matrix applied to `a`.
The finite frequency selection works simultaneously for every spacetime point. -/
theorem profile_fine_frame_reconstruction {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N c : ℝ} (hN : 0 < N) (s : Finset ι) (pbox : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane) :
    ∃ q : Finset IntPlane, ∀ y : Space,
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
        (changedCoefficient b S.χ N c s pbox a ν r
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) *
          freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox, a i p *
          freePacket S.φ b N (ν i) (r + N • latticePoint c p) y) := by
  classical
  let g := profileFrequency b N (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => ν ip.1) (fun ip => r + N • latticePoint c ip.2)
  have hg : Continuous g := profileFrequency_continuous b hb N _ _ _ _
  have hgs : HasCompactSupport g := profileFrequency_compact b hbs hN _ _ _ _
  obtain ⟨q, hq, _⟩ := fine_finite_partition S hN hgs
  refine ⟨q, ?_⟩
  intro y
  have h := fine_frame_reconstruction S hφ hN g hg hgs q
    (fun ξ hξ => hq ξ (subset_closure hξ)) y
  have hcoeff (m n : IntPlane) :
      (∫ ξ, g ξ * (fineWindow S N m ξ : ℂ) *
        oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ)) =
      changedCoefficient b S.χ N c s pbox a ν r
        (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) := by
    have hm := profile_coefficient_eq_matrix b hb hbs S.χ S.χ_smooth.continuous
      hN (s ×ˢ pbox) (fun ip => a ip.1 ip.2) (fun ip => ν ip.1)
      (fun ip => r + N • latticePoint c ip.2)
      (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)
    simpa only [g, fineWindow, changedCoefficient, Finset.sum_product] using hm
  have hext := profileFrequency_extension S.φ hφ b hb hbs hN (s ×ˢ pbox)
    (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => r + N • latticePoint c ip.2) y
  change (∫ ξ, g ξ * oscillation (@inner ℝ Plane _ y.1 ξ + y.2*S.φ ξ)) = _ at hext
  simp only [Finset.sum_product] at hext
  simpa only [hcoeff, hext] using h

end EllipticSquareFunction
