import EllipticSquareFunction.PositiveLpBounds
import EllipticSquareFunction.PositiveTubeKernels

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

def normalizedTubeConvolution (r T : ℝ) (V : Plane) (h : Space → ℝ) (x : Space) : ℝ≥0∞ :=
  ∫⁻ z, ENNReal.ofReal (symmetricTubeAverageKernel r T V z)*ENNReal.ofReal |h (x+z)|

def finiteTubeAverageMax {ι : Type*} (s : Finset ι) (r T : ℝ)
    (V : ι → Plane) (h : Space → ℝ) (x : Space) : ℝ≥0∞ :=
  s.sup (fun i => normalizedTubeConvolution r T (V i) h x)

/-- Parameterized nonnegative integration makes each fixed tube convolution
measurable, even without a pointwise finiteness assertion. -/
theorem measurable_normalizedTubeConvolution (r T : ℝ) (V : Plane)
    (h : Space → ℝ) (hh : Measurable h) : Measurable (normalizedTubeConvolution r T V h) := by
  exact (((measurable_symmetricTubeAverageKernel r T V).ennreal_ofReal.comp measurable_snd).mul
    ((hh.comp (measurable_fst.add measurable_snd)).abs.ennreal_ofReal)).lintegral_prod_right

/-- Taking a finite supremum retains measurability; no measurability theorem
for the uncountable Nikodym supremum is required here. -/
theorem measurable_finiteTubeAverageMax {ι : Type*} (s : Finset ι) (r T : ℝ)
    (V : ι → Plane) (h : Space → ℝ) (hh : Measurable h) :
    Measurable (finiteTubeAverageMax s r T V h) := by
  classical
  induction s using Finset.induction_on with
  | empty => exact measurable_const
  | @insert i s hi ih =>
    unfold finiteTubeAverageMax
    simp only [Finset.sup_insert]
    exact (measurable_normalizedTubeConvolution r T (V i) h hh).sup ih

/-- One fixed-length maximal function controls the entire finite direction
family, with a constant independent of its cardinality. -/
theorem finiteTubeAverageMax_le_nikodym {ι : Type*} (s : Finset ι)
    {r T F : ℝ} (hr : 0<r) (hT : 0<T) (hrT : r≤T) (hF : 0≤F)
    (V : ι → Plane) (hV : ∀ i∈s, ‖V i‖≤F) (h : Space → ℝ) (hh : Measurable h) (x : Space) :
    finiteTubeAverageMax s r T V h x ≤ ENNReal.ofReal (2*(1+F)^3)*
      nikodym (r/(2*(1+F)*T)) (2*(1+F)*T) h x := by
  apply Finset.sup_le
  intro i hi
  exact normalized_tube_kernel_le_nikodym h hh x hr hT hrT hF (V i) (hV i hi)

/-- An actual L3 operator bound for the measurable finite tube maximum,
obtained from the unit-length external input, uniformly in cap count. -/
theorem finiteTubeAverageMax_l3_bound (hinput : NikodymInput)
    {γ : ℝ} (hγ : 0<γ) (hγ₁ : γ≤1) :
    ∃ C : ℝ, 1≤C ∧ ∀ {ι : Type*} (s : Finset ι) (r T F : ℝ),
      0<r → 0<T → r≤T → 0≤F → ∀ V : ι → Plane,
      (∀ i∈s, ‖V i‖≤F) → ∀ h : Space → ℝ, Measurable h → MemLp h 3 volume →
      eLpNorm (finiteTubeAverageMax s r T V h) 3 volume ≤
        ENNReal.ofReal ((2*(1+F)^3)*C*(r/(2*(1+F)*T))^(-γ))*eLpNorm h 3 volume := by
  obtain ⟨C,hC,hbound⟩ := nikodymInput_all_lengths hinput γ hγ hγ₁
  refine ⟨C,hC,?_⟩
  intro ι s r T F hr hT hrT hF V hV h hh hlp
  have hlen : 0<2*(1+F)*T := by positivity
  have hτ : 0<r/(2*(1+F)*T) := div_pos hr hlen
  have hτ₁ : r/(2*(1+F)*T)<1 := by
    apply (div_lt_one hlen).mpr
    nlinarith
  calc
    _ ≤ eLpNorm (fun x => ENNReal.ofReal (2*(1+F)^3)*
        nikodym (r/(2*(1+F)*T)) (2*(1+F)*T) h x) 3 volume :=
      eLpNorm_mono_enorm (fun x => finiteTubeAverageMax_le_nikodym s hr hT hrT hF V hV h hh x)
    _ = ENNReal.ofReal (2*(1+F)^3)*
        eLpNorm (nikodym (r/(2*(1+F)*T)) (2*(1+F)*T) h) 3 volume :=
      positive_l3_const_mul volume _ _ ENNReal.ofReal_ne_top
    _ ≤ ENNReal.ofReal (2*(1+F)^3)*(ENNReal.ofReal (C*(r/(2*(1+F)*T))^(-γ))*eLpNorm h 3 volume) :=
      mul_le_mul_left' (hbound _ hτ hτ₁ _ hlen h hlp) _
    _ = _ := by
      rw [← mul_assoc,← ENNReal.ofReal_mul (by positivity)]
      congr 2
      ring

end EllipticSquareFunction
