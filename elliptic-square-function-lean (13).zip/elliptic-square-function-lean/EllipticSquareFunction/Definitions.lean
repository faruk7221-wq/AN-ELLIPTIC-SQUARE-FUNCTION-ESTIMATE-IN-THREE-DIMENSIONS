import Mathlib

/-!
# Concrete analytic objects from the article

`Space` has two spatial coordinates and one time coordinate. Its product norm
is used only to give its topology; the spatial norm is Euclidean, as in the
article. Integrals use Lebesgue measure. Fourier integrals are explicit,
including the factor `2 * π` and the sign convention.

Definitions are not proofs of the estimates involving these objects.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open MeasureTheory

namespace EllipticSquareFunction

abbrev Plane := EuclideanSpace ℝ (Fin 2)
abbrev Space := Plane × ℝ
abbrev Phase := Plane → ℝ

def oscillation (t : ℝ) : ℂ := Complex.exp ((2 * Real.pi * t : ℝ) * Complex.I)

def fourierTransform (f : Space → ℂ) (ζ : Space) : ℂ :=
  ∫ y : Space, f y * oscillation (-(@inner ℝ Plane _ y.1 ζ.1 + y.2 * ζ.2))

/-- The caps in (1.2). Here `δ = R⁻¹ᐟ²`. -/
def cap (φ : Phase) (ν : Plane) (δ C₀ : ℝ) : Set Space :=
  {ζ | ‖ζ.1 - ν‖ ≤ C₀ * δ ∧ |ζ.2 - φ ζ.1| ≤ C₀ * δ ^ 2}

def velocity (φ : Phase) (ν : Plane) : Plane := gradient φ ν

/-- Equation (4.1). -/
def freePacket (φ : Phase) (b : Plane → ℂ) (N : ℝ)
    (ν v : Plane) (y : Space) : ℂ :=
  (N ^ 2 : ℝ) * ∫ ξ : Plane,
    b (N • (ξ - ν)) *
      oscillation (@inner ℝ Plane _ (y.1 - v) ξ + y.2 * φ ξ)

def bracket {E : Type*} [NormedAddCommGroup E] (u : E) : ℝ := 1 + ‖u‖

/-- The spatial weight in (4.2). -/
def spatialWeight (N M : ℝ) (V v : Plane) (y : Space) : ℝ :=
  bracket (N⁻¹ • (y.1 - v + y.2 • V)) ^ (-M)

/-- Equation (5.1), allowing any real time origin `s`. -/
def packetWeight (R M : ℝ) (V v : Plane) (s : ℝ) (y : Space) : ℝ :=
  bracket ((Real.sqrt R)⁻¹ • (y.1 - v + (y.2 - s) • V)) ^ (-M) *
    bracket ((y.2 - s) / R) ^ (-M)

/-- Equation (6.3). -/
def tubeKernel (R M : ℝ) (V : Plane) (y : Space) : ℝ :=
  (R ^ 2)⁻¹ * packetWeight R M V 0 0 y

/-- Equation (5.2) with an arbitrary time origin; `s = kR` in the unsampled case. -/
def timePacket (φ : Phase) (b : Plane → ℂ) (ψ : ℝ → ℂ) (R : ℝ)
    (ν v : Plane) (s : ℝ) (y : Space) : ℂ :=
  ψ ((y.2 - s) / R) * freePacket φ b (Real.sqrt R) ν v (y.1, y.2 - s)

def squareFunction {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) (y : Space) : ℝ :=
  Real.sqrt (∑ i ∈ s, ‖f i y‖ ^ 2)

def spatialDensity {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N M : ℝ) (y : Space) : ℝ :=
  ∑ i ∈ s, ‖a i‖ ^ 2 * spatialWeight N M (V i) (v i) y

def packetDensity {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (t₀ : ι → ℝ) (R M : ℝ) (y : Space) : ℝ :=
  ∑ i ∈ s, ‖a i‖ ^ 2 * packetWeight R M (V i) (v i) (t₀ i) y

def coreTube (N R : ℝ) (V v : Plane) : Set Space :=
  {y | y.2 ∈ Set.Icc 0 R ∧ ‖y.1 - v + y.2 • V‖ ≤ N}

def coreDensity {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) (y : Space) : ℝ :=
  ∑ i ∈ s, (coreTube N R (V i) (v i)).indicator (fun _ => ‖a i‖ ^ 2) y

def positiveConvolution (g K : Space → ℝ) (y : Space) : ℝ :=
  ∫ z : Space, g (y - z) * K z

def l3 (f : Space → ℂ) (μ : Measure Space := volume) : ℝ≥0∞ := eLpNorm f 3 μ

def l3Real (f : Space → ℝ) (μ : Measure Space := volume) : ℝ≥0∞ := eLpNorm f 3 μ

def lThreeHalves (f : Space → ℝ) (μ : Measure Space := volume) : ℝ≥0∞ :=
  eLpNorm f (3 / 2) μ

/-- A fixed geometric setup. Smoothness and curvature are recorded separately
because the conditional reductions below do not use them algebraically. -/
structure GraphSetup where
  φ : Phase
  K : Set Plane
  compact_K : IsCompact K
  c₀ : ℝ
  C₀ : ℝ
  c₀_pos : 0 < c₀
  C₀_pos : 0 < C₀

def UniformlyEllipticOn (φ : Phase) (U : Set Plane) : Prop :=
  ∃ c C : ℝ, 0 < c ∧ 0 < C ∧ ∀ ξ ∈ U, ∀ v : Plane,
    c * ‖v‖ ^ 2 ≤ fderiv ℝ (fderiv ℝ φ) ξ v v ∧
    fderiv ℝ (fderiv ℝ φ) ξ v v ≤ C * ‖v‖ ^ 2

def GraphHypotheses (G : GraphSetup) : Prop :=
  ∃ U : Set Plane, IsOpen U ∧ G.K ⊆ U ∧
    ContDiffOn ℝ (⊤ : ℕ∞) G.φ U ∧ UniformlyEllipticOn G.φ U

/-- The regularity and Fourier-support conditions on a finite family.
The empty family is permitted. No partition of unity is assumed. -/
def AdmissibleFamily (G : GraphSetup) (R : ℝ) {n : ℕ}
    (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ) : Prop :=
  (∀ i, ν i ∈ G.K) ∧
  (∀ i j, i ≠ j → G.c₀ * (Real.sqrt R)⁻¹ ≤ ‖ν i - ν j‖) ∧
  (∀ i, Function.support (fourierTransform (f i)) ⊆
    cap G.φ (ν i) (Real.sqrt R)⁻¹ G.C₀)

/-- The precise target on a fixed graph, in extended `L³` norms.
No theorem asserting this proposition is postulated in this project. -/
def ReverseSquareFunction (G : GraphSetup) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
    ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
      AdmissibleFamily G R ν f →
      l3 (fun y => ∑ i, f i y) ≤
        ENNReal.ofReal (C * R ^ ε) *
          l3Real (squareFunction Finset.univ (fun i => (f i : Space → ℂ)))

theorem bracket_pos {E : Type*} [NormedAddCommGroup E] (u : E) : 0 < bracket u := by
  unfold bracket
  positivity

theorem spatialWeight_nonneg (N M : ℝ) (V v : Plane) (y : Space) :
    0 ≤ spatialWeight N M V v y := Real.rpow_nonneg (bracket_pos _).le _

theorem packetWeight_nonneg (R M : ℝ) (V v : Plane) (s : ℝ) (y : Space) :
    0 ≤ packetWeight R M V v s y := by
  unfold packetWeight
  exact mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _)
    (Real.rpow_nonneg (bracket_pos _).le _)

theorem squareFunction_sq {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) (y : Space) :
    squareFunction s f y ^ 2 = ∑ i ∈ s, ‖f i y‖ ^ 2 := by
  exact Real.sq_sqrt (Finset.sum_nonneg (fun i _ => sq_nonneg _))

end EllipticSquareFunction
