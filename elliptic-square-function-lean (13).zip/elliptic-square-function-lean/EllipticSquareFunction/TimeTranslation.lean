import EllipticSquareFunction.GlobalPackets

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

def shiftedTimeSlab (s R : ℝ) : Set Space := {y | y.2 ∈ Icc s (s+R)}

/-- Translating the common time origin preserves the L³ norm exactly. -/
theorem time_translation_l3 (F : Space → ℂ) (hF : Continuous F) (s R : ℝ) :
    l3 (fun y : Space => F (y.1,y.2-s)) (volume.restrict (shiftedTimeSlab s R)) =
      l3 F (volume.restrict (timeSlab R)) := by
  have hm : MeasurePreserving (fun y : Space => y+(0,-s)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) 0).prod
      (measurePreserving_add_right (volume : Measure ℝ) (-s))
  have he := (Homeomorph.addRight ((0:Plane),-s)).measurableEmbedding
  have hp : (fun y : Space => y+(0,-s)) ⁻¹' timeSlab R=shiftedTimeSlab s R := by
    ext y
    simp only [timeSlab,shiftedTimeSlab,mem_preimage,mem_setOf_eq,Prod.snd_add,mem_Icc]
    constructor <;> intro h <;> constructor <;> linarith [h.1,h.2]
  have hh := eLpNorm_comp_measurePreserving
    (hF.aestronglyMeasurable : AEStronglyMeasurable F (volume.restrict (timeSlab R)))
    (hm.restrict_preimage_emb he (timeSlab R)) (p := (3:ℝ≥0∞))
  rw [hp] at hh
  simpa only [l3,Function.comp_def,Prod.add_def,add_zero,sub_eq_add_neg] using hh

theorem time_translation_densityCubeRoot (D : Space → ℝ) (s R : ℝ) :
    (∫⁻ y in shiftedTimeSlab s R, (ENNReal.ofReal (D (y.1,y.2-s)))^(3/2:ℝ))^(1/3:ℝ) =
      densityCubeRoot D R := by
  have hm : MeasurePreserving (fun y : Space => y+(0,-s)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) 0).prod
      (measurePreserving_add_right (volume : Measure ℝ) (-s))
  have he := (Homeomorph.addRight ((0:Plane),-s)).measurableEmbedding
  have hp : (fun y : Space => y+(0,-s)) ⁻¹' timeSlab R=shiftedTimeSlab s R := by
    ext y
    simp only [timeSlab,shiftedTimeSlab,mem_preimage,mem_setOf_eq,Prod.snd_add,mem_Icc]
    constructor <;> intro h <;> constructor <;> linarith [h.1,h.2]
  have hh := hm.setLIntegral_comp_preimage_emb he
    (fun y => (ENNReal.ofReal (D y))^(3/2:ℝ)) (timeSlab R)
  rw [hp] at hh
  unfold densityCubeRoot
  congr 1
  simpa only [Prod.add_def,add_zero,sub_eq_add_neg] using hh

/-- The common-time-origin assertion: both packets and their characteristic
density are translated together. This is not the later re-expansion of an
untranslated packet in a different time-slab frame. -/
theorem packet_estimate_common_time_origin {ι : Type*}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane)
    {N : ℝ} (hN : N≠0) (M C : ℝ)
    (h : l3 (fun y => ∑ i ∈ s, a i*freePacket φ b N (ν i) (v i) y)
      (volume.restrict (timeSlab (N^2))) ≤
      ENNReal.ofReal C*densityCubeRoot (spatialDensity s a (fun i => velocity φ (ν i)) v N M) (N^2))
    (t₀ : ℝ) :
    l3 (fun y => ∑ i ∈ s, a i*freePacket φ b N (ν i) (v i) (y.1,y.2-t₀))
      (volume.restrict (shiftedTimeSlab t₀ (N^2))) ≤
      ENNReal.ofReal C*(∫⁻ y in shiftedTimeSlab t₀ (N^2),
        (ENNReal.ofReal (∑ i ∈ s, ‖a i‖^2*
          bracket (N⁻¹ • (y.1-v i+(y.2-t₀) • velocity φ (ν i)))^(-M)))^(3/2:ℝ))^(1/3:ℝ) := by
  have hF : Continuous (fun y => ∑ i ∈ s, a i*freePacket φ b N (ν i) (v i) y) :=
    continuous_finset_sum s (fun i hi => continuous_const.mul
      (continuous_freePacket φ hφ b hb hbs hN _ _))
  rw [time_translation_l3 _ hF t₀ (N^2)]
  simpa only [← time_translation_densityCubeRoot
    (spatialDensity s a (fun i => velocity φ (ν i)) v N M) t₀ (N^2),
    spatialDensity,spatialWeight] using h

end EllipticSquareFunction
