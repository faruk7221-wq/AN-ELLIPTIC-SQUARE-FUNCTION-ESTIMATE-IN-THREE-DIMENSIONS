import EllipticSquareFunction.GeneralGraphLargeScale

noncomputable section
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1400000

/-- Compactness and separation give a scale-uniform cardinality bound when
the scale is restricted to a fixed bounded interval. -/
theorem bounded_scale_cardinality (G : GraphSetup) {T : ℝ} (hT : 2 ≤ T) :
    ∃ N : ℕ, ∀ R : ℝ, 2 ≤ R → R ≤ T → ∀ (n : ℕ) (ν : Fin n → Plane),
      (∀ i, ν i ∈ G.K) →
      (∀ i j, i ≠ j → G.c₀*(Real.sqrt R)⁻¹ ≤ ‖ν i-ν j‖) → n ≤ N := by
  obtain ⟨F,hF⟩ := G.compact_K.exists_bound_of_continuousOn
    (continuous_id : Continuous (id : Plane → Plane)).continuousOn
  let d := G.c₀*(Real.sqrt T)⁻¹
  have hd : 0 < d := mul_pos G.c₀_pos (inv_pos.mpr (Real.sqrt_pos.mpr (by linarith)))
  refine ⟨(integerPlaneBox ⌈(5/d)*F+4⌉₊).card,?_⟩
  intro R hR hRT n ν hν hsep
  have hδ : (Real.sqrt T)⁻¹ ≤ (Real.sqrt R)⁻¹ :=
    (inv_le_inv₀ (Real.sqrt_pos.mpr (by linarith)) (Real.sqrt_pos.mpr (by linarith))).mpr
      (Real.sqrt_le_sqrt hRT)
  have hb := separated_plane_card_bound Finset.univ ν hd 0
    (fun i _ j _ hij => (mul_le_mul_of_nonneg_left hδ G.c₀_pos.le).trans (hsep i j hij))
    (fun i _ => by simpa using hF (ν i) (hν i))
  simpa only [Finset.card_univ,Fintype.card_fin] using hb

/-- The elementary bounded-scale reverse square-function estimate. -/
theorem bounded_scale_graph_estimate (G : GraphSetup) {T : ℝ} (hT : 2 ≤ T) :
    ∃ B : ℝ, 0 < B ∧ ∀ R : ℝ, 2 ≤ R → R ≤ T →
      ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
      AdmissibleFamily G R ν f → l3 (fun y => ∑ i, f i y) ≤
        ENNReal.ofReal B*l3Real (squareFunction Finset.univ (fun i => f i)) := by
  obtain ⟨N,hN⟩ := bounded_scale_cardinality G hT
  refine ⟨Real.sqrt (N : ℝ)+1,by positivity,?_⟩
  intro R hR hRT n ν f had
  have hn := hN R hR hRT n ν had.1 had.2.1
  have hb := finite_family_l3_square_bound Finset.univ (fun i => (f i : Space → ℂ))
  apply hb.trans
  apply mul_le_mul_right'
  apply ENNReal.ofReal_le_ofReal
  simp only [Finset.card_univ,Fintype.card_fin]
  have hh := Real.sqrt_le_sqrt (show (n : ℝ) ≤ N by exact_mod_cast hn)
  linarith

/-- General elliptic graphs over compact parameter sets: the complete graph
estimate, conditional only on the explicitly named external placement,
Nikodym, and continued-phase discrete-density inputs. This does not assert the
subsequent compact embedded surface / boundary reduction. -/
theorem general_graph_reverse_square_function (G : GraphSetup) (hG : GraphHypotheses G)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ S : DiscreteSetup, ContinuedPhase S.φ → DiscreteDensityInput S) :
    ReverseSquareFunction G := by
  intro ε hε
  obtain ⟨T,C,hT,hC,hlarge⟩ := general_graph_large_scale G hG hplacement hnikodym hdiscrete hε
  obtain ⟨B,hB,hbounded⟩ := bounded_scale_graph_estimate G hT
  refine ⟨C+B,by positivity,?_⟩
  intro R hR n ν f had
  have hp : 0 ≤ R^ε := Real.rpow_nonneg (by linarith) _
  by_cases hRT : T ≤ R
  · apply (hlarge R hRT n ν f had).trans
    apply mul_le_mul_right'
    exact ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right (by linarith) hp)
  · apply (hbounded R hR (le_of_not_ge hRT) n ν f had).trans
    apply mul_le_mul_right'
    apply ENNReal.ofReal_le_ofReal
    have hone : 1 ≤ R^ε := Real.one_le_rpow (by linarith) hε.le
    nlinarith

end EllipticSquareFunction
