import EllipticSquareFunction.SeeleyHalfSpaceLocalization

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] [FiniteDimensional ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Local half-space extension from smoothness on a relatively open patch.
All derivative bounds are constructed by cutoff localization. -/
theorem smooth_open_halfspace_extension {f : ℝ × X → E} {V : Set (ℝ × X)}
    (hV : IsOpen V) {a : ℝ × X} (ha : a ∈ V)
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f ({p : ℝ × X | 0 ≤ p.1} ∩ V)) :
    ∃ (F : ℝ × X → E) (U : Set (ℝ × X)), IsOpen U ∧ a ∈ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Set.EqOn F f (U ∩ {p : ℝ × X | 0 ≤ p.1}) := by
  obtain ⟨r,hr,hrV⟩ := Metric.isOpen_iff.mp hV a ha
  let χ : ContDiffBump a := ⟨r/4,r/2,by positivity,by linarith⟩
  let g : ℝ × X → E := fun p => χ p • f p
  have hsupp : tsupport (χ : ℝ × X → ℝ) ⊆ V := by
    rw [χ.tsupport_eq]
    intro p hp
    apply hrV
    exact lt_of_le_of_lt hp (by change r/2 < r; linarith)
  have hg : ContDiffOn ℝ (⊤ : ℕ∞) g {p : ℝ × X | 0 ≤ p.1} := by
    intro p hp
    by_cases hpV : p ∈ V
    · have hfp := (hf p ⟨hp,hpV⟩).mono_of_mem_nhdsWithin
        (Filter.inter_mem self_mem_nhdsWithin (mem_nhdsWithin_of_mem_nhds (hV.mem_nhds hpV)))
      exact χ.contDiff.contDiffWithinAt.smul hfp
    · have hn : p ∉ tsupport (χ : ℝ × X → ℝ) := fun h => hpV (hsupp h)
      have he := not_mem_tsupport_iff_eventuallyEq.mp hn
      have hge : g =ᶠ[𝓝 p] (fun _ => (0 : E)) := by
        filter_upwards [he] with q hq
        simp only [g,hq,Pi.zero_apply,zero_smul]
      exact (contDiffAt_const.congr_of_eventuallyEq hge).contDiffWithinAt
  have hz : ∀ p : ℝ × X, ‖a‖+r/2 < ‖p‖ → g p = 0 := by
    intro p hp
    have hχ : χ p = 0 := χ.zero_of_le_dist (by
      have hh := dist_triangle p a 0
      simp only [dist_zero_right] at hh
      change r/2 ≤ dist p a
      linarith)
    simp only [g,hχ,zero_smul]
  obtain ⟨F,hF,hFg⟩ := smooth_halfspace_extension_of_zero_outside hg hz
  refine ⟨F,Metric.ball a (r/4),Metric.isOpen_ball,Metric.mem_ball_self (by positivity),
    hF.contDiffOn,fun p hp => ?_⟩
  rw [hFg hp.2]
  have hχ : χ p = 1 := χ.one_of_mem_closedBall (by change dist p a ≤ r/4; exact le_of_lt hp.1)
  simp only [g,hχ,one_smul]

end EllipticSquareFunction
