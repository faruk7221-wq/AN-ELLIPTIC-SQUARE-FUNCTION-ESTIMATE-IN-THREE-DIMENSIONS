import EllipticSquareFunction.CriticalHessianComposition

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- A smooth map with invertible differential has a smooth local inverse on
an open neighborhood, with its source contained in the prescribed domain. -/
theorem smooth_local_inverse {g : Plane → Plane} {U : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (hg : ContDiffOn ℝ (⊤ : ℕ∞) g U)
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a) :
    ∃ e : PartialHomeomorph Plane Plane,
      (e : Plane → Plane) = g ∧ a ∈ e.source ∧ e.source ⊆ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) e.symm e.target ∧
      HasFDerivAt e.symm (L.symm : Plane →L[ℝ] Plane) (g a) := by
  have hga := hg.contDiffAt (hU.mem_nhds ha)
  let e₀ := hga.toPartialHomeomorph g hL (by norm_cast)
  have hDa : ContinuousAt (fderiv ℝ g) a :=
    ((hga.fderiv_right (m := 1) (by norm_cast)).continuousAt)
  have hn : {y : Plane | ∃ E : Plane ≃L[ℝ] Plane,
      (E : Plane →L[ℝ] Plane) = fderiv ℝ g y} ∈ 𝓝 a := by
    have hl := L.nhds
    rw [← hL.fderiv] at hl
    exact hDa.preimage_mem_nhds hl
  obtain ⟨V,hVsub,hV,haV⟩ := mem_nhds_iff.mp (Filter.inter_mem (hU.mem_nhds ha) hn)
  let e := e₀.restrOpen V hV
  have he : (e : Plane → Plane)=g := rfl
  have hae : a ∈ e.source := ⟨hga.mem_toPartialHomeomorph_source hL (by norm_cast),haV⟩
  have hsource : e.source ⊆ U := fun y hy => (hVsub hy.2).1
  have hsmooth : ContDiffOn ℝ (⊤ : ℕ∞) e.symm e.target := by
    intro y hy
    have hs := e.map_target hy
    obtain ⟨E,hE⟩ := (hVsub hs.2).2
    have hgy := hg.contDiffAt (hU.mem_nhds (hsource hs))
    have hd : HasFDerivAt e (E : Plane →L[ℝ] Plane) (e.symm y) := by
      rw [he,hE]
      exact (hgy.differentiableAt (by norm_cast)).hasFDerivAt
    exact (e.contDiffAt_symm hy hd (by simpa only [he] using hgy)).contDiffWithinAt
  refine ⟨e,he,hae,hsource,hsmooth,?_⟩
  have hi : e.symm (g a)=a := by simpa only [← he] using e.left_inv hae
  exact e.hasFDerivAt_symm (by simpa only [he] using e.map_source hae)
    (by simpa only [he,hi] using hL)

end EllipticSquareFunction
