import EllipticSquareFunction.EuclideanGraphGeometry
import EllipticSquareFunction.NormalExistence

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- The position vector is normal to a parametrization lying on a sphere. -/
theorem constant_norm_param_normal {F : Plane → EuclideanThree} {U : Set Plane}
    {a : Plane} {r : ℝ} (hU : IsOpen U) (ha : a ∈ U)
    (hF : DifferentiableAt ℝ F a) (hnorm : ∀ b ∈ U, ‖F b‖=r) (v : Plane) :
    @inner ℝ EuclideanThree _ (F a) (fderiv ℝ F a v)=0 := by
  have he : (fun b => ‖F b‖^2) =ᶠ[𝓝 a] (fun _ => r^2) := by
    filter_upwards [hU.mem_nhds ha] with b hb
    rw [hnorm b hb]
  have hh := congrArg (fun D : Plane →L[ℝ] ℝ => D v) he.fderiv_eq
  rw [hF.hasFDerivAt.norm_sq.fderiv,fderiv_const] at hh
  simp only [ContinuousLinearMap.smul_apply,ContinuousLinearMap.comp_apply,
    innerSL_apply,ContinuousLinearMap.zero_apply,smul_eq_mul] at hh
  simp only [two_smul,Pi.zero_apply,ContinuousLinearMap.zero_apply] at hh
  linarith

/-- On a sphere, the normal second form is minus the metric pulled back
by the immersion differential. -/
theorem constant_norm_second_form {F : Plane → EuclideanThree} {U : Set Plane}
    {a : Plane} {r : ℝ} (hU : IsOpen U) (ha : a ∈ U)
    (hF : ContDiffOn ℝ 2 F U) (hnorm : ∀ b ∈ U, ‖F b‖=r) (v w : Plane) :
    euclideanSecondFundamentalForm F (F a) a v w =
      - @inner ℝ EuclideanThree _ (fderiv ℝ F a v) (fderiv ℝ F a w) := by
  have hFa := hF.contDiffAt (hU.mem_nhds ha)
  have hdF := hFa.differentiableAt (by norm_num)
  have hdD := (hFa.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num)
  have hdT : DifferentiableAt ℝ (fun b => fderiv ℝ F b w) a :=
    hdD.clm_apply (differentiableAt_const w)
  have he : (fun b => @inner ℝ EuclideanThree _ (F b) (fderiv ℝ F b w)) =ᶠ[𝓝 a]
      (fun _ => 0) := by
    filter_upwards [hU.mem_nhds ha] with b hb
    exact constant_norm_param_normal hU hb
      ((hF.contDiffAt (hU.mem_nhds hb)).differentiableAt (by norm_num)) hnorm w
  have hh := congrArg (fun D : Plane →L[ℝ] ℝ => D v) he.fderiv_eq
  change fderiv ℝ (fun b => @inner ℝ EuclideanThree _ (F b) (fderiv ℝ F b w)) a v =
    fderiv ℝ (fun _ : Plane => (0 : ℝ)) a v at hh
  rw [fderiv_inner_apply ℝ hdF hdT v,fderiv_const] at hh
  change @inner ℝ EuclideanThree _ (F a) (fderiv ℝ (fun b => fderiv ℝ F b w) a v) +
    @inner ℝ EuclideanThree _ (fderiv ℝ F a v) (fderiv ℝ F a w)=0 at hh
  rw [derivative_tangent_field hFa w v] at hh
  unfold euclideanSecondFundamentalForm
  linarith

theorem unit_sphere_param_definite {F : Plane → EuclideanThree} {U : Set Plane}
    {a : Plane} (hU : IsOpen U) (ha : a ∈ U)
    (hF : ContDiffOn ℝ 2 F U) (hnorm : ∀ b ∈ U, ‖F b‖=1)
    (hD : Function.Injective (fderiv ℝ F a)) :
    EuclideanDefiniteSecondForm F (F a) a := by
  apply Or.inr
  intro v hv
  rw [constant_norm_second_form hU ha hF hnorm]
  apply neg_neg_of_pos
  exact real_inner_self_pos.mpr (fun hz => hv (hD (hz.trans (map_zero _).symm)))

end EllipticSquareFunction
