import EllipticSquareFunction.PacketDecay

/-! # Polynomial losses for arbitrary changes of time origin

The normalized time difference is not restricted to a compact interval.
Every fixed spatial derivative has at most polynomial growth in it.
-/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The norm of each derivative of the unit oscillation is independent of
its real argument. This avoids a compactness assumption on the time shift. -/
theorem oscillation_derivative_norm_constant (k : ℕ) (t : ℝ) :
    ‖iteratedFDeriv ℝ k oscillation t‖ = ‖iteratedFDeriv ℝ k oscillation 0‖ := by
  have he : (fun x : ℝ => oscillation (t+x)) =
      (fun x : ℝ => oscillation t • oscillation x) := by
    funext x
    exact oscillation_add t x
  have hh := congrArg (fun f : ℝ → ℂ => iteratedFDeriv ℝ k f 0) he
  dsimp only at hh
  rw [iteratedFDeriv_comp_add_left,add_zero,
    iteratedFDeriv_const_smul_apply' (contDiff_oscillation.of_le (by exact_mod_cast
      (le_top : (k : ℕ∞)≤⊤))).contDiffAt] at hh
  rw [hh]
  have hn := norm_smul (oscillation t) (iteratedFDeriv ℝ k oscillation 0)
  simpa only [norm_oscillation,one_mul] using hn

theorem normalizedOscillation_polynomial_derivative {φ : Phase}
    (hphase : ContinuedPhase φ) {B : ℝ} (hB : 0≤B) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ N : ℝ, 1≤N → ∀ (ν η : Plane) (u : ℝ),
      ‖η‖≤B → ‖iteratedFDeriv ℝ k (normalizedOscillation φ ν N u) η‖ ≤
        C*(1+|u|)^k := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  choose H hH hbound using phaseRemainder_derivative_bound_on_ball hphase hB
  let C := 1+∑ j ∈ Finset.range (k+1), ‖iteratedFDeriv ℝ j oscillation 0‖
  let D := 1+∑ j ∈ Finset.range (k+1), H j
  have hC : 1≤C := by
    dsimp [C]
    linarith [Finset.sum_nonneg (s := Finset.range (k+1))
      (fun j _ => norm_nonneg (iteratedFDeriv ℝ j oscillation 0))]
  have hD : 1≤D := by
    dsimp [D]
    linarith [Finset.sum_nonneg (fun j (_ : j∈Finset.range (k+1)) => hH j)]
  have hJC (j : ℕ) (hjk : j≤k) : ‖iteratedFDeriv ℝ j oscillation 0‖≤C := by
    have hh := Finset.single_le_sum (f := fun j => ‖iteratedFDeriv ℝ j oscillation 0‖)
      (fun _ _ => norm_nonneg _) (Finset.mem_range.mpr (by omega : j<k+1))
    dsimp [C]; linarith
  have hHD (j : ℕ) (hjk : j≤k) : H j≤D := by
    have hh := Finset.single_le_sum (f := H) (fun j _ => hH j)
      (Finset.mem_range.mpr (by omega : j<k+1))
    dsimp [D]; linarith
  refine ⟨k.factorial*C*D^k,by positivity,?_⟩
  intro N hN ν η u hη
  let R := phaseRemainder φ ν (velocity φ ν) N (N^2)
  have hR : ContDiff ℝ (⊤ : ℕ∞) R := phaseRemainder_contDiff φ hφ ν N
  have hDu : 1≤D*(1+|u|) := by nlinarith [abs_nonneg u]
  have hh : ‖iteratedFDeriv ℝ k (normalizedOscillation φ ν N u) η‖ ≤
      k.factorial*C*(D*(1+|u|))^k := by
    apply norm_iteratedFDeriv_comp_le contDiff_oscillation (contDiff_const.mul hR)
      (by exact_mod_cast (le_top : (k : ℕ∞)≤⊤)) η
    · intro j hjk
      rw [oscillation_derivative_norm_constant]
      exact hJC j hjk
    · intro j hj1 hjk
      change ‖iteratedFDeriv ℝ j (fun z => u • R z) η‖ ≤ (D*(1+|u|))^j
      rw [iteratedFDeriv_const_smul_apply' (hR.of_le (by exact_mod_cast
        (le_top : (j : ℕ∞)≤⊤))).contDiffAt,norm_smul,Real.norm_eq_abs]
      calc
        _ ≤ |u| * H j := mul_le_mul_of_nonneg_left (hbound j N hN ν η hη) (abs_nonneg u)
        _ ≤ D*(1+|u|) := by nlinarith [hHD j hjk,abs_nonneg u]
        _ ≤ _ := le_self_pow₀ hDu (by omega)
  simpa only [mul_pow,mul_assoc] using hh

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

theorem compact_slice_derivative_bound (H : E × Plane → ℂ)
    (hH : ContDiff ℝ (⊤ : ℕ∞) H) {T : Set E} {K : Set Plane}
    (hT : IsCompact T) (hK : IsCompact K) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ t ∈ T, ∀ η ∈ K,
      ‖iteratedFDeriv ℝ k (fun ζ => H (t,ζ)) η‖≤C := by
  obtain ⟨C,hC⟩ := (hT.prod hK).exists_bound_of_continuousOn
    (continuous_iteratedFDeriv_slice H hH k).continuousOn
  exact ⟨max C 0,le_max_right _ _,fun t ht η hη =>
    (hC (t,η) ⟨ht,hη⟩).trans (le_max_left _ _)⟩

/-- A compact smooth amplitude family times the normalized phase has kth
derivative bounded by a fixed constant times (1+|u|)^k. -/
theorem rebaseAmplitude_polynomial_derivative {φ : Phase} (hphase : ContinuedPhase φ)
    (H : E × Plane → ℂ) (hH : ContDiff ℝ (⊤ : ℕ∞) H)
    {T : Set E} {K : Set Plane} (hT : IsCompact T) (hK : IsCompact K) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ t ∈ T, ∀ N : ℝ, 1≤N → ∀ (ν η : Plane) (u : ℝ), η ∈ K →
      ‖iteratedFDeriv ℝ k (fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ) η‖ ≤
        C*(1+|u|)^k := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨B,hB⟩ := hK.exists_bound_of_continuousOn continuous_id.continuousOn
  choose C hC hc using compact_slice_derivative_bound H hH hT hK
  choose D hD hd using normalizedOscillation_polynomial_derivative hphase (le_max_right B 0)
  let J := fun j => (k.choose j : ℝ)*C j*D (k-j)
  have hJ (j : ℕ) : 0≤J j :=
    mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hC j)) (hD (k-j))
  refine ⟨∑ j ∈ Finset.range (k+1), J j,Finset.sum_nonneg (fun j _ => hJ j),?_⟩
  intro t ht N hN ν η u hη
  have hb : ContDiff ℝ (⊤ : ℕ∞) (fun ζ => H (t,ζ)) :=
    hH.comp (contDiff_const.prodMk contDiff_id)
  calc
    _ ≤ ∑ j ∈ Finset.range (k+1), (k.choose j : ℝ)*
        ‖iteratedFDeriv ℝ j (fun ζ => H (t,ζ)) η‖*
        ‖iteratedFDeriv ℝ (k-j) (normalizedOscillation φ ν N u) η‖ :=
      norm_iteratedFDeriv_mul_le hb (normalizedOscillation_contDiff φ hφ ν N u) η
        (by exact_mod_cast (le_top : (k : ℕ∞)≤⊤))
    _ ≤ ∑ j ∈ Finset.range (k+1), J j*(1+|u|)^k := by
      apply Finset.sum_le_sum
      intro j hj
      have hp : (1+|u|)^(k-j)≤(1+|u|)^k :=
        pow_le_pow_right₀ (by linarith [abs_nonneg u]) (Nat.sub_le _ _)
      calc
        _ ≤ (k.choose j : ℝ)*C j*(D (k-j)*(1+|u|)^(k-j)) :=
          mul_le_mul (mul_le_mul_of_nonneg_left (hc j t ht η hη) (Nat.cast_nonneg _))
            (hd (k-j) N hN ν η u ((hB η hη).trans (le_max_left B 0)))
            (norm_nonneg _) (mul_nonneg (Nat.cast_nonneg _) (hC j))
        _ = J j*(1+|u|)^(k-j) := by dsimp [J]; ring
        _ ≤ _ := mul_le_mul_of_nonneg_left hp (hJ j)
    _ = _ := (Finset.sum_mul ..).symm

theorem rebaseAmplitude_polynomial_derivative_integral {φ : Phase} (hphase : ContinuedPhase φ)
    (H : E × Plane → ℂ) (hH : ContDiff ℝ (⊤ : ℕ∞) H)
    {T : Set E} {K : Set Plane} (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ζ => H (t,ζ)) ⊆ K) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ t ∈ T, ∀ N : ℝ, 1≤N → ∀ (ν : Plane) (u : ℝ),
      (∫ η, ‖iteratedFDeriv ℝ k (fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ) η‖) ≤
        C*(1+|u|)^k := by
  obtain ⟨C,hC,hbound⟩ := rebaseAmplitude_polynomial_derivative hphase H hH hT hK k
  refine ⟨C*volume.real K,by positivity,?_⟩
  intro t ht N hN ν u
  let f := fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ
  have hsf : tsupport f⊆K := tsupport_mul_subset_left.trans (hs t ht)
  have he : (∫ η in K, ‖iteratedFDeriv ℝ k f η‖) = ∫ η, ‖iteratedFDeriv ℝ k f η‖ := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro η hη
    have hz : iteratedFDeriv ℝ k f η=0 := by
      by_contra hn
      exact hη (hsf (support_iteratedFDeriv_subset k hn))
    rw [hz,norm_zero]
  change (∫ η, ‖iteratedFDeriv ℝ k f η‖) ≤ _
  rw [← he]
  calc
    _ ≤ ‖∫ η in K, ‖iteratedFDeriv ℝ k f η‖‖ := le_abs_self _
    _ ≤ (C*(1+|u|)^k)*volume.real K := by
      apply norm_setIntegral_le_of_norm_le_const_ae' hK.measure_lt_top
      filter_upwards with η hη
      simpa only [Real.norm_eq_abs,abs_norm] using hbound t ht N hN ν η u hη
    _ = _ := by ring

theorem rebaseAmplitude_polynomial_derivativeMass {φ : Phase} (hphase : ContinuedPhase φ)
    (H : E × Plane → ℂ) (hH : ContDiff ℝ (⊤ : ℕ∞) H)
    {T : Set E} {K : Set Plane} (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ζ => H (t,ζ)) ⊆ K) (L : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ t ∈ T, ∀ N : ℝ, 1≤N → ∀ (ν : Plane) (u : ℝ),
      derivativeMass L (fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ) ≤ C*(1+|u|)^L := by
  choose C hC hc using rebaseAmplitude_polynomial_derivative_integral hphase H hH hT hK hs
  refine ⟨∑ k ∈ Finset.range (L+1), C k,Finset.sum_nonneg (fun k _ => hC k),?_⟩
  intro t ht N hN ν u
  unfold derivativeMass
  rw [Finset.sum_mul]
  apply Finset.sum_le_sum
  intro k hk
  apply (hc k t ht N hN ν u).trans
  exact mul_le_mul_of_nonneg_left
    (pow_le_pow_right₀ (by linarith [abs_nonneg u]) (by have := Finset.mem_range.mp hk; omega)) (hC k)

/-- Uniform integration by parts with a polynomial, rather than bounded,
dependence on the normalized time difference. -/
theorem rebaseAmplitude_oscillatory_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (H : E × Plane → ℂ) (hH : ContDiff ℝ (⊤ : ℕ∞) H)
    {T : Set E} {K : Set Plane} (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ζ => H (t,ζ)) ⊆ K) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ t ∈ T, ∀ N : ℝ, 1≤N → ∀ (ν w : Plane) (u : ℝ),
      ‖∫ ζ, H (t,ζ)*normalizedOscillation φ ν N u ζ * oscillation (@inner ℝ Plane _ w ζ)‖ ≤
        C*(1+|u|)^L*bracket w^(-(L:ℝ)) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨B,hB,hbound⟩ := rebaseAmplitude_polynomial_derivativeMass hphase H hH hT hK hs L
  let K₀ : ℝ := 2^L*(1+2^L)
  have hK₀ : 0≤K₀ := by dsimp [K₀]; positivity
  refine ⟨K₀*B+1,by positivity,?_⟩
  intro t ht N hN ν w u
  have hf : ContDiff ℝ (⊤ : ℕ∞) (fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ) :=
    (hH.comp (contDiff_const.prodMk contDiff_id)).mul (normalizedOscillation_contDiff φ hφ ν N u)
  have hfs : HasCompactSupport (fun ζ => H (t,ζ)*normalizedOscillation φ ν N u ζ) :=
    hK.of_isClosed_subset isClosed_closure (tsupport_mul_subset_left.trans (hs t ht))
  apply (oscillatoryIntegral_bracket_decay _ hf hfs L w).trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by dsimp [bracket]; positivity) _)
  calc
    _ ≤ K₀*(B*(1+|u|)^L) := mul_le_mul_of_nonneg_left (hbound t ht N hN ν u) hK₀
    _ ≤ (K₀*B+1)*(1+|u|)^L := by nlinarith [pow_nonneg (by positivity : 0≤1+|u|) L]

def rebasingKernel (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N : ℝ) (ν a w : Plane) (Δ : ℝ) : ℂ :=
  ∫ ζ, b ζ*(χ (ζ+a) : ℂ)*oscillation
    (@inner ℝ Plane _ w ζ+Δ*phaseRemainder φ ν (velocity φ ν) N (N^2) ζ)

/-- Equation (5.8), with the explicit polynomial exponent L and all real
time differences. The translated window parameter ranges in a fixed ball. -/
theorem equation_5_8 {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (A : ℝ) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ (ν a w : Plane) (Δ : ℝ), ‖a‖≤A →
      ‖rebasingKernel φ b χ N ν a w Δ‖ ≤ C*(1+|Δ|)^L*bracket w^(-(L:ℝ)) := by
  let H : Plane × Plane → ℂ := fun p => b p.2*(χ (p.2+p.1) : ℂ)
  have hχ' : ContDiff ℝ (⊤ : ℕ∞) (fun ξ => (χ ξ : ℂ)) :=
    Complex.ofRealCLM.contDiff.comp hχ
  have hH : ContDiff ℝ (⊤ : ℕ∞) H :=
    (hb.comp contDiff_snd).mul (hχ'.comp (contDiff_snd.add contDiff_fst))
  obtain ⟨C,hC,hbound⟩ := rebaseAmplitude_oscillatory_decay hphase H hH
    (isCompact_closedBall (0:Plane) A) hbs (fun _ _ => tsupport_mul_subset_left) L
  refine ⟨C,hC,?_⟩
  intro N hN ν a w Δ ha
  have he : rebasingKernel φ b χ N ν a w Δ =
      ∫ ζ, H (a,ζ)*normalizedOscillation φ ν N Δ ζ*oscillation (@inner ℝ Plane _ w ζ) := by
    apply integral_congr_ae
    filter_upwards with ζ
    dsimp only [H,normalizedOscillation]
    rw [oscillation_add]
    ring
  rw [he]
  exact hbound a (by simpa [Metric.mem_closedBall,dist_zero_right] using ha) N hN ν w Δ

end EllipticSquareFunction
