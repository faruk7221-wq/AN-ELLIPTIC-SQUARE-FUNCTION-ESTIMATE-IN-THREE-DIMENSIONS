import EllipticSquareFunction.SeeleySeriesDerivative
import Mathlib.Analysis.Calculus.FDeriv.Extend

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- The left derivative at the boundary matches the right-hand derivative data.
The derivative and boundedness assumptions are stated explicitly. -/
theorem seeley_jet_series_boundary_hasDerivWithinAt (m : ℕ) {g g' : ℝ → E}
    {B B' : ℝ} (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hg' : ∀ s : ℝ, 0 ≤ s → ‖g' s‖ ≤ B')
    (hd : ∀ s : ℝ, 0 < s → HasDerivAt g (g' s) s)
    (hc : ContinuousWithinAt g (Set.Ici 0) 0)
    (hc' : ContinuousWithinAt g' (Set.Ici 0) 0) :
    HasDerivWithinAt (seeleyJetSeries m g) (g' 0) (Set.Iic 0) 0 := by
  apply hasDerivWithinAt_Iic_of_tendsto_deriv (s := Set.Iio 0)
  · intro t ht
    exact (seeley_jet_series_hasDerivAt m hg hg' hd ht).differentiableAt.differentiableWithinAt
  · rw [ContinuousWithinAt, seeley_jet_series_zero]
    exact (seeley_jet_series_boundary_limit m hg hc).mono_left
      (nhdsWithin_mono _ Set.Iio_subset_Iic_self)
  · exact self_mem_nhdsWithin
  · have hlim := (seeley_jet_series_boundary_limit (m+1) hg' hc').mono_left
      (nhdsWithin_mono _ Set.Iio_subset_Iic_self)
    apply hlim.congr'
    filter_upwards [self_mem_nhdsWithin] with t ht
    exact (seeley_jet_series_hasDerivAt m hg hg' hd ht).deriv.symm

def seeleyExtension (g : ℝ → E) (t : ℝ) : E :=
  if 0 ≤ t then g t else seeleyJetSeries 0 g t

theorem seeley_extension_eq_nonneg (g : ℝ → E) {t : ℝ} (ht : 0 ≤ t) :
    seeleyExtension g t = g t := by simp [seeleyExtension, ht]

theorem seeley_extension_eq_nonpos (g : ℝ → E) {t : ℝ} (ht : t ≤ 0) :
    seeleyExtension g t = seeleyJetSeries 0 g t := by
  by_cases h : 0 ≤ t
  · have he : t = 0 := le_antisymm ht h
    simp [he, seeleyExtension, seeley_jet_series_zero]
  · simp [seeleyExtension, h]

/-- First-order gluing of the constructed reflection series to the given data. -/
theorem seeley_extension_hasDerivAt_zero {g g' : ℝ → E} {B B' : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hg' : ∀ s : ℝ, 0 ≤ s → ‖g' s‖ ≤ B')
    (hd : ∀ s : ℝ, 0 < s → HasDerivAt g (g' s) s)
    (hzero : HasDerivWithinAt g (g' 0) (Set.Ici 0) 0)
    (hc' : ContinuousWithinAt g' (Set.Ici 0) 0) :
    HasDerivAt (seeleyExtension g) (g' 0) 0 := by
  have hl := (seeley_jet_series_boundary_hasDerivWithinAt 0 hg hg' hd
    hzero.continuousWithinAt hc').congr
    (fun t ht => seeley_extension_eq_nonpos g ht)
    (seeley_extension_eq_nonpos g le_rfl)
  have hr := hzero.congr (fun t ht => seeley_extension_eq_nonneg g ht)
    (seeley_extension_eq_nonneg g le_rfl)
  have hu := hl.union hr
  simpa only [Set.Iic_union_Ici, hasDerivWithinAt_univ] using hu

end EllipticSquareFunction
