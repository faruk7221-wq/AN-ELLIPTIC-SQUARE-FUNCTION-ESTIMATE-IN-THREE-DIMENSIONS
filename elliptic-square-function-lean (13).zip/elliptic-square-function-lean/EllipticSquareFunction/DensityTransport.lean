import EllipticSquareFunction.WindowMatrix
import EllipticSquareFunction.Weights

/-!
# The coefficient and density transport behind equation (4.11)

The article applies weighted Cauchy--Schwarz to the window-change matrix.
The first theorem below isolates that finite argument.  The frequency overlap
of the original separated net is recorded explicitly: without such a
hypothesis the asserted estimate is false for repeated profile labels.
-/

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

/-- Weighted Cauchy--Schwarz for a finite complex matrix row. -/
theorem norm_weighted_matrix_sum_sq {ι : Type*} (s : Finset ι)
    (B a : ι → ℂ) (w : ι → ℝ) {C K : ℝ}
    (hw : ∀ i ∈ s, 0 ≤ w i)
    (hB : ∀ i ∈ s, ‖B i‖ ≤ C * w i)
    (hK : ∑ i ∈ s, w i ≤ K) :
    ‖∑ i ∈ s, B i * a i‖ ^ 2 ≤
      C ^ 2 * K * ∑ i ∈ s, w i * ‖a i‖ ^ 2 := by
  have hn : ‖∑ i ∈ s, B i * a i‖ ≤ C * ∑ i ∈ s, w i * ‖a i‖ := by
    calc
      _ ≤ ∑ i ∈ s, ‖B i * a i‖ := norm_sum_le _ _
      _ ≤ ∑ i ∈ s, (C * w i) * ‖a i‖ := Finset.sum_le_sum (fun i hi => by
        rw [norm_mul]
        exact mul_le_mul_of_nonneg_right (hB i hi) (norm_nonneg _))
      _ = C * ∑ i ∈ s, w i * ‖a i‖ := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro i _
        ring
  have hcs := Finset.sum_mul_sq_le_sq_mul_sq s
    (fun i => Real.sqrt (w i)) (fun i => Real.sqrt (w i) * ‖a i‖)
  have hsqrt : (∑ i ∈ s, Real.sqrt (w i) * (Real.sqrt (w i) * ‖a i‖)) =
      ∑ i ∈ s, w i * ‖a i‖ := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [← mul_assoc, Real.mul_self_sqrt (hw i hi)]
  have hleft : ‖∑ i ∈ s, B i * a i‖ ^ 2 ≤
      C ^ 2 * (∑ i ∈ s, w i * ‖a i‖) ^ 2 := by
    calc
      _ ≤ (C * ∑ i ∈ s, w i * ‖a i‖) ^ 2 :=
        pow_le_pow_left₀ (norm_nonneg _) hn 2
      _ = _ := mul_pow _ _ _
  rw [hsqrt] at hcs
  have hsqw : (∑ i ∈ s, (Real.sqrt (w i)) ^ 2) = ∑ i ∈ s, w i := by
    apply Finset.sum_congr rfl
    intro i hi
    exact Real.sq_sqrt (hw i hi)
  have hsqwa : (∑ i ∈ s, (Real.sqrt (w i) * ‖a i‖) ^ 2) =
      ∑ i ∈ s, w i * ‖a i‖ ^ 2 := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [mul_pow, Real.sq_sqrt (hw i hi)]
  rw [hsqw, hsqwa] at hcs
  calc
    _ ≤ C ^ 2 * (∑ i ∈ s, w i * ‖a i‖) ^ 2 := hleft
    _ ≤ C ^ 2 * ((∑ i ∈ s, w i) * ∑ i ∈ s, w i * ‖a i‖ ^ 2) :=
      mul_le_mul_of_nonneg_left hcs (sq_nonneg C)
    _ ≤ C ^ 2 * (K * ∑ i ∈ s, w i * ‖a i‖ ^ 2) := by
      apply mul_le_mul_of_nonneg_left _ (sq_nonneg C)
      exact mul_le_mul_of_nonneg_right hK
        (Finset.sum_nonneg (fun i hi => mul_nonneg (hw i hi) (sq_nonneg _)))
    _ = _ := by ring

/-- Finite double-counting for the forward frequency-overlap step.  It is the
algebraic mechanism that converts a bound on the number of fine frequencies
interacting with each original profile into a global density bound. -/
theorem sum_near_frequency_le {ι κ : Type*} (s : Finset ι) (q : Finset κ)
    (near : κ → ι → Prop) [DecidableRel near] (F : ι → ℝ) (J : ℕ)
    (hF : ∀ i ∈ s, 0 ≤ F i)
    (hJ : ∀ i ∈ s, (q.filter (fun m => near m i)).card ≤ J) :
    (∑ m ∈ q, ∑ i ∈ s.filter (near m), F i) ≤ (J : ℝ) * ∑ i ∈ s, F i := by
  calc
    _ = ∑ m ∈ q, ∑ i ∈ s, if near m i then F i else 0 := by
      apply Finset.sum_congr rfl
      intro m hm
      exact Finset.sum_filter (near m) F
    _ = ∑ i ∈ s, ∑ m ∈ q, if near m i then F i else 0 := by
      rw [Finset.sum_comm]
    _ = ∑ i ∈ s, ((q.filter (fun m => near m i)).card : ℝ) * F i := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [← Finset.sum_filter]
      simp
    _ ≤ ∑ i ∈ s, (J : ℝ) * F i := by
      apply Finset.sum_le_sum
      intro i hi
      apply mul_le_mul_of_nonneg_right _ (hF i hi)
      exact_mod_cast hJ i hi
    _ = (J : ℝ) * ∑ i ∈ s, F i := by rw [Finset.mul_sum]

/-- Bounded overlap of the original frequency net at scale `N⁻¹`.  Separation
of the net implies this property by a lattice/packing argument. -/
def FrequencyOverlap {ι : Type*} (N A : ℝ) (s : Finset ι)
    (ν : ι → Plane) (μ : Plane) (K : ℕ) : Prop :=
  (s.filter (fun i => ‖μ - ν i‖ ≤ A / N)).card ≤ K

/-- A finite coefficient in the canonical fine frame, before the harmless
restriction to a large finite box.  Original positions are a translate of
the scale-`N` lattice `N • latticePoint c p`. -/
def changedCoefficient {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    (N c : ℝ) (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r μ w : Plane) : ℂ :=
  ∑ i ∈ s, ∑ p ∈ pbox,
    windowMatrix b χ N μ w (ν i) (r + N • latticePoint c p) * a i p

/-- The weighted matrix-row estimate used in (4.11).  The two geometric
inputs are visible in the statement: bounded overlap of frequency centers
and a translated lattice of spatial centers. -/
theorem changedCoefficient_sq_le_near {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    {N c A C L : ℝ} (hN : 0 < N) (hc : 0 < c) (hL : 2 < L)
    (s : Finset ι) (pbox : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r μ w : Plane) (K : ℕ)
    (hoverlap : FrequencyOverlap N A s ν μ K)
    (hcut : ∀ i ∈ s, A / N < ‖μ - ν i‖ →
      ∀ p ∈ pbox, windowMatrix b χ N μ w (ν i)
        (r + N • latticePoint c p) = 0)
    (hdecay : ∀ i ∈ s, ∀ p ∈ pbox,
      ‖windowMatrix b χ N μ w (ν i) (r + N • latticePoint c p)‖ ≤
        C * bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L)) :
    ‖changedCoefficient b χ N c s pbox a ν r μ w‖ ^ 2 ≤
      C ^ 2 * ((K : ℝ) * scaledLatticeSumConstant c L) *
        ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A / N), ∑ p ∈ pbox,
          bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L) * ‖a i p‖ ^ 2 := by
  classical
  let near : ι → Prop := fun i => ‖μ - ν i‖ ≤ A / N
  let wt : ι × IntPlane → ℝ := fun ip =>
    if near ip.1 then bracket (N⁻¹ • (w - (r + N • latticePoint c ip.2))) ^ (-L) else 0
  let t := (s.filter near) ×ˢ pbox
  have hrewrite : changedCoefficient b χ N c s pbox a ν r μ w =
      ∑ ip ∈ t, windowMatrix b χ N μ w (ν ip.1)
        (r + N • latticePoint c ip.2) * a ip.1 ip.2 := by
    rw [changedCoefficient]
    have hprod := Finset.sum_product s pbox (fun ip =>
      windowMatrix b χ N μ w (ν ip.1) (r + N • latticePoint c ip.2) * a ip.1 ip.2)
    rw [← hprod]
    symm
    apply Finset.sum_subset
    · intro ip hip
      exact Finset.mem_product.mpr
        ⟨(Finset.filter_subset near s) (Finset.mem_product.mp hip).1,
          (Finset.mem_product.mp hip).2⟩
    intro ip hip hnot
    have his : ip.1 ∈ s := (Finset.mem_product.mp hip).1
    have hp : ip.2 ∈ pbox := (Finset.mem_product.mp hip).2
    have hnnear : ¬ near ip.1 := by
      intro hn
      exact hnot (Finset.mem_product.mpr ⟨Finset.mem_filter.mpr ⟨his, hn⟩, hp⟩)
    rw [hcut ip.1 his (lt_of_not_ge hnnear) ip.2 hp, zero_mul]
  have hwt (ip : ι × IntPlane) (hip : ip ∈ t) :
      wt ip = bracket (N⁻¹ • (w - (r + N • latticePoint c ip.2))) ^ (-L) := by
    dsimp only [wt]
    rw [if_pos (Finset.mem_filter.mp (Finset.mem_product.mp hip).1).2]
  have hw_nonneg : ∀ ip ∈ t, 0 ≤ wt ip := by
    intro ip hip
    rw [hwt ip hip]
    exact Real.rpow_nonneg (bracket_pos _).le _
  have hmatrix : ∀ ip ∈ t,
      ‖windowMatrix b χ N μ w (ν ip.1) (r + N • latticePoint c ip.2)‖ ≤ C * wt ip := by
    intro ip hip
    rw [hwt ip hip]
    exact hdecay ip.1 (Finset.mem_filter.mp (Finset.mem_product.mp hip).1).1
      ip.2 (Finset.mem_product.mp hip).2
  have hscale (p : IntPlane) :
      N⁻¹ • (w - (r + N • latticePoint c p)) =
        N⁻¹ • (w - r) - latticePoint c p := by
    rw [sub_add_eq_sub_sub, smul_sub, smul_sub, smul_smul, inv_mul_cancel₀ hN.ne', one_smul]
  have hconst : 0 ≤ scaledLatticeSumConstant c L := by
    unfold scaledLatticeSumConstant latticeSumConstant
    exact mul_nonneg (Real.rpow_nonneg (by positivity) _)
      (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (tsum_nonneg fun _ =>
        Real.rpow_nonneg (bracket_pos _).le _))
  have hweights : ∑ ip ∈ t, wt ip ≤ (K : ℝ) * scaledLatticeSumConstant c L := by
    rw [Finset.sum_product]
    calc
      _ = ∑ _i ∈ s.filter near, ∑ p ∈ pbox,
          bracket (N⁻¹ • (w-r) - latticePoint c p) ^ (-L) := by
        apply Finset.sum_congr rfl
        intro i hi
        apply Finset.sum_congr rfl
        intro p hp
        rw [hwt (i,p) (Finset.mem_product.mpr ⟨hi, hp⟩), hscale]
      _ ≤ ∑ _i ∈ s.filter near, scaledLatticeSumConstant c L :=
        Finset.sum_le_sum (fun _i _hi => scaled_lattice_finite_sum_le hc hL _ pbox)
      _ = ((s.filter near).card : ℝ) * scaledLatticeSumConstant c L := by simp
      _ ≤ (K : ℝ) * scaledLatticeSumConstant c L :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast hoverlap)
          hconst
  rw [hrewrite]
  have hmain := norm_weighted_matrix_sum_sq t
    (fun ip => windowMatrix b χ N μ w (ν ip.1) (r + N • latticePoint c ip.2))
    (fun ip => a ip.1 ip.2) wt hw_nonneg hmatrix hweights
  apply hmain.trans_eq
  congr 1
  rw [Finset.sum_product]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro p hp
  rw [hwt (i,p) (Finset.mem_product.mpr ⟨hi, hp⟩)]

/-- A convenient weakened form of `changedCoefficient_sq_le_near`, obtained
by restoring all nonnegative original-frequency terms on the right. -/
theorem changedCoefficient_sq_le {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    {N c A C L : ℝ} (hN : 0 < N) (hc : 0 < c) (hL : 2 < L)
    (s : Finset ι) (pbox : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r μ w : Plane) (K : ℕ)
    (hoverlap : FrequencyOverlap N A s ν μ K)
    (hcut : ∀ i ∈ s, A / N < ‖μ - ν i‖ →
      ∀ p ∈ pbox, windowMatrix b χ N μ w (ν i)
        (r + N • latticePoint c p) = 0)
    (hdecay : ∀ i ∈ s, ∀ p ∈ pbox,
      ‖windowMatrix b χ N μ w (ν i) (r + N • latticePoint c p)‖ ≤
        C * bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L)) :
    ‖changedCoefficient b χ N c s pbox a ν r μ w‖ ^ 2 ≤
      C ^ 2 * ((K : ℝ) * scaledLatticeSumConstant c L) *
        ∑ i ∈ s, ∑ p ∈ pbox,
          bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L) * ‖a i p‖ ^ 2 := by
  classical
  apply (changedCoefficient_sq_le_near b χ hN hc hL s pbox a ν r μ w K
    hoverlap hcut hdecay).trans
  apply mul_le_mul_of_nonneg_left _
    (mul_nonneg (sq_nonneg C) (mul_nonneg (Nat.cast_nonneg K) (by
      unfold scaledLatticeSumConstant latticeSumConstant
      exact mul_nonneg (Real.rpow_nonneg (by positivity) _)
        (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (tsum_nonneg fun _ =>
          Real.rpow_nonneg (bracket_pos _).le _)))))
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ s)
  intro i hi hif
  exact Finset.sum_nonneg (fun p hp =>
    mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (sq_nonneg _))

/-- Equation (4.10), the separated-frequency overlap, and the spatial lattice
sum imply the checked coefficient estimate with constants depending only on
the two fixed windows and the decay exponent. -/
theorem changedCoefficient_from_windows {ι : Type*}
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    (L : ℕ) (hL : 2 < L) :
    ∃ A C : ℝ, 0 < A ∧ 0 < C ∧
      ∀ {N c : ℝ}, 0 < N → 0 < c → ∀ (s : Finset ι) (pbox : Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r μ w : Plane) (K : ℕ),
        FrequencyOverlap N A s ν μ K →
        ‖changedCoefficient b χ N c s pbox a ν r μ w‖ ^ 2 ≤
          C ^ 2 * ((K : ℝ) * scaledLatticeSumConstant c (L : ℝ)) *
            ∑ i ∈ s, ∑ p ∈ pbox,
              bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-(L : ℝ)) *
                ‖a i p‖ ^ 2 := by
  obtain ⟨A, hA, hcut⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hdecay⟩ := windowMatrix_decay b hb hbs χ hχ hχs L
  refine ⟨A, C, hA, hC, ?_⟩
  intro N c hN hc s pbox a ν r μ w K hoverlap
  apply changedCoefficient_sq_le b χ hN hc (by exact_mod_cast hL)
    s pbox a ν r μ w K hoverlap
  · intro i hi hfar p hp
    exact hcut N hN μ w (ν i) (r + N • latticePoint c p) hfar
  · intro i hi p hp
    exact hdecay N hN μ w (ν i) (r + N • latticePoint c p)

/-- At a fixed spacetime point, only uniformly many canonical position tubes
can contain that point.  This is the second bounded-overlap input in the
passage from the coefficient estimate to (4.11). -/
theorem canonical_core_position_count {N c : ℝ} (hN : 0 < N) (hc : 0 < c)
    (V : Plane) (y : Space) (q : Finset IntPlane)
    (hq : ∀ n ∈ q, y ∈ coreTube N (N ^ 2) V (N • latticePoint c n)) :
    q.card ≤ (integerPlaneBox ⌈c⁻¹ + 2⌉₊).card := by
  apply translated_lattice_card_bound ((N * c)⁻¹ • (y.1 + y.2 • V)) c⁻¹
  intro n hn
  have hcore := (hq n hn).2
  have hl : (N * c)⁻¹ • (N • latticePoint c n) = latticePoint 1 n := by
    rw [← latticePoint_mul, ← latticePoint_mul, inv_mul_cancel₀ (mul_ne_zero hN.ne' hc.ne')]
  have he : (N * c)⁻¹ • (y.1 + y.2 • V) - latticePoint 1 n =
      (N * c)⁻¹ • (y.1 - N • latticePoint c n + y.2 • V) := by
    rw [smul_add, smul_add, smul_sub, smul_smul, hl]
    abel
  rw [he, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr (mul_pos hN hc))]
  have hmul := mul_le_mul_of_nonneg_left hcore (inv_pos.mpr (mul_pos hN hc)).le
  convert hmul using 1 <;> field_simp

/-- Velocity closeness transfers the matrix's position weight to the
article's moving spatial weight on a fine tube core. -/
theorem matrixWeight_le_spatialWeight_on_core {N E L : ℝ}
    (hN : 0 < N) (hE : 0 ≤ E) (hL : 0 ≤ L)
    (Vμ Vν w v : Plane) (y : Space)
    (hy : y ∈ coreTube N (N ^ 2) Vμ w)
    (hvel : ‖Vμ - Vν‖ ≤ E / N) :
    bracket (N⁻¹ • (w-v)) ^ (-L) ≤
      (2+E) ^ L * spatialWeight N L Vν v y := by
  have ht0 : 0 ≤ y.2 := hy.1.1
  have htN : y.2 ≤ N^2 := hy.1.2
  have hcore : ‖N⁻¹ • (y.1-w+y.2 • Vμ)‖ ≤ 1 := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hN)]
    have hm := mul_le_mul_of_nonneg_left hy.2 (inv_pos.mpr hN).le
    convert hm using 1 <;> field_simp
  have htime : ‖N⁻¹ • (y.2 • (Vν-Vμ))‖ ≤ E := by
    rw [smul_smul, norm_smul, Real.norm_eq_abs]
    have habs : |N⁻¹ * y.2| = N⁻¹ * y.2 := abs_of_nonneg (mul_nonneg (inv_pos.mpr hN).le ht0)
    rw [habs, norm_sub_rev]
    calc
      N⁻¹ * y.2 * ‖Vμ-Vν‖ ≤ N⁻¹ * y.2 * (E/N) :=
        mul_le_mul_of_nonneg_left hvel (mul_nonneg (inv_pos.mpr hN).le ht0)
      _ ≤ N⁻¹ * N^2 * (E/N) := by
        exact mul_le_mul_of_nonneg_right
          (mul_le_mul_of_nonneg_left htN (inv_pos.mpr hN).le)
          (div_nonneg hE hN.le)
      _ = E := by field_simp; ring
  have heq : N⁻¹ • (y.1-v+y.2 • Vν) =
      N⁻¹ • (w-v) + N⁻¹ • (y.1-w+y.2 • Vμ) + N⁻¹ • (y.2 • (Vν-Vμ)) := by
    rw [← smul_add, ← smul_add]
    congr 1
    module
  have hbr : bracket (N⁻¹ • (y.1-v+y.2 • Vν)) ≤
      (2+E) * bracket (N⁻¹ • (w-v)) := by
    rw [heq]
    unfold bracket
    calc
      1 + ‖N⁻¹ • (w-v) + N⁻¹ • (y.1-w+y.2 • Vμ) + N⁻¹ • (y.2 • (Vν-Vμ))‖
          ≤ 1 + (‖N⁻¹ • (w-v)‖ + ‖N⁻¹ • (y.1-w+y.2 • Vμ)‖ +
            ‖N⁻¹ • (y.2 • (Vν-Vμ))‖) := by
            gcongr
            exact (norm_add_le _ _).trans (add_le_add_right (norm_add_le _ _) _)
      _ ≤ 1 + (‖N⁻¹ • (w-v)‖ + 1 + E) := by gcongr
      _ ≤ (2+E) * (1+‖N⁻¹ • (w-v)‖) := by
        nlinarith [norm_nonneg (N⁻¹ • (w-v))]
  have hbase : 0 < 2+E := by linarith
  have hr := Real.rpow_le_rpow_of_nonpos (bracket_pos _)
    hbr (neg_nonpos.mpr hL)
  rw [Real.mul_rpow hbase.le (bracket_pos _).le] at hr
  have hp : 0 < (2+E)^L := Real.rpow_pos_of_pos hbase L
  have hm := mul_le_mul_of_nonneg_left hr hp.le
  rw [spatialWeight]
  calc
    bracket (N⁻¹ • (w-v)) ^ (-L) =
        (2+E)^L * ((2+E)^(-L) * bracket (N⁻¹ • (w-v))^(-L)) := by
          rw [← mul_assoc, ← Real.rpow_add hbase]
          simp
    _ ≤ (2+E)^L * bracket (N⁻¹ • (y.1-v+y.2 • Vν))^(-L) := hm

/-- The position-summed part of density transport for one fine frequency.
It combines the weighted coefficient estimate, velocity transport, and the
uniform overlap of canonical position cores. -/
theorem changedCoefficient_position_density_near {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c d A C E L : ℝ}
    (hN : 0 < N) (hc : 0 < c) (hd : 0 < d) (hE : 0 ≤ E) (hL : 2 < L)
    (s : Finset ι) (pbox q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν Vν : ι → Plane) (r μ : Plane) (Vμ : Plane) (y : Space) (K : ℕ)
    (hoverlap : FrequencyOverlap N A s ν μ K)
    (hvel : ∀ i ∈ s, ‖μ - ν i‖ ≤ A / N → ‖Vμ - Vν i‖ ≤ E / N)
    (hcut : ∀ (w : Plane) (i : ι), i ∈ s → A / N < ‖μ - ν i‖ →
      ∀ p ∈ pbox, windowMatrix b χ N μ w (ν i)
        (r + N • latticePoint c p) = 0)
    (hdecay : ∀ (w : Plane) (i : ι), i ∈ s → ∀ p ∈ pbox,
      ‖windowMatrix b χ N μ w (ν i) (r + N • latticePoint c p)‖ ≤
        C * bracket (N⁻¹ • (w - (r + N • latticePoint c p))) ^ (-L))
    (hq : ∀ n ∈ q, y ∈ coreTube N (N^2) Vμ (N • latticePoint d n)) :
    (∑ n ∈ q,
      ‖changedCoefficient b χ N c s pbox a ν r μ (N • latticePoint d n)‖^2) ≤
      ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) *
          ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox, ‖a i p‖^2 *
            spatialWeight N L (Vν i) (r + N • latticePoint c p) y := by
  classical
  let D := ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox, ‖a i p‖^2 *
    spatialWeight N L (Vν i) (r + N • latticePoint c p) y
  have hconst : 0 ≤ scaledLatticeSumConstant c L := by
    unfold scaledLatticeSumConstant latticeSumConstant
    exact mul_nonneg (Real.rpow_nonneg (by positivity) _)
      (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (tsum_nonneg fun _ =>
        Real.rpow_nonneg (bracket_pos _).le _))
  have hpoint (n : IntPlane) (hn : n ∈ q) :
      ‖changedCoefficient b χ N c s pbox a ν r μ (N • latticePoint d n)‖^2 ≤
        (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D := by
    have hy := hq n hn
    have hcfs := changedCoefficient_sq_le_near b χ hN hc hL s pbox a ν r μ
      (N • latticePoint d n) K hoverlap
      (hcut (N • latticePoint d n)) (hdecay (N • latticePoint d n))
    have hsum : (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox,
        bracket (N⁻¹ • (N • latticePoint d n - (r + N • latticePoint c p))) ^ (-L) *
          ‖a i p‖ ^ 2) ≤ (2+E)^L * D := by
      calc
        _ ≤ ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox,
            ((2+E)^L * spatialWeight N L (Vν i) (r + N • latticePoint c p) y) *
              ‖a i p‖^2 := by
          apply Finset.sum_le_sum
          intro i hi
          apply Finset.sum_le_sum
          intro p hp
          exact mul_le_mul_of_nonneg_right
            (matrixWeight_le_spatialWeight_on_core hN hE (by linarith) Vμ (Vν i)
              (N • latticePoint d n) (r + N • latticePoint c p) y hy
              (hvel i (Finset.mem_filter.mp hi).1 (Finset.mem_filter.mp hi).2))
            (sq_nonneg _)
        _ = (2+E)^L * (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N),
            ∑ p ∈ pbox, ‖a i p‖^2 *
              spatialWeight N L (Vν i) (r + N • latticePoint c p) y) := by
          simp_rw [mul_assoc, ← Finset.mul_sum]
          congr 1
          apply Finset.sum_congr rfl
          intro i hi
          apply Finset.sum_congr rfl
          intro p hp
          ring
    calc
      _ ≤ C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) *
          (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox,
            bracket (N⁻¹ • (N • latticePoint d n - (r + N • latticePoint c p))) ^ (-L) *
              ‖a i p‖ ^ 2) := hcfs
      _ ≤ C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * ((2+E)^L * D) :=
        mul_le_mul_of_nonneg_left hsum
          (mul_nonneg (sq_nonneg C) (mul_nonneg (Nat.cast_nonneg K) hconst))
      _ = _ := by ring
  have hcard : q.card ≤ (integerPlaneBox ⌈d⁻¹+2⌉₊).card :=
    canonical_core_position_count hN hd Vμ y q hq
  change (∑ n ∈ q, ‖changedCoefficient b χ N c s pbox a ν r μ
      (N • latticePoint d n)‖^2) ≤
    ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
      (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D
  calc
    _ ≤ ∑ _n ∈ q, (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D :=
      Finset.sum_le_sum hpoint
    _ = (q.card : ℝ) *
        (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D := by
      simp
      ring
    _ ≤ ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D := by
      have hD : 0 ≤ D := Finset.sum_nonneg (fun i hi =>
        Finset.sum_nonneg (fun p hp => mul_nonneg (sq_nonneg _)
          (spatialWeight_nonneg N L (Vν i) (r + N • latticePoint c p) y)))
      have hfac : 0 ≤ (C^2 * ((K : ℝ) * scaledLatticeSumConstant c L) * (2+E)^L) * D :=
        mul_nonneg (mul_nonneg
          (mul_nonneg (sq_nonneg C) (mul_nonneg (Nat.cast_nonneg K) hconst))
          (Real.rpow_nonneg (by linarith) L)) hD
      rw [mul_assoc, mul_assoc]
      have hcardR : (q.card : ℝ) ≤ ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) := by
        exact_mod_cast hcard
      convert mul_le_mul_of_nonneg_right hcardR hfac using 1 <;> ring

end EllipticSquareFunction
