import EllipticSquareFunction.FineFrameLocal

/-! # The bounded-position profile estimate for a common isotropic lattice

This does not yet cover all translated rectangular lattices in the manuscript.
The separation, lattice geometry, and support margins are explicit hypotheses.
-/
noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

/-- The cubic integral form of the bounded profile estimate. No fine-frame
transport, reconstruction, or remainder estimate is assumed as a bridge. -/
theorem bounded_profile_cubed {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F A Q : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hA : 0≤A) (hQ : 0≤Q)
    (hA₁ : A+1 ≤ S.C₁) (hQ₂ : Q+1 ≤ S.C₂) (M : ℕ) (hM : 2<M) :
    ∃ Z : ℝ, 0<Z ∧ (F+Z ≤ S.frequencyBound →
      ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
        let N : ℝ := (2:ℝ)^j
        ∀ (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
          (ν : ι → Plane) (r : Plane),
        (∀ i ∈ s, ‖ν i‖ ≤ F) →
        (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N ≤ ‖ν i-ν k‖) →
        (∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) →
        (∫ y in Metric.closedBall (0:Plane) (Q*N^2) ×ˢ Icc 0 (N^2),
          ‖∑ i ∈ s, ∑ p ∈ pbox, a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y‖^3) ≤
        C * (P*N^(10*κ+η)*Real.log (2+N)^2+1) *
          ∫ y : Space in spatialSlab (N^2),
            (spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
              (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2)
              N (M:ℝ) y)^(3/2:ℝ)) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨ρ, ζ, hρ, hρ', hζ, hsupp, hζb, hζone, hζs, hform, hφ, hrest⟩
    exact hφ
  obtain ⟨Z,B,hZ,hB,happrox⟩ := profile_fine_discrete_approximation (ι := ι)
    S hφ.continuous b hb hbs 7 (by norm_num)
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  obtain ⟨D,hD,hdensity⟩ := fine_frame_integrated_density (ι := ι) S hphase b hb hbs hc hσ M hM
  obtain ⟨C,hC,hdiscrete⟩ := local_discrete_cubed_of_external S hphase hinput Q hQ₂
  let E := Real.pi*Q^2*B^3*(profileLabelCountConstant c σ F A)^2 /
    (Real.pi*(2:ℝ)^(-((M:ℝ)*(3/2))))
  have hE : 0≤E := by dsimp [E]; positivity
  refine ⟨4*(C*D+E)+1,by positivity,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hp⟩ := hdiscrete κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N s pbox a ν r hν hsep hv
  have hN : 1≤N := one_le_pow₀ (by norm_num)
  have hN0 : 0<N := by linarith
  obtain ⟨q,hq,hqtail⟩ := happrox N hN c A F hA₁ hFZ s pbox a ν r hν hv
  let U := Metric.closedBall (0:Plane) (Q*N^2) ×ˢ Icc 0 (N^2)
  let f := fun y => ∑ i ∈ s, ∑ p ∈ pbox,
    a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y
  let g := discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
    (profileFineCoefficient S b N c s pbox a ν r)
  let e := fun y => f y-g y
  let H := ∫ y : Space in spatialSlab (N^2),
    (spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
      (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2) N (M:ℝ) y)^(3/2:ℝ)
  let loss := P*N^(10*κ+η)*Real.log (2+N)^2+1
  have hH : 0≤H := integral_nonneg (fun _ => Real.rpow_nonneg
    (Finset.sum_nonneg (fun k hk => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))) _)
  have hloss : 1≤loss := by
    have hh : 0≤P*N^(10*κ+η)*Real.log (2+N)^2 := by positivity
    dsimp [loss]; linarith
  have hfc : Continuous f := continuous_finset_sum s (fun i hi =>
    continuous_finset_sum pbox (fun p hp => continuous_const.mul
      (continuous_freePacket S.φ hφ.continuous b hb.continuous hbs hN0.ne' _ _)))
  have hgc : Continuous g := continuous_discreteExtension S hφ.continuous hN _ _ hq
  have hU := (isCompact_closedBall (0:Plane) (Q*N^2)).prod (isCompact_Icc : IsCompact (Icc (0:ℝ) (N^2)))
  have hgi : IntegrableOn (fun y => ‖g y‖^3) U volume :=
    (hgc.norm.pow 3).continuousOn.integrableOn_compact hU
  have hei : IntegrableOn (fun y => ‖e y‖^3) U volume :=
    ((hfc.sub hgc).norm.pow 3).continuousOn.integrableOn_compact hU
  have hMr : (2:ℝ)<M := by exact_mod_cast hM
  have herr : (∫ y in U, ‖e y‖^3) ≤ E*H :=
    fine_remainder_absorbed S.φ s pbox a ν r hN hc hσ hF hA hQ hB.le
      (by nlinarith : (2:ℝ)<(M:ℝ)*(3/2)) hν hsep hv e (by simpa only [Nat.cast_ofNat, show (7:ℝ)-3=4 by norm_num] using hqtail)
  have hret : (∫ y in U, ‖g y‖^3) ≤ C*loss*D*H := by
    have hh := hp j hj (q ×ˢ fineRetainedPositions S N A)
      (profileFineCoefficient S b N c s pbox a ν r) hq
    have hh' := hdensity hN0 s pbox q (fineRetainedPositions S N A) a ν r hsep
    apply hh.trans
    convert mul_le_mul_of_nonneg_left hh' (mul_nonneg hC.le (by linarith : 0≤loss)) using 1 <;> ring
  have heq (y : Space) : f y = g y+e y := by dsimp [e]; ring
  calc
    _ = ∫ y in U, ‖g y+e y‖^3 := by simp only [← heq]; rfl
    _ ≤ 4*((∫ y in U, ‖g y‖^3)+(∫ y in U, ‖e y‖^3)) :=
      integral_norm_add_cubed_le (volume.restrict U) g e hgi hei
    _ ≤ 4*(C*loss*D*H+E*H) := by linarith [hret,herr]
    _ ≤ (4*(C*D+E)+1)*loss*H := by nlinarith [mul_nonneg hE hH]

/-- Corrected (4.14) for finite profiles on a common translated isotropic
position lattice, with separated original frequencies and natural decay order.
The whole-plane density integration and setup support margins are explicit. -/
theorem corrected_equation_4_14_common_lattice {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F A Q : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hA : 0≤A) (hQ : 0≤Q)
    (hA₁ : A+1 ≤ S.C₁) (hQ₂ : Q+1 ≤ S.C₂) (M : ℕ) (hM : 2<M) :
    ∃ Z : ℝ, 0<Z ∧ (F+Z ≤ S.frequencyBound →
      ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
        let N : ℝ := (2:ℝ)^j
        ∀ (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
          (ν : ι → Plane) (r : Plane),
        (∀ i ∈ s, ‖ν i‖ ≤ F) →
        (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N ≤ ‖ν i-ν k‖) →
        (∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) →
        ∀ W : Set Plane, W ⊆ Metric.closedBall (0:Plane) (Q*N^2) →
        LocalProfileEstimate S.φ b (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
          (fun ip => ν ip.1) (fun ip => r+N • latticePoint c ip.2)
          N (M:ℝ) P κ η C W) := by
  obtain ⟨Z,hZ,hbound⟩ := bounded_profile_cubed (ι := ι) S hphase hinput b hb hbs
    hc hσ hF hA hQ hA₁ hQ₂ M hM
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  obtain ⟨C,hC,hcubic⟩ := hbound hFZ
  let B := localLossAbsorptionConstant
  have hB : 0<B := localLossAbsorptionConstant_pos
  have hCB : 0<C*B := mul_pos hC hB
  have hcube : C*B ≤ (C*B+1)^3 := by nlinarith [sq_nonneg (C*B), pow_nonneg hCB.le 3]
  refine ⟨C*B+1,by positivity,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hp⟩ := hcubic κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N s pbox a ν r hν hsep hv W hW
  have hN : 1≤N := one_le_pow₀ (by norm_num)
  have hN0 : 0<N := by linarith
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨ρ, ζ, hρ, hρ', hζ, hsupp, hζb, hζone, hζs, hform, hφ, hrest⟩
    exact hφ
  let f := fun y => ∑ ip ∈ s ×ˢ pbox,
    a ip.1 ip.2 * freePacket S.φ b N (ν ip.1) (r+N • latticePoint c ip.2) y
  let H := spatialDensity (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2) N (M:ℝ)
  let D := ∫ y : Space in spatialSlab (N^2), (H y)^(3/2:ℝ)
  let U := Metric.closedBall (0:Plane) (Q*N^2) ×ˢ Icc 0 (N^2)
  let p := packetConstant P κ η (N^2)
  have hD : 0≤D := integral_nonneg (fun _ => Real.rpow_nonneg
    (Finset.sum_nonneg (fun k hk => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))) _)
  have hp0 : 0≤p := by
    have hP0 : 0≤P := by linarith
    have hl : 0≤Real.log (2+N^2) := Real.log_nonneg (by nlinarith [sq_nonneg N])
    dsimp [p,packetConstant]; positivity
  have hfc : Continuous f := continuous_finset_sum (s ×ˢ pbox) (fun ip hip =>
    continuous_const.mul (continuous_freePacket S.φ hφ.continuous b hb.continuous hbs hN0.ne' _ _))
  have hfi : IntegrableOn (fun y => ‖f y‖^3) U volume :=
    (hfc.norm.pow 3).continuousOn.integrableOn_compact ((isCompact_closedBall _ _).prod isCompact_Icc)
  have hh : (∫ y in U, ‖f y‖^3) ≤ ((C*B+1)*p)^3*D := by
    calc
      _ ≤ C*(P*N^(10*κ+η)*Real.log (2+N)^2+1)*D := by
        simpa only [f,Finset.sum_product] using hp j hj s pbox a ν r hν hsep hv
      _ ≤ C*(B*p^3)*D := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left (local_loss_absorption hP hN hκ.le hη.le) hC.le) hD
      _ = C*B*(p^3*D) := by ring
      _ ≤ (C*B+1)^3*(p^3*D) := mul_le_mul_of_nonneg_right hcube (by positivity)
      _ = _ := by ring
  have hn := l3_le_of_cubic_integral (volume.restrict U) f hfi
    (mul_nonneg (by positivity) hp0) hh
  have hMr : (2:ℝ)<M := by exact_mod_cast hM
  rw [← spatial_densityCubeRoot_eq_integral (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity S.φ (ν ip.1)) (fun ip => r+N • latticePoint c ip.2)
    hN0.ne' (by nlinarith : (2:ℝ)<(M:ℝ)*(3/2))] at hn
  apply le_trans _ hn
  apply eLpNorm_mono_measure
  apply Measure.restrict_mono _ le_rfl
  intro y hy
  exact ⟨hW hy.1,hy.2⟩

/-- Reducing the decay exponent increases the profile density. -/
theorem spatialDensity_mono_decay {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N : ℝ) {M L : ℝ} (hML : M≤L) (y : Space) :
    spatialDensity s a V v N L y ≤ spatialDensity s a V v N M y := by
  apply Finset.sum_le_sum
  intro i hi
  apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
  apply Real.rpow_le_rpow_of_exponent_le
  · dsimp [spatialWeight,bracket]; linarith [norm_nonneg (N⁻¹ • (y.1-v i+y.2 • V i))]
  · linarith

theorem densityCubeRoot_mono (H K : Space → ℝ) (R : ℝ) (h : ∀ y, H y≤K y) :
    densityCubeRoot H R ≤ densityCubeRoot K R := by
  apply ENNReal.rpow_le_rpow _ (by norm_num : (0:ℝ)≤1/3)
  apply lintegral_mono
  intro y
  exact ENNReal.rpow_le_rpow (ENNReal.ofReal_le_ofReal (h y)) (by norm_num : (0:ℝ)≤3/2)

theorem localProfileEstimate_mono_decay {ι : Type*} {φ : Phase} {b : Plane → ℂ}
    {s : Finset ι} {a : ι → ℂ} {ν v : ι → Plane} {N M L P κ η C : ℝ} {Q : Set Plane}
    (h : LocalProfileEstimate φ b s a ν v N L P κ η C Q) (hML : M≤L) :
    LocalProfileEstimate φ b s a ν v N M P κ η C Q := by
  apply h.trans
  exact mul_le_mul_left' (densityCubeRoot_mono _ _ (N^2)
    (fun y => spatialDensity_mono_decay s a _ v N hML y)) _

/-- The bounded common-lattice estimate for every real decay exponent above two. -/
theorem corrected_equation_4_14_common_lattice_real_decay {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F A Q : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hA : 0≤A) (hQ : 0≤Q)
    (hA₁ : A+1 ≤ S.C₁) (hQ₂ : Q+1 ≤ S.C₂) (M : ℝ) (hM : 2<M) :
    ∃ Z : ℝ, 0<Z ∧ (F+Z ≤ S.frequencyBound →
      ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
        let N : ℝ := (2:ℝ)^j
        ∀ (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
          (ν : ι → Plane) (r : Plane),
        (∀ i ∈ s, ‖ν i‖ ≤ F) →
        (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N ≤ ‖ν i-ν k‖) →
        (∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) →
        ∀ W : Set Plane, W ⊆ Metric.closedBall (0:Plane) (Q*N^2) →
        LocalProfileEstimate S.φ b (s ×ˢ pbox) (fun ip => a ip.1 ip.2)
          (fun ip => ν ip.1) (fun ip => r+N • latticePoint c ip.2)
          N M P κ η C W) := by
  let L : ℕ := ⌈M⌉₊
  have hML : M≤(L:ℝ) := Nat.le_ceil M
  have hL : 2<L := by exact_mod_cast (hM.trans_le hML)
  obtain ⟨Z,hZ,hZbound⟩ := corrected_equation_4_14_common_lattice (ι := ι)
    S hphase hinput b hb hbs hc hσ hF hA hQ hA₁ hQ₂ L hL
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  obtain ⟨C,hC,hbound⟩ := hZbound hFZ
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hp⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N s pbox a ν r hν hsep hv W hW
  exact localProfileEstimate_mono_decay (hp j hj s pbox a ν r hν hsep hv W hW) hML

end EllipticSquareFunction
