import EllipticSquareFunction.SamplingSupportBox
import EllipticSquareFunction.SamplingIndices

noncomputable section
open MeasureTheory Set
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- Uniform packet expansion of inverse Fourier data supported in a curved cap.
The profiles and positive integer oversampling are constructed before R and ν.
This proves the synthesis part of Lemma 4 for inverse-transform data; Fourier
inversion for the article's physical Schwartz functions and the density bound
are separate obligations. -/
theorem uniform_inverse_cap_packet_expansion {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ : ℝ} (hC₀ : 0≤C₀) :
    ∃ χ : Plane → ℂ, ∃ ρ : SchwartzMap ℝ ℂ, ∃ D : ℕ,
      ContDiff ℝ (⊤ : ℕ∞) χ ∧ HasCompactSupport χ ∧
      HasCompactSupport (ρ : ℝ → ℂ) ∧ 0<D ∧
      ∀ R : ℝ, 0<R → ∀ ν : Plane, ∀ f : Space → ℂ,
      Continuous f → HasCompactSupport f →
      Function.support f ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀ → ∀ y : Space,
      let p := fun i : IntPlane × ℤ => samplePoint (Real.sqrt R) R D D
        (velocity φ ν) (latticePoint 1 i.1) i.2
      HasSum (fun i : IntPlane × ℤ =>
        ((((D:ℝ)^3)⁻¹:ℝ)*inverseSpaceTransform f (p i))*
          timePacket φ χ (inverseTimeProfile ρ) R ν (p i).1 (p i).2 y)
        (inverseSpaceTransform f y) := by
  obtain ⟨χ,hχ,hχs,hχone,ρ,hρs,hρone⟩ := exists_sampling_cutoffs hC₀
  obtain ⟨C₁,hC₁,hsupp⟩ := curvedMultiplier_support_cap χ hχs ρ hρs
  obtain ⟨C,hC,hcapbox⟩ := continuedPhase_cap_box hphase
  obtain ⟨D,hD,hbox⟩ := exists_integer_spaceBox (max C₀ C₁)
    (max (C₀+C*C₀^2) (C₁+C*C₁^2))
  refine ⟨χ,ρ,D,hχ,hχs,hρs,hD,?_⟩
  intro R hR ν f hf hfs hfcap y p
  let r := Real.sqrt R
  have hr : 0<r := Real.sqrt_pos.mpr hR
  have hsq : r^2=R := Real.sq_sqrt hR.le
  let e := curvedFrequencyHomeomorph (tangentPhase ν (velocity φ ν) (φ ν))
    (continuous_tangentPhase ν (velocity φ ν) (φ ν)) hr.ne' hR.ne' ν
  have he (ζ : Space) : e ζ=affineFrequencyCoordinates φ ν r R ζ :=
    tangent_homeomorph_eq_coordinates φ ν hr.ne' hR.ne' ζ
  have hfb : Function.support (fun z => f (e.symm z)) ⊆ spaceBox (fun _ => -(1/2:ℝ)) (D:ℝ) := by
    intro z hz
    have hh := hcapbox ν r C₀ hr (e.symm z) (hfcap hz)
    simp only [hsq] at hh
    have hb := hbox (e (e.symm z)) ((by rw [he]; exact hh.1.trans (le_max_left _ _)))
      ((by rw [he]; exact hh.2.trans (le_max_left _ _)))
    simpa only [e.apply_symm_apply] using hb
  have hmb : Function.support (fun z => curvedMultiplier φ χ ρ r R ν (e.symm z)) ⊆
      spaceBox (fun _ => -(1/2:ℝ)) (D:ℝ) := by
    intro z hz
    have hc : e.symm z ∈ cap φ ν r⁻¹ C₁ := by
      apply hsupp φ r hr ν
      simpa only [hsq] using hz
    have hh := hcapbox ν r C₁ hr (e.symm z) hc
    simp only [hsq] at hh
    have hb := hbox (e (e.symm z)) ((by rw [he]; exact hh.1.trans (le_max_right _ _)))
      ((by rw [he]; exact hh.2.trans (le_max_right _ _)))
    simpa only [e.apply_symm_apply] using hb
  have hone (ζ : Space) (hz : ζ ∈ Function.support f) : curvedMultiplier φ χ ρ r R ν ζ=1 := by
    have hh := curvedMultiplier_one_on_cap φ χ ρ hr hχone hρone ν (hfcap hz)
    simpa only [hsq] using hh
  have hφ : Continuous φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  have hh := affine_curved_packet_sampling φ hφ χ hχ.continuous hχs ρ hρs ν
    (velocity φ ν) hR (by exact_mod_cast hD) (fun _ => -(1/2:ℝ)) f hf hfs hfb hmb hone y
  exact (sampling_hasSum_reindex r R (D:ℝ) (velocity φ ν)
    (fun q => ((((D:ℝ)^3)⁻¹:ℝ)*inverseSpaceTransform f q)*
      timePacket φ χ (inverseTimeProfile ρ) R ν q.1 q.2 y) (inverseSpaceTransform f y)).mp hh

end EllipticSquareFunction
