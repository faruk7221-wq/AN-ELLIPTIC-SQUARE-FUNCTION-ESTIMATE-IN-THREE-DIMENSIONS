import EllipticSquareFunction.ArrayRelabeling
import EllipticSquareFunction.PropositionThreeMargins
import EllipticSquareFunction.EnlargedSetup

noncomputable section
namespace EllipticSquareFunction

/-- Proposition 3 with constants uniform in the number of caps: use ℕ once as
the ambient label type, then embed every Fin n without changing constants. -/
theorem single_profile_enlarged_uniform_cap_count
    (T₀ : DiscreteSetup) (hphase : ContinuedPhase T₀.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (ψ : SchwartzMap ℝ ℂ) {c σ F M : ℝ}
    (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=T₀.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      T₀.frequencyBound≤S.frequencyBound ∧ T₀.C₁≤S.C₁ ∧ T₀.C₂≤S.C₂ ∧
      (DiscreteDensityInput S → ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ,
        0<κ → κ<1/10 → 0<η → η≤1 → ∃ P : ℝ, 1≤P ∧ ∀ n : ℕ,
        UniformTimeProfileBound (Fin n) T₀.φ b ψ c σ F M C P κ η) := by
  obtain ⟨Z,A,Z',hZ,hA,hZ',hbound⟩ := proposition_three_unit_uniform_setup_margins (ι := ℕ)
    T₀ hphase b hb hbs ψ hc hσ hF hM
  let S := enlargeSetup T₀ (F+Z+Z') (A+1) 3
  refine ⟨S,rfl,rfl,rfl,le_max_left _ _,le_max_left _ _,le_max_left _ _,?_⟩
  intro hinput
  obtain ⟨C,hC,hbound⟩ := hbound S rfl rfl hinput
    (le_max_right _ _) (le_max_right _ _) (le_max_right _ _)
  have hφ : Continuous T₀.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,fun n => ?_⟩
  exact uniformTimeProfileBound_of_embedding Fin.valEmbedding T₀.φ b ψ c σ F M C P κ η
    (uniform_time_profile_of_unit T₀.φ hφ b hb.continuous hbs ψ ψ.continuous
      c σ F M C P κ η hbound)

end EllipticSquareFunction
