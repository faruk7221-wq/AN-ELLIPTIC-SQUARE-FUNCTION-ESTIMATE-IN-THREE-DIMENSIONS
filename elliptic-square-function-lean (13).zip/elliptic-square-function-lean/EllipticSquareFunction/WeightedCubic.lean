import EllipticSquareFunction.GlobalAssembly
import Mathlib.Analysis.MeanInequalities

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

theorem ennreal_weighted_cubic {ι : Type*} (s : Finset ι) (q u : ι → ℝ≥0∞) :
    (∑ i ∈ s, q i*u i)^3 ≤ (∑ i ∈ s, q i)^2*(∑ i ∈ s, q i*u i^3) := by
  have hc : (3/2:ℝ).HolderConjugate 3 := by
    apply Real.holderConjugate_iff.mpr
    norm_num
  have h := ENNReal.inner_le_Lp_mul_Lq s
    (fun i => q i^(2/3:ℝ)) (fun i => q i^(1/3:ℝ)*u i) hc
  have he (x y : ℝ≥0∞) : x^(2/3:ℝ)*(x^(1/3:ℝ)*y)=x*y := by
    rw [← mul_assoc,← ENNReal.rpow_add_of_nonneg (2/3:ℝ) (1/3:ℝ) (by norm_num) (by norm_num)]
    norm_num
  have hf (x : ℝ≥0∞) : (x^(2/3:ℝ))^(3/2:ℝ)=x := by
    rw [← ENNReal.rpow_mul]; norm_num
  have hg (x y : ℝ≥0∞) : (x^(1/3:ℝ)*y)^(3:ℝ)=x*y^3 := by
    rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num),← ENNReal.rpow_mul]
    norm_num
  simp only [he,hf,hg] at h
  have hh := pow_le_pow_left' h 3
  rw [mul_pow] at hh
  norm_num only [one_div] at hh
  have h₂ (x : ℝ≥0∞) : (x^(2/3:ℝ))^3=x^2 := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]; norm_num
  have h₃ (x : ℝ≥0∞) : (x^(1/3:ℝ))^3=x := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]; norm_num
  norm_num only [inv_div,div_one] at hh
  simpa only [h₂,h₃] using hh

theorem ennreal_sum_three_halves {ι : Type*} (s : Finset ι) (x : ι → ℝ≥0∞) :
    (∑ i ∈ s, x i^(3/2:ℝ)) ≤ (∑ i ∈ s, x i)^(3/2:ℝ) := by
  have he (a : ℝ≥0∞) : a^(3/2:ℝ)=a*a^(1/2:ℝ) := by
    rw [show (3/2:ℝ)=1+1/2 by norm_num,
      ENNReal.rpow_add_of_nonneg 1 (1/2) (by norm_num) (by norm_num),ENNReal.rpow_one]
  simp_rw [he]
  calc
    _ ≤ ∑ i ∈ s, x i*(∑ k ∈ s, x k)^(1/2:ℝ) := by
      apply Finset.sum_le_sum
      intro i hi
      exact mul_le_mul_left' (ENNReal.rpow_le_rpow (Finset.single_le_sum (fun _ _ => zero_le _) hi) (by norm_num)) _
    _ = _ := (Finset.sum_mul ..).symm

theorem ennreal_weighted_density_sum {ι : Type*} (s : Finset ι) (q d : ι → ℝ≥0∞) :
    (∑ i ∈ s, q i*d i^(3/2:ℝ)) ≤
      (∑ i ∈ s, q i^(2/3:ℝ)*d i)^(3/2:ℝ) := by
  have he (x y : ℝ≥0∞) : (x^(2/3:ℝ)*y)^(3/2:ℝ)=x*y^(3/2:ℝ) := by
    rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num),← ENNReal.rpow_mul]
    norm_num
  simpa only [he] using ennreal_sum_three_halves s (fun i => q i^(2/3:ℝ)*d i)

/-- The finite weighted cubic step in (5.11). Extended-real integrals require
no prior global integrability of the density or the target function. -/
theorem l3_weighted_cubic_assembly {ι : Type*} (s : Finset ι) (μ : Measure Space)
    (F : ι → Space → ℂ) (D : ι → Space → ℝ≥0∞) (q : ι → ℝ≥0∞) (C : ℝ≥0∞)
    (hF : ∀ i ∈ s, AEStronglyMeasurable (F i) μ) (hD : ∀ i ∈ s, Measurable (D i))
    (hbound : ∀ i ∈ s, l3 (F i) μ≤C*q i*(∫⁻ y, D i y^(3/2:ℝ) ∂μ)^(1/3:ℝ)) :
    (l3 (fun y => ∑ i ∈ s, F i y) μ)^3 ≤
      C^3*(∑ i ∈ s, q i)^2*
        (∫⁻ y, (∑ i ∈ s, q i^(2/3:ℝ)*D i y)^(3/2:ℝ) ∂μ) := by
  have hsum : l3 (fun y => ∑ i ∈ s, F i y) μ ≤
      C*(∑ i ∈ s, q i*(∫⁻ y, D i y^(3/2:ℝ) ∂μ)^(1/3:ℝ)) := by
    have hh := eLpNorm_sum_le hF (by norm_num : (1:ℝ≥0∞)≤3)
    have he : (∑ i ∈ s, F i)=(fun y => ∑ i ∈ s, F i y) := by ext y; simp
    rw [he] at hh
    apply hh.trans
    rw [Finset.mul_sum]
    exact Finset.sum_le_sum (fun i hi => by simpa only [mul_assoc] using hbound i hi)
  have hh := pow_le_pow_left' hsum 3
  rw [mul_pow] at hh
  have hc := ennreal_weighted_cubic s q (fun i => (∫⁻ y, D i y^(3/2:ℝ) ∂μ)^(1/3:ℝ))
  have he (x : ℝ≥0∞) : (x^(1/3:ℝ))^3=x := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]; norm_num
  simp only [he] at hc
  apply (hh.trans (mul_le_mul_left' hc _)).trans
  rw [← mul_assoc]
  apply mul_le_mul_left'
  calc
    _ = ∫⁻ y, ∑ i ∈ s, q i*D i y^(3/2:ℝ) ∂μ := by
      rw [lintegral_finset_sum s (fun i hi => measurable_const.mul ((hD i hi).pow_const _))]
      apply Finset.sum_congr rfl
      intro i hi
      rw [lintegral_const_mul _ ((hD i hi).pow_const _)]
    _ ≤ _ := lintegral_mono (fun y => ennreal_weighted_density_sum s q (fun i => D i y))

end EllipticSquareFunction
