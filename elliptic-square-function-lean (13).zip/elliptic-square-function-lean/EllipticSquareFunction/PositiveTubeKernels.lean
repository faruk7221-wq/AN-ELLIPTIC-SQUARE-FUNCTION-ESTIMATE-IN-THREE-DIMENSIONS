import EllipticSquareFunction.NormalizedDyadicTubes
import EllipticSquareFunction.TubeAverages

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Nonnegativity and measurability of normalized tube-average kernels. -/
theorem symmetricTubeAverageKernel_nonneg (r T : ℝ) (V : Plane) (y : Space) :
    0≤symmetricTubeAverageKernel r T V y := by
  unfold symmetricTubeAverageKernel
  apply mul_nonneg (inv_nonneg.mpr (ENNReal.toReal_nonneg))
  exact Set.indicator_nonneg (fun _ _ => by norm_num) y

theorem measurable_symmetricTubeAverageKernel (r T : ℝ) (V : Plane) :
    Measurable (symmetricTubeAverageKernel r T V) :=
  (measurable_const.indicator (measurableSet_symmetricTube r T V)).const_mul _

/-- The real unit-mass kernel agrees with the nonnegative set-average
normalization, with no finiteness assumption on the tested function. -/
theorem lintegral_symmetricTubeAverageKernel {r T : ℝ} (hr : 0<r) (hT : 0<T)
    (V : Plane) (g : Space → ℝ≥0∞) (hg : Measurable g) :
    (∫⁻ z, ENNReal.ofReal (symmetricTubeAverageKernel r T V z)*g z)=
      (volume (symmetricTube r T V))⁻¹*(∫⁻ z in symmetricTube r T V, g z) := by
  have hvol : 0<volume.real (symmetricTube r T V) := by
    rw [real_volume_symmetricTube hr.le hT.le]
    positivity
  have hfin : volume (symmetricTube r T V)≠⊤ := by
    rw [volume_symmetricTube]
    exact ENNReal.mul_ne_top (ENNReal.mul_ne_top (ENNReal.pow_ne_top ENNReal.ofReal_ne_top)
      ENNReal.ofReal_ne_top) ENNReal.ofReal_ne_top
  have he (z : Space) : ENNReal.ofReal (symmetricTubeAverageKernel r T V z)*g z=
      (volume (symmetricTube r T V))⁻¹*(symmetricTube r T V).indicator g z := by
    by_cases hz : z∈symmetricTube r T V
    · simp only [symmetricTubeAverageKernel,Set.indicator_of_mem hz,mul_one,
        measureReal_def]
      have hp : 0 < (volume (symmetricTube r T V)).toReal := hvol
      rw [ENNReal.ofReal_inv_of_pos hp, ENNReal.ofReal_toReal hfin]
    · simp only [symmetricTubeAverageKernel,Set.indicator_of_not_mem hz,mul_zero,ENNReal.ofReal_zero,zero_mul]
  simp_rw [he]
  rw [lintegral_const_mul'' _ (hg.indicator (measurableSet_symmetricTube r T V)).aemeasurable,
    lintegral_indicator (measurableSet_symmetricTube r T V)]

/-- Each normalized sheared tube convolution is pointwise bounded by a
Nikodym maximal function of one fixed length for the whole direction family. -/
theorem normalized_tube_kernel_le_nikodym (h : Space → ℝ) (hh : Measurable h) (x : Space)
    {r T F : ℝ} (hr : 0<r) (hT : 0<T) (hrT : r≤T) (hF : 0≤F)
    (V : Plane) (hV : ‖V‖≤F) :
    (∫⁻ z, ENNReal.ofReal (symmetricTubeAverageKernel r T V z)*ENNReal.ofReal |h (x+z)|) ≤
      ENNReal.ofReal (2*(1+F)^3)*nikodym (r/(2*(1+F)*T)) (2*(1+F)*T) h x := by
  rw [lintegral_symmetricTubeAverageKernel hr hT V (fun z => ENNReal.ofReal |h (x+z)|)
    ((hh.comp ((measurable_const : Measurable (fun _ : Space => x)).add measurable_id)).abs.ennreal_ofReal)]
  exact symmetric_tube_average_le_nikodym h x hr hT hrT hF V hV

end EllipticSquareFunction
