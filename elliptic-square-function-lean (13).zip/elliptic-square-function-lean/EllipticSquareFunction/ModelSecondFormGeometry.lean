import EllipticSquareFunction.BoundaryManifoldAdapter
import EllipticSquareFunction.SecondFormSymmetry

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
  (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]

theorem model_surface_param_smooth [IsManifold I (⊤ : ℕ∞) M]
    {f : M → EuclideanThree} (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (x : M) :
    ContDiffOn ℝ (⊤ : ℕ∞) (modelSurfaceParam I f x) (extChartAt I x).target :=
  (hf.comp_contMDiffOn (contMDiffOn_extChartAt_symm (I := I) x)).contDiffOn

/-- Symmetry holds intrinsically on a boundary chart, without assuming
the existence of a smooth extension to an open domain. -/
theorem model_second_form_symmetric [IsManifold I (⊤ : ℕ∞) M]
    {f : M → EuclideanThree} (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (x : M) (N : EuclideanThree) (v w : Plane) :
    modelSecondForm I f x N v w = modelSecondForm I f x N w v := by
  have ha := mem_extChartAt_target (I := I) x
  have hp : ContDiffWithinAt ℝ 2 (modelSurfaceParam I f x) (extChartAt I x).target
      (extChartAt I x x) := (model_surface_param_smooth I hf x _ ha).of_le (by norm_cast)
  have hs := hp.isSymmSndFDerivWithinAt
    (by norm_num) (uniqueDiffOn_extChartAt_target x)
    (extChartAt_target_subset_closure_interior ha) ha
  unfold modelSecondForm
  rw [hs.eq v w]

theorem model_second_form_add_left (f : M → EuclideanThree) (x : M)
    (N : EuclideanThree) (u v w : Plane) :
    modelSecondForm I f x N (u+v) w = modelSecondForm I f x N u w+modelSecondForm I f x N v w := by
  simp [modelSecondForm,map_add,inner_add_right]

theorem model_second_form_smul_left (f : M → EuclideanThree) (x : M)
    (N : EuclideanThree) (v w : Plane) (c : ℝ) :
    modelSecondForm I f x N (c • v) w = c*modelSecondForm I f x N v w := by
  simp [modelSecondForm,map_smul,inner_smul_right]

theorem model_definite_second_form_neg_iff (f : M → EuclideanThree) (x : M)
    (N : EuclideanThree) :
    ModelDefiniteSecondForm I f x (-N) ↔ ModelDefiniteSecondForm I f x N := by
  unfold ModelDefiniteSecondForm modelSecondForm
  simp only [inner_neg_left,neg_pos,neg_lt_zero]
  exact or_comm

/-- Definiteness of the intrinsic boundary-chart form is independent of
the unit normal, using only injectivity of the manifold derivative. -/
theorem model_definite_second_form_normal_independent {f : M → EuclideanThree} (x : M)
    (hD : Function.Injective (mfderiv I 𝓘(ℝ, EuclideanThree) f x))
    (N P : EuclideanThree) (hN : ‖N‖=1) (hP : ‖P‖=1)
    (hNo : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0)
    (hPo : ∀ v, @inner ℝ EuclideanThree _ P (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0) :
    ModelDefiniteSecondForm I f x P ↔ ModelDefiniteSecondForm I f x N := by
  rcases euclidean_unit_normal_unique _ hD N P hN hP hNo hPo with he | he
  · rw [he]
  · rw [he]
    exact model_definite_second_form_neg_iff I f x N

/-- For a boundaryless model, smoothness itself supplies the extension.
The model target is open, so no extension theorem is needed. -/
theorem boundaryless_model_has_smooth_extensions [I.Boundaryless]
    [IsManifold I (⊤ : ℕ∞) M] {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) :
    HasSmoothModelExtensions I f := by
  intro x
  exact ⟨modelSurfaceParam I f x,(extChartAt I x).target,isOpen_extChartAt_target x,
    mem_extChartAt_target x,model_surface_param_smooth I hf x,fun _ _ => rfl⟩

end EllipticSquareFunction
