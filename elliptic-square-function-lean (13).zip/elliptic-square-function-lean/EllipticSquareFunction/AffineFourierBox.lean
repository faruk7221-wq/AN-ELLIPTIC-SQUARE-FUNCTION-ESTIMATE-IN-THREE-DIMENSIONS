import EllipticSquareFunction.AffineFrequency

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem spaceFrequencyLattice_neg (D : ℝ) (n : Fin 3 → ℤ) :
    spaceFrequencyLattice D (-n)= -spaceFrequencyLattice D n := by
  apply Prod.ext
  · ext i
    simp [spaceFrequencyLattice,latticePoint]
  · simp [spaceFrequencyLattice]

theorem unshearScale_neg (r R : ℝ) (V : Plane) (q : Space) :
    unshearScale r R V (-q)= -unshearScale r R V q := by
  apply Prod.ext
  · simp only [unshearScale,Prod.fst_neg,Prod.snd_neg,mul_neg,neg_smul,smul_neg]
    abel
  · simp [unshearScale]

/-- Reconstruction on an affine tangent-frequency box. The box volume factor
is exactly r² R / D³. The index is a genuine three-dimensional integer lattice. -/
theorem affine_box_reconstruction (ν V : Plane) (h : ℝ)
    {r R D : ℝ} (hr : 0<r) (hR : 0<R) (hD : 0<D) (a : Fin 3 → ℝ)
    (f g : Space → ℂ) (hf : Continuous f) (hg : Continuous g)
    (hfs : HasCompactSupport f) (hgs : HasCompactSupport g)
    (hfb : Function.support (fun z => f ((curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν).symm z)) ⊆ spaceBox a D)
    (hgb : Function.support (fun z => g ((curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν).symm z)) ⊆ spaceBox a D) :
    HasSum (fun n : Fin 3 → ℤ => ((r^2*R/D^3:ℝ):ℂ)*
      (inverseSpaceTransform f (unshearScale r R V (spaceFrequencyLattice D n))*
       inverseSpaceTransform g (-unshearScale r R V (spaceFrequencyLattice D n))))
      (∫ ζ : Space, f ζ*g ζ) := by
  let e := curvedFrequencyHomeomorph (tangentPhase ν V h)
    (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν
  let J : ℂ := ((r^2*R:ℝ):ℂ)
  have hJ : J≠0 := by dsimp [J]; exact_mod_cast (mul_ne_zero (pow_ne_zero 2 hr.ne') hR.ne')
  have hh := space_box_reconstruction a hD (hf.comp e.symm.continuous)
    (hg.comp e.symm.continuous) hfb hgb
  have hc (n : Fin 3 → ℤ) :
      inverseSpaceTransform (fun z => f (e.symm z)) (spaceFrequencyLattice D n)*
      inverseSpaceTransform (fun z => g (e.symm z)) (spaceFrequencyLattice D (-n)) =
      J^2*(inverseSpaceTransform f (unshearScale r R V (spaceFrequencyLattice D n))*
        inverseSpaceTransform g (-unshearScale r R V (spaceFrequencyLattice D n))) := by
    rw [inverse_affine_frequency_coordinates ν V h hr hR f hf hfs,
      inverse_affine_frequency_coordinates ν V h hr hR g hg hgs,
      spaceFrequencyLattice_neg,unshearScale_neg,spacePair_neg_left,neg_neg]
    have ho (s : ℝ) : oscillation (-s)*oscillation s=1 := by
      rw [← oscillation_add]
      simp [oscillation]
    change J*oscillation _*_* (J*oscillation _*_) = _
    calc
      _ = J^2*(oscillation (-spacePair (unshearScale r R V (spaceFrequencyLattice D n)) (ν,h))*
          oscillation (spacePair (unshearScale r R V (spaceFrequencyLattice D n)) (ν,h)))*
          (inverseSpaceTransform f (unshearScale r R V (spaceFrequencyLattice D n))*
            inverseSpaceTransform g (-unshearScale r R V (spaceFrequencyLattice D n))) := by ring
      _ = _ := by rw [ho,mul_one]
  have he : (∫ z : Space, f (e.symm z)*g (e.symm z))=J*(∫ ζ : Space, f ζ*g ζ) :=
    integral_curved_frequency_inverse (tangentPhase ν V h) (continuous_tangentPhase ν V h)
      hr hR ν (fun ζ => f ζ*g ζ) (hf.mul hg) hfs.mul_right
  simp only [Function.comp_def,hc,he] at hh
  have hh' := hh.mul_left J⁻¹
  convert hh' using 1
  · funext n
    simp only [Complex.real_smul]
    have hcoef : ((r^2*R/D^3:ℝ):ℂ)=(((D^3)⁻¹:ℝ):ℂ)*J := by
      dsimp [J]
      push_cast
      ring
    rw [hcoef]
    let X := inverseSpaceTransform f (unshearScale r R V (spaceFrequencyLattice D n))*
      inverseSpaceTransform g (-unshearScale r R V (spaceFrequencyLattice D n))
    let k : ℂ := (((D^3)⁻¹:ℝ):ℂ)
    change k*J*X=J⁻¹*(k*(J^2*X))
    calc
      _ = (J⁻¹*J)*(k*J*X) := by rw [inv_mul_cancel₀ hJ,one_mul]
      _ = _ := by ring
  · rw [← mul_assoc,inv_mul_cancel₀ hJ,one_mul]

end EllipticSquareFunction
