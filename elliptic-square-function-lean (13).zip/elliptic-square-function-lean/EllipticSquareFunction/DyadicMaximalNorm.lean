import EllipticSquareFunction.WeightedPositiveLp
import EllipticSquareFunction.TubeMaximalNorm
import EllipticSquareFunction.DyadicKernelConvolution

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

def finiteKernelMax {ι : Type*} (s : Finset ι) (R M : ℝ)
    (V : ι → Plane) (h : Space → ℝ) (x : Space) : ℝ≥0∞ :=
  s.sup (fun i => ∫⁻ z, ENNReal.ofReal (tubeKernel R M (V i) z)*ENNReal.ofReal |h (x+z)|)

/-- The finite family kernel maximum is bounded by a sum of measurable
finite tube maxima, one for each common dyadic length. -/
theorem finiteKernelMax_le_dyadicTubes {ι : Type*} (s : Finset ι)
    {R M : ℝ} (hR : 0<R) (hM : 0<M) (V : ι → Plane)
    (h : Space → ℝ) (hh : Measurable h) (x : Space) :
    finiteKernelMax s R M V h x ≤ ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*
      ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
        finiteTubeAverageMax s ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V h x := by
  apply Finset.sup_le
  intro i hi
  apply (positive_tubeKernel_dyadic_convolution hR hM (V i)
    (fun z => ENNReal.ofReal |h (x+z)|)
    ((hh.comp ((measurable_const : Measurable (fun _ : Space => x)).add measurable_id)).abs.ennreal_ofReal)).trans
  apply mul_le_mul_left'
  apply ENNReal.tsum_le_tsum
  intro m
  have hh : normalizedTubeConvolution ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) (V i) h x ≤
      finiteTubeAverageMax s ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V h x :=
    Finset.le_sup (f := fun j => normalizedTubeConvolution ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) (V j) h x) hi
  exact mul_le_mul_left' hh (ENNReal.ofReal (((2:ℝ)^m)^(-(M-3))))

/-- The geometric weights have finite total mass in the required range. -/
theorem dyadic_tube_ennreal_sum_ne_top {M : ℝ} (hM : 3<M) :
    (∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3))))≠⊤ := by
  rw [← ENNReal.ofReal_tsum_of_nonneg (fun m => by positivity)
    (dyadic_tube_coefficients_summable hM)]
  exact ENNReal.ofReal_ne_top

/-- The L3 maximal-kernel estimate obtained from External input 3, with its
loss written in the exact common aspect ratio. All tube lengths have been
summed with finite geometric mass; no maximal-operator measurability premise
has been assumed. The scalar conversion to R^(gamma/2) is separate. -/
theorem finiteKernelMax_l3_aspect_bound (hinput : NikodymInput)
    {γ : ℝ} (hγ : 0<γ) (hγ₁ : γ≤1) :
    ∃ C : ℝ, 1≤C ∧ ∀ {ι : Type*} (s : Finset ι) (R M F : ℝ),
      1≤R → 3<M → 0≤F → ∀ V : ι → Plane,
      (∀ i∈s, ‖V i‖≤F) → ∀ h : Space → ℝ, Measurable h → MemLp h 3 volume →
      eLpNorm (finiteKernelMax s R M V h) 3 volume ≤
        ENNReal.ofReal (((2*Real.pi)*(2:ℝ)^M)*((2*(1+F)^3)*C*
          (Real.sqrt R/(2*(1+F)*R))^(-γ)))*
          (∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3))))*eLpNorm h 3 volume := by
  obtain ⟨C,hC,hbound⟩ := finiteTubeAverageMax_l3_bound hinput hγ hγ₁
  refine ⟨C,hC,?_⟩
  intro ι s R M F hR hM hF V hV h hh hlp
  have hR₀ : 0<R := by linarith
  have hsR : Real.sqrt R≤R := by
    apply Real.sqrt_le_iff.mpr
    exact ⟨hR₀.le,by nlinarith⟩
  let B : ℝ := (2*(1+F)^3)*C*(Real.sqrt R/(2*(1+F)*R))^(-γ)
  have hb (m : ℕ) : eLpNorm (finiteTubeAverageMax s ((2:ℝ)^m*Real.sqrt R)
      ((2:ℝ)^m*R) V h) 3 volume ≤ ENNReal.ofReal B*eLpNorm h 3 volume := by
    have ht := hbound s ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) F
      (by positivity) (by positivity) (mul_le_mul_of_nonneg_left hsR (by positivity)) hF V hV h hh hlp
    have he : ((2:ℝ)^m*Real.sqrt R)/(2*(1+F)*((2:ℝ)^m*R))=
        Real.sqrt R/(2*(1+F)*R) := by field_simp; ring
    simpa only [he,B] using ht
  have hseries := positive_l3_weighted_tsum_bound volume
    (fun m => finiteTubeAverageMax s ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V h)
    (fun m => measurable_finiteTubeAverageMax s _ _ V h hh)
    (fun m => ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))) (fun _ => ENNReal.ofReal_ne_top)
    (ENNReal.ofReal B*eLpNorm h 3 volume) hb
  have hmono : eLpNorm (finiteKernelMax s R M V h) 3 volume ≤
      eLpNorm (fun x => ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*
        ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
          finiteTubeAverageMax s ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V h x) 3 volume :=
    eLpNorm_mono_enorm
    (fun x => finiteKernelMax_le_dyadicTubes s hR₀ (by linarith : 0<M) V h hh x)
  rw [positive_l3_const_mul volume _ _ ENNReal.ofReal_ne_top] at hmono
  apply hmono.trans
  have hn := mul_le_mul_left' hseries (ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M))
  rw [ENNReal.ofReal_mul (by positivity : 0≤(2*Real.pi)*(2:ℝ)^M)]
  simpa only [B,mul_assoc,mul_left_comm,mul_comm] using hn

end EllipticSquareFunction
