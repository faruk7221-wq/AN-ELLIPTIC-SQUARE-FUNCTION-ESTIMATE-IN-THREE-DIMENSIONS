import EllipticSquareFunction.WeightedCubic
import EllipticSquareFunction.TimeWeights

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Summation over the complete time lattice, with the density weights from
(5.11). The only analytic premise is the explicitly stated per-slab bound. -/
theorem time_lattice_cubic_assembly (s : Finset ℤ) (R A M : ℝ)
    (hA : 1<A) (hM : 0≤M) (hAM : M≤2*A/3)
    (F : ℤ → Space → ℂ) (D : ℤ → Space → ℝ≥0∞) (C : ℝ≥0∞)
    (hF : ∀ k ∈ s, Continuous (F k)) (hD : ∀ k ∈ s, Measurable (D k))
    (hbound : ∀ j : ℤ, ∀ k ∈ s,
      l3 (F k) (volume.restrict (timeTile R j)) ≤
      C*ENNReal.ofReal (timeInteraction A j k)*
        (∫⁻ y in timeTile R j, D k y^(3/2:ℝ))^(1/3:ℝ)) :
    (l3 (fun y => ∑ k ∈ s, F k y) volume)^3 ≤
      C^3*(ENNReal.ofReal (timeLatticeSumConstant A))^2*(ENNReal.ofReal (2^M))^(3/2:ℝ)*
        (∫⁻ y, (∑ k ∈ s, ENNReal.ofReal (bracket (y.2/R-(k:ℝ))^(-M))*D k y)^(3/2:ℝ)) := by
  let H := fun y : Space => ∑ k ∈ s, ENNReal.ofReal (bracket (y.2/R-(k:ℝ))^(-M))*D k y
  have hweight (k : ℤ) : Measurable (fun y : Space => ENNReal.ofReal (bracket (y.2/R-(k:ℝ))^(-M))) := by
    unfold bracket
    fun_prop
  have hH : Measurable H := Finset.measurable_sum s (fun k hk => (hweight k).mul (hD k hk))
  have htile (j : ℤ) :
      (∫⁻ y in timeTile R j, ENNReal.ofReal (‖∑ k ∈ s, F k y‖^3)) ≤
      C^3*(ENNReal.ofReal (timeLatticeSumConstant A))^2*(ENNReal.ofReal (2^M))^(3/2:ℝ)*
        (∫⁻ y in timeTile R j, H y^(3/2:ℝ)) := by
    have hh := l3_weighted_cubic_assembly s (volume.restrict (timeTile R j)) F D
      (fun k => ENNReal.ofReal (timeInteraction A j k)) C
      (fun k hk => (hF k hk).aestronglyMeasurable) hD (hbound j)
    rw [l3_cube_eq_lintegral] at hh
    have hpoint (y : Space) (hy : y∈timeTile R j) :
        (∑ k ∈ s, (ENNReal.ofReal (timeInteraction A j k))^(2/3:ℝ)*D k y) ≤
        ENNReal.ofReal (2^M)*H y := by
      dsimp only [H]
      rw [Finset.mul_sum]
      apply Finset.sum_le_sum
      intro k hk
      rw [← mul_assoc]
      apply mul_le_mul_right'
      rw [ENNReal.ofReal_rpow_of_nonneg (timeInteraction_pos A j k).le (by norm_num : (0:ℝ)≤2/3),
        ← ENNReal.ofReal_mul (by positivity : (0:ℝ)≤2^M)]
      exact ENNReal.ofReal_le_ofReal (timeInteraction_density_bound hM hAM j k hy)
    have hint : (∫⁻ y in timeTile R j,
        (∑ k ∈ s, (ENNReal.ofReal (timeInteraction A j k))^(2/3:ℝ)*D k y)^(3/2:ℝ)) ≤
        (ENNReal.ofReal (2^M))^(3/2:ℝ)*(∫⁻ y in timeTile R j, H y^(3/2:ℝ)) := by
      calc
        _ ≤ ∫⁻ y in timeTile R j, (ENNReal.ofReal (2^M)*H y)^(3/2:ℝ) :=
          setLIntegral_mono' (measurableSet_timeTile R j) (fun y hy =>
            ENNReal.rpow_le_rpow (hpoint y hy) (by norm_num))
        _ = _ := by
          simp_rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0:ℝ)≤3/2)]
          rw [lintegral_const_mul _ (hH.pow_const _)]
    apply hh.trans
    have hsum := timeInteraction_ennreal_sum hA j s
    calc
      _ ≤ C^3*(ENNReal.ofReal (timeLatticeSumConstant A))^2*
          ((ENNReal.ofReal (2^M))^(3/2:ℝ)*(∫⁻ y in timeTile R j, H y^(3/2:ℝ))) := by gcongr
      _ = _ := by simp only [mul_assoc]
  rw [l3_cube_eq_lintegral,lintegral_time_tiles R]
  calc
    _ ≤ ∑' j : ℤ, C^3*(ENNReal.ofReal (timeLatticeSumConstant A))^2*
        (ENNReal.ofReal (2^M))^(3/2:ℝ)*(∫⁻ y in timeTile R j, H y^(3/2:ℝ)) :=
      ENNReal.tsum_le_tsum htile
    _ = _ := by rw [ENNReal.tsum_mul_left,← lintegral_time_tiles]

theorem time_lattice_l3_assembly (s : Finset ℤ) (R A M : ℝ)
    (hA : 1<A) (hM : 0≤M) (hAM : M≤2*A/3)
    (F : ℤ → Space → ℂ) (D : ℤ → Space → ℝ≥0∞) (C : ℝ≥0∞)
    (hF : ∀ k ∈ s, Continuous (F k)) (hD : ∀ k ∈ s, Measurable (D k))
    (hbound : ∀ j : ℤ, ∀ k ∈ s,
      l3 (F k) (volume.restrict (timeTile R j)) ≤
      C*ENNReal.ofReal (timeInteraction A j k)*
        (∫⁻ y in timeTile R j, D k y^(3/2:ℝ))^(1/3:ℝ)) :
    l3 (fun y => ∑ k ∈ s, F k y) volume ≤
      (C*(ENNReal.ofReal (timeLatticeSumConstant A))^(2/3:ℝ)*(ENNReal.ofReal (2^M))^(1/2:ℝ))*
        (∫⁻ y, (∑ k ∈ s, ENNReal.ofReal (bracket (y.2/R-(k:ℝ))^(-M))*D k y)^(3/2:ℝ))^(1/3:ℝ) := by
  apply l3_le_of_cubic_lintegral
  rw [← l3_cube_eq_lintegral]
  have hh := time_lattice_cubic_assembly s R A M hA hM hAM F D C hF hD hbound
  have h₂ (x : ℝ≥0∞) : (x^(2/3:ℝ))^3=x^2 := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]; norm_num
  have h₃ (x : ℝ≥0∞) : (x^(1/2:ℝ))^3=x^(3/2:ℝ) := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]; norm_num
  simpa only [mul_pow,h₂,h₃] using hh

end EllipticSquareFunction
