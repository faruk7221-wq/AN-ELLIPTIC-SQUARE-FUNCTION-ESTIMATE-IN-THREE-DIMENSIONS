import EllipticSquareFunction.Losses
import EllipticSquareFunction.LpReduction

/-!
# A checked reduction of the graph theorem to two explicit analytic bridges

WARNING: these bridge propositions are not the external inputs of the paper.
Deriving them from those external inputs is unfinished. The main theorem of
this file is therefore a conditional REDUCTION, not a completed formalization
of Theorem 1. Neither bridge is declared as an axiom.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open MeasureTheory
namespace EllipticSquareFunction

def smoothedSquareDensity {n : ℕ} (G : GraphSetup) (R decay : ℝ)
    (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ) (y : Space) : ℝ :=
  ∑ i, positiveConvolution (fun z => ‖f i z‖ ^ 2)
    (tubeKernel R decay (velocity G.φ (ν i))) y

theorem tubeKernel_nonneg (R decay : ℝ) (V : Plane) (y : Space) :
    0 ≤ tubeKernel R decay V y :=
  mul_nonneg (inv_nonneg.mpr (sq_nonneg _)) (packetWeight_nonneg R decay V 0 0 y)

theorem smoothedSquareDensity_nonneg {n : ℕ} (G : GraphSetup) (R decay : ℝ)
    (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ) (y : Space) :
    0 ≤ smoothedSquareDensity G R decay ν f y := by
  apply Finset.sum_nonneg
  intro i _
  apply integral_nonneg
  intro z
  exact mul_nonneg (sq_nonneg _) (tubeKernel_nonneg _ _ _ _)

/-- The combined packet and sampling estimates needed from Sections 4–6.
Constants are chosen BEFORE the scale and the cap family. This includes the
passage from dyadic scales to all real scales. It is an outstanding obligation. -/
def PacketSamplingEstimates (G : GraphSetup) (decay : ℝ) : Prop :=
  ∀ κ η : ℝ, 0 < κ → κ < 1 / 10 → 0 < η → η ≤ 1 →
    ∃ A B : ℝ, 0 < A ∧ 0 < B ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
        AdmissibleFamily G R ν f → ∃ H : Space → ℝ,
          (∀ y, 0 ≤ H y) ∧
          l3 (fun y => ∑ i, f i y) ≤
            ENNReal.ofReal (A * R ^ ((10 * κ + η) / 6) *
              Real.log (2 + R) ^ (2 / 3 : ℝ)) * l3Real (fun y => Real.sqrt (H y)) ∧
          (∀ y, H y ≤ B * smoothedSquareDensity G R decay ν f y)

/-- The specialization of Lemma 5 needed for squared Schwartz functions.
This is an outstanding obligation; it is NOT defined to be `NikodymInput`. -/
def TubeSmoothingEstimates (G : GraphSetup) (decay : ℝ) : Prop :=
  ∀ γ : ℝ, 0 < γ → γ ≤ 1 → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
    ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
      AdmissibleFamily G R ν f →
      lThreeHalves (smoothedSquareDensity G R decay ν f) ≤
        ENNReal.ofReal (C * R ^ (γ / 2)) *
          lThreeHalves (fun y => ∑ i, ‖f i y‖ ^ 2)

/-- Equation (7.5), with all fixed constants absorbed into `D`.
Its parameter and scale quantifiers preserve the paper's order. -/
def QuantitativeEstimate (G : GraphSetup) : Prop :=
  ∀ κ η γ : ℝ, 0 < κ → κ < 1 / 10 → 0 < η → η ≤ 1 → 0 < γ → γ ≤ 1 →
    ∃ D : ℝ, 0 < D ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
        AdmissibleFamily G R ν f →
        l3 (fun y => ∑ i, f i y) ≤
          ENNReal.ofReal (D * R ^ lossExponent κ η γ *
            Real.log (2 + R) ^ (2 / 3 : ℝ)) *
              l3Real (squareFunction Finset.univ (fun i => (f i : Space → ℂ)))

theorem quantitativeEstimate_of_bridges (G : GraphSetup) (decay : ℝ)
    (hpacket : PacketSamplingEstimates G decay)
    (hsmooth : TubeSmoothingEstimates G decay) : QuantitativeEstimate G := by
  intro κ η γ hκ hκ' hη hη' hγ hγ'
  obtain ⟨A, B, hA, hB, hp⟩ := hpacket κ η hκ hκ' hη hη'
  obtain ⟨C, hC, hs⟩ := hsmooth γ hγ hγ'
  refine ⟨A * Real.sqrt B * Real.sqrt C, by positivity, ?_⟩
  intro R hR n ν f hf
  obtain ⟨H, hH, hpH, hd⟩ := hp R hR n ν f hf
  have hR0 : 0 < R := by linarith
  have hlog : 0 ≤ Real.log (2 + R) := Real.log_nonneg (by linarith)
  have hred := section7_reduction volume (fun y => ∑ i, f i y)
    H (smoothedSquareDensity G R decay ν f) (fun y => ∑ i, ‖f i y‖ ^ 2)
    (A := A * R ^ ((10 * κ + η) / 6) * Real.log (2 + R) ^ (2 / 3 : ℝ))
    (B := B) (C := C * R ^ (γ / 2))
    (by positivity) hB.le (by positivity) hH
    (smoothedSquareDensity_nonneg G R decay ν f)
    (fun y => Finset.sum_nonneg (fun i _ => sq_nonneg _)) hpH hd (hs R hR n ν f hf)
  have hroot : Real.sqrt (C * R ^ (γ / 2)) = Real.sqrt C * R ^ (γ / 4) := by
    rw [Real.sqrt_mul hC.le, Real.sqrt_eq_rpow (R ^ (γ / 2)), ← Real.rpow_mul hR0.le]
    congr 2
    ring
  have hconst : A * R ^ ((10 * κ + η) / 6) * Real.log (2 + R) ^ (2 / 3 : ℝ) *
      Real.sqrt B * Real.sqrt (C * R ^ (γ / 2)) =
      A * Real.sqrt B * Real.sqrt C * R ^ lossExponent κ η γ *
        Real.log (2 + R) ^ (2 / 3 : ℝ) := by
    rw [hroot, lossExponent, Real.rpow_add hR0]
    ring
  simpa only [hconst, l3, l3Real, squareFunction] using hred

/-- Scalar form of logarithm absorption, allowing any fixed nonnegative
prefactor. No growth hypothesis on that prefactor is used. -/
theorem absorb_scalar_loss {D κ η γ ε : ℝ} (hD : 0 ≤ D) (hε : 0 < ε)
    (hexp : lossExponent κ η γ ≤ ε / 2) :
    ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      D * R ^ lossExponent κ η γ * Real.log (2 + R) ^ (2 / 3 : ℝ) ≤ C * R ^ ε := by
  obtain ⟨C, hC, h⟩ := absorb_totalConstant (P := 1) (M := 1) (by norm_num)
    (by norm_num) hε hexp
  refine ⟨D * C + 1, by positivity, ?_⟩
  intro R hR
  have h' := mul_le_mul_of_nonneg_left (h R hR) hD
  simp only [totalConstant, Real.one_rpow, one_mul] at h'
  have hRpow : 0 ≤ R ^ ε := Real.rpow_nonneg (by linarith) _
  nlinarith

/-- A complete formal proof of the last epsilon-absorption step, assuming
the quantitative estimate (7.5). This is not a proof of (7.5). -/
theorem reverseSquareFunction_of_quantitativeEstimate (G : GraphSetup)
    (hq : QuantitativeEstimate G) : ReverseSquareFunction G := by
  intro ε hε
  obtain ⟨κ, η, γ, hκ, hκ', hη, hη', hγ, hγ', he⟩ := choose_loss_parameters hε
  obtain ⟨D, hD, hd⟩ := hq κ η γ hκ hκ' hη hη' hγ hγ'
  obtain ⟨C, hC, hc⟩ := absorb_scalar_loss hD.le hε he
  refine ⟨C, hC, ?_⟩
  intro R hR n ν f hf
  exact (hd R hR n ν f hf).trans
    (mul_le_mul_right' (ENNReal.ofReal_le_ofReal (hc R hR)) _)

/-- Checked conditional reduction. The two hypotheses are the unproved
internal analytic bridges, not merely the three cited external results. -/
theorem reverseSquareFunction_of_bridges (G : GraphSetup) (decay : ℝ)
    (hpacket : PacketSamplingEstimates G decay)
    (hsmooth : TubeSmoothingEstimates G decay) : ReverseSquareFunction G :=
  reverseSquareFunction_of_quantitativeEstimate G
    (quantitativeEstimate_of_bridges G decay hpacket hsmooth)

end EllipticSquareFunction
