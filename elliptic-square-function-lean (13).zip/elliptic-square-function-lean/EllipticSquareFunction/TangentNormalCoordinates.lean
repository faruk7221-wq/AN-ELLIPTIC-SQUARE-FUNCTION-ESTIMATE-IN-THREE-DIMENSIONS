import EllipticSquareFunction.GraphNormalGeometry

noncomputable section
namespace EllipticSquareFunction

def tangentNormalMap (D : Plane →L[ℝ] Space) (N : Space) : Space →L[ℝ] Space :=
  D.comp (ContinuousLinearMap.fst ℝ Plane ℝ) +
    (ContinuousLinearMap.snd ℝ Plane ℝ).smulRight N

theorem tangentNormalMap_apply (D : Plane →L[ℝ] Space) (N : Space) (z : Space) :
    tangentNormalMap D N z = D z.1+z.2 • N := rfl

theorem spacePair_self_pos {N : Space} (hN : N ≠ 0) : 0 < spacePair N N := by
  have he := spaceEuclideanEquiv_pair (spaceEuclideanEquiv.symm N) (spaceEuclideanEquiv.symm N)
  simp only [ContinuousLinearEquiv.apply_symm_apply,real_inner_self_eq_norm_sq] at he
  rw [he]
  exact sq_pos_of_pos (norm_pos_iff.mpr (fun hz => hN
    (spaceEuclideanEquiv.symm.injective (hz.trans (map_zero _).symm))))

theorem tangentNormalMap_normal (D : Plane →L[ℝ] Space) (N : Space)
    (horth : ∀ v, spacePair N (D v)=0) (z : Space) :
    spacePair N (tangentNormalMap D N z)=z.2*spacePair N N := by
  change (spacePairLinear N) (D z.1+z.2 • N)=_
  rw [map_add,map_smul]
  change spacePair N (D z.1)+z.2*spacePair N N=_
  rw [horth,zero_add]

theorem tangentNormalMap_injective (D : Plane →L[ℝ] Space) (N : Space)
    (hD : Function.Injective D) (hN : N ≠ 0) (horth : ∀ v, spacePair N (D v)=0) :
    Function.Injective (tangentNormalMap D N) := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro z hz
  change tangentNormalMap D N z=0 at hz
  have ht := tangentNormalMap_normal D N horth z
  rw [hz] at ht
  have hz₂ : z.2=0 := by
    have hn := spacePair_self_pos hN
    have hs : z.2*spacePair N N=0 := by simpa [spacePair] using ht.symm
    exact (mul_eq_zero.mp hs).resolve_right hn.ne'
  have hz₁ : z.1=0 := by
    have hd : D z.1=0 := by simpa [tangentNormalMap_apply,hz₂] using hz
    exact hD (hd.trans (map_zero D).symm)
  exact Prod.ext hz₁ hz₂

/-- Coordinates built from the tangent injection and a nonzero normal.
No ambient coordinate equivalence is assumed. -/
def tangentNormalEquiv (D : Plane →L[ℝ] Space) (N : Space)
    (hD : Function.Injective D) (hN : N ≠ 0) (horth : ∀ v, spacePair N (D v)=0) :
    Space ≃L[ℝ] Space :=
  (LinearEquiv.ofInjectiveEndo (tangentNormalMap D N).toLinearMap
    (tangentNormalMap_injective D N hD hN horth)).toContinuousLinearEquiv

theorem tangentNormalEquiv_apply (D : Plane →L[ℝ] Space) (N : Space)
    (hD : Function.Injective D) (hN : N ≠ 0) (horth : ∀ v, spacePair N (D v)=0) (z : Space) :
    tangentNormalEquiv D N hD hN horth z=D z.1+z.2 • N := rfl

theorem tangentNormalEquiv_symm_tangent (D : Plane →L[ℝ] Space) (N : Space)
    (hD : Function.Injective D) (hN : N ≠ 0) (horth : ∀ v, spacePair N (D v)=0) (v : Plane) :
    (tangentNormalEquiv D N hD hN horth).symm (D v)=(v,0) := by
  apply (tangentNormalEquiv D N hD hN horth).injective
  simp [tangentNormalEquiv_apply]

theorem tangentNormalEquiv_symm_height (D : Plane →L[ℝ] Space) (N : Space)
    (hD : Function.Injective D) (hN : N ≠ 0) (horth : ∀ v, spacePair N (D v)=0) (z : Space) :
    ((tangentNormalEquiv D N hD hN horth).symm z).2 =
      (spacePair N N)⁻¹ * spacePair N z := by
  let E := tangentNormalEquiv D N hD hN horth
  have ht := tangentNormalMap_normal D N horth (E.symm z)
  change spacePair N (E (E.symm z))=(E.symm z).2*spacePair N N at ht
  rw [E.apply_symm_apply] at ht
  rw [ht]
  field_simp [(spacePair_self_pos hN).ne']
  rfl

end EllipticSquareFunction
