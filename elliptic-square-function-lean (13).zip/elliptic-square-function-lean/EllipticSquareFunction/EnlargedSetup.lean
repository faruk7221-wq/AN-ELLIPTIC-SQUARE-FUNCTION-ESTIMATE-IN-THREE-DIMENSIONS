import EllipticSquareFunction.UniformSetupMargins

/-! Construction of a setup with adequate margins for Proposition 2.
The external discrete-density input is required for the constructed setup. -/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Enlarge only the label bounds; phase, window and frame spacing are retained. -/
def enlargeSetup (T : DiscreteSetup) (F A Q : ℝ) : DiscreteSetup :=
  { T with
    frequencyBound := max T.frequencyBound F
    frequencyBound_pos := lt_of_lt_of_le T.frequencyBound_pos (le_max_left _ _)
    C₁ := max T.C₁ A
    C₁_pos := lt_of_lt_of_le T.C₁_pos (le_max_left _ _)
    C₂ := max T.C₂ Q
    C₂_pos := lt_of_lt_of_le T.C₂_pos (le_max_left _ _) }

theorem enlarged_setup_preserves_core (T : DiscreteSetup) (F A Q : ℝ) :
    (enlargeSetup T F A Q).φ=T.φ ∧ (enlargeSetup T F A Q).χ=T.χ ∧
      (enlargeSetup T F A Q).D=T.D := ⟨rfl,rfl,rfl⟩

theorem enlarged_setup_bounds (T : DiscreteSetup) (F A Q : ℝ) :
    T.frequencyBound≤(enlargeSetup T F A Q).frequencyBound ∧
    F≤(enlargeSetup T F A Q).frequencyBound ∧
    T.C₁≤(enlargeSetup T F A Q).C₁ ∧ A≤(enlargeSetup T F A Q).C₁ ∧
    T.C₂≤(enlargeSetup T F A Q).C₂ ∧ Q≤(enlargeSetup T F A Q).C₂ :=
  ⟨le_max_left _ _,le_max_right _ _,le_max_left _ _,le_max_right _ _,
    le_max_left _ _,le_max_right _ _⟩

/-- Proposition 2, one profile, with an actually constructed adequate setup.
No margin implication remains. The required external input is for this setup. -/
theorem exists_enlarged_setup_global_packets {ι : Type*}
    (T : DiscreteSetup) (hphaseT : ContinuedPhase T.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F)
    (M : ℝ) (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=T.φ ∧ S.χ=T.χ ∧ S.D=T.D ∧
      T.frequencyBound≤S.frequencyBound ∧ T.C₁≤S.C₁ ∧ T.C₂≤S.C₂ ∧
      (DiscreteDensityInput S →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
        ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
          let N : ℝ := (2:ℝ)^j
          ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
            (ν : ι → Plane) (v : ι → IntPlane → Plane),
          (∀ i ∈ s, ‖ν i‖≤F) →
          (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
          (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
          l3 (fun y => ∑ i ∈ s, ∑ p ∈ pbox i,
            a i p*freePacket T.φ b N (ν i) (v i p) y)
            (volume.restrict (timeSlab (N^2))) ≤
          ENNReal.ofReal (C*packetConstant P κ η (N^2))*
            densityCubeRoot (spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
              (fun ip => velocity T.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M) (N^2)) := by
  obtain ⟨A,Z,hA,hZ,hglobal⟩ := global_packets_uniform_setup_margins (ι := ι)
    T hphaseT b hb hbs hc hσ hF M hM
  let S := enlargeSetup T (F+Z) (A+1) 3
  refine ⟨S,rfl,rfl,rfl,le_max_left _ _,le_max_left _ _,le_max_left _ _,?_⟩
  intro hinput
  exact hglobal S rfl rfl hinput (le_max_right _ _) (le_max_right _ _) (le_max_right _ _)

end EllipticSquareFunction
