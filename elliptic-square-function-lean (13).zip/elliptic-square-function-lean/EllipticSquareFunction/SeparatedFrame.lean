import EllipticSquareFunction.SeparatedDensityTransport
import EllipticSquareFunction.FineFrameTruncation

/-! # Fine reconstruction for independently positioned original profiles -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

theorem separated_profile_fine_frame_reconstruction {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : 0 < N) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) :
    ∃ q : Finset IntPlane, ∀ y : Space,
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
        (separatedCoefficient b S.χ N s pbox a ν v
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) *
          freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox i, a i p *
          freePacket S.φ b N (ν i) (v i p) y) := by
  classical
  let g := profileFrequency b N (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
  have hg : Continuous g := profileFrequency_continuous b hb N _ _ _ _
  have hgs : HasCompactSupport g := profileFrequency_compact b hbs hN _ _ _ _
  obtain ⟨q, hq, _⟩ := fine_finite_partition S hN hgs
  refine ⟨q, ?_⟩
  intro y
  have h := fine_frame_reconstruction S hφ hN g hg hgs q
    (fun ξ hξ => hq ξ (subset_closure hξ)) y
  have hcoeff (m n : IntPlane) :
      (∫ ξ, g ξ * (fineWindow S N m ξ : ℂ) *
        oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ)) =
      separatedCoefficient b S.χ N s pbox a ν v
        (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) := by
    have hm := profile_coefficient_eq_matrix b hb hbs S.χ S.χ_smooth.continuous
      hN (s.sigma pbox) (fun ip => a ip.1 ip.2) (fun ip => ν ip.1)
      (fun ip => v ip.1 ip.2)
      (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)
    simpa only [g, fineWindow, separatedCoefficient, Finset.sum_sigma] using hm
  have hext := profileFrequency_extension S.φ hφ b hb hbs hN (s.sigma pbox)
    (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => v ip.1 ip.2) y
  change (∫ ξ, g ξ * oscillation (@inner ℝ Plane _ y.1 ξ + y.2*S.φ ξ)) = _ at hext
  simp only [Finset.sum_sigma] at hext
  simpa only [hcoeff, hext] using h

def omittedSeparatedCoefficient {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    (N d A : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) (n : IntPlane) : ℝ :=
  if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, ‖separatedCoefficient b χ N s pbox a ν v
      (latticePoint N⁻¹ m) (N • latticePoint d n)‖ else 0

theorem separatedCoefficient_absolute_tail {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N d A F C L : ℝ}
    (hN : 0 < N) (hd : 0 < d) (hC : 0 ≤ C) (hL : 3 ≤ L)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane)
    (hv : ∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖ ≤ A*N^2)
    (hdecay : ∀ μ w ν v : Plane, ‖windowMatrix b χ N μ w ν v‖ ≤
      C * bracket (N⁻¹ • (w-v))^(-L))
    (hcut : ∀ μ w ν v : Plane, F/N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0) :
    Summable (omittedSeparatedCoefficient b χ N d A s pbox q a ν v) ∧
      (∑' n, omittedSeparatedCoefficient b χ N d A s pbox q a ν v n) ≤
      ((integerPlaneBox ⌈F+2⌉₊).card *
        (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3))) *
      (∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖) := by
  classical
  let G := fun (j : Σ _ : ι, IntPlane) (m n : IntPlane) =>
    if (A+1)*N^2 < ‖N • latticePoint d n‖ then
      windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n)
        (ν j.1) (v j.1 j.2) else 0
  let T := (integerPlaneBox ⌈F+2⌉₊).card *
        (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3))
  have hcol (j : Σ _ : ι, IntPlane) (hj : j ∈ s.sigma pbox) :=
    windowMatrix_frequency_position_tail b χ hN hd hC hL q (ν j.1)
      (v j.1 j.2) (hv _ (Finset.mem_sigma.mp hj).1 _ (Finset.mem_sigma.mp hj).2)
      (fun μ w => hdecay μ w _ _) (fun μ w => hcut μ w _ _)
  have he (j : Σ _ : ι, IntPlane) (m n : IntPlane) : ‖G j m n‖ =
      if (A+1)*N^2 < ‖N • latticePoint d n‖ then
        ‖windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n)
          (ν j.1) (v j.1 j.2)‖ else 0 := by
    dsimp [G]; split_ifs <;> simp
  have hh := finite_matrix_absolute_tail (s.sigma pbox) q (fun j => a j.1 j.2) G
    (fun _ => T)
    (fun j hj m hm => by simpa only [he] using (hcol j hj).1 m)
    (fun j hj => by simpa only [he] using (hcol j hj).2)
  have hf : (fun n => ∑ m ∈ q, ‖∑ j ∈ s.sigma pbox, G j m n * a j.1 j.2‖) =
      omittedSeparatedCoefficient b χ N d A s pbox q a ν v := by
    funext n
    by_cases hn : (A+1)*N^2 < ‖N • latticePoint d n‖
    · simp only [G, hn, if_pos, Finset.sum_sigma, omittedSeparatedCoefficient, separatedCoefficient]
    · simp [G, hn, omittedSeparatedCoefficient]
  rw [hf] at hh
  refine ⟨hh.1, ?_⟩
  simpa only [T, Finset.sum_sigma, ← Finset.sum_mul, mul_comm] using hh.2

/-- Smooth compact windows supply every hypothesis of the absolute tail bound. -/
theorem smooth_separatedCoefficient_absolute_tail {ι : Type*}
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    {d : ℝ} (hd : 0 < d) (L : ℕ) (hL : 3 ≤ L) :
    ∃ B : ℝ, 0 < B ∧ ∀ N : ℝ, 0 < N → ∀ A : ℝ,
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖ ≤ A*N^2) →
      Summable (omittedSeparatedCoefficient b χ N d A s pbox q a ν v) ∧
      (∑' n, omittedSeparatedCoefficient b χ N d A s pbox q a ν v n) ≤
        B * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖) := by
  obtain ⟨F, hF, hcut⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hdecay⟩ := windowMatrix_decay b hb hbs χ hχ hχs L
  let B := max ((integerPlaneBox ⌈F+2⌉₊).card * C * scaledLatticeSumConstant d 3) 0 + 1
  refine ⟨B, by dsimp [B]; positivity, ?_⟩
  intro N hN A s pbox q a ν v hv
  obtain ⟨hs, ht⟩ := separatedCoefficient_absolute_tail b χ hN hd hC.le
    (by exact_mod_cast hL : (3 : ℝ) ≤ L) s pbox q a ν v hv (hdecay N hN) (hcut N hN)
  refine ⟨hs, ht.trans ?_⟩
  have hp : 0 ≤ (1+N)^(-((L : ℝ)-3)) := Real.rpow_nonneg (by linarith) _
  have ha : 0 ≤ ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖ :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => norm_nonneg _))
  have hB : ((integerPlaneBox ⌈F+2⌉₊).card : ℝ) * C * scaledLatticeSumConstant d 3 ≤ B := by
    dsimp [B]; linarith [le_max_left
      (((integerPlaneBox ⌈F+2⌉₊).card : ℝ) * C * scaledLatticeSumConstant d 3) 0]
  convert mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hB hp) ha using 1 <;> ring

/-- The actual omitted synthesis, before its fixed normalization. -/
def separatedSynthesisTail {ι : Type*} (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N d A : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) (y : Space) : ℂ :=
  ∑' n : IntPlane, if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, separatedCoefficient b χ N s pbox a ν v
      (latticePoint N⁻¹ m) (N • latticePoint d n) *
      freePacket φ (fun ζ => (χ ζ : ℂ)) N (latticePoint N⁻¹ m) (N • latticePoint d n) y
    else 0

/-- Absolute coefficient summability controls the synthesis uniformly in spacetime. -/
theorem separatedSynthesisTail_norm_bound {ι : Type*} (φ : Phase) (b : Plane → ℂ)
    (χ : Plane → ℝ) (hχ : Integrable (fun ζ => (χ ζ : ℂ)))
    {N d A : ℝ} (hN : 0 < N) (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane)
    (hs : Summable (omittedSeparatedCoefficient b χ N d A s pbox q a ν v)) (y : Space) :
    ‖separatedSynthesisTail φ b χ N d A s pbox q a ν v y‖ ≤
      (∫ ζ, ‖(χ ζ : ℂ)‖) * ∑' n, omittedSeparatedCoefficient b χ N d A s pbox q a ν v n := by
  classical
  let f := fun n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, separatedCoefficient b χ N s pbox a ν v
      (latticePoint N⁻¹ m) (N • latticePoint d n) *
      freePacket φ (fun ζ => (χ ζ : ℂ)) N (latticePoint N⁻¹ m) (N • latticePoint d n) y
    else 0
  let H := ∫ ζ, ‖(χ ζ : ℂ)‖
  have hmajor (n : IntPlane) : ‖f n‖ ≤ H * omittedSeparatedCoefficient b χ N d A s pbox q a ν v n := by
    by_cases hn : (A+1)*N^2 < ‖N • latticePoint d n‖
    · simp only [f, omittedSeparatedCoefficient, if_pos hn, Finset.mul_sum]
      apply (norm_sum_le _ _).trans
      apply Finset.sum_le_sum
      intro m hm
      rw [norm_mul, mul_comm H]
      exact mul_le_mul_of_nonneg_left (freePacket_uniform_bound φ _ hχ hN _ _ y) (norm_nonneg _)
    · simp [f, omittedSeparatedCoefficient, hn]
  have hn : Summable (fun n => ‖f n‖) :=
    (hs.mul_left H).of_nonneg_of_le (fun _ => norm_nonneg _) hmajor
  calc
    _ ≤ ∑' n, ‖f n‖ := norm_tsum_le_tsum_norm hn
    _ ≤ ∑' n, H * omittedSeparatedCoefficient b χ N d A s pbox q a ν v n :=
      hn.tsum_le_tsum hmajor (hs.mul_left H)
    _ = _ := tsum_mul_left

def separatedProfileCoefficient {ι : Type*} (S : DiscreteSetup) (b : Plane → ℂ)
    (N : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (k : PacketIndex) : ℂ :=
  separatedCoefficient b S.χ N s pbox a ν v
    (latticePoint N⁻¹ k.1) (latticePoint (N/S.D) k.2)

theorem separatedSynthesisTail_eq_sub {ι : Type*} (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) {N A : ℝ} (hN : 0 < N)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (y : Space)
    (hs : HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
      (separatedProfileCoefficient S b N s pbox a ν v (m,n) *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
          (latticePoint (N/S.D) n) y))
      (∑ i ∈ s, ∑ p ∈ pbox i, a i p * freePacket S.φ b N (ν i) (v i p) y)) :
    (((S.D : ℝ)^2)⁻¹ : ℝ) •
      separatedSynthesisTail S.φ b S.χ N (S.D : ℝ)⁻¹ A s pbox q a ν v y =
      (∑ i ∈ s, ∑ p ∈ pbox i, a i p * freePacket S.φ b N (ν i) (v i p) y) -
      discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
        (separatedProfileCoefficient S b N s pbox a ν v) y := by
  classical
  have he (n : IntPlane) : N • latticePoint (S.D : ℝ)⁻¹ n = latticePoint (N/S.D) n := by
    rw [← latticePoint_mul, div_eq_mul_inv]
  have ht := (hasSum_omitted_finset (fineRetainedPositions S N A) _ hs).tsum_eq
  rw [discreteExtension_eq_freePackets S hφ hN]
  have hfin : (∑ n ∈ fineRetainedPositions S N A, ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
      (separatedProfileCoefficient S b N s pbox a ν v (m,n) *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y)) =
      (((S.D : ℝ)^2)⁻¹ : ℝ) • ∑ k ∈ q ×ˢ fineRetainedPositions S N A,
        separatedProfileCoefficient S b N s pbox a ν v k *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ k.1) (latticePoint (N/S.D) k.2) y := by
    simp only [Finset.sum_product, Finset.smul_sum]
    rw [Finset.sum_comm]
  rw [hfin] at ht
  rw [← ht, separatedSynthesisTail]
  simp only [Complex.real_smul]
  rw [← tsum_mul_left]
  apply tsum_congr
  intro n
  by_cases hn : n ∈ fineRetainedPositions S N A
  · have hn' := (mem_fineRetainedPositions S hN A n).mp hn
    simp [he, hn, not_lt_of_ge hn']
  · have hn' : (A+1)*N^2 < ‖latticePoint (N/S.D) n‖ :=
      lt_of_not_ge (fun hh => hn ((mem_fineRetainedPositions S hN A n).mpr hh))
    simp [he, hn, hn', Finset.smul_sum, Finset.mul_sum, separatedProfileCoefficient]

/-- Far fine-frequency labels have zero analyzed coefficient. -/
theorem separatedCoefficient_zero_of_frequency {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N F Z : ℝ} (hN : 1 ≤ N) (hZ : 0 ≤ Z)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (μ w : Plane) (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hμ : F+Z < ‖μ‖)
    (hcut : ∀ μ w ν v : Plane, Z/N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0) :
    separatedCoefficient b χ N s pbox a ν v μ w = 0 := by
  apply Finset.sum_eq_zero
  intro i hi
  apply Finset.sum_eq_zero
  intro p hp
  have htri := norm_sub_le μ (ν i)
  have htri' : ‖μ‖ ≤ ‖μ-ν i‖ + ‖ν i‖ := by
    simpa only [sub_add_cancel] using norm_add_le (μ-ν i) (ν i)
  have hdiv : Z/N ≤ Z := div_le_self hZ hN
  rw [hcut μ w (ν i) (v i p) (by linarith [hν i hi]), zero_mul]

/-- The exact fine synthesis can be restricted to allowed frequency labels,
provided the fixed setup contains the original supports with a cutoff margin. -/
theorem separated_profile_bounded_frequencies {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N F Z : ℝ} (hN : 1 ≤ N) (hZ : 0 ≤ Z) (hFZ : F+Z ≤ S.frequencyBound)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hcut : ∀ μ w ν v : Plane, Z/N < ‖μ-ν‖ → windowMatrix b S.χ N μ w ν v = 0) :
    ∃ q : Finset IntPlane,
      (∀ m ∈ q, ‖latticePoint N⁻¹ m‖ ≤ S.frequencyBound) ∧
      ∀ y : Space,
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
        (separatedProfileCoefficient S b N s pbox a ν v (m,n) *
          freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox i, a i p * freePacket S.φ b N (ν i) (v i p) y) := by
  classical
  obtain ⟨q, hq⟩ := separated_profile_fine_frame_reconstruction S hφ b hb hbs (by linarith : 0<N) s pbox a ν v
  refine ⟨q.filter (fun m => ‖latticePoint N⁻¹ m‖ ≤ S.frequencyBound),
    fun m hm => (Finset.mem_filter.mp hm).2, ?_⟩
  intro y
  apply (hq y).congr
  intro ns
  apply Finset.sum_congr rfl
  intro n hn
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro m hm hmn
  have hfar : S.frequencyBound < ‖latticePoint N⁻¹ m‖ := by
    apply lt_of_not_ge
    intro hh
    exact hmn (Finset.mem_filter.mpr ⟨hm,hh⟩)
  have hz := separatedCoefficient_zero_of_frequency b S.χ hN hZ s pbox a ν v
    (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) hν (hFZ.trans_lt hfar) hcut
  simp only [separatedProfileCoefficient, hz, zero_mul, smul_zero]

theorem separated_profile_discrete_approximation {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (L : ℕ) (hL : 3 ≤ L) :
    ∃ Z B : ℝ, 0 < Z ∧ 0 < B ∧ ∀ N : ℝ, 1 ≤ N → ∀ A F : ℝ,
      A+1 ≤ S.C₁ → F+Z ≤ S.frequencyBound →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖ ≤ F) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖ ≤ A*N^2) →
      ∃ q : Finset IntPlane,
        discreteLabelsAllowed S N (q ×ˢ fineRetainedPositions S N A) ∧
        ∀ y : Space,
        ‖(∑ i ∈ s, ∑ p ∈ pbox i, a i p * freePacket S.φ b N (ν i) (v i p) y) -
          discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
            (separatedProfileCoefficient S b N s pbox a ν v) y‖ ≤
          B * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖) := by
  classical
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨Z,hZ,hcut⟩ := windowMatrix_frequency_cutoff b hbs S.χ S.χ_compact
  obtain ⟨C,hC,hcoeff⟩ := smooth_separatedCoefficient_absolute_tail (ι := ι)
    b hb hbs S.χ S.χ_smooth S.χ_compact (inv_pos.mpr hD) L hL
  have hχ : Integrable (fun ζ => (S.χ ζ : ℂ)) :=
    (Complex.continuous_ofReal.comp S.χ_smooth.continuous).integrable_of_hasCompactSupport
      (S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero)
  let H := ∫ ζ, ‖(S.χ ζ : ℂ)‖
  have hH : 0 ≤ H := integral_nonneg (fun _ => norm_nonneg _)
  let u : ℝ := ((S.D : ℝ)^2)⁻¹
  have hu : 0 ≤ u := by dsimp [u]; positivity
  refine ⟨Z, u*H*C+1, hZ, by positivity, ?_⟩
  intro N hN A F hA hF s pbox a ν v hν hv
  have hN0 : 0<N := by linarith
  obtain ⟨q,hq,hs⟩ := separated_profile_bounded_frequencies S hφ b hb.continuous hbs
    hN hZ.le hF s pbox a ν v hν (hcut N hN0)
  refine ⟨q, fine_retained_labels_allowed S hN0 q hq hA, ?_⟩
  intro y
  obtain ⟨hc,ht⟩ := hcoeff N hN0 A s pbox q a ν v hv
  rw [← separatedSynthesisTail_eq_sub S hφ b hN0 s pbox q a ν v y (hs y),
    norm_smul, Real.norm_eq_abs, abs_of_nonneg hu]
  have ht' := separatedSynthesisTail_norm_bound S.φ b S.χ hχ hN0 s pbox q a ν v hc y
  have hp : 0 ≤ (1+N)^(-((L : ℝ)-3)) := Real.rpow_nonneg (by linarith) _
  have ha : 0 ≤ ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖ :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => norm_nonneg _))
  calc
    _ ≤ u * (H * ∑' n, omittedSeparatedCoefficient b S.χ N (S.D : ℝ)⁻¹ A s pbox q a ν v n) :=
      mul_le_mul_of_nonneg_left ht' hu
    _ ≤ u * (H * (C * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖))) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left ht hH) hu
    _ ≤ _ := by nlinarith


end EllipticSquareFunction
