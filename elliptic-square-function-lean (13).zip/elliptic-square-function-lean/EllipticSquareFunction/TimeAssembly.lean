import EllipticSquareFunction.TerminalTail
import EllipticSquareFunction.RetainedReconstruction

/-! # Assembly of the integer time slabs -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

theorem localSlab_integral_iterated {Q : Set Plane} (hQ : IsCompact Q)
    {F : Space → ℝ} (hF : Continuous F) {a b : ℝ} (hab : a ≤ b) :
    (∫ y in Q ×ˢ Icc a b, F y) = ∫ x in Q, ∫ t in a..b, F (x,t) := by
  have hi : Integrable F ((volume.restrict Q).prod (volume.restrict (Icc a b))) := by
    rw [Measure.prod_restrict]
    exact ContinuousOn.integrableOn_compact (hQ.prod isCompact_Icc) hF.continuousOn
  change (∫ y, F y ∂(volume.prod volume).restrict (Q ×ˢ Icc a b)) = _
  rw [← Measure.prod_restrict, integral_prod _ hi]
  apply integral_congr_ae
  filter_upwards with x
  rw [intervalIntegral.integral_of_le hab, integral_Icc_eq_integral_Ioc]

theorem localSlab_unit_translation {Q : Set Plane} (hQ : IsCompact Q)
    {F : Space → ℝ} (hF : Continuous F) (j : ℝ) :
    (∫ y in Q ×ˢ Icc 0 1, F (y.1,j+y.2)) =
      ∫ y in Q ×ˢ Icc j (j+1), F y := by
  have ht : Continuous (fun y : Space => (y.1,j+y.2)) :=
    continuous_fst.prodMk (continuous_const.add continuous_snd)
  have hshift := hF.comp ht
  dsimp only [Function.comp_def] at hshift
  rw [localSlab_integral_iterated hQ hshift (by norm_num),
    localSlab_integral_iterated hQ hF (by linarith)]
  apply integral_congr_ae
  filter_upwards with x
  simpa only [add_zero] using intervalIntegral.integral_comp_add_left (a := 0) (b := 1) (fun t => F (x,t)) j

/-- Exact assembly of translated unit slabs for a continuous integrand on
a compact spatial set, including the measure-zero endpoint overlaps. -/
theorem localSlab_sum_units {Q : Set Plane} (hQ : IsCompact Q)
    {F : Space → ℝ} (hF : Continuous F) (K : ℕ) :
    (∫ y in Q ×ˢ Icc 0 (K : ℝ), F y) =
      ∑ j ∈ Finset.range K, ∫ y in Q ×ˢ Icc 0 1, F (y.1,(j : ℝ)+y.2) := by
  classical
  rw [localSlab_integral_iterated hQ hF (by positivity)]
  have he (x : Plane) : (∫ t in (0 : ℝ)..(K : ℝ), F (x,t)) =
      ∑ j ∈ Finset.range K, ∫ t in (j : ℝ)..((j : ℝ)+1), F (x,t) := by
    have hc : Continuous (fun t : ℝ => F (x,t)) := hF.comp (continuous_const.prodMk continuous_id)
    simpa only [Nat.cast_zero, Nat.cast_add, Nat.cast_one] using
      (intervalIntegral.sum_integral_adjacent_intervals (a := fun j : ℕ => (j : ℝ))
        (n := K) (fun k _ => hc.intervalIntegrable _ _)).symm
  simp_rw [he]
  have hi (j : ℕ) : IntegrableOn (fun x => ∫ t in (j : ℝ)..((j : ℝ)+1), F (x,t)) Q volume := by
    have hprod : Integrable F ((volume.restrict Q).prod (volume.restrict (Icc (j : ℝ) ((j : ℝ)+1)))) := by
      rw [Measure.prod_restrict]
      exact ContinuousOn.integrableOn_compact (hQ.prod isCompact_Icc) hF.continuousOn
    have h := hprod.integral_prod_left
    simp_rw [integral_Icc_eq_integral_Ioc, ← intervalIntegral.integral_of_le
      (show (j : ℝ) ≤ (j : ℝ)+1 by linarith)] at h
    exact h
  rw [integral_finset_sum _ (fun j _ => hi j)]
  apply Finset.sum_congr rfl
  intro j _
  rw [localSlab_unit_translation hQ hF, localSlab_integral_iterated hQ hF (by linarith)]

theorem coreTube_zero_eq_product (B R : ℝ) :
    coreTube B R 0 0 = Metric.closedBall (0 : Plane) B ×ˢ Icc (0 : ℝ) R := by
  ext y
  simp [coreTube, Metric.mem_closedBall, dist_zero_right, and_comm]

/-- Equation (4.7) summed over an arbitrary finite set of integer time
labels. Every constant is uniform in the spatial and time label sets. -/
theorem retainedTerminal_sum_cubed (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane) :
    ∃ C : ℝ, 0 < C ∧ ∀ (p : Finset IntPlane) (J : Finset ℕ) (N : ℝ)
      (s : Finset PacketIndex) (d : PacketIndex → ℂ),
      (∀ j, IntegrableOn (fun y => ‖retainedTerminal S q p N s d j y‖ ^ 3)
        (spatialSlab 1) volume) ∧
      (∑ j ∈ J, ∫ y in spatialSlab 1, ‖retainedTerminal S q p N s d j y‖ ^ 3) ≤
        C * ∑ i ∈ q ×ˢ (p ×ˢ J), ‖terminalCoefficient S N s d i‖ ^ 3 := by
  classical
  obtain ⟨C, hC, hc⟩ := normalized_retained_reconstruction_cubed S hφ q
  refine ⟨C, hC, ?_⟩
  intro p J N s d
  have he (j : ℕ) (y : Space) : retainedTerminal S q p N s d j y =
      (((S.D : ℝ)^2)⁻¹ : ℝ) • ∑ i ∈ q ×ˢ p,
        terminalCoefficient S N s d (i.1,i.2,j) * windowKernel S.φ (canonicalWindow S i.1)
          (y.1-latticePoint (S.D : ℝ)⁻¹ i.2) y.2 := by
    rw [retainedTerminal, Finset.sum_comm, Finset.sum_product, Finset.smul_sum]
    apply Finset.sum_congr rfl
    intro m _
    rw [Finset.smul_sum]
  have hj (j : ℕ) := hc p (fun i => terminalCoefficient S N s d (i.1,i.2,j))
  simp_rw [← he] at hj
  refine ⟨fun j => (hj j).1, ?_⟩
  calc
    _ ≤ ∑ j ∈ J, C * ∑ i ∈ q ×ˢ p, ‖terminalCoefficient S N s d (i.1,i.2,j)‖^3 :=
      Finset.sum_le_sum (fun j _ => (hj j).2)
    _ = _ := by
      rw [← Finset.mul_sum]
      congr 1
      simp_rw [Finset.sum_product]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro m _
      rw [Finset.sum_comm]

end EllipticSquareFunction
