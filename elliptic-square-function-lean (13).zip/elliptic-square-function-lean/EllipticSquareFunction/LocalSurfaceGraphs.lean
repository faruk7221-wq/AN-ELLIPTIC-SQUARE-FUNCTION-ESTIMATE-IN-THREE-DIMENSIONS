import EllipticSquareFunction.EuclideanSurfaceTheorem

noncomputable section
namespace EllipticSquareFunction

/-- Local open graph data with a smooth elliptic extension. No compact
parameter domain, finite cover, or uniform chart size is supplied here.
The inclusion formulation permits smooth boundary pieces. -/
def LocalSmoothEllipticGraphs (carrier : Set Space) : Prop :=
  ∀ p ∈ carrier, ∃ (W : Set Space) (A : Space ≃ᵃ[ℝ] Space) (φ : Phase) (U : Set Plane),
    IsOpen W ∧ p ∈ W ∧ IsOpen U ∧ ContDiffOn ℝ (⊤ : ℕ∞) φ U ∧
      UniformlyEllipticOn φ U ∧
      ∀ q ∈ carrier ∩ W, (A q).1 ∈ U ∧ (A q).2=φ (A q).1

theorem affine_space_continuous (A : Space ≃ᵃ[ℝ] Space) : Continuous A := by
  have he : (A : Space → Space) = fun q => A.linear.toContinuousLinearEquiv q+A 0 := by
    funext q
    exact affine_apply_eq_linear_add A q
  rw [he]
  exact A.linear.toContinuousLinearEquiv.continuous.add continuous_const

/-- Shrinking each open graph chart constructs all compact parameter data
needed by the surface theorem; these are not extra atlas assumptions. -/
theorem local_elliptic_atlas_of_local_smooth_graphs {carrier : Set Space}
    (hlocal : LocalSmoothEllipticGraphs carrier) : LocalEllipticGraphAtlas carrier := by
  intro p hp
  obtain ⟨W,A,φ,U,hW,hpW,hU,hφ,hell,hgraph⟩ := hlocal p hp
  have hpU := (hgraph p ⟨hp,hpW⟩).1
  obtain ⟨r,hr,hball⟩ := Metric.isOpen_iff.mp hU _ hpU
  let K := Metric.closedBall (A p).1 (r/2)
  have hKU : K ⊆ U := by
    intro x hx
    apply hball
    have hh : dist x (A p).1 ≤ r/2 := hx
    change dist x (A p).1 < r
    linarith
  let G : GraphSetup :=
    { φ := φ, K := K, compact_K := isCompact_closedBall _ _
      c₀ := 1, C₀ := 1, c₀_pos := by norm_num, C₀_pos := by norm_num }
  let V := W ∩ (fun q : Space => (A q).1) ⁻¹' Metric.ball (A p).1 (r/2)
  have hV : IsOpen V := hW.inter
    (Metric.isOpen_ball.preimage (affine_space_continuous A).fst)
  refine ⟨V,A,G,hV,⟨hpW,Metric.mem_ball_self (by positivity)⟩,⟨U,hU,hKU,hφ,hell⟩,?_⟩
  intro q hq
  have hg := hgraph q ⟨hq.1,hq.2.1⟩
  exact ⟨Metric.ball_subset_closedBall hq.2.2,hg.2⟩

theorem surface_reverse_square_function_of_local_graphs (S : SurfaceSetup)
    (hlocal : LocalSmoothEllipticGraphs S.carrier)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    SurfaceReverseSquareFunction S :=
  surface_atlas_reverse_square_function S
    (local_elliptic_atlas_of_local_smooth_graphs hlocal) hplacement hnikodym hdiscrete

/-- A compact portion of an extended graph directly supplies the local
surface hypothesis, even if its parameter set has a boundary. -/
theorem graphOver_local_elliptic_atlas (G : GraphSetup) (hG : GraphHypotheses G) :
    LocalEllipticGraphAtlas (graphOver G.φ G.K) := by
  intro p hp
  refine ⟨Set.univ,AffineEquiv.refl ℝ Space,G,isOpen_univ,Set.mem_univ _,hG,?_⟩
  intro q hq
  obtain ⟨ξ,hξ,rfl⟩ := hq.1
  exact ⟨hξ,rfl⟩

end EllipticSquareFunction
