import EllipticSquareFunction.FineFrame
import EllipticSquareFunction.TerminalTail

/-! # Absolute coefficient tails in the fine frame

The lattice estimates retain three powers for summability in dimension two.
Consequently the proved bound has factor (1+N)^(3-L), sufficient when L is
chosen larger. No sharper rate is assumed.
-/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

def omittedFineCoefficient {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    (N c d A : ℝ) (s : Finset ι) (pbox q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane) (n : IntPlane) : ℝ :=
  if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, ‖changedCoefficient b χ N c s pbox a ν r
      (latticePoint N⁻¹ m) (N • latticePoint d n)‖ else 0

/-- A single matrix column has a summable omitted-position tail. -/
theorem windowMatrix_position_tail (b : Plane → ℂ) (χ : Plane → ℝ)
    {N d A C L : ℝ} (hN : 0 < N) (hd : 0 < d) (hC : 0 ≤ C) (hL : 3 ≤ L)
    (μ ν v : Plane) (hv : ‖v‖ ≤ A*N^2)
    (hdecay : ∀ w : Plane, ‖windowMatrix b χ N μ w ν v‖ ≤
      C * bracket (N⁻¹ • (w-v))^(-L)) :
    let f := fun n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖
      then ‖windowMatrix b χ N μ (N • latticePoint d n) ν v‖ else 0
    Summable f ∧ (∑' n, f n) ≤
      C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3) := by
  classical
  let x := N⁻¹ • v
  have hx : ‖x‖ ≤ A*N := by
    rw [show x = N⁻¹ • v from rfl, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hN)]
    have hh := mul_le_mul_of_nonneg_left hv (inv_pos.mpr hN).le
    convert hh using 1 <;> field_simp <;> ring
  obtain ⟨hw, hsum⟩ := scaled_lattice_position_tail hd (by norm_num : (2:ℝ)<3) hL hN.le x hx
  let w := fun n : IntPlane => if (A+1)*N < ‖latticePoint d n‖
    then bracket (x-latticePoint d n)^(-L) else 0
  have hiff (n : IntPlane) : (A+1)*N^2 < ‖N • latticePoint d n‖ ↔
      (A+1)*N < ‖latticePoint d n‖ := by
    rw [norm_smul, Real.norm_eq_abs, abs_of_pos hN]
    have he : (A+1)*N^2 = N*((A+1)*N) := by ring
    rw [he, mul_lt_mul_left hN]
  have hbr (n : IntPlane) : bracket (N⁻¹ • (N • latticePoint d n-v)) =
      bracket (x-latticePoint d n) := by
    rw [smul_sub, smul_smul, inv_mul_cancel₀ hN.ne', one_smul]
    exact congrArg (fun t : ℝ => 1+t) (norm_sub_rev _ _)
  let f := fun n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖
    then ‖windowMatrix b χ N μ (N • latticePoint d n) ν v‖ else 0
  have hmajor (n : IntPlane) : f n ≤ C*w n := by
    dsimp only [f,w]
    simp only [hiff]
    split_ifs
    · simpa only [hbr] using hdecay (N • latticePoint d n)
    · simp
  have hf0 (n : IntPlane) : 0 ≤ f n := by dsimp [f]; split_ifs <;> positivity
  have hfs : Summable f := (hw.mul_left C).of_nonneg_of_le hf0 hmajor
  refine ⟨hfs, ?_⟩
  calc
    _ ≤ ∑' n, C*w n := hfs.tsum_le_tsum hmajor (hw.mul_left C)
    _ = C * ∑' n, w n := tsum_mul_left
    _ ≤ _ := mul_le_mul_of_nonneg_left hsum hC

/-- A finite combination inherits absolute column-tail estimates. -/
theorem finite_matrix_absolute_tail {ι κ α : Type*}
    (s : Finset ι) (q : Finset κ) (a : ι → ℂ) (F : ι → κ → α → ℂ)
    (T : ι → ℝ)
    (hs : ∀ i ∈ s, ∀ m ∈ q, Summable (fun n => ‖F i m n‖))
    (ht : ∀ i ∈ s, (∑ m ∈ q, ∑' n, ‖F i m n‖) ≤ T i) :
    let f := fun n => ∑ m ∈ q, ‖∑ i ∈ s, F i m n * a i‖
    Summable f ∧ (∑' n, f n) ≤ ∑ i ∈ s, ‖a i‖ * T i := by
  classical
  let g := fun n => ∑ i ∈ s, ∑ m ∈ q, ‖a i‖ * ‖F i m n‖
  have hg : Summable g := by
    apply summable_sum
    intro i hi
    apply summable_sum
    intro m hm
    exact (hs i hi m hm).mul_left _
  let f := fun n => ∑ m ∈ q, ‖∑ i ∈ s, F i m n * a i‖
  have hmajor (n) : f n ≤ g n := by
    dsimp [f,g]
    calc
      _ ≤ ∑ m ∈ q, ∑ i ∈ s, ‖a i‖ * ‖F i m n‖ := by
        apply Finset.sum_le_sum
        intro m hm
        simpa only [norm_mul, mul_comm] using norm_sum_le (s := s) (fun i => F i m n * a i)
      _ = _ := Finset.sum_comm
  have hf : Summable f := hg.of_nonneg_of_le
    (fun n => Finset.sum_nonneg (fun m hm => norm_nonneg _)) hmajor
  refine ⟨hf, (hf.tsum_le_tsum hmajor hg).trans ?_⟩
  calc
    ∑' n, g n = ∑ i ∈ s, ∑ m ∈ q, ‖a i‖ * ∑' n, ‖F i m n‖ := by
      rw [show g = (fun n => ∑ i ∈ s, ∑ m ∈ q, ‖a i‖ * ‖F i m n‖) from rfl,
        Summable.tsum_finsetSum (fun i hi => summable_sum (fun m hm => (hs i hi m hm).mul_left _))]
      apply Finset.sum_congr rfl
      intro i hi
      rw [Summable.tsum_finsetSum (fun m hm => (hs i hi m hm).mul_left _)]
      simp only [tsum_mul_left]
    _ ≤ ∑ i ∈ s, ‖a i‖ * T i := by
      apply Finset.sum_le_sum
      intro i hi
      rw [← Finset.mul_sum]
      exact mul_le_mul_of_nonneg_left (ht i hi) (norm_nonneg _)

/-- Summing a column over fine frequencies costs only the overlap constant,
not the size of the chosen finite frequency set. -/
theorem windowMatrix_frequency_position_tail (b : Plane → ℂ) (χ : Plane → ℝ)
    {N d A F C L : ℝ} (hN : 0 < N) (hd : 0 < d) (hC : 0 ≤ C) (hL : 3 ≤ L)
    (q : Finset IntPlane) (ν v : Plane) (hv : ‖v‖ ≤ A*N^2)
    (hdecay : ∀ μ w : Plane, ‖windowMatrix b χ N μ w ν v‖ ≤
      C * bracket (N⁻¹ • (w-v))^(-L))
    (hcut : ∀ μ w : Plane, F/N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0) :
    let f := fun m n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖
      then ‖windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n) ν v‖ else 0
    (∀ m, Summable (f m)) ∧ (∑ m ∈ q, ∑' n, f m n) ≤
      (integerPlaneBox ⌈F+2⌉₊).card *
        (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3)) := by
  classical
  let f := fun m n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖
      then ‖windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n) ν v‖ else 0
  have hcol (m : IntPlane) := windowMatrix_position_tail b χ hN hd hC hL
    (latticePoint N⁻¹ m) ν v hv (hdecay _)
  refine ⟨fun m => (hcol m).1, ?_⟩
  let qnear := q.filter (fun m => ‖latticePoint N⁻¹ m-ν‖ ≤ F/N)
  have he : (∑ m ∈ q, ∑' n, f m n) = ∑ m ∈ qnear, ∑' n, f m n := by
    symm
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro m hm hmn
    have hfar : F/N < ‖latticePoint N⁻¹ m-ν‖ := by
      have : ¬ ‖latticePoint N⁻¹ m-ν‖ ≤ F/N := by
        intro hh
        exact hmn (Finset.mem_filter.mpr ⟨hm,hh⟩)
      exact lt_of_not_ge this
    simp only [f, hcut _ _ hfar, norm_zero, ite_self, tsum_zero]
  have hT : 0 ≤ C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3) := by
    have hh := (hcol (0 : IntPlane)).2
    exact (tsum_nonneg (fun n => by dsimp [f]; split_ifs <;> positivity)).trans hh
  rw [he]
  calc
    _ ≤ ∑ _m ∈ qnear, C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3) :=
      Finset.sum_le_sum (fun m hm => (hcol m).2)
    _ = (qnear.card : ℝ) * (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3)) := by
      simp only [Finset.sum_const, nsmul_eq_mul]
    _ ≤ _ := mul_le_mul_of_nonneg_right
      (by exact_mod_cast canonical_frequency_near_count (A := F) hN ν q) hT

/-- Absolute fine-coefficient tails for bounded original positions. The
constant is uniform in both finite frequency and original position sets. -/
theorem changedCoefficient_absolute_tail {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c d A F C L : ℝ}
    (hN : 0 < N) (hd : 0 < d) (hC : 0 ≤ C) (hL : 3 ≤ L)
    (s : Finset ι) (pbox q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r : Plane)
    (hv : ∀ p ∈ pbox, ‖r + N • latticePoint c p‖ ≤ A*N^2)
    (hdecay : ∀ μ w ν v : Plane, ‖windowMatrix b χ N μ w ν v‖ ≤
      C * bracket (N⁻¹ • (w-v))^(-L))
    (hcut : ∀ μ w ν v : Plane, F/N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0) :
    Summable (omittedFineCoefficient b χ N c d A s pbox q a ν r) ∧
      (∑' n, omittedFineCoefficient b χ N c d A s pbox q a ν r n) ≤
      ((integerPlaneBox ⌈F+2⌉₊).card *
        (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3))) *
      (∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖) := by
  classical
  let G := fun (j : ι × IntPlane) (m n : IntPlane) =>
    if (A+1)*N^2 < ‖N • latticePoint d n‖ then
      windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n)
        (ν j.1) (r + N • latticePoint c j.2) else 0
  let T := (integerPlaneBox ⌈F+2⌉₊).card *
        (C * ((1+N)^(-(L-3)) * scaledLatticeSumConstant d 3))
  have hcol (j : ι × IntPlane) (hj : j ∈ s ×ˢ pbox) :=
    windowMatrix_frequency_position_tail b χ hN hd hC hL q (ν j.1)
      (r + N • latticePoint c j.2) (hv _ (Finset.mem_product.mp hj).2)
      (fun μ w => hdecay μ w _ _) (fun μ w => hcut μ w _ _)
  have he (j : ι × IntPlane) (m n : IntPlane) : ‖G j m n‖ =
      if (A+1)*N^2 < ‖N • latticePoint d n‖ then
        ‖windowMatrix b χ N (latticePoint N⁻¹ m) (N • latticePoint d n)
          (ν j.1) (r + N • latticePoint c j.2)‖ else 0 := by
    dsimp [G]; split_ifs <;> simp
  have hh := finite_matrix_absolute_tail (s ×ˢ pbox) q (fun j => a j.1 j.2) G
    (fun _ => T)
    (fun j hj m hm => by simpa only [he] using (hcol j hj).1 m)
    (fun j hj => by simpa only [he] using (hcol j hj).2)
  have hf : (fun n => ∑ m ∈ q, ‖∑ j ∈ s ×ˢ pbox, G j m n * a j.1 j.2‖) =
      omittedFineCoefficient b χ N c d A s pbox q a ν r := by
    funext n
    by_cases hn : (A+1)*N^2 < ‖N • latticePoint d n‖
    · simp only [G, hn, if_pos, Finset.sum_product, omittedFineCoefficient, changedCoefficient]
    · simp [G, hn, omittedFineCoefficient]
  rw [hf] at hh
  refine ⟨hh.1, ?_⟩
  simpa only [T, Finset.sum_product, ← Finset.sum_mul, mul_comm] using hh.2

/-- Smooth compact windows supply every hypothesis of the absolute tail bound. -/
theorem smooth_changedCoefficient_absolute_tail {ι : Type*}
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    {d : ℝ} (hd : 0 < d) (L : ℕ) (hL : 3 ≤ L) :
    ∃ B : ℝ, 0 < B ∧ ∀ N : ℝ, 0 < N → ∀ c A : ℝ,
      ∀ (s : Finset ι) (pbox q : Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (r : Plane),
      (∀ p ∈ pbox, ‖r + N • latticePoint c p‖ ≤ A*N^2) →
      Summable (omittedFineCoefficient b χ N c d A s pbox q a ν r) ∧
      (∑' n, omittedFineCoefficient b χ N c d A s pbox q a ν r n) ≤
        B * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖) := by
  obtain ⟨F, hF, hcut⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hdecay⟩ := windowMatrix_decay b hb hbs χ hχ hχs L
  let B := max ((integerPlaneBox ⌈F+2⌉₊).card * C * scaledLatticeSumConstant d 3) 0 + 1
  refine ⟨B, by dsimp [B]; positivity, ?_⟩
  intro N hN c A s pbox q a ν r hv
  obtain ⟨hs, ht⟩ := changedCoefficient_absolute_tail b χ hN hd hC.le
    (by exact_mod_cast hL : (3 : ℝ) ≤ L) s pbox q a ν r hv (hdecay N hN) (hcut N hN)
  refine ⟨hs, ht.trans ?_⟩
  have hp : 0 ≤ (1+N)^(-((L : ℝ)-3)) := Real.rpow_nonneg (by linarith) _
  have ha : 0 ≤ ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖ :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => norm_nonneg _))
  have hB : ((integerPlaneBox ⌈F+2⌉₊).card : ℝ) * C * scaledLatticeSumConstant d 3 ≤ B := by
    dsimp [B]; linarith [le_max_left
      (((integerPlaneBox ⌈F+2⌉₊).card : ℝ) * C * scaledLatticeSumConstant d 3) 0]
  convert mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hB hp) ha using 1 <;> ring

/-- The actual omitted synthesis, before its fixed normalization. -/
def fineSynthesisTail {ι : Type*} (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N c d A : ℝ) (s : Finset ι) (pbox q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane) (y : Space) : ℂ :=
  ∑' n : IntPlane, if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, changedCoefficient b χ N c s pbox a ν r
      (latticePoint N⁻¹ m) (N • latticePoint d n) *
      freePacket φ (fun ζ => (χ ζ : ℂ)) N (latticePoint N⁻¹ m) (N • latticePoint d n) y
    else 0

/-- Absolute coefficient summability controls the synthesis uniformly in spacetime. -/
theorem fineSynthesisTail_norm_bound {ι : Type*} (φ : Phase) (b : Plane → ℂ)
    (χ : Plane → ℝ) (hχ : Integrable (fun ζ => (χ ζ : ℂ)))
    {N c d A : ℝ} (hN : 0 < N) (s : Finset ι) (pbox q : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane)
    (hs : Summable (omittedFineCoefficient b χ N c d A s pbox q a ν r)) (y : Space) :
    ‖fineSynthesisTail φ b χ N c d A s pbox q a ν r y‖ ≤
      (∫ ζ, ‖(χ ζ : ℂ)‖) * ∑' n, omittedFineCoefficient b χ N c d A s pbox q a ν r n := by
  classical
  let f := fun n : IntPlane => if (A+1)*N^2 < ‖N • latticePoint d n‖ then
    ∑ m ∈ q, changedCoefficient b χ N c s pbox a ν r
      (latticePoint N⁻¹ m) (N • latticePoint d n) *
      freePacket φ (fun ζ => (χ ζ : ℂ)) N (latticePoint N⁻¹ m) (N • latticePoint d n) y
    else 0
  let H := ∫ ζ, ‖(χ ζ : ℂ)‖
  have hmajor (n : IntPlane) : ‖f n‖ ≤ H * omittedFineCoefficient b χ N c d A s pbox q a ν r n := by
    by_cases hn : (A+1)*N^2 < ‖N • latticePoint d n‖
    · simp only [f, omittedFineCoefficient, if_pos hn, Finset.mul_sum]
      apply (norm_sum_le _ _).trans
      apply Finset.sum_le_sum
      intro m hm
      rw [norm_mul, mul_comm H]
      exact mul_le_mul_of_nonneg_left (freePacket_uniform_bound φ _ hχ hN _ _ y) (norm_nonneg _)
    · simp [f, omittedFineCoefficient, hn]
  have hn : Summable (fun n => ‖f n‖) :=
    (hs.mul_left H).of_nonneg_of_le (fun _ => norm_nonneg _) hmajor
  calc
    _ ≤ ∑' n, ‖f n‖ := norm_tsum_le_tsum_norm hn
    _ ≤ ∑' n, H * omittedFineCoefficient b χ N c d A s pbox q a ν r n :=
      hn.tsum_le_tsum hmajor (hs.mul_left H)
    _ = _ := tsum_mul_left

end EllipticSquareFunction
