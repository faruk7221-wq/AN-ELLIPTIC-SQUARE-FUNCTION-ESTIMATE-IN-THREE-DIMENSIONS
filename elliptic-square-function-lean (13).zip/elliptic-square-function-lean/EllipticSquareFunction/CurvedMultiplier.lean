import EllipticSquareFunction.FrameReconstruction

/-! The exact curved multiplier in (6.4) and its inverse transform (6.9). -/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Positive-sign Fourier integral in the paper's physical coordinates. -/
def inverseSpaceTransform (m : Space → ℂ) (y : Space) : ℂ :=
  ∫ ζ, m ζ*oscillation (@inner ℝ Plane _ y.1 ζ.1+y.2*ζ.2)

def inverseTimeTransform (ρ : ℝ → ℂ) (t : ℝ) : ℂ :=
  ∫ τ, ρ τ*oscillation (t*τ)

def curvedMultiplier (φ : Phase) (χ : Plane → ℂ) (ρ : ℝ → ℂ)
    (r R : ℝ) (ν : Plane) (ζ : Space) : ℂ :=
  χ (r • (ζ.1-ν))*ρ (R*(ζ.2-φ ζ.1))

/-- These coordinates retain the exact phase, not its tangent approximation. -/
def curvedFrequencyHomeomorph (φ : Phase) (hφ : Continuous φ)
    {r R : ℝ} (hr : r≠0) (hR : R≠0) (ν : Plane) : Space ≃ₜ Space where
  toFun ζ := (r • (ζ.1-ν),R*(ζ.2-φ ζ.1))
  invFun z := (ν+r⁻¹ • z.1,φ (ν+r⁻¹ • z.1)+R⁻¹*z.2)
  left_inv ζ := by
    have hx : ν+r⁻¹ • (r • (ζ.1-ν))=ζ.1 := by simp [smul_smul,hr]
    simp only [hx]
    apply Prod.ext
    · rfl
    · dsimp
      field_simp
  right_inv z := by
    apply Prod.ext
    · simp [smul_smul,hr]
    · simp [hR]
  continuous_toFun := (continuous_const.smul (continuous_fst.sub continuous_const)).prodMk
    (continuous_const.mul (continuous_snd.sub (hφ.comp continuous_fst)))
  continuous_invFun := by
    have hx : Continuous (fun z : Space => ν+r⁻¹ • z.1) :=
      continuous_const.add (continuous_const.smul continuous_fst)
    exact hx.prodMk ((hφ.comp hx).add (continuous_const.mul continuous_snd))

theorem continuous_curvedMultiplier (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (ρ : ℝ → ℂ) (hρ : Continuous ρ)
    (r R : ℝ) (ν : Plane) : Continuous (curvedMultiplier φ χ ρ r R ν) := by
  exact (hχ.comp (continuous_const.smul (continuous_fst.sub continuous_const))).mul
    (hρ.comp (continuous_const.mul (continuous_snd.sub (hφ.comp continuous_fst))))

theorem compactSupport_curvedMultiplier (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχs : HasCompactSupport χ)
    (ρ : ℝ → ℂ) (hρs : HasCompactSupport ρ)
    {r R : ℝ} (hr : r≠0) (hR : R≠0) (ν : Plane) :
    HasCompactSupport (curvedMultiplier φ χ ρ r R ν) := by
  have hprod : HasCompactSupport (fun z : Space => χ z.1*ρ z.2) := by
    apply HasCompactSupport.of_support_subset_isCompact (hχs.prod hρs)
    intro z hz
    exact ⟨subset_tsupport _ ((mul_ne_zero_iff.mp hz).1),
      subset_tsupport _ ((mul_ne_zero_iff.mp hz).2)⟩
  exact hprod.comp_homeomorph (curvedFrequencyHomeomorph φ hφ hr hR ν)

/-- The one-dimensional change of variables used in (6.9), including its
Jacobian and modulation. This holds for every profile, with Bochner's convention. -/
theorem inverse_time_shift_scale (ρ : ℝ → ℂ) {R : ℝ} (hR : 0<R) (a t : ℝ) :
    (∫ τ : ℝ, ρ (R*(τ-a))*oscillation (t*τ)) =
      (R⁻¹:ℝ)*inverseTimeTransform ρ (t/R)*oscillation (t*a) := by
  have hphase (u : ℝ) : t*(u+a)=t*u+t*a := by ring
  have he : (∫ τ : ℝ, ρ (R*(τ-a))*oscillation (t*τ)) =
      ∫ u : ℝ, ρ (R*u)*oscillation (t*(u+a)) := by
    symm
    simpa only [add_sub_cancel_right] using
      integral_add_right_eq_self (fun τ : ℝ => ρ (R*(τ-a))*oscillation (t*τ)) a
  rw [he]
  simp_rw [hphase,oscillation_add,← mul_assoc]
  rw [integral_mul_const]
  have hs : (∫ u : ℝ, ρ (R*u)*oscillation (t*u)) =
      (R⁻¹:ℝ) • inverseTimeTransform ρ (t/R) := by
    have hh := Measure.integral_comp_mul_left
      (fun v : ℝ => ρ v*oscillation ((t/R)*v)) R
    have hp (u : ℝ) : (t/R)*(R*u)=t*u := by field_simp; ring
    simpa only [hp,abs_of_pos (inv_pos.mpr hR),inverseTimeTransform] using hh
  rw [hs,Complex.real_smul]

/-- Equation (6.9), first form, proved by Fubini and the exact time integral. -/
theorem inverse_curvedMultiplier (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (hχs : HasCompactSupport χ)
    (ρ : ℝ → ℂ) (hρ : Continuous ρ) (hρs : HasCompactSupport ρ)
    {r R : ℝ} (hr : r≠0) (hR : 0<R) (ν : Plane) (y : Space) :
    inverseSpaceTransform (curvedMultiplier φ χ ρ r R ν) y =
      (R⁻¹:ℝ)*inverseTimeTransform ρ (y.2/R)*
        ∫ ξ : Plane, χ (r • (ξ-ν))*oscillation (@inner ℝ Plane _ y.1 ξ+y.2*φ ξ) := by
  let m := curvedMultiplier φ χ ρ r R ν
  have hm := continuous_curvedMultiplier φ hφ χ hχ ρ hρ r R ν
  have hms := compactSupport_curvedMultiplier φ hφ χ hχs ρ hρs hr hR.ne' ν
  have ho : Continuous (fun ζ : Space => oscillation (@inner ℝ Plane _ y.1 ζ.1+y.2*ζ.2)) := by
    apply continuous_oscillation.comp
    fun_prop
  have hi : Integrable (fun ζ : Space => curvedMultiplier φ χ ρ r R ν ζ *
      oscillation (@inner ℝ Plane _ y.1 ζ.1+y.2*ζ.2)) :=
    (hm.mul ho).integrable_of_hasCompactSupport hms.mul_right
  change (∫ ζ : Space, curvedMultiplier φ χ ρ r R ν ζ *
    oscillation (@inner ℝ Plane _ y.1 ζ.1+y.2*ζ.2) ∂volume.prod volume)=_
  rw [integral_prod _ hi]
  have he (ξ : Plane) :
      (∫ τ : ℝ, curvedMultiplier φ χ ρ r R ν (ξ,τ)*
        oscillation (@inner ℝ Plane _ y.1 ξ+y.2*τ)) =
      ((R⁻¹:ℝ)*inverseTimeTransform ρ (y.2/R))*
        (χ (r • (ξ-ν))*oscillation (@inner ℝ Plane _ y.1 ξ+y.2*φ ξ)) := by
    simp only [curvedMultiplier,oscillation_add]
    have hmul (τ : ℝ) : χ (r • (ξ-ν))*ρ (R*(τ-φ ξ))*
        (oscillation (@inner ℝ Plane _ y.1 ξ)*oscillation (y.2*τ)) =
        (χ (r • (ξ-ν))*oscillation (@inner ℝ Plane _ y.1 ξ))*
          (ρ (R*(τ-φ ξ))*oscillation (y.2*τ)) := by ring
    simp_rw [hmul]
    rw [integral_const_mul,inverse_time_shift_scale ρ hR]
    ring
  simp_rw [he]
  exact integral_const_mul _ _

/-- The packet normalization in the second equality of (6.9). -/
theorem equation_6_9 (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (hχs : HasCompactSupport χ)
    (ρ : ℝ → ℂ) (hρ : Continuous ρ) (hρs : HasCompactSupport ρ)
    {R : ℝ} (hR : 0<R) (ν : Plane) (y : Space) :
    inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) y =
      ((R^2)⁻¹:ℝ)*inverseTimeTransform ρ (y.2/R)*
        freePacket φ χ (Real.sqrt R) ν 0 y := by
  rw [inverse_curvedMultiplier φ hφ χ hχ hχs ρ hρ hρs
    (Real.sqrt_pos.mpr hR).ne' hR]
  simp only [freePacket,sub_zero,Real.sq_sqrt hR.le]
  generalize (∫ ξ : Plane, χ (Real.sqrt R • (ξ-ν))*
    oscillation (@inner ℝ Plane _ y.1 ξ+y.2*φ ξ)) = J
  simp only [Complex.ofReal_inv,Complex.ofReal_pow]
  field_simp [Complex.ofReal_ne_zero.mpr hR.ne']
  ring

end EllipticSquareFunction
