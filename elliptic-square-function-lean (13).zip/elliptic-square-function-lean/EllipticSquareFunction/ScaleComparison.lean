import EllipticSquareFunction.DyadicSamplingBridge

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Every target scale is below a dyadic squared scale by a factor at most 4. -/
theorem exists_upper_dyadic_square {R : ℝ} (hR : 2≤R) :
    ∃ j : ℕ, 1≤j ∧ R≤((2:ℝ)^j)^2 ∧ ((2:ℝ)^j)^2≤4*R := by
  have hR₀ : 0≤R := by linarith
  obtain ⟨k,hlo,hhi⟩ := exists_nat_pow_near ((Real.one_le_sqrt).mpr (by linarith : 1≤R))
    (by norm_num : (1:ℝ)<2)
  refine ⟨k+1,by omega,?_,?_⟩
  · nlinarith [Real.sq_sqrt hR₀,Real.sqrt_nonneg R,pow_pos (by norm_num : (0:ℝ)<2) (k+1)]
  · rw [pow_succ (2:ℝ) k]
    nlinarith [Real.sq_sqrt hR₀,Real.sqrt_nonneg R,pow_pos (by norm_num : (0:ℝ)<2) k]

theorem comparable_inverse_scales {R S : ℝ} (hR : 0<R) (hRS : R≤S) (hSR : S≤4*R) :
    (Real.sqrt R)⁻¹≤4*(Real.sqrt S)⁻¹ ∧ R⁻¹≤4*S⁻¹ := by
  have hS : 0<S := hR.trans_le hRS
  have hr := Real.sqrt_pos.mpr hR
  have hs := Real.sqrt_pos.mpr hS
  have hsle : Real.sqrt S≤4*Real.sqrt R := by
    nlinarith [Real.sq_sqrt hR.le,Real.sq_sqrt hS.le]
  constructor
  · rw [← div_eq_mul_inv,inv_eq_one_div,div_le_div_iff₀ hr hs]
    simpa only [one_mul] using hsle
  · rw [← div_eq_mul_inv,inv_eq_one_div,div_le_div_iff₀ hR hS]
    simpa only [one_mul] using hSR

def enlargedCapGraph (G : GraphSetup) : GraphSetup :=
  {G with C₀ := 4*G.C₀, C₀_pos := mul_pos (by norm_num) G.C₀_pos}

/-- A fixed fourfold cap enlargement makes original data admissible at the
next dyadic scale. The frequency-separation constant is preserved. -/
theorem admissibleFamily_upper_scale (G : GraphSetup) {R S : ℝ}
    (hR : 0<R) (hRS : R≤S) (hSR : S≤4*R) {n : ℕ}
    (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ)
    (hf : AdmissibleFamily G R ν f) : AdmissibleFamily (enlargedCapGraph G) S ν f := by
  have hS : 0<S := hR.trans_le hRS
  obtain ⟨hx,ht⟩ := comparable_inverse_scales hR hRS hSR
  refine ⟨hf.1,?_,?_⟩
  · intro i j hij
    apply le_trans _ (hf.2.1 i j hij)
    apply mul_le_mul_of_nonneg_left _ G.c₀_pos.le
    exact inv_anti₀ (Real.sqrt_pos.mpr hR) (Real.sqrt_le_sqrt hRS)
  · intro i ζ hz
    obtain ⟨hs,ht'⟩ := hf.2.2 i hz
    refine ⟨hs.trans ?_,ht'.trans ?_⟩
    · change G.C₀*(Real.sqrt R)⁻¹≤(4*G.C₀)*(Real.sqrt S)⁻¹
      nlinarith [mul_le_mul_of_nonneg_left hx G.C₀_pos.le]
    · change G.C₀*((Real.sqrt R)⁻¹)^2≤(4*G.C₀)*((Real.sqrt S)⁻¹)^2
      rw [inv_pow,inv_pow,Real.sq_sqrt hR.le,Real.sq_sqrt hS.le]
      nlinarith [mul_le_mul_of_nonneg_left ht G.C₀_pos.le]

/-- Transfer a negative-power weight across a fixed bracket comparison. -/
theorem negative_power_comparison {a b c M : ℝ} (ha : 0<a) (hb : 0<b)
    (hc : 0<c) (hM : 0≤M) (h : a≤c*b) : b^(-M)≤c^M*a^(-M) := by
  have hh := Real.rpow_le_rpow_of_nonpos ha h (neg_nonpos.mpr hM)
  rw [Real.mul_rpow hc.le hb.le,Real.rpow_neg hc.le] at hh
  have hp : 0<c^M := Real.rpow_pos_of_pos hc _
  have hh' := mul_le_mul_of_nonneg_left hh hp.le
  have he : c^M*((c^M)⁻¹*b^(-M))=b^(-M) := by field_simp
  rwa [he] at hh'

/-- Pointwise comparison of normalized tube kernels at comparable scales. -/
theorem tubeKernel_upper_scale {R S M : ℝ} (hR : 0<R) (hRS : R≤S)
    (hSR : S≤4*R) (hM : 0≤M) (V : Plane) (y : Space) :
    tubeKernel S M V y≤((4:ℝ)^M)^2*tubeKernel R M V y := by
  have hS : 0<S := hR.trans_le hRS
  obtain ⟨hx,ht⟩ := comparable_inverse_scales hR hRS hSR
  have hx' : bracket ((Real.sqrt R)⁻¹ • (y.1+y.2 • V))≤
      4*bracket ((Real.sqrt S)⁻¹ • (y.1+y.2 • V)) := by
    simp only [bracket,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr (Real.sqrt_pos.mpr hR)),
      abs_of_pos (inv_pos.mpr (Real.sqrt_pos.mpr hS))]
    nlinarith [norm_nonneg (y.1+y.2 • V),mul_le_mul_of_nonneg_right hx (norm_nonneg (y.1+y.2 • V))]
  have ht' : bracket (y.2/R)≤4*bracket (y.2/S) := by
    simp only [bracket,Real.norm_eq_abs,div_eq_inv_mul,abs_mul,abs_of_pos (inv_pos.mpr hR),
      abs_of_pos (inv_pos.mpr hS)]
    nlinarith [abs_nonneg y.2,mul_le_mul_of_nonneg_right ht (abs_nonneg y.2)]
  have hxs := negative_power_comparison (bracket_pos _) (bracket_pos _) (by norm_num) hM hx'
  have hts := negative_power_comparison (bracket_pos _) (bracket_pos _) (by norm_num) hM ht'
  have hp := mul_le_mul hxs hts (Real.rpow_nonneg (bracket_pos _).le _)
    (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (Real.rpow_nonneg (bracket_pos _).le _))
  have hinv : (S^2)⁻¹≤(R^2)⁻¹ := inv_anti₀ (sq_pos_of_pos hR)
    (pow_le_pow_left₀ hR.le hRS 2)
  have hh := mul_le_mul hinv hp (mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _)
    (Real.rpow_nonneg (bracket_pos _).le _)) (by positivity : 0≤(R^2)⁻¹)
  simp only [tubeKernel,packetWeight,sub_zero]
  convert hh using 1 <;> ring

end EllipticSquareFunction
