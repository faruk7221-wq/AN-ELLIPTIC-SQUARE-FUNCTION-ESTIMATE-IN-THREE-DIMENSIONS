import EllipticSquareFunction.CanonicalPacketBound
import EllipticSquareFunction.EnlargedSetup

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The rebased slab estimate (5.10), with all margins chosen before
the setup label bounds. There is no internal packet
estimate hypothesis: the canonical estimate is obtained from the external
discrete input. All constants precede the loss parameters and the scale. -/
theorem equation_5_10_uniform_setup_margins {ι : Type*}
    (T : DiscreteSetup) (hphase : ContinuedPhase T.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F M : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M)
    :
    ∃ Z A Z' : ℝ, 0<Z ∧ 1≤A ∧ 0<Z' ∧
      ∀ S : DiscreteSetup, S.φ=T.φ → S.χ=T.χ → DiscreteDensityInput S →
        3≤S.C₂ → A+1≤S.C₁ → F+Z+Z'≤S.frequencyBound →
        ∃ Cp Cd : ℝ, 0<Cp ∧ 0<Cd ∧ ∃ B : ℕ,
          ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
          ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
          let N : ℝ := (2:ℝ)^j
          ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
            (ν : ι → Plane) (v : ι → IntPlane → Plane),
          (∀ i ∈ s, ‖ν i‖≤F) →
          (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
          (∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v i p-v i r‖) →
          ∀ Δ : ℝ,
          l3 (fun y => ∑ i ∈ s, ∑ p ∈ pbox i,
            a i p*freePacket T.φ b N (ν i) (v i p) (y.1,y.2+Δ*N^2))
            (volume.restrict (timeSlab (N^2))) ≤
          ENNReal.ofReal ((Cp*packetConstant P κ η (N^2))*Real.sqrt (Cd*(1+|Δ|)^B))*
            densityCubeRoot (fun y => spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
              (fun ip => velocity T.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M
              (y.1,y.2+Δ*N^2)) (N^2) := by
  obtain ⟨Z,Cd,hZ,hCd,B,hslab⟩ := rebased_slab_estimate_of_packet_bound (ι := ι)
    T hphase b hb hbs hc hσ (by linarith : 0≤M)
  have hD : 0<(T.D:ℝ) := by exact_mod_cast T.D_pos
  have hχ : ContDiff ℝ (⊤ : ℕ∞) (fun ζ => (T.χ ζ:ℂ)) :=
    Complex.ofRealCLM.contDiff.comp T.χ_smooth
  have hχs : HasCompactSupport (fun ζ => (T.χ ζ:ℂ)) :=
    T.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero
  obtain ⟨A,Z',hA,hZ',hglobal⟩ := global_packets_uniform_setup_margins (ι := IntPlane)
    T hphase _ hχ hχs (inv_pos.mpr hD) (by norm_num : (0:ℝ)<1)
      (by linarith : 0≤F+Z) M hM
  refine ⟨Z,A,Z',hZ,hA,hZ',?_⟩
  intro S heφ heχ hinput hQ₂ hA₁ hFZ
  obtain ⟨Cp,hCp,hglobal⟩ := hglobal S heφ heχ hinput hQ₂ hA₁ hFZ
  simp only [heφ] at hglobal
  refine ⟨Cp,Cd,hCp,hCd,B,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hglobal⟩ := hglobal κ η hκ hκ' hη hη'
  have hcanonical : UniformSingleProfileBound IntPlane T.φ (fun ζ => (T.χ ζ:ℂ))
      (T.D:ℝ)⁻¹ 1 (F+Z) M Cp P κ η := by
    intro j hj d hd
    exact hglobal j hj d.labels d.positions d.coefficient d.frequency d.position hd.1 hd.2.1 hd.2.2
  refine ⟨P,hP,?_⟩
  intro j hj N
  have hN : 1≤N := one_le_pow₀ (by norm_num)
  have hcoef : 0≤Cp*packetConstant P κ η (N^2) :=
    mul_nonneg hCp.le (packetConstant_nonneg_global (by linarith) κ η)
  apply hslab N F (Cp*packetConstant P κ η (N^2)) hN hcoef
  intro q p d hq
  exact canonical_packet_bound_of_uniform T (F+Z) M Cp P κ η hcanonical j hj q p d hq

end EllipticSquareFunction
