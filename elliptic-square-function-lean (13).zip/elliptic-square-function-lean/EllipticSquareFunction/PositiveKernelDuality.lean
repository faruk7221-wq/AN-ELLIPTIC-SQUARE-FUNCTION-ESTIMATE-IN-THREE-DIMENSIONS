import EllipticSquareFunction.SamplingDensityReal

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000
attribute [local instance] space_volume_add_left_invariant

/-- Tonelli and translation give the exact positive convolution duality
identity; infinite integrals are allowed. -/
theorem positive_kernel_duality (g K h : Space → ℝ≥0∞)
    (hg : Measurable g) (hK : Measurable K) (hh : Measurable h) :
    (∫⁻ y, (∫⁻ z, g (y-z)*K z)*h y) =
      ∫⁻ x, g x*(∫⁻ z, K z*h (x+z)) := by
  have hleft (y : Space) : (∫⁻ z, g (y-z)*K z)*h y=
      ∫⁻ z, (g (y-z)*K z)*h y :=
    (lintegral_mul_const'' _ ((hg.comp (measurable_const.sub measurable_id)).mul hK).aemeasurable).symm
  simp_rw [hleft]
  rw [lintegral_lintegral_swap (by
    apply Measurable.aemeasurable
    exact ((hg.comp (measurable_fst.sub measurable_snd)).mul (hK.comp measurable_snd)).mul
      (hh.comp measurable_fst))]
  have hshift (z : Space) : (∫⁻ y, (g (y-z)*K z)*h y)=
      ∫⁻ x, (g x*K z)*h (x+z) := by
    have ht := lintegral_add_left_eq_self (μ := volume) (fun y => (g (y-z)*K z)*h y) z
    simpa only [add_sub_cancel_left,add_comm z,add_sub_cancel_right] using ht.symm
  simp_rw [hshift]
  rw [lintegral_lintegral_swap (by
    apply Measurable.aemeasurable
    exact ((hg.comp measurable_snd).mul (hK.comp measurable_fst)).mul
      (hh.comp (measurable_snd.add measurable_fst)))]
  apply lintegral_congr
  intro x
  simp only [mul_assoc]
  exact lintegral_const_mul'' _ (hK.mul (hh.comp (measurable_const.add measurable_id))).aemeasurable

/-- The finite-family inequality (7.2), expressed as a nonnegative integral.
No norm estimate or bound for the supremum is assumed or asserted. -/
theorem finite_positive_kernel_duality_bound {ι : Type*} (s : Finset ι)
    (g K : ι → Space → ℝ≥0∞) (h : Space → ℝ≥0∞)
    (hg : ∀ i ∈ s, Measurable (g i)) (hK : ∀ i ∈ s, Measurable (K i))
    (hh : Measurable h) :
    (∫⁻ y, (∑ i ∈ s, ∫⁻ z, g i (y-z)*K i z)*h y) ≤
      ∫⁻ x, (∑ i ∈ s, g i x)*s.sup (fun i => ∫⁻ z, K i z*h (x+z)) := by
  classical
  have hconv (i : ι) (hi : i∈s) : Measurable (fun y => ∫⁻ z, g i (y-z)*K i z) :=
    ((hg i hi).comp (measurable_fst.sub measurable_snd) |>.mul
      ((hK i hi).comp measurable_snd)).lintegral_prod_right
  have hadj (i : ι) (hi : i∈s) : Measurable (fun x => ∫⁻ z, K i z*h (x+z)) :=
    (((hK i hi).comp measurable_snd).mul (hh.comp (measurable_fst.add measurable_snd))).lintegral_prod_right
  simp_rw [Finset.sum_mul]
  rw [lintegral_finset_sum' s (fun i hi => ((hconv i hi).mul hh).aemeasurable)]
  calc
    _ = ∑ i ∈ s, ∫⁻ x, g i x*(∫⁻ z, K i z*h (x+z)) :=
      Finset.sum_congr rfl (fun i hi => positive_kernel_duality _ _ h (hg i hi) (hK i hi) hh)
    _ = ∫⁻ x, ∑ i ∈ s, g i x*(∫⁻ z, K i z*h (x+z)) :=
      (lintegral_finset_sum' s (fun i hi => ((hg i hi).mul (hadj i hi)).aemeasurable)).symm
    _ ≤ _ := by
      apply lintegral_mono
      intro x
      exact Finset.sum_le_sum (fun i hi => mul_le_mul_left' (Finset.le_sup hi) (g i x))

end EllipticSquareFunction
