import EllipticSquareFunction.Definitions

/-!
# Decaying-weight convolution

The weight-transfer inequality is proved in every normed additive group.
The infinite-sum theorem assumes summability of the translated lattice weight;
the uniform lattice-counting bound is a separate geometric obligation.
-/

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

theorem bracket_sub_le_mul {E : Type*} [NormedAddCommGroup E] (u n v : E) :
    bracket (u - v) ≤ bracket (u - n) * bracket (n - v) := by
  have h := norm_add_le (u - n) (n - v)
  rw [sub_add_sub_cancel] at h
  unfold bracket
  nlinarith [norm_nonneg (u - n), norm_nonneg (n - v)]

/-- A Peetre-type estimate. Summing it gives (2.2) once the remaining weight
with exponent `b-a` is known to have uniformly bounded lattice sum. -/
theorem weight_transfer {E : Type*} [NormedAddCommGroup E]
    (u n v : E) {a b : ℝ} (ha : 0 ≤ a) :
    bracket (u - n) ^ (-b) * bracket (n - v) ^ (-a) ≤
      bracket (u - v) ^ (-a) * bracket (u - n) ^ (-(b - a)) := by
  have h := Real.rpow_le_rpow_of_nonpos (bracket_pos (u - v))
    (bracket_sub_le_mul u n v) (neg_nonpos.mpr ha)
  rw [Real.mul_rpow (bracket_pos _).le (bracket_pos _).le] at h
  have hp : bracket (u - n) ^ (-b) =
      bracket (u - n) ^ (-a) * bracket (u - n) ^ (-(b - a)) := by
    rw [← Real.rpow_add (bracket_pos _)]
    congr 1
    ring
  rw [hp, mul_right_comm]
  exact mul_le_mul_of_nonneg_right h (Real.rpow_nonneg (bracket_pos _).le _)

theorem finite_weight_convolution {ι E : Type*} [NormedAddCommGroup E]
    (s : Finset ι) (n : ι → E) (u v : E) {a b C : ℝ} (ha : 0 ≤ a)
    (hs : ∑ i ∈ s, bracket (u - n i) ^ (-(b - a)) ≤ C) :
    (∑ i ∈ s, bracket (u - n i) ^ (-b) * bracket (n i - v) ^ (-a)) ≤
      C * bracket (u - v) ^ (-a) := by
  calc
    _ ≤ ∑ i ∈ s, bracket (u - v) ^ (-a) * bracket (u - n i) ^ (-(b - a)) :=
      Finset.sum_le_sum (fun i _ => weight_transfer u (n i) v ha)
    _ = bracket (u - v) ^ (-a) * ∑ i ∈ s, bracket (u - n i) ^ (-(b - a)) :=
      (Finset.mul_sum ..).symm
    _ ≤ bracket (u - v) ^ (-a) * C :=
      mul_le_mul_of_nonneg_left hs (Real.rpow_nonneg (bracket_pos _).le _)
    _ = _ := mul_comm _ _

theorem summable_weight_convolution {ι E : Type*} [NormedAddCommGroup E]
    (n : ι → E) (u v : E) {a b : ℝ} (ha : 0 ≤ a)
    (hs : Summable (fun i => bracket (u - n i) ^ (-(b - a)))) :
    Summable (fun i => bracket (u - n i) ^ (-b) * bracket (n i - v) ^ (-a)) := by
  apply Summable.of_nonneg_of_le
    (fun i => mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _)
      (Real.rpow_nonneg (bracket_pos _).le _))
    (fun i => weight_transfer u (n i) v ha)
  exact hs.mul_left _

theorem infinite_weight_convolution {ι E : Type*} [NormedAddCommGroup E]
    (n : ι → E) (u v : E) {a b C : ℝ} (ha : 0 ≤ a)
    (hs : Summable (fun i => bracket (u - n i) ^ (-(b - a))))
    (hC : (∑' i, bracket (u - n i) ^ (-(b - a))) ≤ C) :
    (∑' i, bracket (u - n i) ^ (-b) * bracket (n i - v) ^ (-a)) ≤
      C * bracket (u - v) ^ (-a) := by
  calc
    _ ≤ ∑' i, bracket (u - v) ^ (-a) * bracket (u - n i) ^ (-(b - a)) :=
      Summable.tsum_le_tsum (fun i => weight_transfer u (n i) v ha)
        (summable_weight_convolution n u v ha hs) (hs.mul_left _)
    _ = bracket (u - v) ^ (-a) * ∑' i, bracket (u - n i) ^ (-(b - a)) :=
      tsum_mul_left
    _ ≤ bracket (u - v) ^ (-a) * C :=
      mul_le_mul_of_nonneg_left hC (Real.rpow_nonneg (bracket_pos _).le _)
    _ = _ := mul_comm _ _

end EllipticSquareFunction
