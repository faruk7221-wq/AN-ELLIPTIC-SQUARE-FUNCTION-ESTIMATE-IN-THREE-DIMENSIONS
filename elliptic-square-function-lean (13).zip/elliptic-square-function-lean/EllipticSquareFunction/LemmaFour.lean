import EllipticSquareFunction.SamplingDensityReal

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- The normalization of (6.10) is at most one for positive integer D. -/
theorem sampling_coefficient_norm_le {D : ℕ} (hD : 0<D) (z : ℂ) :
    ‖((((D:ℝ)^3)⁻¹:ℝ):ℂ)*z‖ ≤ ‖z‖ := by
  have hD₁ : (1:ℝ)≤D := by exact_mod_cast hD
  have hq : 0≤((D:ℝ)^3)⁻¹ := by positivity
  have hq₁ : ((D:ℝ)^3)⁻¹≤1 := inv_le_one_of_one_le₀ (one_le_pow₀ hD₁)
  rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg hq]
  simpa only [one_mul] using mul_le_mul_of_nonneg_right hq₁ (norm_nonneg z)

/-- Lemma 4: a uniform physical Schwartz packet expansion and the actual
coefficient-density estimate (6.2), for every finite cap family. No packet
estimate, Nikodym bound, or internal sampling hypothesis is assumed. -/
theorem lemma_four_synthesis_and_density {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ M : ℝ} (hC₀ : 0≤C₀) (hM : 2<M) :
    ∃ χ : Plane → ℂ, ∃ ρ : SchwartzMap ℝ ℂ, ∃ D : ℕ, ∃ C : ℝ,
      ContDiff ℝ (⊤ : ℕ∞) χ ∧ HasCompactSupport χ ∧
      HasCompactSupport (ρ : ℝ → ℂ) ∧ 0<D ∧ 0<C ∧
      ∀ R : ℝ, 1≤R → ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
      (∀ θ, Function.support (fourierTransform (f θ)) ⊆ cap φ (ν θ) (Real.sqrt R)⁻¹ C₀) →
      let p := fun θ (i : IntPlane × ℤ) => samplePoint (Real.sqrt R) R D D
        (velocity φ (ν θ)) (latticePoint 1 i.1) i.2
      let a := fun θ i => ((((D:ℝ)^3)⁻¹:ℝ):ℂ)*f θ (p θ i)
      (∀ θ y, HasSum (fun i => a θ i*timePacket φ χ (inverseTimeProfile ρ) R (ν θ)
        (p θ i).1 (p θ i).2 y) (f θ y)) ∧
      (∀ θ y, Summable (fun i => ‖a θ i‖^2*
        packetWeight R M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y)) ∧
      ∀ y, (∑ θ, ∑' i, ‖a θ i‖^2*
        packetWeight R M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y) ≤
        C*∑ θ, positiveConvolution (fun z => ‖f θ z‖^2) (tubeKernel R M (velocity φ (ν θ))) y := by
  obtain ⟨χ,ρ,D,hχ,hχs,hρs,hD,hexpand⟩ := uniform_schwartz_cap_packet_expansion hphase hC₀
  have hD₀ : (0:ℝ)<D := by exact_mod_cast hD
  obtain ⟨C,hC,hdensity⟩ := uniform_cap_sampling_density_real hphase hC₀ hM hD₀ hD₀
  refine ⟨χ,ρ,D,C,hχ,hχs,hρs,hD,hC,?_⟩
  intro R hR n ν f hcap p a
  have hR₀ : 0<R := by linarith
  have hpoint (θ : Fin n) (y : Space) (i : IntPlane × ℤ) :
      ‖a θ i‖^2*packetWeight R M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y ≤
      ‖f θ (p θ i)‖^2*packetWeight R M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y :=
    mul_le_mul_of_nonneg_right
      (pow_le_pow_left₀ (norm_nonneg _) (sampling_coefficient_norm_le hD _) 2) (packetWeight_nonneg ..)
  have hsum (θ : Fin n) (y : Space) : Summable (fun i => ‖a θ i‖^2*
      packetWeight R M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y) :=
    (hdensity R hR (ν θ) (f θ) (hcap θ) y).1.of_nonneg_of_le
      (fun _ => mul_nonneg (sq_nonneg _) (packetWeight_nonneg ..)) (hpoint θ y)
  refine ⟨fun θ y => hexpand R hR₀ (ν θ) (f θ) (hcap θ) y,hsum,?_⟩
  intro y
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro θ hθ
  exact ((hsum θ y).tsum_le_tsum (hpoint θ y)
    (hdensity R hR (ν θ) (f θ) (hcap θ) y).1).trans
      (hdensity R hR (ν θ) (f θ) (hcap θ) y).2

end EllipticSquareFunction
