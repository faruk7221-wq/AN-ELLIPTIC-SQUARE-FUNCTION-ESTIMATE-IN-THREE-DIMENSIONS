import EllipticSquareFunction.AllTimePacketDecay
import EllipticSquareFunction.TemporalCutoff
import EllipticSquareFunction.InverseTimeProfile
import EllipticSquareFunction.WeightIntegrals

noncomputable section
open MeasureTheory
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Global spacetime decay, uniform in scale, frequency, and packet center. -/
theorem timePacket_global_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (ψ : SchwartzMap ℝ ℂ) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν v : Plane) (s : ℝ) (y : Space),
      ‖timePacket φ b ψ R ν v s y‖ ≤ C*packetWeight R L (velocity φ ν) v s y := by
  obtain ⟨Cs,hCs,hs⟩ := freePacket_all_time_polynomial_decay hphase b hb hbs L
  obtain ⟨Ct,hCt,ht⟩ := schwartz_absorbs_time_loss ψ L L
  refine ⟨Cs*Ct,mul_pos hCs hCt,?_⟩
  intro R hR ν v s y
  have hR₀ : 0<R := by linarith
  have hN : 1≤Real.sqrt R := (Real.one_le_sqrt).mpr hR
  let u := (y.2-s)/R
  let w := bracket ((Real.sqrt R)⁻¹ • (y.1-v+(y.2-s) • velocity φ ν))^(-(L:ℝ))
  have hw : 0≤w := Real.rpow_nonneg (bracket_pos _).le _
  have hh := hs (Real.sqrt R) hN ν v (y.1,y.2-s)
  simp only [Real.sq_sqrt hR₀.le] at hh
  have hh' : ‖freePacket φ b (Real.sqrt R) ν v (y.1,y.2-s)‖ ≤ Cs*bracket u^L*w := by
    simpa only [u,w,bracket,Real.norm_eq_abs] using hh
  have ht' := ht u u (by constructor <;> simp)
  unfold timePacket
  rw [norm_mul]
  calc
    _ ≤ ‖ψ u‖*(Cs*bracket u^L*w) := mul_le_mul_of_nonneg_left hh' (norm_nonneg _)
    _ = Cs*(‖ψ u‖*bracket u^L)*w := by ring
    _ ≤ Cs*(Ct*bracket u^(-(L:ℝ)))*w :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left ht' hCs.le) hw
    _ = (Cs*Ct)*packetWeight R L (velocity φ ν) v s y := by
      unfold packetWeight
      dsimp only [u,w]
      ring

/-- Pointwise decay of the actual curved kernel with its R^-2 normalization. -/
theorem inverse_curvedMultiplier_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (χ : Plane → ℂ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    (ρ : SchwartzMap ℝ ℂ) (hρs : HasCompactSupport (ρ : ℝ → ℂ)) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν : Plane) (y : Space),
      ‖inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) y‖ ≤
        C*tubeKernel R L (velocity φ ν) y := by
  obtain ⟨C,hC,hbound⟩ := timePacket_global_decay hphase χ hχ hχs (inverseTimeProfile ρ) L
  have hφ : Continuous φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  refine ⟨C,hC,?_⟩
  intro R hR ν y
  have hR₀ : 0<R := by linarith
  rw [inverse_curvedMultiplier_timePacket φ hφ χ hχ.continuous hχs ρ hρs hR₀,
    norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (by positivity : 0≤(R^2)⁻¹)]
  have hh := mul_le_mul_of_nonneg_left (hbound R hR ν 0 0 y) (by positivity : 0≤(R^2)⁻¹)
  simpa only [tubeKernel,mul_left_comm] using hh

end EllipticSquareFunction
