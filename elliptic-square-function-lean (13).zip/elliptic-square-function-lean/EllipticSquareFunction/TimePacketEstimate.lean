import EllipticSquareFunction.RebasedTimeOrigins
import EllipticSquareFunction.TemporalAssembly

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- The complete unit-time-lattice argument of Proposition 3, with the
rebased free-wave estimate as a precise premise, supplied in the next module. -/
theorem time_packet_estimate_of_rebased (ψ : SchwartzMap ℝ ℂ) (B : ℕ)
    {M Cd : ℝ} (hM : 0≤M) (hCd : 0≤Cd) :
    ∃ C : ℝ, 0<C ∧ ∀ (R K : ℝ) (s : Finset ℤ)
      (F : ℤ → Space → ℂ) (D : ℤ → Space → ℝ), 0<R → 0≤K →
      (∀ k ∈ s, Continuous (F k)) → (∀ k ∈ s, Continuous (D k)) →
      (∀ k ∈ s, ∀ y, 0≤D k y) →
      (∀ k ∈ s, ∀ Δ : ℝ,
        l3 (fun y => F k (y.1,y.2+Δ*R)) (volume.restrict (timeSlab R)) ≤
        ENNReal.ofReal (K*Real.sqrt (Cd*bracket Δ^B))*
          densityCubeRoot (fun y => D k (y.1,y.2+Δ*R)) R) →
      l3 (fun y => ∑ k ∈ s, ψ ((y.2-(k:ℝ)*R)/R)*F k (y.1,y.2-(k:ℝ)*R)) volume ≤
        ENNReal.ofReal (C*K)*
          (∫⁻ y : Space, (ENNReal.ofReal (∑ k ∈ s,
            bracket ((y.2-(k:ℝ)*R)/R)^(-M)*D k (y.1,y.2-(k:ℝ)*R)))^(3/2:ℝ))^(1/3:ℝ) := by
  let A : ℕ := ⌈3*M/2⌉₊+2
  have hA : 1<(A:ℝ) := by dsimp [A]; push_cast; linarith [Nat.cast_nonneg (α := ℝ) ⌈3*M/2⌉₊]
  have hAM : M≤2*(A:ℝ)/3 := by
    have hh := Nat.le_ceil (3*M/2)
    dsimp [A]; push_cast; linarith
  obtain ⟨C₀,hC₀,hcut⟩ := cutoff_time_slice ψ A B
  let Q := timeLatticeSumConstant (A:ℝ)
  have hQ : 0≤Q := by simpa [Q] using timeInteraction_sum_bound hA 0 ∅
  let C := C₀*Real.sqrt Cd*Q^(2/3:ℝ)*(2^M)^(1/2:ℝ)
  have hC : 0≤C := by dsimp [C]; positivity
  refine ⟨C+1,by positivity,?_⟩
  intro R K s F D hR hK hF hD hD₀ hfree
  let U := fun (k : ℤ) (y : Space) => ψ ((y.2-(k:ℝ)*R)/R)*F k (y.1,y.2-(k:ℝ)*R)
  let V := fun (k : ℤ) (y : Space) => ENNReal.ofReal (D k (y.1,y.2-(k:ℝ)*R))
  have hU (k : ℤ) (hk : k∈s) : Continuous (U k) := by
    dsimp [U]
    exact (ψ.continuous.comp ((continuous_snd.sub continuous_const).div_const R)).mul
      ((hF k hk).comp (continuous_fst.prodMk (continuous_snd.sub continuous_const)))
  have hV (k : ℤ) (hk : k∈s) : Measurable (V k) :=
    ((hD k hk).comp (continuous_fst.prodMk (continuous_snd.sub continuous_const))).measurable.ennreal_ofReal
  have hbound (j k : ℤ) (hk : k∈s) := hcut (F k) (D k) R K Cd (hF k hk) hR hK hCd (hfree k hk) j k
  have hh := time_lattice_l3_assembly s R (A:ℝ) M hA hM hAM U V
    (ENNReal.ofReal (C₀*K*Real.sqrt Cd)) hU hV hbound
  have hcoef : ENNReal.ofReal (C₀*K*Real.sqrt Cd)*(ENNReal.ofReal Q)^(2/3:ℝ)*
      (ENNReal.ofReal (2^M))^(1/2:ℝ) ≤ ENNReal.ofReal ((C+1)*K) := by
    rw [ENNReal.ofReal_rpow_of_nonneg hQ (by norm_num),
      ENNReal.ofReal_rpow_of_nonneg (by positivity : (0:ℝ)≤2^M) (by norm_num),
      ← ENNReal.ofReal_mul (by positivity : 0≤C₀*K*Real.sqrt Cd),
      ← ENNReal.ofReal_mul (by positivity : 0≤(C₀*K*Real.sqrt Cd)*Q^(2/3:ℝ))]
    apply ENNReal.ofReal_le_ofReal
    have he : C₀*K*Real.sqrt Cd*Q^(2/3:ℝ)*(2^M)^(1/2:ℝ)=C*K := by dsimp [C]; ring
    rw [he]
    exact mul_le_mul_of_nonneg_right (by linarith) hK
  have he (y : Space) :
      (∑ k ∈ s, ENNReal.ofReal (bracket (y.2/R-(k:ℝ))^(-M))*V k y) =
      ENNReal.ofReal (∑ k ∈ s, bracket ((y.2-(k:ℝ)*R)/R)^(-M)*D k (y.1,y.2-(k:ℝ)*R)) := by
    rw [ENNReal.ofReal_sum_of_nonneg (fun k hk =>
      mul_nonneg (Real.rpow_nonneg (bracket_pos _).le _) (hD₀ k hk _))]
    apply Finset.sum_congr rfl
    intro k hk
    have ht : (y.2-(k:ℝ)*R)/R=y.2/R-(k:ℝ) := by field_simp; ring
    rw [ht,ENNReal.ofReal_mul (Real.rpow_nonneg (bracket_pos _).le _)]
  simp_rw [he] at hh
  exact hh.trans (mul_le_mul_right' hcoef _)

end EllipticSquareFunction
