import EllipticSquareFunction.TangentSecondFundamentalForm
import EllipticSquareFunction.ArticleMainTheorem

noncomputable section
namespace EllipticSquareFunction

/-- The same smooth embedded boundary-chart definition, with curvature
expressed as definiteness of a bilinear form on the actual tangent plane. -/
def TangentEllipticSurfaceWithBoundary (K : Set EuclideanThree) : Prop :=
  ∀ p ∈ K, ∃ (F : Plane → EuclideanThree) (U : Set Plane) (a : Plane)
      (W : Set EuclideanThree) (N : EuclideanThree) (model : SurfaceParameterModel)
      (hD : Function.Injective (fderiv ℝ F a)),
    IsOpen U ∧ a ∈ U ∧ a ∈ model.domain ∧ (model = .boundary → a 1=0) ∧
    ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Topology.IsEmbedding (fun b : U => F b) ∧ F a=p ∧
    IsOpen W ∧ p ∈ W ∧ K ∩ W=(F '' (U ∩ model.domain)) ∩ W ∧ ‖N‖=1 ∧
    (∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F a v)=0) ∧
    ((∀ v : euclideanTangentPlane F a, v ≠ 0 → 0 < tangentSecondForm F N a hD v v) ∨
      (∀ v : euclideanTangentPlane F a, v ≠ 0 → tangentSecondForm F N a hD v v < 0))

theorem tangent_surface_definition_iff (K : Set EuclideanThree) :
    TangentEllipticSurfaceWithBoundary K ↔ SmoothEllipticSurfaceWithBoundary K := by
  constructor
  · intro hs p hp
    obtain ⟨F,U,a,W,N,model,hD,hU,ha,ham,hab,hF,hemb,hFa,hW,hpW,hpatch,hN,horth,hdef⟩ := hs p hp
    exact ⟨F,U,a,W,N,model,hU,ha,ham,hab,hF,hemb,hFa,hW,hpW,hpatch,hD,hN,horth,
      (tangent_second_form_definite_iff F N a hD).mp hdef⟩
  · intro hs p hp
    obtain ⟨F,U,a,W,N,model,hU,ha,ham,hab,hF,hemb,hFa,hW,hpW,hpatch,hD,hN,horth,hdef⟩ := hs p hp
    exact ⟨F,U,a,W,N,model,hD,hU,ha,ham,hab,hF,hemb,hFa,hW,hpW,hpatch,hN,horth,
      (tangent_second_form_definite_iff F N a hD).mpr hdef⟩

/-- Surface Theorem 1 with curvature stated on tangent vectors. Interior and
smooth boundary charts are both covered. -/
theorem article_tangent_surface_theorem {K : Set EuclideanThree} (hK : IsCompact K)
    (hsurface : TangentEllipticSurfaceWithBoundary K) {c₀ C₀ : ℝ}
    (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ :=
  article_surface_theorem hK hc₀ hC₀ ((tangent_surface_definition_iff K).mp hsurface)
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
