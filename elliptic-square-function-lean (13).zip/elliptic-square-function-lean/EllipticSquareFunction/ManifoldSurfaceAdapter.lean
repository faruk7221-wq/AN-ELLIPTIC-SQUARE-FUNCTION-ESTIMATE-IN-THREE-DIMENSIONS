import EllipticSquareFunction.ArticleMainTheorem
import Mathlib.Geometry.Manifold.ContMDiff.Atlas
import Mathlib.Geometry.Manifold.ContMDiff.NormedSpace

noncomputable section
open scoped Manifold
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace Plane M]
  [IsManifold 𝓘(ℝ, Plane) (⊤ : ℕ∞) M]

def manifoldSurfaceParam (f : M → EuclideanThree) (x : M) : Plane → EuclideanThree :=
  f ∘ (chartAt Plane x).symm

/-- Immersion and definite normal curvature in the canonical manifold
charts. Smoothness and embeddedness are supplied separately by Mathlib's
ContMDiff and IsEmbedding predicates. -/
def ManifoldEllipticImmersion (f : M → EuclideanThree) : Prop :=
  ∀ x : M, Function.Injective (fderiv ℝ (manifoldSurfaceParam f x) (chartAt Plane x x)) ∧
    ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N
        (fderiv ℝ (manifoldSurfaceParam f x) (chartAt Plane x x) v)=0) ∧
      EuclideanDefiniteSecondForm (manifoldSurfaceParam f x) N (chartAt Plane x x)

theorem manifold_surface_param_smooth {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) (x : M) :
    ContDiffOn ℝ (⊤ : ℕ∞) (manifoldSurfaceParam f x) (chartAt Plane x).target :=
  (hf.comp_contMDiffOn (contMDiffOn_chart_symm (I := 𝓘(ℝ, Plane)) (x := x))).contDiffOn

/-- An embedded smooth Mathlib manifold without boundary yields the explicit
surface chart definition. Only the immersion and curvature conditions are
recorded in local coordinates; graph charts are still constructed later. -/
theorem manifold_embedding_surface_charts {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f) (hell : ManifoldEllipticImmersion f) :
    SmoothEllipticSurfaceWithBoundary (Set.range f) := by
  intro p hp
  obtain ⟨x,rfl⟩ := hp
  let e := chartAt Plane x
  let F := manifoldSurfaceParam f x
  obtain ⟨hD,N,hN,horth,hdef⟩ := hell x
  obtain ⟨W,hW,heW⟩ := hemb.isInducing.isOpen_iff.mp e.open_source
  have hx : x ∈ e.source := mem_chart_source Plane x
  have hpW : f x ∈ W := by
    have hm : x ∈ f ⁻¹' W := by rw [heW]; exact hx
    exact hm
  have hFe : Topology.IsEmbedding (fun b : e.target => F b) :=
    hemb.comp (Topology.IsEmbedding.subtypeVal.comp e.symm.toHomeomorphSourceTarget.isEmbedding)
  have hboundary : SurfaceParameterModel.interior = .boundary → (e x) 1=0 := by
    intro h
    cases h
  refine ⟨F,e.target,e x,W,N,.interior,e.open_target,e.map_source hx,
    Set.mem_univ _,hboundary,manifold_surface_param_smooth hf x,hFe,
    ?_,hW,hpW,?_,hD,hN,horth,hdef⟩
  · change f (e.symm (e x))=f x
    rw [e.left_inv hx]
  · ext y
    constructor
    · rintro ⟨⟨z,rfl⟩,hzW⟩
      have hz : z ∈ e.source := by
        rw [← heW]
        exact hzW
      refine ⟨⟨e z,⟨e.map_source hz,Set.mem_univ _⟩,?_⟩,hzW⟩
      change f (e.symm (e z))=f z
      rw [e.left_inv hz]
    · rintro ⟨⟨b,_,rfl⟩,hbW⟩
      exact ⟨⟨e.symm b,rfl⟩,hbW⟩

/-- The estimate for the image of a compact, smoothly embedded Mathlib
two-manifold without boundary, with definite normal curvature. -/
theorem compact_manifold_surface_estimate [CompactSpace M] {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f) (hell : ManifoldEllipticImmersion f)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ :=
  article_surface_theorem (isCompact_range hf.continuous) hc₀ hC₀
    (manifold_embedding_surface_charts hf hemb hell) hplacement hnikodym hdiscrete

end EllipticSquareFunction
