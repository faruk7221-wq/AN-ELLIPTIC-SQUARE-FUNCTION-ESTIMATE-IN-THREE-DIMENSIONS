import EllipticSquareFunction.TimePacketEstimate

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

def arrayTimePacket {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    (b : Plane → ℂ) (ψ : ℝ → ℂ) (N s : ℝ) (y : Space) : ℂ :=
  ψ ((y.2-s)/(N^2))*arrayPacketSum d φ b N (y.1,y.2-s)

def arrayPacketDensity {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    (N M s : ℝ) (y : Space) : ℝ :=
  bracket ((y.2-s)/(N^2))^(-M)*arraySpatialDensity d φ N M (y.1,y.2-s)

theorem continuous_arraySpatialDensity {ι : Type*} (d : FinitePacketArray ι)
    (φ : Phase) (N M : ℝ) : Continuous (arraySpatialDensity d φ N M) := by
  unfold arraySpatialDensity spatialDensity
  apply continuous_finset_sum
  intro ip hip
  apply continuous_const.mul
  unfold spatialWeight bracket
  apply Continuous.rpow_const
  · fun_prop
  · intro y
    left
    positivity

theorem arrayTimePacket_eq_packets {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    (b : Plane → ℂ) (ψ : ℝ → ℂ) {N : ℝ} (hN : 0≤N) (s : ℝ) (y : Space) :
    arrayTimePacket d φ b ψ N s y =
      ∑ i ∈ d.labels, ∑ p ∈ d.positions i,
        d.coefficient i p*timePacket φ b ψ (N^2) (d.frequency i) (d.position i p) s y := by
  simp only [arrayTimePacket,arrayPacketSum,timePacket,Real.sqrt_sq hN,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro p hp
  ring

theorem arrayPacketDensity_eq_packets {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    {N : ℝ} (hN : 0≤N) (M s : ℝ) (y : Space) :
    arrayPacketDensity d φ N M s y =
      packetDensity (d.labels.sigma d.positions) (fun ip => d.coefficient ip.1 ip.2)
        (fun ip => velocity φ (d.frequency ip.1)) (fun ip => d.position ip.1 ip.2)
        (fun _ => s) (N^2) M y := by
  simp only [arrayPacketDensity,arraySpatialDensity,spatialDensity,packetDensity,
    packetWeight_square_scale hN,Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro ip hip
  ring

/-- Proposition 3 for one profile and the unit time lattice, with arbitrary
separated spatial arrays at each time origin. Constants precede κ,η and scale.
The only analytic input is the stated external discrete estimate. -/
theorem proposition_three_unit_fixed_setup {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (ψ : SchwartzMap ℝ ℂ)
    {c σ F M : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M) (hQ₂ : 3≤S.C₂) :
    ∃ Z A : ℝ, 0<Z ∧ 1≤A ∧ (A+1≤S.C₁ →
      ∃ Z' : ℝ, 0<Z' ∧ (F+Z+Z'≤S.frequencyBound →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
          ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
          let N : ℝ := (2:ℝ)^j
          ∀ (T : Finset ℤ) (d : ℤ → FinitePacketArray ι),
          (∀ k ∈ T, SeparatedPacketArray (d k) N c σ F) →
          l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) S.φ b ψ N ((k:ℝ)*N^2) y) volume ≤
            ENNReal.ofReal (C*packetConstant P κ η (N^2))*
              (∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
                arrayPacketDensity (d k) S.φ N M ((k:ℝ)*N^2) y))^(3/2:ℝ))^(1/3:ℝ))) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨Z,A,hZ,hA,hbound⟩ := equation_5_10_fixed_setup (ι := ι)
    S hphase hinput b hb hbs hc hσ hF hM hQ₂
  refine ⟨Z,A,hZ,hA,?_⟩
  intro hA₁
  obtain ⟨Z',hZ',hbound⟩ := hbound hA₁
  refine ⟨Z',hZ',?_⟩
  intro hFZ
  obtain ⟨Cp,Cd,hCp,hCd,B,hbound⟩ := hbound hFZ
  obtain ⟨Ct,hCt,htime⟩ := time_packet_estimate_of_rebased ψ B (by linarith : 0≤M) hCd.le
  refine ⟨Ct*Cp,mul_pos hCt hCp,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N T d hd
  have hN : 0<N := by positivity
  have hK : 0≤Cp*packetConstant P κ η (N^2) :=
    mul_nonneg hCp.le (packetConstant_nonneg_global (by linarith) κ η)
  have hf (k : ℤ) (hk : k∈T) (Δ : ℝ) :=
    hbound j hj (d k).labels (d k).positions (d k).coefficient (d k).frequency (d k).position
      (hd k hk).1 (hd k hk).2.1 (hd k hk).2.2 Δ
  have hh := htime (N^2) (Cp*packetConstant P κ η (N^2)) T
    (fun k => arrayPacketSum (d k) S.φ b N) (fun k => arraySpatialDensity (d k) S.φ N M)
    (sq_pos_of_pos hN) hK
    (fun k _ => continuous_arrayPacketSum (d k) S.φ hφ.continuous b hb.continuous hbs hN.ne')
    (fun k _ => continuous_arraySpatialDensity (d k) S.φ N M)
    (fun k _ y => spatialDensity_nonneg_global ..)
    (fun k hk Δ => by simpa only [arrayPacketSum,arraySpatialDensity,bracket,Real.norm_eq_abs] using hf k hk Δ)
  simpa only [arrayTimePacket,arrayPacketDensity,mul_assoc] using hh

end EllipticSquareFunction
