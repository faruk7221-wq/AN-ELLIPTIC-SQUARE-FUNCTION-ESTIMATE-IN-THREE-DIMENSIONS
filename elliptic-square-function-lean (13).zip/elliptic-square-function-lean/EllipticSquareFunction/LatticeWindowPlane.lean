import EllipticSquareFunction.LatticeWindowOne

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

def latticeWindowPlane (x : Plane) : ℝ := latticeWindowOne (x 0)*latticeWindowOne (x 1)

theorem latticeWindowOne_square_summable (x : ℝ) :
    Summable (fun m : ℤ => latticeWindowOne (x-m)^2) := by
  apply summable_of_ne_finset_zero (s := {Int.floor x,Int.floor x+1})
  intro m hm
  rw [latticeWindowOne_translate_zero x m hm]
  simp

theorem latticeWindowPlane_nonneg (x : Plane) : 0≤latticeWindowPlane x :=
  mul_nonneg (latticeWindowOne_nonneg _) (latticeWindowOne_nonneg _)

theorem latticeWindowPlane_smooth : ContDiff ℝ (⊤:ℕ∞) latticeWindowPlane := by
  unfold latticeWindowPlane
  apply ContDiff.mul
  · exact latticeWindowOne_smooth.comp (EuclideanSpace.proj (𝕜 := ℝ) (ι := Fin 2) 0).contDiff
  · exact latticeWindowOne_smooth.comp (EuclideanSpace.proj (𝕜 := ℝ) (ι := Fin 2) 1).contDiff

theorem latticeWindowPlane_partition (x : Plane) :
    (∑' m : IntPlane, latticeWindowPlane (x-latticePoint 1 m)^2)=1 := by
  have hs := latticeWindowOne_square_summable (x 0)
  have ht := latticeWindowOne_square_summable (x 1)
  have he := hs.tsum_mul_tsum ht
    (hs.mul_of_nonneg ht (fun m => sq_nonneg _) (fun m => sq_nonneg _))
  rw [latticeWindowOne_partition,latticeWindowOne_partition,one_mul] at he
  calc
    _ = ∑' m : IntPlane, latticeWindowOne (x 0-(m 0:ℝ))^2*
        latticeWindowOne (x 1-(m 1:ℝ))^2 := by
      apply tsum_congr
      intro m
      simp [latticeWindowPlane,latticePoint,mul_pow]
    _ = ∑' p : ℤ×ℤ, latticeWindowOne (x 0-(p.1:ℝ))^2*
        latticeWindowOne (x 1-(p.2:ℝ))^2 :=
      by
      simpa only [finTwoArrowEquiv,piFinTwoEquiv,Equiv.coe_fn_mk] using
        (finTwoArrowEquiv ℤ).tsum_eq (fun p : ℤ×ℤ => latticeWindowOne (x 0-(p.1:ℝ))^2*
          latticeWindowOne (x 1-(p.2:ℝ))^2)
    _ = 1 := he.symm

/-- The constructed window is supported in a fixed coordinate box. -/
theorem latticeWindowPlane_support : tsupport latticeWindowPlane⊆
    {x : Plane | ∀ i : Fin 2, |x i|≤1} := by
  apply closure_minimal
  · intro x hx i
    have hn : latticeWindowPlane x≠0 := hx
    have h0 : latticeWindowOne (x 0)≠0 := fun hh => hn (by simp [latticeWindowPlane,hh])
    have h1 : latticeWindowOne (x 1)≠0 := fun hh => hn (by simp [latticeWindowPlane,hh])
    have hb (j : Fin 2) (hj : latticeWindowOne (x j)≠0) : |x j|≤1 := by
      have hs := latticeWindowOne_support (subset_closure hj)
      exact abs_le.mpr hs
    fin_cases i
    · exact hb 0 h0
    · exact hb 1 h1
  · rw [Set.setOf_forall]
    exact isClosed_iInter (fun i => isClosed_le (EuclideanSpace.proj i).continuous.abs continuous_const)

theorem latticeWindowPlane_compact : HasCompactSupport latticeWindowPlane := by
  apply (isCompact_closedBall (0:Plane) 2).of_isClosed_subset (isClosed_tsupport _)
  intro x hx
  have hb := latticeWindowPlane_support hx
  rw [Metric.mem_closedBall,dist_zero_right,EuclideanSpace.norm_eq]
  apply Real.sqrt_le_iff.mpr
  refine ⟨by norm_num,?_⟩
  simp only [Fin.sum_univ_two,Real.norm_eq_abs]
  have h0 := hb 0
  have h1 := hb 1
  nlinarith [abs_nonneg (x 0),abs_nonneg (x 1)]

end EllipticSquareFunction
