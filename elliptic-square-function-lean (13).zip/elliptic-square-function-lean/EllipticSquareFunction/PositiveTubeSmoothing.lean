import EllipticSquareFunction.PositiveDualNormUnrestricted
import EllipticSquareFunction.SchwartzTubeSmoothing

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- Lemma 5, in positive-integral form, for arbitrary measurable nonnegative
data. The norms may be infinite; no preliminary smoothing hypothesis or
integrability of the output is needed. The constant precedes all data. -/
theorem positive_tube_smoothing_bound (hinput : NikodymInput)
    {M F γ : ℝ} (hM : 3<M) (hF : 0≤F) (hγ : 0<γ) (hγ₁ : γ≤1) :
    ∃ A : ℝ, 0<A ∧ ∀ {ι : Type*} (s : Finset ι) (R : ℝ), 1≤R →
      ∀ V : ι → Plane, (∀ i∈s, ‖V i‖≤F) → ∀ g : ι → Space → ℝ≥0∞,
      (∀ i∈s, Measurable (g i)) →
      eLpNorm (fun y => ∑ i∈s, ∫⁻ z, g i (y-z)*ENNReal.ofReal (tubeKernel R M (V i) z))
        (3/2) volume ≤
        ENNReal.ofReal (A*R^(γ/2))*eLpNorm (fun y => ∑ i∈s, g i y) (3/2) volume := by
  classical
  obtain ⟨A,hA,hmax⟩ := finiteKernelMax_l3_bound hinput hM hF hγ hγ₁
  refine ⟨A,hA,?_⟩
  intro ι s R hR V hV g hg
  have hK (i : ι) : Measurable (fun z => ENNReal.ofReal (tubeKernel R M (V i) z)) := by
    unfold tubeKernel packetWeight bracket
    fun_prop
  have hm : Measurable (fun y => ∑ i∈s, ∫⁻ z, g i (y-z)*ENNReal.ofReal (tubeKernel R M (V i) z)) :=
    Finset.measurable_sum s (fun i hi =>
      (((hg i hi).comp (measurable_fst.sub measurable_snd)).mul
        ((hK i).comp measurable_snd)).lintegral_prod_right)
  apply positive_lThreeHalves_le_of_tests volume _ hm
  intro h hpos hmeas hlp
  have ht := finite_positive_kernel_duality_bound s g
    (fun i z => ENNReal.ofReal (tubeKernel R M (V i) z)) (fun y => ENNReal.ofReal (h y))
    hg (fun i hi => hK i) hmeas.ennreal_ofReal
  have ht' : (∫⁻ y, (∑ i∈s, ∫⁻ z, g i (y-z)*ENNReal.ofReal (tubeKernel R M (V i) z))*
      ENNReal.ofReal (h y)) ≤ ∫⁻ x, (∑ i∈s, g i x)*finiteKernelMax s R M V h x := by
    simpa only [finiteKernelMax,abs_of_nonneg (hpos _)] using ht
  have hh := positive_holder_three_halves volume (fun x => ∑ i∈s, g i x)
    (finiteKernelMax s R M V h)
    (Finset.measurable_sum s hg).aemeasurable
    (measurable_finiteKernelMax s R M V h hmeas).aemeasurable
  apply (ht'.trans hh).trans
  have hb := mul_le_mul_left' (hmax s R hR V hV h hmeas hlp)
    (eLpNorm (fun x => ∑ i∈s, g i x) (3/2) volume)
  simpa only [mul_assoc,mul_left_comm,mul_comm] using hb

end EllipticSquareFunction
