import EllipticSquareFunction.GlobalPacketDecay
import EllipticSquareFunction.ReproducingMultiplier
import EllipticSquareFunction.SamplingCauchySchwarz

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Continuity of the inverse transform of a continuous compact multiplier. -/
theorem continuous_inverseSpaceTransform (m : Space → ℂ) (hm : Continuous m)
    (hms : HasCompactSupport m) : Continuous (inverseSpaceTransform m) := by
  apply continuous_iff_continuousOn_univ.mpr
  apply continuousOn_integral_of_compact_support (μ := volume) hms
  · apply Continuous.continuousOn
    exact (hm.comp continuous_snd).mul (continuous_oscillation.comp
      ((continuous_fst.fst.inner continuous_snd.fst).add
        (continuous_fst.snd.mul continuous_snd.snd)))
  · intro y ζ hy hζ
    rw [image_eq_zero_of_nmem_tsupport hζ,zero_mul]

theorem packetWeight_reflect (R M : ℝ) (V : Plane) (p z : Space) :
    packetWeight R M V 0 0 (p-z)=packetWeight R M V p.1 p.2 z := by
  simp only [packetWeight_shearScale,Prod.mk.eta]
  change productBracketWeight M (shearScale (Real.sqrt R) R V ((p-z)-0))=_
  rw [sub_zero,shearScale_sub,shearScale_sub,productBracketWeight_sub_symm]

/-- A kernel with normalized packet decay has a mass bound independent of
scale, slope, and center. No integrability of the kernel is assumed. -/
theorem kernel_mass_of_packet_decay {R M C : ℝ} (hR : 0<R) (hM : 2<M)
    (hC : 0≤C) (V : Plane) (p : Space) (K : Space → ℂ)
    (hdecay : ∀ z, ‖K z‖≤C*(R^2)⁻¹*packetWeight R M V p.1 p.2 z) :
    (∫⁻ z, ENNReal.ofReal ‖K z‖) ≤
      ENNReal.ofReal (C*(spatialWeightMass M*temporalWeightMass M)) := by
  calc
    _ ≤ ∫⁻ z, ENNReal.ofReal (C*(R^2)⁻¹*packetWeight R M V p.1 p.2 z) :=
      lintegral_mono (fun z => ENNReal.ofReal_le_ofReal (hdecay z))
    _ = ENNReal.ofReal (∫ z, C*(R^2)⁻¹*packetWeight R M V p.1 p.2 z) := by
      symm
      apply ofReal_integral_eq_lintegral_ofReal
        ((packetWeight_integrable hR hM V p.1 p.2).const_mul _)
      exact Filter.Eventually.of_forall (fun z => by
        exact mul_nonneg (mul_nonneg hC (by positivity)) (packetWeight_nonneg ..))
    _ = _ := by
      rw [integral_const_mul,integral_packetWeight hR hM]
      congr 1
      field_simp
      ring

/-- Uniform pointwise decay and L1 mass for every translate of the actual
curved inverse multiplier. -/
theorem curved_reproducing_kernel_bounds {φ : Phase} (hphase : ContinuedPhase φ)
    (χ : Plane → ℂ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    (ρ : SchwartzMap ℝ ℂ) (hρs : HasCompactSupport (ρ : ℝ → ℂ))
    (L : ℕ) (hL : 2<(L:ℝ)) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν : Plane) (p : Space),
      let K := fun z => inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) (p-z)
      Continuous K ∧
      (∀ z, ‖K z‖≤C*(R^2)⁻¹*packetWeight R L (velocity φ ν) p.1 p.2 z) ∧
      (∫⁻ z, ENNReal.ofReal ‖K z‖) ≤
        ENNReal.ofReal (C*(spatialWeightMass L*temporalWeightMass L)) := by
  obtain ⟨C,hC,hbound⟩ := inverse_curvedMultiplier_decay hphase χ hχ hχs ρ hρs L
  have hφ : Continuous φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  refine ⟨C,hC,?_⟩
  intro R hR ν p
  have hR₀ : 0<R := by linarith
  have hm := continuous_curvedMultiplier φ hφ χ hχ.continuous ρ ρ.continuous (Real.sqrt R) R ν
  have hms := compactSupport_curvedMultiplier φ hφ χ hχs ρ hρs
    (Real.sqrt_pos.mpr hR₀).ne' hR₀.ne' ν
  have hd (z : Space) := hbound R hR ν (p-z)
  simp only [tubeKernel,packetWeight_reflect,← mul_assoc] at hd
  exact ⟨(continuous_inverseSpaceTransform _ hm hms).comp
    (continuous_const.sub continuous_id),hd,kernel_mass_of_packet_decay hR₀ hL hC.le _ p _ hd⟩

end EllipticSquareFunction
