import EllipticSquareFunction.PositiveTubeSmoothing

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000
attribute [local instance] space_volume_neg_invariant space_volume_add_left_invariant

/-- Hölder against the constant function, cubed. Infinite values are allowed. -/
theorem positive_integral_cube_le {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (h : α → ℝ≥0∞) (hm : Measurable h) :
    (∫⁻ x, h x ∂μ)^(3:ℝ)≤(∫⁻ x, h x^(3:ℝ) ∂μ)*(μ Set.univ)^(2:ℝ) := by
  have hh := ENNReal.lintegral_mul_le_Lp_mul_Lq μ
    (Real.holderConjugate_iff.mpr (by norm_num : 1<(3:ℝ) ∧ (3:ℝ)⁻¹+(3/2:ℝ)⁻¹=1))
    hm.aemeasurable (measurable_const : Measurable (fun _ : α => (1:ℝ≥0∞))).aemeasurable
  simp only [Pi.mul_apply,mul_one,ENNReal.one_rpow,lintegral_const,one_mul] at hh
  have hc := ENNReal.rpow_le_rpow hh (by norm_num : (0:ℝ)≤3)
  rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0:ℝ)≤3)] at hc
  simp only [← ENNReal.rpow_mul] at hc
  norm_num at hc
  simpa only [ENNReal.rpow_ofNat] using hc

/-- Weighted Hölder for a positive convolution, with the exact kernel mass. -/
theorem positive_weighted_integral_cube_le {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (K h : α → ℝ≥0∞) (hK : Measurable K) (hh : Measurable h) :
    (∫⁻ x, K x*h x ∂μ)^(3:ℝ)≤
      (∫⁻ x, K x*h x^(3:ℝ) ∂μ)*(∫⁻ x, K x ∂μ)^(2:ℝ) := by
  have hb := positive_integral_cube_le (μ.withDensity K) h hh
  rw [lintegral_withDensity_eq_lintegral_mul μ hK hh,
    lintegral_withDensity_eq_lintegral_mul μ hK (hh.pow_const (3:ℝ)),
    withDensity_apply K MeasurableSet.univ,Measure.restrict_univ] at hb
  exact hb

/-- Young's L1-to-L3 convolution estimate for arbitrary measurable positive
kernels and data. It applies to the absolute chart kernels in Section 8. -/
theorem positive_young_l3 (K h : Space → ℝ≥0∞) (hK : Measurable K) (hh : Measurable h) :
    eLpNorm (fun y => ∫⁻ z, K z*h (y-z)) 3 volume≤
      (∫⁻ z, K z)*eLpNorm h 3 volume := by
  have hp : (∫⁻ y, (∫⁻ z, K z*h (y-z))^(3:ℝ))≤
      (∫⁻ z, K z)^(3:ℝ)*(∫⁻ y, h y^(3:ℝ)) := by
    calc
      _ ≤ ∫⁻ y, (∫⁻ z, K z*h (y-z)^(3:ℝ))*(∫⁻ z, K z)^(2:ℝ) :=
        lintegral_mono (fun y => positive_weighted_integral_cube_le volume K _ hK
          (hh.comp (measurable_const.sub measurable_id)))
      _ = (∫⁻ y, ∫⁻ z, K z*h (y-z)^(3:ℝ))*(∫⁻ z, K z)^(2:ℝ) := by
        exact lintegral_mul_const'' _
          (((hK.comp measurable_snd).mul
            ((hh.comp (measurable_fst.sub measurable_snd)).pow_const (3:ℝ))).lintegral_prod_right).aemeasurable
      _ = (∫⁻ z, K z*(∫⁻ y, h y^(3:ℝ)))*(∫⁻ z, K z)^(2:ℝ) := by
        have hm : Measurable (fun p : Space×Space => K p.2*h (p.1-p.2)^(3:ℝ)) :=
          (hK.comp measurable_snd).mul ((hh.comp (measurable_fst.sub measurable_snd)).pow_const (3:ℝ))
        rw [lintegral_lintegral_swap hm.aemeasurable]
        congr 1
        apply lintegral_congr
        intro z
        rw [lintegral_const_mul (K z) (f := fun y => h (y-z)^(3:ℝ))
          ((hh.comp (measurable_id.sub measurable_const)).pow_const (3:ℝ)),
          lintegral_sub_right_eq_self (fun y => h y^(3:ℝ)) z]
      _ = _ := by
        rw [lintegral_mul_const (μ := (volume : Measure Space)) _ hK]
        have he : (3:ℝ)=1+2 := by norm_num
        rw [he,ENNReal.rpow_add_of_nonneg _ _ (by norm_num) (by norm_num),ENNReal.rpow_one]
        simp only [mul_assoc,mul_left_comm,mul_comm]
  simp only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3:ℝ≥0∞)≠0)
    (by norm_num : (3:ℝ≥0∞)≠⊤),ENNReal.toReal_ofNat,enorm_eq_self]
  apply (ENNReal.rpow_le_rpow hp (by norm_num : (0:ℝ)≤1/3)).trans_eq
  rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0:ℝ)≤1/3),← ENNReal.rpow_mul]
  norm_num

end EllipticSquareFunction
