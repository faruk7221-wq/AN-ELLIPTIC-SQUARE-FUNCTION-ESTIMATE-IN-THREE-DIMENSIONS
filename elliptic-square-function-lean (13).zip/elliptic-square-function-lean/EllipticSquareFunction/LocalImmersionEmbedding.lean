import EllipticSquareFunction.NormalExistence
import EllipticSquareFunction.SmoothLocalInverse

noncomputable section
namespace EllipticSquareFunction

/-- A smooth immersed parametrization is an embedding after restriction to
an open neighborhood. No embeddedness hypothesis is imposed on its extension. -/
theorem immersion_locally_embedding {F : Plane → EuclideanThree} {U : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U)
    (hD : Function.Injective (fderiv ℝ F a)) :
    ∃ V : Set Plane, IsOpen V ∧ a ∈ V ∧ V ⊆ U ∧
      Topology.IsEmbedding (fun b : V => F b) := by
  let D := fderiv ℝ F a
  obtain ⟨N,hN,horth⟩ := immersion_unit_normal_exists D hD
  let S := spaceEuclideanEquiv
  let D' := S.toContinuousLinearMap.comp D
  have hD' : Function.Injective D' := S.injective.comp hD
  have hN' : S N ≠ 0 := by
    intro hz
    have hn : N=0 := S.injective (hz.trans (map_zero S).symm)
    simpa [hn] using hN
  have ho : ∀ v, spacePair (S N) (D' v)=0 := by
    intro v
    exact (spaceEuclideanEquiv_pair N (D v)).trans (horth v)
  let E := tangentNormalEquiv D' (S N) hD' hN' ho
  let P : EuclideanThree →L[ℝ] Plane :=
    (ContinuousLinearMap.fst ℝ Plane ℝ).comp (E.symm.toContinuousLinearMap.comp S.toContinuousLinearMap)
  have hPD : ∀ v, P (D v)=v := by
    intro v
    exact congrArg Prod.fst (tangentNormalEquiv_symm_tangent D' (S N) hD' hN' ho v)
  have hd := P.hasFDerivAt.comp a ((hF.contDiffAt (hU.mem_nhds ha)).differentiableAt (by norm_cast)).hasFDerivAt
  have hder : HasFDerivAt (P ∘ F) (ContinuousLinearMap.id ℝ Plane) a := by
    convert hd using 1
    apply ContinuousLinearMap.ext
    intro v
    exact (hPD v).symm
  obtain ⟨e,he,hae,heU,_,_⟩ := smooth_local_inverse hU ha
    (P.contDiff.comp_contDiffOn hF) (ContinuousLinearEquiv.refl ℝ Plane) hder
  refine ⟨e.source,e.open_source,hae,heU,?_⟩
  apply Topology.IsEmbedding.of_comp
    (continuousOn_iff_continuous_restrict.mp (hF.continuousOn.mono heU)) P.continuous
  have hi : Topology.IsEmbedding (fun b : e.source => e b) :=
    Topology.IsEmbedding.subtypeVal.comp e.toHomeomorphSourceTarget.isEmbedding
  simpa only [he,Function.comp_def] using hi

end EllipticSquareFunction
