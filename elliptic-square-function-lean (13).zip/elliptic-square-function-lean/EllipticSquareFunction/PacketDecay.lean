import EllipticSquareFunction.NormalizedPhaseHigher
import EllipticSquareFunction.UniformKernels

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

def normalizedOscillation (φ : Phase) (ν : Plane) (N u : ℝ) (η : Plane) : ℂ :=
  oscillation (u * phaseRemainder φ ν (velocity φ ν) N (N^2) η)

theorem normalizedOscillation_contDiff (φ : Phase)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (ν : Plane) (N u : ℝ) :
    ContDiff ℝ (⊤ : ℕ∞) (normalizedOscillation φ ν N u) :=
  contDiff_oscillation.comp (contDiff_const.mul (phaseRemainder_contDiff φ hφ ν N))

theorem normalizedOscillation_derivative_bound {φ : Phase}
    (hphase : ContinuedPhase φ) {B : ℝ} (hB : 0≤B) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ N : ℝ, 1≤N → ∀ (ν η : Plane) (u : ℝ),
      ‖η‖≤B → |u|≤1 → ‖iteratedFDeriv ℝ k (normalizedOscillation φ ν N u) η‖ ≤ C := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  choose H hH hbound using phaseRemainder_derivative_bound_on_ball hphase hB
  have houter (j : ℕ) : ∃ C : ℝ, 0≤C ∧ ∀ x ∈ Metric.closedBall (0:ℝ) (H 0),
      ‖iteratedFDeriv ℝ j oscillation x‖ ≤ C := by
    obtain ⟨C,hC⟩ := (isCompact_closedBall (0:ℝ) (H 0)).exists_bound_of_continuousOn
      (contDiff_oscillation.continuous_iteratedFDeriv (by exact_mod_cast
        (le_top : (j : ℕ∞) ≤ ⊤))).continuousOn
    exact ⟨max C 0,le_max_right _ _,fun x hx => (hC x hx).trans (le_max_left _ _)⟩
  choose J hJ hj using houter
  let C := 1+∑ j ∈ Finset.range (k+1), J j
  let D := 1+∑ j ∈ Finset.range (k+1), H j
  have hC : 1≤C := by dsimp [C]; linarith [Finset.sum_nonneg (fun j (_ : j∈Finset.range (k+1)) => hJ j)]
  have hD : 1≤D := by dsimp [D]; linarith [Finset.sum_nonneg (fun j (_ : j∈Finset.range (k+1)) => hH j)]
  have hJC (j : ℕ) (hjk : j≤k) : J j≤C := by
    have hh := Finset.single_le_sum (f := J) (fun j (_ : j∈Finset.range (k+1)) => hJ j)
      (Finset.mem_range.mpr (by omega : j<k+1))
    dsimp [C]; linarith
  have hHD (j : ℕ) (hjk : j≤k) : H j≤D := by
    have hh := Finset.single_le_sum (f := H) (fun j (_ : j∈Finset.range (k+1)) => hH j)
      (Finset.mem_range.mpr (by omega : j<k+1))
    dsimp [D]; linarith
  refine ⟨k.factorial*C*D^k,by positivity,?_⟩
  intro N hN ν η u hη hu
  let R := phaseRemainder φ ν (velocity φ ν) N (N^2)
  have hR : ContDiff ℝ (⊤ : ℕ∞) R := phaseRemainder_contDiff φ hφ ν N
  have hr0 : |R η| ≤ H 0 := by
    simpa only [norm_iteratedFDeriv_zero,Real.norm_eq_abs] using hbound 0 N hN ν η hη
  have hmem : u*R η ∈ Metric.closedBall (0:ℝ) (H 0) := by
    simp only [Metric.mem_closedBall,dist_zero_right,Real.norm_eq_abs,abs_mul]
    exact (mul_le_mul_of_nonneg_left hr0 (abs_nonneg u)).trans (by nlinarith [hH 0])
  apply norm_iteratedFDeriv_comp_le contDiff_oscillation (contDiff_const.mul hR)
    (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤)) η
  · intro j hjk
    exact (hj j _ hmem).trans (hJC j hjk)
  · intro j hj1 hjk
    change ‖iteratedFDeriv ℝ j (fun z => u • R z) η‖ ≤ D^j
    rw [iteratedFDeriv_const_smul_apply' (hR.of_le (by exact_mod_cast
      (le_top : (j : ℕ∞) ≤ ⊤))).contDiffAt]
    rw [norm_smul,Real.norm_eq_abs]
    calc
      _ ≤ |u| * H j := mul_le_mul_of_nonneg_left (hbound j N hN ν η hη) (abs_nonneg u)
      _ ≤ H j := by nlinarith [hH j]
      _ ≤ D := hHD j hjk
      _ ≤ D^j := le_self_pow₀ hD (by omega)

def normalizedAmplitude (φ : Phase) (b : Plane → ℂ) (ν : Plane) (N u : ℝ) (η : Plane) : ℂ :=
  b η * normalizedOscillation φ ν N u η

theorem normalizedAmplitude_contDiff (φ : Phase)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (b : Plane → ℂ)
    (hb : ContDiff ℝ (⊤ : ℕ∞) b) (ν : Plane) (N u : ℝ) :
    ContDiff ℝ (⊤ : ℕ∞) (normalizedAmplitude φ b ν N u) :=
  hb.mul (normalizedOscillation_contDiff φ hφ ν N u)

theorem normalizedAmplitude_support (φ : Phase) (b : Plane → ℂ)
    (ν : Plane) (N u : ℝ) :
    tsupport (normalizedAmplitude φ b ν N u) ⊆ tsupport b :=
  tsupport_mul_subset_left

theorem normalizedAmplitude_derivative_bound {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) {B : ℝ} (hB : 0≤B) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ N : ℝ, 1≤N → ∀ (ν η : Plane) (u : ℝ),
      ‖η‖≤B → |u|≤1 → ‖iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η‖ ≤ C := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  choose H hH hbound using normalizedOscillation_derivative_bound hphase hB
  have hbder (j : ℕ) : ∃ C : ℝ, 0≤C ∧ ∀ η : Plane, ‖η‖≤B →
      ‖iteratedFDeriv ℝ j b η‖ ≤ C := by
    obtain ⟨C,hC⟩ := (isCompact_closedBall (0:Plane) B).exists_bound_of_continuousOn
      (hb.continuous_iteratedFDeriv (by exact_mod_cast (le_top : (j : ℕ∞) ≤ ⊤))).continuousOn
    refine ⟨max C 0,le_max_right _ _,?_⟩
    intro η hη
    exact (hC η (by simpa [Metric.mem_closedBall,dist_zero_right] using hη)).trans (le_max_left _ _)
  choose J hJ hj using hbder
  refine ⟨∑ j ∈ Finset.range (k+1), (k.choose j : ℝ)*J j*H (k-j),
    Finset.sum_nonneg (fun j _ => mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (hJ j)) (hH (k-j))),?_⟩
  intro N hN ν η u hη hu
  apply (norm_iteratedFDeriv_mul_le hb (normalizedOscillation_contDiff φ hφ ν N u) η
    (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤))).trans
  apply Finset.sum_le_sum
  intro j hjk
  exact mul_le_mul (mul_le_mul_of_nonneg_left (hj j η hη) (Nat.cast_nonneg _))
    (hbound (k-j) N hN ν η u hη hu) (norm_nonneg _) (mul_nonneg (Nat.cast_nonneg _) (hJ j))

theorem normalizedAmplitude_derivative_integral {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b) (k : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ N : ℝ, 1≤N → ∀ (ν : Plane) (u : ℝ), |u|≤1 →
      (∫ η, ‖iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η‖) ≤ C := by
  obtain ⟨B,hB⟩ := hbs.exists_bound_of_continuousOn continuous_id.continuousOn
  obtain ⟨C,hC,hbound⟩ := normalizedAmplitude_derivative_bound hphase b hb (le_max_right B 0) k
  refine ⟨C*volume.real (tsupport b),by positivity,?_⟩
  intro N hN ν u hu
  have he : (∫ η in tsupport b, ‖iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η‖) =
      ∫ η, ‖iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η‖ := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro η hη
    have hz : iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η=0 := by
      by_contra hn
      exact hη (normalizedAmplitude_support φ b ν N u (support_iteratedFDeriv_subset k hn))
    rw [hz,norm_zero]
  rw [← he]
  calc
    _ ≤ ‖∫ η in tsupport b, ‖iteratedFDeriv ℝ k (normalizedAmplitude φ b ν N u) η‖‖ := le_abs_self _
    _ ≤ C*volume.real (tsupport b) := by
      apply norm_setIntegral_le_of_norm_le_const_ae' hbs.measure_lt_top
      filter_upwards with η hη
      simpa only [Real.norm_eq_abs,abs_norm] using
        hbound N hN ν η u ((hB η hη).trans (le_max_left B 0)) hu

theorem normalizedAmplitude_derivativeMass {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b) (L : ℕ) :
    ∃ C : ℝ, 0≤C ∧ ∀ N : ℝ, 1≤N → ∀ (ν : Plane) (u : ℝ), |u|≤1 →
      derivativeMass L (normalizedAmplitude φ b ν N u) ≤ C := by
  choose C hC hbound using normalizedAmplitude_derivative_integral hphase b hb hbs
  refine ⟨∑ k ∈ Finset.range (L+1),C k,Finset.sum_nonneg (fun k _ => hC k),?_⟩
  intro N hN ν u hu
  exact Finset.sum_le_sum (fun k _ => hbound k N hN ν u hu)

theorem normalizedAmplitude_oscillatory_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ (ν w : Plane) (u : ℝ), |u|≤1 →
      ‖∫ η, normalizedAmplitude φ b ν N u η * oscillation (@inner ℝ Plane _ w η)‖ ≤
        C*bracket w^(-(L:ℝ)) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨B,hB,hbound⟩ := normalizedAmplitude_derivativeMass hphase b hb hbs L
  refine ⟨2^L*(1+2^L)*B+1,by positivity,?_⟩
  intro N hN ν w u hu
  have hs : HasCompactSupport (normalizedAmplitude φ b ν N u) :=
    hbs.of_isClosed_subset isClosed_closure (normalizedAmplitude_support φ b ν N u)
  apply (oscillatoryIntegral_bracket_decay _ (normalizedAmplitude_contDiff φ hφ b hb ν N u) hs L w).trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by dsimp [bracket]; positivity) _)
  have hh := mul_le_mul_of_nonneg_left (hbound N hN ν u hu)
    (by positivity : 0≤(2:ℝ)^L*(1+2^L))
  linarith

theorem freePacket_normalization (φ : Phase) (b : Plane → ℂ)
    {N : ℝ} (hN : 0<N) (ν v : Plane) (y : Space) :
    freePacket φ b N ν v y =
      oscillation (@inner ℝ Plane _ (y.1-v) ν + y.2*φ ν) *
      ∫ η, (b η * oscillation ((y.2/N^2) * phaseRemainder φ ν (velocity φ ν) N (N^2) η)) *
        oscillation (@inner ℝ Plane _ (N⁻¹ • (y.1-v+y.2 • velocity φ ν)) η) := by
  let f := fun ξ => b (N • (ξ-ν)) *
    oscillation (@inner ℝ Plane _ (y.1-v) ξ + y.2*φ ξ)
  have hscale := Measure.integral_comp_smul_of_nonneg volume (fun ξ => f (ξ+ν))
    N⁻¹ (hR := (inv_pos.mpr hN).le)
  have he : (∫ η, f (N⁻¹ • η+ν)) = freePacket φ b N ν v y := by
    rw [integral_add_right_eq_self] at hscale
    simpa [freePacket,f,inv_pow,smul_eq_mul] using hscale
  rw [← he,← integral_const_mul]
  apply integral_congr_ae
  filter_upwards with η
  have hfirst : N • (N⁻¹ • η+ν-ν)=η := by simp [smul_smul,hN.ne']
  have ht : (y.2/N^2)*N^2=y.2 := div_mul_cancel₀ _ (pow_ne_zero _ hN.ne')
  have hp := rebase_phase_identity φ ν (velocity φ ν) y.1 v η N (N^2) (y.2/N^2)
  rw [ht] at hp
  have ha : N⁻¹ • η+ν=ν+N⁻¹ • η := add_comm _ _
  dsimp only [f]
  rw [hfirst,ha,hp,oscillation_add,oscillation_add]
  ring


/-- Equation (4.15), uniformly in scale, cap center, and position. The proof
also permits negative times with absolute value at most `N²`. -/
theorem equation_4_15 {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ (ν v : Plane) (y : Space), |y.2|≤N^2 →
      ‖freePacket φ b N ν v y‖ ≤
        C*bracket (N⁻¹ • (y.1-v+y.2 • velocity φ ν))^(-(L:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := normalizedAmplitude_oscillatory_decay hphase b hb hbs L
  refine ⟨C,hC,?_⟩
  intro N hN ν v y ht
  have hN0 : 0<N := by linarith
  have hu : |y.2/N^2|≤1 := by
    rw [abs_div,abs_of_pos (pow_pos hN0 _)]
    exact (div_le_one (pow_pos hN0 _)).mpr ht
  rw [freePacket_normalization φ b hN0,norm_mul,norm_oscillation,one_mul]
  exact hbound N hN ν _ _ hu

end EllipticSquareFunction
