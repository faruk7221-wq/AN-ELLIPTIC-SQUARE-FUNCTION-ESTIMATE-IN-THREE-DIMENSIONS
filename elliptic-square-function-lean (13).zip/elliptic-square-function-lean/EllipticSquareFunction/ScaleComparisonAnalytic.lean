import EllipticSquareFunction.ScaleComparison

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

theorem positiveConvolution_square_upper_scale (f : SchwartzMap Space ℂ)
    {R S M : ℝ} (hR : 0<R) (hRS : R≤S) (hSR : S≤4*R) (hM : 2<M)
    (V : Plane) (y : Space) :
    positiveConvolution (fun z => ‖f z‖^2) (tubeKernel S M V) y ≤
      ((4:ℝ)^M)^2*positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V) y := by
  have hS : 0<S := hR.trans_le hRS
  have hc : 0≤((4:ℝ)^M)^2 := sq_nonneg _
  have hg : 0≤positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V) y :=
    integral_nonneg (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..))
  apply (ENNReal.ofReal_le_ofReal_iff (mul_nonneg hc hg)).mp
  rw [ENNReal.ofReal_mul hc,← lintegral_schwartz_square_tube f hS hM,
    ← lintegral_schwartz_square_tube f hR hM]
  have hm : AEMeasurable (fun z => ENNReal.ofReal (‖f z‖^2)*
      ENNReal.ofReal (tubeKernel R M V (y-z))) volume := by
    apply Measurable.aemeasurable
    apply Measurable.mul (f.continuous.norm.pow 2).measurable.ennreal_ofReal
    apply Measurable.ennreal_ofReal
    unfold tubeKernel packetWeight bracket
    fun_prop
  rw [← lintegral_const_mul'' _ hm]
  apply lintegral_mono
  intro z
  have hh := ENNReal.ofReal_le_ofReal (tubeKernel_upper_scale (M := M) hR hRS hSR (by linarith) V (y-z))
  rw [ENNReal.ofReal_mul hc] at hh
  simpa only [mul_left_comm] using mul_le_mul_left' hh (ENNReal.ofReal (‖f z‖^2))

theorem smoothedSquareDensity_upper_scale {n : ℕ} (G : GraphSetup)
    {R S M : ℝ} (hR : 0<R) (hRS : R≤S) (hSR : S≤4*R) (hM : 2<M)
    (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ) (y : Space) :
    smoothedSquareDensity (enlargedCapGraph G) S M ν f y ≤
      ((4:ℝ)^M)^2*smoothedSquareDensity G R M ν f y := by
  unfold smoothedSquareDensity
  rw [Finset.mul_sum]
  exact Finset.sum_le_sum (fun θ _ => positiveConvolution_square_upper_scale (f θ) hR hRS hSR hM _ y)

/-- Fixed-scale comparison of the exact polynomial and logarithmic losses. -/
theorem packet_loss_upper_scale {R S α : ℝ} (hR : 2≤R) (hRS : R≤S)
    (hSR : S≤4*R) (hα : 0≤α) :
    S^α*Real.log (2+S)^(2/3:ℝ) ≤
      ((4:ℝ)^α*2^(2/3:ℝ))*(R^α*Real.log (2+R)^(2/3:ℝ)) := by
  have hR₀ : 0<R := by linarith
  have hS₀ : 0<S := hR₀.trans_le hRS
  have hp : S^α≤4^α*R^α := by
    rw [← Real.mul_rpow (by norm_num) hR₀.le]
    exact Real.rpow_le_rpow hS₀.le hSR hα
  have hlogR : 0≤Real.log (2+R) := Real.log_nonneg (by linarith)
  have hlog : Real.log (2+S)≤2*Real.log (2+R) := by
    have h₁ := Real.log_le_log (by linarith : 0<2+S) (show 2+S≤4*(2+R) by linarith)
    rw [Real.log_mul (by norm_num : (4:ℝ)≠0) (by linarith : 2+R≠0)] at h₁
    have h₂ := Real.log_le_log (by norm_num : (0:ℝ)<4) (show 4≤2+R by linarith)
    linarith
  have hl : Real.log (2+S)^(2/3:ℝ)≤2^(2/3:ℝ)*Real.log (2+R)^(2/3:ℝ) := by
    rw [← Real.mul_rpow (by norm_num) hlogR]
    exact Real.rpow_le_rpow (Real.log_nonneg (by linarith)) hlog (by norm_num)
  have hh := mul_le_mul hp hl (Real.rpow_nonneg (Real.log_nonneg (by linarith)) _)
    (mul_nonneg (Real.rpow_nonneg (by norm_num) _) (Real.rpow_nonneg hR₀.le _))
  convert hh using 1 <;> ring

end EllipticSquareFunction
