import EllipticSquareFunction.TubeMeasureDilation
import EllipticSquareFunction.FrameReconstruction

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000
local instance : (volume : Measure Space).IsAddHaarMeasure :=
  Measure.prod.instIsAddHaarMeasure (volume : Measure Plane) (volume : Measure ℝ)

/-- Jacobian for an arbitrary invertible physical linear change of variables. -/
theorem space_volume_map_linearEquiv (L : Space ≃L[ℝ] Space) :
    Measure.map L volume=ENNReal.ofReal |(LinearMap.det L.toLinearMap)⁻¹| • volume := by
  exact Measure.map_linearMap_addHaar_eq_smul_addHaar volume
    L.toLinearEquiv.isUnit_det'.ne_zero

theorem lintegral_space_linearEquiv (L : Space ≃L[ℝ] Space) (g : Space → ℝ≥0∞) :
    (∫⁻ y, g (L y))=ENNReal.ofReal |(LinearMap.det L.toLinearMap)⁻¹| * (∫⁻ y, g y) := by
  have hh := lintegral_map_equiv (μ := (volume : Measure Space)) g L.toHomeomorph.toMeasurableEquiv
  change (∫⁻ y, g y ∂Measure.map L volume)=(∫⁻ y, g (L y)) at hh
  rw [space_volume_map_linearEquiv,lintegral_smul_measure] at hh
  exact hh.symm

/-- The determinant rescales every finite-exponent norm by the same factor. -/
theorem eLpNorm_space_linearEquiv {E : Type*} [ENorm E]
    (L : Space ≃L[ℝ] Space) (g : Space → E) {p : ℝ≥0∞} (hp₀ : p≠0) (hpfin : p≠⊤) :
    eLpNorm (fun y => g (L y)) p volume=
      ENNReal.ofReal |(LinearMap.det L.toLinearMap)⁻¹|^(1/p.toReal)*eLpNorm g p volume := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm hp₀ hpfin]
  rw [lintegral_space_linearEquiv L (fun y => ‖g y‖ₑ^p.toReal)]
  exact ENNReal.mul_rpow_of_nonneg _ _ (by positivity)

def modulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : Space → ℂ) (y : Space) : ℂ :=
  oscillation (@inner ℝ Plane _ b.1 y.1+b.2*y.2)*f (L y)

theorem norm_modulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : Space → ℂ) (y : Space) : ‖modulatedLinearPullback L b f y‖=‖f (L y)‖ := by
  simp only [modulatedLinearPullback,norm_mul,norm_oscillation,one_mul]

theorem eLpNorm_modulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : Space → ℂ) {p : ℝ≥0∞} (hp₀ : p≠0) (hpfin : p≠⊤) :
    eLpNorm (modulatedLinearPullback L b f) p volume=
      ENNReal.ofReal |(LinearMap.det L.toLinearMap)⁻¹|^(1/p.toReal)*eLpNorm f p volume := by
  have he : eLpNorm (modulatedLinearPullback L b f) p volume=
      eLpNorm (fun y => f (L y)) p volume :=
    eLpNorm_congr_norm_ae (Filter.Eventually.of_forall (fun y => norm_modulatedLinearPullback L b f y))
  rw [he]
  exact eLpNorm_space_linearEquiv L f hp₀ hpfin

theorem squareFunction_modulatedLinearPullback {ι : Type*} (s : Finset ι)
    (L : Space ≃L[ℝ] Space) (b : Space) (f : ι → Space → ℂ) (y : Space) :
    squareFunction s (fun i => modulatedLinearPullback L b (f i)) y=
      squareFunction s f (L y) := by
  simp only [squareFunction,norm_modulatedLinearPullback]

/-- Both sides of the reverse square-function inequality acquire exactly
the same nonzero finite Jacobian factor. Modulation contributes modulus one. -/
theorem reverse_square_function_affine_norm_iff {ι : Type*} (s : Finset ι)
    (L : Space ≃L[ℝ] Space) (b : Space) (f : ι → Space → ℂ) (C : ℝ≥0∞) :
    (l3 (fun y => ∑ i∈s, modulatedLinearPullback L b (f i) y) ≤
      C*l3Real (squareFunction s (fun i => modulatedLinearPullback L b (f i)))) ↔
    (l3 (fun y => ∑ i∈s, f i y)≤C*l3Real (squareFunction s f)) := by
  have he : (fun y => ∑ i∈s, modulatedLinearPullback L b (f i) y)=
      modulatedLinearPullback L b (fun y => ∑ i∈s, f i y) := by
    funext y
    simp only [modulatedLinearPullback,Finset.mul_sum]
  have hs : squareFunction s (fun i => modulatedLinearPullback L b (f i))=
      (fun y => squareFunction s f (L y)) := funext (squareFunction_modulatedLinearPullback s L b f)
  unfold l3 l3Real
  rw [he,hs,eLpNorm_modulatedLinearPullback L b _ (by norm_num) (by norm_num),
    eLpNorm_space_linearEquiv L _ (by norm_num) (by norm_num)]
  let d : ℝ≥0∞ := ENNReal.ofReal |(LinearMap.det L.toLinearMap)⁻¹|^(1/(3:ℝ≥0∞).toReal)
  have hd₀ : d≠0 := by
    apply (ENNReal.rpow_eq_zero_iff_of_pos (by norm_num : (0:ℝ)<1/(3:ℝ≥0∞).toReal)).not.mpr
    exact (ENNReal.ofReal_pos.mpr (abs_pos.mpr (inv_ne_zero L.toLinearEquiv.isUnit_det'.ne_zero))).ne'
  have hdfin : d≠⊤ := ENNReal.rpow_ne_top_of_nonneg (by positivity) ENNReal.ofReal_ne_top
  change d*_≤C*(d*_) ↔ _
  rw [mul_left_comm C d]
  exact ENNReal.mul_le_mul_left hd₀ hdfin

end EllipticSquareFunction
