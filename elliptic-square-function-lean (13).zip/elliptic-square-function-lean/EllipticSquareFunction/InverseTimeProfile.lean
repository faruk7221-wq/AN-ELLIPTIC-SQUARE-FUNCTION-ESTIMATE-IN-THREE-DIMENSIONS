import EllipticSquareFunction.CurvedMultiplier

noncomputable section
open MeasureTheory
namespace EllipticSquareFunction

/-- The inverse transform of a Schwartz time cutoff is a Schwartz profile. -/
def inverseTimeProfile (ρ : SchwartzMap ℝ ℂ) : SchwartzMap ℝ ℂ :=
  (SchwartzMap.fourierTransformCLE ℂ).symm ρ

theorem inverseTimeProfile_apply (ρ : SchwartzMap ℝ ℂ) (t : ℝ) :
    inverseTimeProfile ρ t=inverseTimeTransform ρ t := by
  change Real.fourierIntegral ρ (-t)=_
  rw [← Real.fourierIntegralInv_eq_fourierIntegral_neg,Real.fourierIntegralInv_eq']
  unfold inverseTimeTransform
  apply integral_congr_ae
  filter_upwards with u
  simp only [RCLike.inner_apply,conj_trivial,smul_eq_mul,oscillation]
  rw [mul_comm]

/-- Equation (6.9) with an actual Schwartz time profile. -/
theorem inverse_curvedMultiplier_timePacket (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (hχs : HasCompactSupport χ)
    (ρ : SchwartzMap ℝ ℂ) (hρs : HasCompactSupport (ρ : ℝ → ℂ))
    {R : ℝ} (hR : 0<R) (ν : Plane) (y : Space) :
    inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) y =
      ((R^2)⁻¹:ℝ)*timePacket φ χ (inverseTimeProfile ρ) R ν 0 0 y := by
  rw [equation_6_9 φ hφ χ hχ hχs ρ ρ.continuous hρs hR]
  simp only [timePacket,sub_zero,inverseTimeProfile_apply,mul_assoc]

/-- Translating the multiplier kernel gives the actual packet centers and time origins. -/
theorem inverse_curvedMultiplier_translated (φ : Phase) (hφ : Continuous φ)
    (χ : Plane → ℂ) (hχ : Continuous χ) (hχs : HasCompactSupport χ)
    (ρ : SchwartzMap ℝ ℂ) (hρs : HasCompactSupport (ρ : ℝ → ℂ))
    {R : ℝ} (hR : 0<R) (ν v : Plane) (s : ℝ) (y : Space) :
    inverseSpaceTransform (curvedMultiplier φ χ ρ (Real.sqrt R) R ν) (y-(v,s)) =
      ((R^2)⁻¹:ℝ)*timePacket φ χ (inverseTimeProfile ρ) R ν v s y := by
  rw [inverse_curvedMultiplier_timePacket φ hφ χ hχ hχs ρ hρs hR]
  simp only [timePacket,freePacket,Prod.fst_sub,Prod.snd_sub,sub_zero]

end EllipticSquareFunction
