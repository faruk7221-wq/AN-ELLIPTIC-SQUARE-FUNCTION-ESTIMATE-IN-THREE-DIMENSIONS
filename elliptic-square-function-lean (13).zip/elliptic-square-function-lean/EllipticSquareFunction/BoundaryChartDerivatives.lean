import EllipticSquareFunction.BoundaryChartSecondForm

noncomputable section
open Filter
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- First derivatives in overlapping boundary charts transform by the
actual tangent-bundle coordinate change. -/
theorem boundary_chart_param_derivative_transition {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x y z : M) (hzx : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (hzy : z ∈ (extChartAt (𝓡∂ 2) y).source) :
    fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x) (Set.range (𝓡∂ 2)) (extChartAt (𝓡∂ 2) x z) =
      (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f y) (Set.range (𝓡∂ 2)) (extChartAt (𝓡∂ 2) y z)).comp
        (tangentCoordChange (𝓡∂ 2) x y z) := by
  let I := 𝓡∂ 2
  let g : Plane → Plane := extChartAt I y ∘ (extChartAt I x).symm
  let a := extChartAt I x z
  have hga : g a = extChartAt I y z := by
    change extChartAt I y ((extChartAt I x).symm (extChartAt I x z)) = _
    rw [(extChartAt I x).left_inv hzx]
  have hx : a ∈ ((extChartAt I x).symm ≫ extChartAt I y).source :=
    ⟨(extChartAt I x).map_source hzx,by
      change (extChartAt I x).symm (extChartAt I x z) ∈ (extChartAt I y).source
      rwa [(extChartAt I x).left_inv hzx]⟩
  have hdy : DifferentiableWithinAt ℝ (modelSurfaceParam I f y) (Set.range I) (g a) := by
    rw [hga]
    exact ((model_surface_param_smooth I hf y _ ((extChartAt I y).map_source hzy)).mono_of_mem_nhdsWithin
      (extChartAt_target_mem_nhdsWithin' hzy)).differentiableWithinAt (by norm_cast)
  have hdg : DifferentiableWithinAt ℝ g (Set.range I) a :=
    (contDiffWithinAt_ext_coord_change y x hx).differentiableWithinAt (by norm_cast)
  have hmaps : Set.MapsTo g (Set.range I) (Set.range I) := by
    intro p hp
    exact ⟨chartAt (EuclideanHalfSpace 2) y ((extChartAt I x).symm p),rfl⟩
  have he : modelSurfaceParam I f y ∘ g =ᶠ[𝓝[Set.range I] a] modelSurfaceParam I f x := by
    have hn := PartialHomeomorph.extend_coord_change_source_mem_nhdsWithin'
      (chartAt (EuclideanHalfSpace 2) x) (chartAt (EuclideanHalfSpace 2) y)
      (I := I) (by simpa only [extChartAt_source] using hzx)
      (by simpa only [extChartAt_source] using hzy)
    filter_upwards [hn] with p hp
    exact congrArg f ((extChartAt I y).left_inv hp.2)
  have he0 : (modelSurfaceParam I f y ∘ g) a = modelSurfaceParam I f x a := by
    change f ((extChartAt I y).symm (g a)) = f ((extChartAt I x).symm a)
    rw [hga,(extChartAt I y).left_inv hzy,(extChartAt I x).left_inv hzx]
  have hh := fderivWithin_comp a hdy hdg hmaps
    (I.uniqueDiffOn a (extChartAt_target_subset_range x ((extChartAt I x).map_source hzx)))
  rw [he.fderivWithin_eq he0,hga] at hh
  exact hh

/-- At the preferred chart center the coordinate derivative is precisely mfderiv. -/
theorem boundary_chart_param_derivative_self {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f) (z : M) :
    fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f z) (Set.range (𝓡∂ 2)) (extChartAt (𝓡∂ 2) z z) =
      mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z := by
  rw [(hf.mdifferentiable (by norm_cast) z).mfderiv]
  simp only [writtenInExtChartAt,mfld_simps]
  rfl

/-- Normality of the manifold differential implies normality in every chart. -/
theorem boundary_chart_normal_of_mfderiv {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    ∀ v, @inner ℝ EuclideanThree _ N
      (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x) (Set.range (𝓡∂ 2)) (extChartAt (𝓡∂ 2) x z) v)=0 := by
  intro v
  rw [boundary_chart_param_derivative_transition hf x z z hz (mem_extChartAt_source z),
    boundary_chart_param_derivative_self hf z]
  exact hN _

/-- The canonical second form is a well-defined bilinear form on the tangent
fiber: every boundary chart gives the same value after its tangent coordinate change. -/
theorem boundary_intrinsic_second_form_in_chart {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0)
    (v w : TangentSpace (𝓡∂ 2) z) :
    modelSecondForm (𝓡∂ 2) f z N v w = boundaryChartSecondForm f x z N
      (tangentCoordChange (𝓡∂ 2) z x z v) (tangentCoordChange (𝓡∂ 2) z x z w) := by
  rw [← boundary_chart_second_form_self]
  exact boundary_chart_second_form_transition hf z x z (mem_extChartAt_source z) hz N
    (boundary_chart_normal_of_mfderiv hf x z hz N hN) v w

end EllipticSquareFunction
