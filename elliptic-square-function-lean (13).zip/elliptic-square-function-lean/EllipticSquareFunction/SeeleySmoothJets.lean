import EllipticSquareFunction.SeeleyBoundaryDerivative

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def seeleyGluedJet (m : ℕ) (g : ℝ → E) (t : ℝ) : E :=
  if 0 ≤ t then g t else seeleyJetSeries m g t

theorem seeley_glued_jet_eq_nonneg (m : ℕ) (g : ℝ → E) {t : ℝ} (ht : 0 ≤ t) :
    seeleyGluedJet m g t = g t := by simp [seeleyGluedJet, ht]

theorem seeley_glued_jet_eq_nonpos (m : ℕ) (g : ℝ → E) {t : ℝ} (ht : t ≤ 0) :
    seeleyGluedJet m g t = seeleyJetSeries m g t := by
  by_cases h : 0 ≤ t
  · have he : t = 0 := le_antisymm ht h
    simp [he, seeleyGluedJet, seeley_jet_series_zero]
  · simp [seeleyGluedJet, h]

theorem seeley_glued_jet_hasDerivAt (m : ℕ) {g g' : ℝ → E} {B B' : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hg' : ∀ s : ℝ, 0 ≤ s → ‖g' s‖ ≤ B')
    (hd : ∀ s : ℝ, 0 ≤ s → HasDerivWithinAt g (g' s) (Set.Ici 0) s)
    (hc' : ContinuousWithinAt g' (Set.Ici 0) 0) (t : ℝ) :
    HasDerivAt (seeleyGluedJet m g) (seeleyGluedJet (m+1) g' t) t := by
  have hp : ∀ s : ℝ, 0 < s → HasDerivAt g (g' s) s :=
    fun s hs => (hd s (le_of_lt hs)).hasDerivAt (Ici_mem_nhds hs)
  rcases lt_trichotomy t 0 with ht | ht | ht
  · rw [seeley_glued_jet_eq_nonpos (m+1) g' (le_of_lt ht)]
    apply (seeley_jet_series_hasDerivAt m hg hg' hp ht).congr_of_eventuallyEq
    filter_upwards [Iio_mem_nhds ht] with s hs
    exact seeley_glued_jet_eq_nonpos m g (le_of_lt hs)
  · subst t
    rw [seeley_glued_jet_eq_nonneg (m+1) g' le_rfl]
    have hz := hd 0 le_rfl
    have hl := (seeley_jet_series_boundary_hasDerivWithinAt m hg hg' hp
      hz.continuousWithinAt hc').congr
      (fun s hs => seeley_glued_jet_eq_nonpos m g hs)
      (seeley_glued_jet_eq_nonpos m g le_rfl)
    have hr := hz.congr (fun s hs => seeley_glued_jet_eq_nonneg m g hs)
      (seeley_glued_jet_eq_nonneg m g le_rfl)
    simpa only [Set.Iic_union_Ici, hasDerivWithinAt_univ] using hl.union hr
  · rw [seeley_glued_jet_eq_nonneg (m+1) g' (le_of_lt ht)]
    apply (hp t ht).congr_of_eventuallyEq
    filter_upwards [Ioi_mem_nhds ht] with s hs
    exact seeley_glued_jet_eq_nonneg m g (le_of_lt hs)

theorem seeley_glued_jets_contDiff_nat (g : ℕ → ℝ → E) (B : ℕ → ℝ)
    (hb : ∀ m s, 0 ≤ s → ‖g m s‖ ≤ B m)
    (hd : ∀ m s, 0 ≤ s → HasDerivWithinAt (g m) (g (m+1) s) (Set.Ici 0) s)
    (n m : ℕ) : ContDiff ℝ n (seeleyGluedJet m (g m)) := by
  have hder : ∀ m t, HasDerivAt (seeleyGluedJet m (g m))
      (seeleyGluedJet (m+1) (g (m+1)) t) t := fun m t =>
    seeley_glued_jet_hasDerivAt m (hb m) (hb (m+1)) (hd m)
      (hd (m+1) 0 le_rfl).continuousWithinAt t
  induction n generalizing m with
  | zero => exact contDiff_zero.mpr (continuous_iff_continuousAt.mpr (fun t => (hder m t).continuousAt))
  | succ n ih =>
    rw [show ((n+1 : ℕ) : WithTop ℕ∞) = (n : WithTop ℕ∞)+1 by simp,
      contDiff_succ_iff_deriv]
    refine ⟨fun t => (hder m t).differentiableAt, by simp, ?_⟩
    have he : deriv (seeleyGluedJet m (g m)) = seeleyGluedJet (m+1) (g (m+1)) :=
      funext (fun t => (hder m t).deriv)
    rw [he]
    exact ih (m+1)

/-- A genuine one-dimensional smooth extension, given a bounded compatible
sequence of all right-hand derivatives. No multivariable extension is claimed. -/
theorem seeley_smooth_extension_of_bounded_jets (g : ℕ → ℝ → E) (B : ℕ → ℝ)
    (hb : ∀ m s, 0 ≤ s → ‖g m s‖ ≤ B m)
    (hd : ∀ m s, 0 ≤ s → HasDerivWithinAt (g m) (g (m+1) s) (Set.Ici 0) s) :
    ∃ F : ℝ → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F (g 0) (Set.Ici 0) := by
  refine ⟨seeleyGluedJet 0 (g 0), ?_, fun t ht => seeley_glued_jet_eq_nonneg 0 (g 0) ht⟩
  rw [contDiff_infty]
  intro n
  exact seeley_glued_jets_contDiff_nat g B hb hd n 0

end EllipticSquareFunction
