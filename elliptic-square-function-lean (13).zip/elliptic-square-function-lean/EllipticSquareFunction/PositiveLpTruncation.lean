import EllipticSquareFunction.PositiveDualNorm

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Monotone convergence of positive L^(3/2) norms. -/
theorem positive_three_halves_iSup {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (f : ℕ → α → ℝ≥0∞) (hf : ∀ n, Measurable (f n)) (hmono : Monotone f) :
    eLpNorm (fun x => ⨆ n, f n x) (3/2) μ=⨆ n, eLpNorm (f n) (3/2) μ := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3/2:ℝ≥0∞)≠0)
    (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne,
    ENNReal.toReal_div, ENNReal.toReal_ofNat,enorm_eq_self]
  have hp (x : α) : (⨆ n, f n x)^(3/2:ℝ)=⨆ n, (f n x)^(3/2:ℝ) :=
    (ENNReal.orderIsoRpow (3/2) (by norm_num)).map_iSup _
  simp_rw [hp]
  rw [lintegral_iSup (fun n => (hf n).pow_const (3/2:ℝ))
    (fun n m hnm x => ENNReal.rpow_le_rpow (hmono hnm x) (by norm_num : (0:ℝ)≤3/2))]
  exact (ENNReal.orderIsoRpow (1/(3/2)) (by norm_num)).map_iSup _

def positiveTruncation {α : Type*} [MeasurableSpace α] (μ : Measure α) [SigmaFinite μ]
    (f : α → ℝ≥0∞) (n : ℕ) : α → ℝ≥0∞ :=
  (spanningSets μ n).indicator (fun x => min (f x) (n:ℝ≥0∞))

theorem positiveTruncation_le {α : Type*} [MeasurableSpace α] (μ : Measure α) [SigmaFinite μ]
    (f : α → ℝ≥0∞) (n : ℕ) (x : α) : positiveTruncation μ f n x≤f x := by
  by_cases hx : x∈spanningSets μ n
  · simpa [positiveTruncation,hx] using min_le_left (f x) (n:ℝ≥0∞)
  · simp [positiveTruncation,hx]

theorem positiveTruncation_le_nat {α : Type*} [MeasurableSpace α] (μ : Measure α) [SigmaFinite μ]
    (f : α → ℝ≥0∞) (n : ℕ) (x : α) : positiveTruncation μ f n x≤n := by
  by_cases hx : x∈spanningSets μ n
  · simpa [positiveTruncation,hx] using min_le_right (f x) (n:ℝ≥0∞)
  · simp [positiveTruncation,hx]

theorem positiveTruncation_mono {α : Type*} [MeasurableSpace α] (μ : Measure α) [SigmaFinite μ]
    (f : α → ℝ≥0∞) : Monotone (positiveTruncation μ f) := by
  intro n m hnm x
  by_cases hx : x∈spanningSets μ n
  · have hxm := spanningSets_mono hnm hx
    simp only [positiveTruncation,Set.indicator_of_mem hx,Set.indicator_of_mem hxm]
    exact min_le_min_left _ (by exact_mod_cast hnm)
  · simp only [positiveTruncation,Set.indicator_of_not_mem hx]
    exact zero_le _

theorem positiveTruncation_iSup {α : Type*} [MeasurableSpace α] (μ : Measure α) [SigmaFinite μ]
    (f : α → ℝ≥0∞) (x : α) : (⨆ n, positiveTruncation μ f n x)=f x := by
  apply le_antisymm (iSup_le (fun n => positiveTruncation_le μ f n x))
  have hx : x∈⋃ n, spanningSets μ n := by simp
  obtain ⟨m,hm⟩ := Set.mem_iUnion.mp hx
  have hh : f x=⨆ k : ℕ, min (f x) (k:ℝ≥0∞) := by
    rw [← inf_iSup_eq,ENNReal.iSup_natCast]
    simp
  rw [hh]
  apply iSup_le
  intro k
  apply le_iSup_of_le (max m k)
  have hxm := spanningSets_mono (le_max_left m k) hm
  simp only [positiveTruncation,Set.indicator_of_mem hxm]
  exact min_le_min_left _ (by exact_mod_cast le_max_right m k)

theorem measurable_positiveTruncation {α : Type*} [MeasurableSpace α]
    (μ : Measure α) [SigmaFinite μ] (f : α → ℝ≥0∞) (hf : Measurable f) (n : ℕ) :
    Measurable (positiveTruncation μ f n) :=
  (hf.min measurable_const).indicator (measurableSet_spanningSets μ n)

/-- The truncations are genuine finite-norm real test densities. -/
theorem positiveTruncation_toReal_memLp {α : Type*} [MeasurableSpace α]
    (μ : Measure α) [SigmaFinite μ] (f : α → ℝ≥0∞) (hf : Measurable f) (n : ℕ) :
    MemLp (fun x => (positiveTruncation μ f n x).toReal) (3/2) μ := by
  have hm := (measurable_positiveTruncation μ f hf n).ennreal_toReal
  apply (memLp_indicator_const (3/2) (measurableSet_spanningSets μ n) (n:ℝ)
    (Or.inr (measure_spanningSets_lt_top μ n).ne)).mono hm.aestronglyMeasurable
  filter_upwards with x
  by_cases hx : x∈spanningSets μ n
  · rw [Set.indicator_of_mem hx,Real.norm_eq_abs,abs_of_nonneg ENNReal.toReal_nonneg,
      Real.norm_eq_abs,abs_of_nonneg (Nat.cast_nonneg n)]
    exact (ENNReal.toReal_mono (by simp) (positiveTruncation_le_nat μ f n x)).trans_eq (by simp)
  · simp [positiveTruncation,hx]

end EllipticSquareFunction
