import EllipticSquareFunction.SeparatedBoundedProfile

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

theorem freePacket_spatial_translation (φ : Phase) (b : Plane → ℂ)
    (N : ℝ) (ν v m : Plane) (y : Space) :
    freePacket φ b N ν (v-m) y = freePacket φ b N ν v (y.1+m,y.2) := by
  unfold freePacket
  have he : y.1-(v-m)=y.1+m-v := by abel
  simp only [he]

theorem spatialDensity_spatial_translation {ι : Type*} (s : Finset ι)
    (a : ι → ℂ) (V v : ι → Plane) (N M : ℝ) (m : Plane) (y : Space) :
    spatialDensity s a V (fun i => v i-m) N M y =
      spatialDensity s a V v N M (y.1+m,y.2) := by
  unfold spatialDensity spatialWeight
  apply Finset.sum_congr rfl
  intro i hi
  have he : y.1-(v i-m)+y.2 • V i=y.1+m-v i+y.2 • V i := by abel
  simp only [he]

theorem spatial_translation_l3 (F : Space → ℂ) (hF : Continuous F)
    (W : Set Plane) (R : ℝ) (m : Plane) :
    l3 (fun y : Space => F (y.1+m,y.2))
      (volume.restrict (localSlab ((fun x : Plane => x+m) ⁻¹' W) R)) =
      l3 F (volume.restrict (localSlab W R)) := by
  have hm : MeasurePreserving (fun y : Space => y+(m,0)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) m).prod
      (measurePreserving_add_right (volume : Measure ℝ) 0)
  have he := (Homeomorph.addRight (m, (0:ℝ))).measurableEmbedding
  have hp : (fun y : Space => y+(m,0)) ⁻¹' localSlab W R =
      localSlab ((fun x : Plane => x+m) ⁻¹' W) R := by
    ext y
    simp [localSlab]
  have hh := eLpNorm_comp_measurePreserving
    (hF.aestronglyMeasurable : AEStronglyMeasurable F (volume.restrict (localSlab W R)))
    (hm.restrict_preimage_emb he (localSlab W R)) (p := (3:ℝ≥0∞))
  rw [hp] at hh
  simpa only [l3,Function.comp_def,Prod.add_def,add_zero] using hh

theorem spatial_translation_densityCubeRoot (D : Space → ℝ) (R : ℝ) (m : Plane) :
    densityCubeRoot (fun y : Space => D (y.1+m,y.2)) R = densityCubeRoot D R := by
  have hm : MeasurePreserving (fun y : Space => y+(m,0)) volume volume :=
    (measurePreserving_add_right (volume : Measure Plane) m).prod
      (measurePreserving_add_right (volume : Measure ℝ) 0)
  have he := (Homeomorph.addRight (m, (0:ℝ))).measurableEmbedding
  have hp : (fun y : Space => y+(m,0)) ⁻¹' timeSlab R = timeSlab R := by
    ext y
    simp [timeSlab]
  have hh := hm.setLIntegral_comp_preimage_emb he
    (fun y => (ENNReal.ofReal (D y))^(3/2:ℝ)) (timeSlab R)
  rw [hp] at hh
  unfold densityCubeRoot
  congr 1
  simpa only [Prod.add_def,add_zero] using hh

/-- Transport a proved local profile estimate to an arbitrary spatial center.
The right-hand density integral remains over the whole spatial plane. -/
theorem localProfileEstimate_spatial_translation {ι : Type*}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane)
    {N : ℝ} (hN : N≠0) (M P κ η C : ℝ) (W : Set Plane) (m : Plane)
    (h : LocalProfileEstimate φ b s a ν (fun i => v i-m) N M P κ η C
      ((fun x : Plane => x+m) ⁻¹' W)) :
    LocalProfileEstimate φ b s a ν v N M P κ η C W := by
  let F := fun y => ∑ i ∈ s, a i*freePacket φ b N (ν i) (v i) y
  let D := spatialDensity s a (fun i => velocity φ (ν i)) v N M
  have hF : Continuous F := continuous_finset_sum s (fun i hi =>
    continuous_const.mul (continuous_freePacket φ hφ b hb hbs hN _ _))
  have hD : spatialDensity s a (fun i => velocity φ (ν i)) (fun i => v i-m) N M =
      fun y : Space => D (y.1+m,y.2) := by
    funext y
    exact spatialDensity_spatial_translation s a (fun i => velocity φ (ν i)) v N M m y
  unfold LocalProfileEstimate at h ⊢
  simp only [freePacket_spatial_translation,spatialDensity_spatial_translation] at h
  rw [hD] at h
  change l3 (fun y : Space => F (y.1+m,y.2))
      (volume.restrict (localSlab ((fun x : Plane => x+m) ⁻¹' W) (N^2))) ≤
      ENNReal.ofReal (C*packetConstant P κ η (N^2))*
        densityCubeRoot (fun y : Space => D (y.1+m,y.2)) (N^2) at h
  rw [spatial_translation_l3 F hF W (N^2) m,spatial_translation_densityCubeRoot D (N^2) m] at h
  exact h

/-- Corrected (4.14) around any spatial center, with one constant for all centers. -/
theorem corrected_equation_4_14_centered {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F A Q : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hA : 0≤A) (hQ : 0≤Q)
    (hA₁ : A+1 ≤ S.C₁) (hQ₂ : Q+1 ≤ S.C₂) (M : ℝ) (hM : 2<M) :
    ∃ Z : ℝ, 0<Z ∧ (F+Z ≤ S.frequencyBound →
      ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
        let N : ℝ := (2:ℝ)^j
        ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
          (ν : ι → Plane) (v : ι → IntPlane → Plane) (m : Plane),
        (∀ i ∈ s, ‖ν i‖ ≤ F) →
        (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N ≤ ‖ν i-ν k‖) →
        (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
        (∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p-m‖ ≤ A*N^2) →
        ∀ W : Set Plane, W ⊆ Metric.closedBall m (Q*N^2) →
        LocalProfileEstimate S.φ b (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
          N M P κ η C W) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨Z,hZ,hbound⟩ := corrected_equation_4_14_separated_real_decay (ι := ι)
    S hphase hinput b hb hbs hc hσ hF hA hQ hA₁ hQ₂ M hM
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  obtain ⟨C,hC,hc⟩ := hbound hFZ
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hp⟩ := hc κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N s pbox a ν v m hν hsep hpos hv W hW
  apply localProfileEstimate_spatial_translation S.φ hφ.continuous b hb.continuous hbs
    (s.sigma pbox) (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
    (by positivity : N≠0) M P κ η C W m
  apply hp j hj s pbox a ν (fun i p => v i p-m) hν hsep _ hv
    ((fun x : Plane => x+m) ⁻¹' W)
  · intro x hx
    have hh := hW hx
    simpa only [Metric.mem_closedBall,dist_eq_norm,add_sub_cancel_right,sub_zero] using hh
  · intro i hi p hp q hq hpq
    have he : (v i p-m)-(v i q-m)=v i p-v i q := by abel
    rw [he]
    exact hpos i hi p hp q hq hpq

end EllipticSquareFunction
