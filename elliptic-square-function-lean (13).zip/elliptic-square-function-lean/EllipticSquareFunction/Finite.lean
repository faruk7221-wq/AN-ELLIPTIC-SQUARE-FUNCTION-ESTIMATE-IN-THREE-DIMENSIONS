import Mathlib

/-!
# Finite inequalities used in Sections 4 and 5

These are proved from Mathlib, without any hypotheses from the article's
external inputs. Infinite sums and the Fourier reconstruction are separate
analytic obligations; this file does not assert that those have been proved.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open Finset

namespace EllipticSquareFunction

/-- Superadditivity of the `p`-th power, for `p ≥ 1`, in a finite sum.
Used in (4.8), (4.13), Section 4.3, and (5.11). -/
theorem sum_rpow_le_rpow_sum {ι : Type*} (s : Finset ι) (f : ι → ℝ)
    {p : ℝ} (hf : ∀ i ∈ s, 0 ≤ f i) (hp : 1 ≤ p) :
    (∑ i ∈ s, (f i) ^ p) ≤ (∑ i ∈ s, f i) ^ p := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [Real.zero_rpow (by linarith : p ≠ 0)]
  | @insert a s ha ih =>
    simp only [Finset.sum_insert ha]
    exact (add_le_add_left (ih (fun i hi => hf i (by simp [hi]))) _).trans
      (Real.add_rpow_le_rpow_add (hf a (by simp))
        (Finset.sum_nonneg (fun i hi => hf i (by simp [hi]))) hp)

/-- The weighted cubic Hölder inequality displayed after (4.7),
also used when summing the time slabs in Section 5. -/
theorem weighted_cubic_holder {ι : Type*} (s : Finset ι) (w u : ι → ℝ)
    (hw : ∀ i ∈ s, 0 ≤ w i) (hu : ∀ i ∈ s, 0 ≤ u i) :
    (∑ i ∈ s, w i * u i) ^ 3 ≤
      (∑ i ∈ s, w i) ^ 2 * ∑ i ∈ s, w i * (u i) ^ 3 := by
  classical
  by_cases hs : (∑ i ∈ s, w i) = 0
  · have hw0 : ∀ i ∈ s, w i = 0 := (Finset.sum_eq_zero_iff_of_nonneg hw).mp hs
    have hwu : (∑ i ∈ s, w i * u i) = 0 :=
      Finset.sum_eq_zero (fun i hi => by rw [hw0 i hi]; simp)
    simp [hs, hwu]
  · have hspos : 0 < ∑ i ∈ s, w i :=
      lt_of_le_of_ne (Finset.sum_nonneg hw) (Ne.symm hs)
    have hj := Real.pow_arith_mean_le_arith_mean_pow s
      (fun i => w i / (∑ j ∈ s, w j)) u
      (fun i hi => div_nonneg (hw i hi) hspos.le)
      (by rw [← Finset.sum_div, div_self hs]) hu 3
    simp_rw [div_mul_eq_mul_div, ← Finset.sum_div] at hj
    have hm := mul_le_mul_of_nonneg_right hj (pow_nonneg hspos.le 3)
    convert hm using 1 <;> field_simp
    ring

/-- Complex-valued weighted reconstruction, the pointwise part of (4.7). -/
theorem norm_reconstruction_cubed {ι : Type*} (s : Finset ι)
    (c K : ι → ℂ) (k : ι → ℝ) (hk : ∀ i ∈ s, ‖K i‖ ≤ k i) :
    ‖∑ i ∈ s, c i * K i‖ ^ 3 ≤
      (∑ i ∈ s, k i) ^ 2 * ∑ i ∈ s, k i * ‖c i‖ ^ 3 := by
  have hk0 : ∀ i ∈ s, 0 ≤ k i := fun i hi => (norm_nonneg _).trans (hk i hi)
  have hn : ‖∑ i ∈ s, c i * K i‖ ≤ ∑ i ∈ s, k i * ‖c i‖ := by
    calc
      _ ≤ ∑ i ∈ s, ‖c i * K i‖ := norm_sum_le _ _
      _ ≤ _ := Finset.sum_le_sum (fun i hi => by
        rw [norm_mul, mul_comm (k i)]
        exact mul_le_mul_of_nonneg_left (hk i hi) (norm_nonneg _))
  exact (pow_le_pow_left₀ (norm_nonneg _) hn 3).trans
    (weighted_cubic_holder s k (fun i => ‖c i‖) hk0 (fun _ _ => norm_nonneg _))

/-- The pointwise second inequality in (5.11), with arbitrary nonnegative
weights. In the article `w k = (1 + |j-k|)⁻ᴬ`. -/
theorem merge_weighted_densities {ι : Type*} (s : Finset ι) (w H : ι → ℝ)
    (hw : ∀ i ∈ s, 0 ≤ w i) (hH : ∀ i ∈ s, 0 ≤ H i) :
    (∑ i ∈ s, w i * (H i) ^ (3 / 2 : ℝ)) ≤
      (∑ i ∈ s, (w i) ^ (2 / 3 : ℝ) * H i) ^ (3 / 2 : ℝ) := by
  calc
    _ = ∑ i ∈ s, ((w i) ^ (2 / 3 : ℝ) * H i) ^ (3 / 2 : ℝ) := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [Real.mul_rpow (Real.rpow_nonneg (hw i hi) _) (hH i hi),
        ← Real.rpow_mul (hw i hi)]
      norm_num
    _ ≤ _ := sum_rpow_le_rpow_sum s _
      (fun i hi => mul_nonneg (Real.rpow_nonneg (hw i hi) _) (hH i hi)) (by norm_num)

/-- The overlap summation used for the near packets in Section 4.3. -/
theorem bounded_overlap_density {ι : Type*} (s : Finset ι) (d : ι → ℝ)
    {D C : ℝ} (hd : ∀ i ∈ s, 0 ≤ d i) (hD : 0 ≤ D) (hC : 0 ≤ C)
    (hoverlap : ∑ i ∈ s, d i ≤ C * D) :
    (∑ i ∈ s, (d i) ^ (3 / 2 : ℝ)) ≤ C ^ (3 / 2 : ℝ) * D ^ (3 / 2 : ℝ) := by
  calc
    _ ≤ (∑ i ∈ s, d i) ^ (3 / 2 : ℝ) :=
      sum_rpow_le_rpow_sum s d hd (by norm_num)
    _ ≤ (C * D) ^ (3 / 2 : ℝ) :=
      Real.rpow_le_rpow (Finset.sum_nonneg hd) hoverlap (by norm_num)
    _ = _ := Real.mul_rpow hC hD

end EllipticSquareFunction
