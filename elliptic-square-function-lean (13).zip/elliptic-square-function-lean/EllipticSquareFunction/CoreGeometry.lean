import EllipticSquareFunction.Definitions
import EllipticSquareFunction.Integration

/-! # Core tube volumes and the coefficient lower bound (4.8) -/

noncomputable section
open scoped BigOperators ENNReal
open MeasureTheory Set
namespace EllipticSquareFunction

theorem measurableSet_coreTube (N R : ℝ) (V v : Plane) :
    MeasurableSet (coreTube N R V v) := by
  apply MeasurableSet.inter
  · exact measurableSet_Icc.preimage measurable_snd
  · exact (isClosed_le (f := fun y : Space => ‖y.1 - v + y.2 • V‖)
      (g := fun _ => N) (by fun_prop) continuous_const).measurableSet

theorem coreTube_section (N R t : ℝ) (V v : Plane) :
    (fun x : Plane => (x, t)) ⁻¹' coreTube N R V v =
      if t ∈ Icc 0 R then Metric.closedBall (v - t • V) N else ∅ := by
  ext x
  have he : x - v + t • V = x - (v - t • V) := by module
  by_cases ht : t ∈ Icc 0 R
  · simp [coreTube, ht, ht.1, ht.2, Metric.mem_closedBall, dist_eq_norm, he]
  · change (t ∈ Icc 0 R ∧ ‖x - v + t • V‖ ≤ N) ↔ x ∈ _
    rw [if_neg ht]
    simp only [mem_empty_iff_false, iff_false, not_and]
    exact fun h => (ht h).elim

/-- The core volume is exactly `π N² R`, independent of the slope and center. -/
theorem volume_coreTube (N R : ℝ) (V v : Plane) :
    volume (coreTube N R V v) = ENNReal.ofReal N ^ 2 *
      ENNReal.ofReal Real.pi * ENNReal.ofReal R := by
  change (volume.prod volume) (coreTube N R V v) = _
  rw [Measure.prod_apply_symm (measurableSet_coreTube N R V v)]
  simp_rw [coreTube_section]
  have hf : (fun t : ℝ => volume
      (if t ∈ Icc 0 R then Metric.closedBall (v - t • V) N else ∅)) =
      (Icc 0 R).indicator (fun _ => ENNReal.ofReal N ^ 2 * ENNReal.ofReal Real.pi) := by
    funext t
    by_cases ht : t ∈ Icc 0 R
    · simp [ht]
    · simp [ht]
  rw [hf, lintegral_indicator_const measurableSet_Icc]
  simp

theorem volume_coreTube_ne_top (N R : ℝ) (V v : Plane) :
    volume (coreTube N R V v) ≠ ∞ := by
  rw [volume_coreTube]
  exact ENNReal.mul_ne_top (ENNReal.mul_ne_top (ENNReal.pow_ne_top ENNReal.ofReal_ne_top) ENNReal.ofReal_ne_top)
    ENNReal.ofReal_ne_top

theorem coreDensity_nonneg {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) (y : Space) :
    0 ≤ coreDensity s a V v N R y := by
  apply Finset.sum_nonneg
  intro i _
  exact Set.indicator_nonneg (fun _ _ => sq_nonneg _) y

theorem coreDensity_memLp {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) (p : ℝ≥0∞) :
    MemLp (coreDensity s a V v N R) p volume := by
  apply memLp_finset_sum
  intro i _
  exact memLp_indicator_const p (measurableSet_coreTube N R (V i) (v i)) _
    (Or.inr (volume_coreTube_ne_top N R (V i) (v i)))

theorem integral_core_indicator (N R : ℝ) (V v : Plane)
    (hN : 0 ≤ N) (hR : 0 ≤ R) :
    (∫ y : Space, (coreTube N R V v).indicator (fun _ => (1 : ℝ)) y) =
      Real.pi * N ^ 2 * R := by
  rw [integral_indicator (measurableSet_coreTube N R V v), integral_const]
  simp only [Measure.restrict_apply_univ, smul_eq_mul, mul_one, measureReal_def,
    volume_coreTube, ENNReal.toReal_mul, ENNReal.toReal_pow,
    ENNReal.toReal_ofReal hN, ENNReal.toReal_ofReal hR,
    ENNReal.toReal_ofReal Real.pi_pos.le]
  ring

/-- No separate integrability assumption is needed for the finite core density. -/
theorem coreDensity_integrable_rpow {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) :
    Integrable (fun y => coreDensity s a V v N R y ^ (3 / 2 : ℝ)) volume := by
  have h := (coreDensity_memLp s a V v N R (3 / 2)).integrable_norm_rpow
    (by norm_num) (ENNReal.div_lt_top (by norm_num) (by norm_num)).ne
  simpa only [ENNReal.toReal_div, ENNReal.toReal_ofNat, Real.norm_eq_abs,
    abs_of_nonneg (coreDensity_nonneg s a V v N R _)] using h

/-- Equation (4.8), including its geometric constant, for a slab of height `R`. -/
theorem coreDensity_integral_lower_bound {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N R : ℝ) (hN : 0 ≤ N) (hR : 0 ≤ R) :
    Real.pi * N ^ 2 * R * ∑ i ∈ s, ‖a i‖ ^ 3 ≤
      ∫ y : Space, coreDensity s a V v N R y ^ (3 / 2 : ℝ) := by
  classical
  let ρ := fun i => (coreTube N R (V i) (v i)).indicator (fun _ => (1 : ℝ))
  have hρpow (i : ι) (y : Space) : ρ i y ^ (3 / 2 : ℝ) = ρ i y := by
    by_cases hy : y ∈ coreTube N R (V i) (v i) <;> simp [ρ, hy]
  have he (y : Space) : ∑ i ∈ s, ‖a i‖ ^ 2 * ρ i y =
      coreDensity s a V v N R y := by
    apply Finset.sum_congr rfl
    intro i _
    by_cases hy : y ∈ coreTube N R (V i) (v i) <;> simp [ρ, hy]
  have hi (i : ι) : Integrable (fun y => ρ i y ^ (3 / 2 : ℝ)) volume := by
    simp_rw [hρpow]
    exact memLp_one_iff_integrable.mp (memLp_indicator_const 1
      (measurableSet_coreTube N R (V i) (v i)) (1 : ℝ)
      (Or.inr (volume_coreTube_ne_top N R (V i) (v i))))
  have hm (i : ι) : Real.pi * N ^ 2 * R = ∫ y, ρ i y ^ (3 / 2 : ℝ) := by
    simp_rw [hρpow]
    exact (integral_core_indicator N R (V i) (v i) hN hR).symm
  have h := density_integral_lower_bound volume s a ρ
    (fun y i _ => Set.indicator_nonneg (fun _ _ => by norm_num) y)
    (fun i _ => hi i) (by simpa only [he] using coreDensity_integrable_rpow s a V v N R)
    (fun i _ => (hm i).le)
  simpa only [he] using h

/-- The manuscript's scale `R = N²` gives the factor `π N⁴`. -/
theorem equation_4_8 {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N : ℝ) (hN : 0 ≤ N) :
    Real.pi * N ^ 4 * ∑ i ∈ s, ‖a i‖ ^ 3 ≤
      ∫ y : Space, coreDensity s a V v N (N ^ 2) y ^ (3 / 2 : ℝ) := by
  have h := coreDensity_integral_lower_bound s a V v N (N ^ 2) hN (sq_nonneg N)
  convert h using 1
  ring

end EllipticSquareFunction
