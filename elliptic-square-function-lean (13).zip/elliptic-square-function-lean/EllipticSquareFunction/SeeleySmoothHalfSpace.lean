import EllipticSquareFunction.SeeleyTensorBoundary

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Compatible bounded tensors give a jointly smooth extension, not merely
separate smoothness in the normal and tangential variables. -/
theorem seeley_smooth_extension_of_bounded_tensors
    (J : (m : ℕ) → ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E)
    (B : ℕ → ℝ) (hb : ∀ m p, 0 ≤ p.1 → ‖J m p‖ ≤ B m)
    (hd : ∀ m p, 0 ≤ p.1 → HasFDerivWithinAt (J m) (J (m+1) p).curryLeft
      {q : ℝ × X | 0 ≤ q.1} p) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧
      Set.EqOn F (fun p => (J 0 p).curry0) {p : ℝ × X | 0 ≤ p.1} := by
  let P : ℝ × X → FormalMultilinearSeries ℝ (ℝ × X) E :=
    fun p m => seeleyGluedTensor m (J m) p
  let F : ℝ × X → E := fun p => (P p 0).curry0
  have ht : HasFTaylorSeriesUpToOn (⊤ : ℕ∞) F P Set.univ := by
    rw [hasFTaylorSeriesUpToOn_top_iff' le_rfl]
    refine ⟨fun p hp => rfl, ?_⟩
    intro m p hp
    exact (seeley_glued_tensor_hasFDerivAt m (hb m) (hb (m+1))
      (fun q hq => (hd (m+1) q hq).continuousWithinAt) (hd m) p).hasFDerivWithinAt
  refine ⟨F,contDiffOn_univ.mp ht.contDiffOn,fun p hp => ?_⟩
  change (seeleyGluedTensor 0 (J 0) p).curry0 = _
  rw [seeley_glued_tensor_nonneg 0 (J 0) hp]

theorem seeley_halfspace_uniqueDiffOn :
    UniqueDiffOn ℝ {p : ℝ × X | 0 ≤ p.1} := by
  simpa only [Set.prod_univ,Set.preimage,Set.mem_Ici] using
    (uniqueDiffOn_Ici (0 : ℝ)).prod (uniqueDiffOn_univ (𝕜 := ℝ) (E := X))

/-- A smooth map on a closed half-space extends smoothly to the whole product
when all its within-derivatives have uniform bounds. -/
theorem smooth_halfspace_extension_of_bounded_derivatives {f : ℝ × X → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1})
    (hb : ∀ m : ℕ, ∃ B : ℝ, ∀ p : ℝ × X, 0 ≤ p.1 →
      ‖iteratedFDerivWithin ℝ m f {q : ℝ × X | 0 ≤ q.1} p‖ ≤ B) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧
      Set.EqOn F f {p : ℝ × X | 0 ≤ p.1} := by
  choose B hB using hb
  have ht := hf.ftaylorSeriesWithin seeley_halfspace_uniqueDiffOn
  obtain ⟨F,hF,hEq⟩ := seeley_smooth_extension_of_bounded_tensors
    (fun m p => iteratedFDerivWithin ℝ m f {q : ℝ × X | 0 ≤ q.1} p) B hB
    (fun m p hp => ht.fderivWithin m
      (by exact_mod_cast (WithTop.coe_lt_top (a := m))) p hp)
  exact ⟨F,hF,fun p hp => (hEq hp).trans (ht.zero_eq p hp)⟩

end EllipticSquareFunction
