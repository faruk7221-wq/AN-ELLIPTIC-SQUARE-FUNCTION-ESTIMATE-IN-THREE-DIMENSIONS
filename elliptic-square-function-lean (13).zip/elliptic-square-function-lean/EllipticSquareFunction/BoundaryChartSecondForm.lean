import EllipticSquareFunction.BoundaryChartExtensions
import EllipticSquareFunction.BoundarySecondFormPullback

noncomputable section
open Filter
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- Normal second form in a chosen chart at any point of that chart.
The derivative is taken within the model range, including its boundary. -/
def boundaryChartSecondForm (f : M → EuclideanThree) (x z : M) (N : EuclideanThree)
    (v w : Plane) : ℝ :=
  @inner ℝ EuclideanThree _ N
    (fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x) (Set.range (𝓡∂ 2)))
      (Set.range (𝓡∂ 2)) (extChartAt (𝓡∂ 2) x z) v w)

/-- The normal second form has the tensor transition rule in actual Mathlib
boundary charts. Only normality kills the second derivative of the transition. -/
theorem boundary_chart_second_form_transition {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x y z : M) (hzx : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (hzy : z ∈ (extChartAt (𝓡∂ 2) y).source) (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N
      (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f y) (Set.range (𝓡∂ 2))
        (extChartAt (𝓡∂ 2) y z) v)=0) (v w : Plane) :
    boundaryChartSecondForm f x z N v w =
      boundaryChartSecondForm f y z N
        (tangentCoordChange (𝓡∂ 2) x y z v) (tangentCoordChange (𝓡∂ 2) x y z w) := by
  let I := 𝓡∂ 2
  let g : Plane → Plane := extChartAt I y ∘ (extChartAt I x).symm
  let a := extChartAt I x z
  have hga : g a = extChartAt I y z := by
    change extChartAt I y ((extChartAt I x).symm (extChartAt I x z)) = _
    rw [(extChartAt I x).left_inv hzx]
  have haR : a ∈ Set.range I :=
    extChartAt_target_subset_range x ((extChartAt I x).map_source hzx)
  have hgaR : g a ∈ Set.range I := by
    rw [hga]
    exact extChartAt_target_subset_range y ((extChartAt I y).map_source hzy)
  obtain ⟨F,U,hU,haU,hF,heF⟩ := boundary_chart_param_extension hf y z hzy
  obtain ⟨G,V,hV,haV,hG,heG⟩ := boundary_chart_transition_extension x y z hzx hzy
  have hmaps : Set.MapsTo g (Set.range I) (Set.range I) := by
    intro p hp
    change extChartAt I y ((extChartAt I x).symm p) ∈ Set.range I
    rw [extChartAt_coe]
    exact ⟨chartAt (EuclideanHalfSpace 2) y ((extChartAt I x).symm p),rfl⟩
  have horth' : ∀ v, @inner ℝ EuclideanThree _ N
      (fderivWithin ℝ (modelSurfaceParam I f y) (Set.range I) (g a) v)=0 := by
    simpa only [hga] using horth
  have hgaU : g a ∈ U := by rw [hga]; exact haU
  have hh := boundary_second_form_pullback (f := modelSurfaceParam I f y) (g := g) (a := a) hU hV haV haR
    hgaU hgaR I.uniqueDiffOn I.uniqueDiffOn hF hG
    heF heG hmaps N horth' v w
  have he : modelSurfaceParam I f y ∘ g =ᶠ[𝓝[Set.range I] a]
      modelSurfaceParam I f x := by
    have hn := PartialHomeomorph.extend_coord_change_source_mem_nhdsWithin'
      (chartAt (EuclideanHalfSpace 2) x) (chartAt (EuclideanHalfSpace 2) y)
      (I := I) (by simpa only [extChartAt_source] using hzx)
      (by simpa only [extChartAt_source] using hzy)
    filter_upwards [hn] with p hp
    change f ((extChartAt I y).symm (extChartAt I y ((extChartAt I x).symm p))) =
      f ((extChartAt I x).symm p)
    exact congrArg f ((extChartAt I y).left_inv hp.2)
  have he0 : (modelSurfaceParam I f y ∘ g) a = modelSurfaceParam I f x a := by
    change f ((extChartAt I y).symm (g a)) = f ((extChartAt I x).symm a)
    rw [hga,(extChartAt I y).left_inv hzy,(extChartAt I x).left_inv hzx]
  have he2 := (he.fderivWithin (𝕜 := ℝ)).fderivWithin_eq (𝕜 := ℝ) (he.fderivWithin_eq (𝕜 := ℝ) he0)
  rw [he2,hga] at hh
  exact hh

/-- At its preferred center, the chart formula is exactly the canonical
model second fundamental form already used by the main theorem. -/
theorem boundary_chart_second_form_self (f : M → EuclideanThree) (z : M)
    (N : EuclideanThree) (v w : Plane) :
    boundaryChartSecondForm f z z N v w = modelSecondForm (𝓡∂ 2) f z N v w := by
  have he := extChartAt_target_eventuallyEq (I := 𝓡∂ 2) (x := z)
  have hd := fderivWithin_eventually_congr_set (𝕜 := ℝ)
    (f := modelSurfaceParam (𝓡∂ 2) f z) he
  unfold boundaryChartSecondForm modelSecondForm
  rw [hd.fderivWithin_eq_nhds, fderivWithin_congr_set he]

/-- Symmetry is valid in every boundary chart at every point of its source. -/
theorem boundary_chart_second_form_symmetric {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (N : EuclideanThree) (v w : Plane) :
    boundaryChartSecondForm f x z N v w = boundaryChartSecondForm f x z N w v := by
  obtain ⟨F,U,hU,ha,hF,heq⟩ := boundary_chart_param_extension hf x z hz
  have haR := extChartAt_target_subset_range x ((extChartAt (𝓡∂ 2) x).map_source hz)
  unfold boundaryChartSecondForm
  rw [extension_second_fderivWithin hU ha haR (𝓡∂ 2).uniqueDiffOn
    (hF.of_le (by norm_cast)) heq]
  exact euclidean_second_form_symmetric
    ((hF.contDiffAt (hU.mem_nhds ha)).of_le (by norm_cast)) N v w

end EllipticSquareFunction
