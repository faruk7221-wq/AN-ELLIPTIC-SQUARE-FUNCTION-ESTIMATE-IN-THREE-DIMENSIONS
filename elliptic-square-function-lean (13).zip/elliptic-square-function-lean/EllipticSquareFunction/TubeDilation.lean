import EllipticSquareFunction.ExternalInputs

noncomputable section
namespace EllipticSquareFunction

/-- Homogeneity of the actual Euclidean length on the product space. -/
theorem euclideanLength_smul (c : ℝ) (y : Space) :
    euclideanLength (c • y)= |c| * euclideanLength y := by
  unfold euclideanLength
  simp only [Prod.smul_fst,Prod.smul_snd,norm_smul,Real.norm_eq_abs,smul_eq_mul]
  rw [mul_pow,mul_pow,sq_abs,← mul_add,Real.sqrt_mul (sq_nonneg c),Real.sqrt_sq_eq_abs]

/-- Positive scalar dilations preserve the tube shape and rescale its radius.
This is the geometric part of the outstanding Nikodym dilation argument. -/
theorem geometricTube_smul {c : ℝ} (hc : 0<c) (a b y : Space) (r : ℝ) :
    c • y∈geometricTube (c • a) (c • b) (c*r) ↔ y∈geometricTube a b r := by
  have he (s : ℝ) : c • y-((1-s) • (c • a)+s • (c • b))=
      c • (y-((1-s) • a+s • b)) := by module
  simp only [geometricTube,Set.mem_setOf_eq,he,euclideanLength_smul,abs_of_pos hc,
    mul_le_mul_left hc]

end EllipticSquareFunction
