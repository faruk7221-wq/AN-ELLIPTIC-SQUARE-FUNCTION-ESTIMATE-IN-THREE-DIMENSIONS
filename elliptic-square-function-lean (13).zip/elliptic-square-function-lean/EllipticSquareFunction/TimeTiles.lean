import EllipticSquareFunction.TimeTranslation
import EllipticSquareFunction.TimeLattice

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

def timeTile (R : ℝ) (j : ℤ) : Set Space := {y | ⌊y.2/R⌋=j}

theorem measurableSet_timeTile (R : ℝ) (j : ℤ) : MeasurableSet (timeTile R j) := by
  exact (measurableSet_singleton j).preimage (measurable_snd.div_const R).floor

theorem timeTile_cover (R : ℝ) : (⋃ j : ℤ, timeTile R j)=univ := by
  ext y
  simp only [mem_iUnion,mem_univ,iff_true]
  exact ⟨⌊y.2/R⌋,rfl⟩

theorem timeTile_disjoint (R : ℝ) : Pairwise (fun j k => Disjoint (timeTile R j) (timeTile R k)) := by
  intro j k hjk
  exact disjoint_left.mpr (fun y hy hk => hjk (hy.symm.trans hk))

theorem timeTile_subset_slab {R : ℝ} (hR : 0<R) (j : ℤ) :
    timeTile R j ⊆ shiftedTimeSlab ((j:ℝ)*R) R := by
  intro y hy
  have hl := Int.floor_le (y.2/R)
  have hu := Int.lt_floor_add_one (y.2/R)
  change ⌊y.2/R⌋=j at hy
  rw [hy] at hl hu
  change (j:ℝ)*R≤y.2 ∧ y.2≤(j:ℝ)*R+R
  constructor
  · exact (le_div_iff₀ hR).mp hl
  · have hh := (div_lt_iff₀ hR).mp hu
    nlinarith

theorem lintegral_time_tiles (R : ℝ) (f : Space → ℝ≥0∞) :
    (∫⁻ y, f y)=∑' j : ℤ, ∫⁻ y in timeTile R j, f y := by
  have h := lintegral_iUnion (μ := (volume : Measure Space)) (measurableSet_timeTile R) (timeTile_disjoint R) f
  simpa only [timeTile_cover,Measure.restrict_univ] using h

theorem timeTile_normalized {R : ℝ} (j : ℤ) {y : Space} (hy : y∈timeTile R j) :
    0≤y.2/R-j ∧ y.2/R-j≤1 := by
  change ⌊y.2/R⌋=j at hy
  have hl := Int.floor_le (y.2/R)
  have hu := Int.lt_floor_add_one (y.2/R)
  rw [hy] at hl hu
  constructor <;> linarith

theorem bracket_time_slab_comparison {u a : ℝ} (h : 0≤u-a ∧ u-a≤1) :
    bracket u≤2*bracket a ∧ bracket a≤2*bracket u := by
  have hd : |u-a|≤1 := by rw [abs_of_nonneg h.1]; exact h.2
  have h₁ := abs_add_le a (u-a)
  have h₂ := abs_add_le u (a-u)
  rw [abs_sub_comm a u] at h₂
  have he₁ : a+(u-a)=u := by ring
  have he₂ : u+(a-u)=a := by ring
  rw [he₁] at h₁
  rw [he₂] at h₂
  simp only [bracket,Real.norm_eq_abs]
  constructor <;> nlinarith [abs_nonneg u,abs_nonneg a]

theorem packetWeight_square_scale {N : ℝ} (hN : 0≤N) (M : ℝ) (V v : Plane)
    (s : ℝ) (y : Space) :
    packetWeight (N^2) M V v s y =
      spatialWeight N M V v (y.1,y.2-s)*bracket ((y.2-s)/(N^2))^(-M) := by
  simp only [packetWeight,spatialWeight,Real.sqrt_sq hN]

theorem timeTile_eq_prod_Ico {R : ℝ} (hR : 0<R) (j : ℤ) :
    timeTile R j=univ ×ˢ Ico ((j:ℝ)*R) ((j:ℝ)*R+R) := by
  ext y
  simp only [timeTile,mem_setOf_eq,Int.floor_eq_iff,mem_prod,mem_univ,true_and,mem_Ico]
  constructor
  · intro h
    exact ⟨(le_div_iff₀ hR).mp h.1,by have hh := (div_lt_iff₀ hR).mp h.2; nlinarith⟩
  · intro h
    exact ⟨(le_div_iff₀ hR).mpr h.1,(div_lt_iff₀ hR).mpr (by nlinarith [h.2])⟩

/-- Closed slabs and the disjoint floor tiles define exactly the same
restricted volume measure; their endpoint hyperplanes have measure zero. -/
theorem timeTile_restrict_eq_slab {R : ℝ} (hR : 0<R) (j : ℤ) :
    volume.restrict (timeTile R j)=volume.restrict (shiftedTimeSlab ((j:ℝ)*R) R) := by
  rw [timeTile_eq_prod_Ico hR]
  have he : shiftedTimeSlab ((j:ℝ)*R) R=univ ×ˢ Icc ((j:ℝ)*R) ((j:ℝ)*R+R) := by
    ext y; simp [shiftedTimeSlab]
  rw [he]
  change ((volume : Measure Plane).prod (volume : Measure ℝ)).restrict _ =
    ((volume : Measure Plane).prod (volume : Measure ℝ)).restrict _
  rw [← Measure.prod_restrict,← Measure.prod_restrict,
    Measure.restrict_congr_set (Ico_ae_eq_Icc (μ := (volume : Measure ℝ)))]

end EllipticSquareFunction
