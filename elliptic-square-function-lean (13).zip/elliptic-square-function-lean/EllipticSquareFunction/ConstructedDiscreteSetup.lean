import EllipticSquareFunction.LatticeWindowPlane
import EllipticSquareFunction.GraphSmoothingBridge

noncomputable section
namespace EllipticSquareFunction

/-- An explicit initial partition setup for every phase. Label bounds are
subsequently enlarged by the proved uniform construction. -/
def initialDiscreteSetup (φ : Phase) : DiscreteSetup where
  φ := φ
  χ := latticeWindowPlane
  χ_smooth := latticeWindowPlane_smooth
  χ_compact := latticeWindowPlane_compact
  χ_nonneg := latticeWindowPlane_nonneg
  χ_partition := latticeWindowPlane_partition
  D := 4
  D_pos := by norm_num
  χ_support := by
    intro ξ hξ i
    have hh := latticeWindowPlane_support hξ i
    norm_num
    linarith
  frequencyBound := 1
  frequencyBound_pos := by norm_num
  C₁ := 1
  C₁_pos := by norm_num
  C₂ := 1
  C₂_pos := by norm_num

theorem initialDiscreteSetup_phase (φ : Phase) : (initialDiscreteSetup φ).φ=φ := rfl

/-- The continued-graph theorem with an actually constructed partition and
adequate label bounds. There are no internal analytic or window hypotheses. -/
theorem continued_graph_exists_setup (G : GraphSetup)
    (hphase : ContinuedPhase G.φ) (hnikodym : NikodymInput) :
    ∃ S : DiscreteSetup, S.φ=G.φ ∧
      (DiscreteDensityInput S → ReverseSquareFunction G) := by
  obtain ⟨S,hφ,hχ,hD,hbound⟩ := reverseSquareFunction_of_external_analytic_inputs
    G (initialDiscreteSetup G.φ) rfl hphase hnikodym
  exact ⟨S,hφ,hbound⟩

/-- Theorem 1 on a continued graph, conditional only on the paper's two
external analytic inputs. The general elliptic graph still needs affine
placement, finite chart assembly, and boundary treatment. -/
theorem continued_graph_reverse_square_function (G : GraphSetup)
    (hphase : ContinuedPhase G.φ) (hnikodym : NikodymInput)
    (hdiscrete : ∀ S : DiscreteSetup, S.φ=G.φ → DiscreteDensityInput S) :
    ReverseSquareFunction G := by
  obtain ⟨S,hφ,hbound⟩ := continued_graph_exists_setup G hphase hnikodym
  exact hbound (hdiscrete S hφ)

end EllipticSquareFunction
