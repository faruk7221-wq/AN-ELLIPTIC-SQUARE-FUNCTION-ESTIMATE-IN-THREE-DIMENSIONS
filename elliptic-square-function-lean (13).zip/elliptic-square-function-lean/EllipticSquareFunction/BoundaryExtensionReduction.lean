import EllipticSquareFunction.AnalyticBoundaryExtension
import EllipticSquareFunction.ModelSecondFormGeometry

noncomputable section
open Filter
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
  (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]
  [IsManifold I (⊤ : ℕ∞) M]

/-- At interior points the canonical parametrization itself is a smooth
extension on a sufficiently small open neighborhood. -/
theorem smooth_model_extension_at_interior {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) (x : M)
    (hx : extChartAt I x x ∈ interior (Set.range I)) :
    ∃ (F : Plane → EuclideanThree) (U : Set Plane),
      IsOpen U ∧ extChartAt I x x ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
        Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target) := by
  have ht := extChartAt_target_mem_nhdsWithin (I := I) x
  rw [nhdsWithin_eq_nhds.mpr (mem_interior_iff_mem_nhds.mp hx)] at ht
  obtain ⟨U,hUsub,hU,ha⟩ := mem_nhds_iff.mp ht
  exact ⟨modelSurfaceParam I f x,U,hU,ha,
    (model_surface_param_smooth I hf x).mono hUsub,fun _ _ => rfl⟩

/-- The general extension obligation only has to be solved on the boundary
of the model; all interior points are handled by smoothness. -/
theorem smooth_model_extensions_of_boundary_extensions {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hb : ∀ x : M, extChartAt I x x ∉ interior (Set.range I) →
      ∃ (F : Plane → EuclideanThree) (U : Set Plane),
        IsOpen U ∧ extChartAt I x x ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
          Set.EqOn F (modelSurfaceParam I f x) (U ∩ (extChartAt I x).target)) :
    HasSmoothModelExtensions I f := by
  intro x
  by_cases hx : extChartAt I x x ∈ interior (Set.range I)
  · exact smooth_model_extension_at_interior I hf x hx
  · exact hb x hx

/-- Analyticity is needed only at boundary model points in this sufficient
condition; the embedding may be merely smooth elsewhere. -/
theorem smooth_model_extensions_of_boundary_analytic {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hb : ∀ x : M, extChartAt I x x ∉ interior (Set.range I) →
      AnalyticWithinAt ℝ (modelSurfaceParam I f x) (extChartAt I x).target (extChartAt I x x)) :
    HasSmoothModelExtensions I f := by
  apply smooth_model_extensions_of_boundary_extensions I hf
  intro x hx
  exact analytic_within_smooth_extension (hb x hx)

end EllipticSquareFunction
