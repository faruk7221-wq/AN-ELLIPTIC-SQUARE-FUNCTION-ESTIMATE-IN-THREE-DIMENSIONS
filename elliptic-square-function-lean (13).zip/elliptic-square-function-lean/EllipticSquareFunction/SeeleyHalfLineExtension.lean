import EllipticSquareFunction.SeeleySmoothJets
import Mathlib.Analysis.Calculus.IteratedDeriv.Defs

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem smooth_halfline_derivative_jets {f : ℝ → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0)) (m : ℕ) {s : ℝ} (hs : 0 ≤ s) :
    HasDerivWithinAt (iteratedDerivWithin m f (Set.Ici 0))
      (iteratedDerivWithin (m+1) f (Set.Ici 0) s) (Set.Ici 0) s := by
  rw [iteratedDerivWithin_succ]
  exact (hf.differentiableOn_iteratedDerivWithin
    (by exact_mod_cast (WithTop.coe_lt_top (a := m))) (uniqueDiffOn_Ici 0) s hs).hasDerivWithinAt

/-- Smooth data on the closed half-line admit an open smooth extension when
all within-derivatives are bounded. The remaining localization step is separate. -/
theorem smooth_halfline_extension_of_bounded_derivatives {f : ℝ → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0))
    (hb : ∀ m : ℕ, ∃ B : ℝ, ∀ s : ℝ, 0 ≤ s →
      ‖iteratedDerivWithin m f (Set.Ici 0) s‖ ≤ B) :
    ∃ F : ℝ → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F f (Set.Ici 0) := by
  choose B hB using hb
  have h := seeley_smooth_extension_of_bounded_jets
    (fun m => iteratedDerivWithin m f (Set.Ici 0)) B hB
    (fun m s hs => smooth_halfline_derivative_jets hf m hs)
  simpa only [iteratedDerivWithin_zero] using h

end EllipticSquareFunction
