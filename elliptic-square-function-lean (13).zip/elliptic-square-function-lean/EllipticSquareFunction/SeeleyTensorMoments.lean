import EllipticSquareFunction.SeeleyReflectionGeometry

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def seeleyNormalProjection : (ℝ × X) →L[ℝ] (ℝ × X) :=
  (ContinuousLinearMap.fst ℝ ℝ X).prod 0

def seeleyTangentProjection : (ℝ × X) →L[ℝ] (ℝ × X) :=
  (0 : (ℝ × X) →L[ℝ] ℝ).prod (ContinuousLinearMap.snd ℝ ℝ X)

def seeleyTensorSlot {m : ℕ} (s : Finset (Fin m)) (i : Fin m) :
    (ℝ × X) →L[ℝ] (ℝ × X) :=
  if i ∈ s then seeleyNormalProjection else seeleyTangentProjection

theorem seeley_reflection_split (k : ℕ) (p : ℝ × X) :
    seeleyReflection (X := X) k p = seeleyNode k • seeleyNormalProjection p + seeleyTangentProjection p := by
  ext <;> simp [seeley_reflection_apply,seeleyNormalProjection,seeleyTangentProjection]

theorem seeley_tensor_slot_factor {m : ℕ} (s : Finset (Fin m)) (b : ℝ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) (v : Fin m → ℝ × X) :
    A (s.piecewise (fun i => b • seeleyNormalProjection (v i))
      (fun i => seeleyTangentProjection (v i))) =
      b^s.card • A (fun i => seeleyTensorSlot s i (v i)) := by
  have he : s.piecewise (fun i => b • seeleyNormalProjection (v i))
      (fun i => seeleyTangentProjection (v i)) =
      fun i => (if i ∈ s then b else 1) • seeleyTensorSlot s i (v i) := by
    funext i
    by_cases hi : i ∈ s <;> simp [Finset.piecewise,seeleyTensorSlot,hi]
  rw [he,A.map_smul_univ]
  congr 1
  simp

theorem seeley_tensor_expansion (k m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) :
    A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k) =
      ∑ s : Finset (Fin m), seeleyNode k ^ s.card •
        A.compContinuousLinearMap (seeleyTensorSlot s) := by
  ext v
  change A (fun i => seeleyReflection (X := X) k (v i)) = _
  simp only [seeley_reflection_split]
  rw [show (fun i => seeleyNode k • seeleyNormalProjection (v i) + seeleyTangentProjection (v i)) =
    (fun i => seeleyNode k • seeleyNormalProjection (v i)) +
      (fun i => seeleyTangentProjection (v i)) from rfl]
  have hadd := A.toMultilinearMap.map_add_univ
    (fun i => seeleyNode k • seeleyNormalProjection (v i)) (fun i => seeleyTangentProjection (v i))
  change A _ = _ at hadd
  rw [hadd]
  simp only [ContinuousMultilinearMap.sum_apply,ContinuousMultilinearMap.smul_apply,
    ContinuousMultilinearMap.compContinuousLinearMap_apply]
  apply Finset.sum_congr rfl
  intro s hs
  exact seeley_tensor_slot_factor s (seeleyNode k) A v

theorem seeley_tensor_slots_sum (m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) :
    (∑ s : Finset (Fin m), A.compContinuousLinearMap (seeleyTensorSlot s)) = A := by
  ext v
  simp only [ContinuousMultilinearMap.sum_apply,ContinuousMultilinearMap.compContinuousLinearMap_apply]
  have h := A.toMultilinearMap.map_add_univ
    (fun i => seeleyNormalProjection (v i)) (fun i => seeleyTangentProjection (v i))
  have he : (fun i => seeleyNormalProjection (v i)) + (fun i => seeleyTangentProjection (v i)) = v := by
    ext i <;> simp [seeleyNormalProjection,seeleyTangentProjection]
  rw [he] at h
  change A v = _ at h
  rw [h]
  apply Finset.sum_congr rfl
  intro s hs
  change A (fun i => seeleyTensorSlot s i (v i)) =
    A (s.piecewise (fun i => seeleyNormalProjection (v i)) (fun i => seeleyTangentProjection (v i)))
  apply congrArg A
  funext i
  by_cases hi : i ∈ s <;> simp [seeleyTensorSlot,Finset.piecewise,hi]

theorem seeley_tensor_summable (m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) :
    Summable (fun k : ℕ => seeleyCoeff k • A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)) := by
  apply ((seeley_coeff_weighted_summable m).mul_right ‖A‖).of_norm_bounded
  intro k
  rw [norm_smul (seeleyCoeff k) (A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)),Real.norm_eq_abs]
  calc
    _ ≤ |seeleyCoeff k| * (‖A‖ * (2 : ℝ)^(k*m)) :=
      mul_le_mul_of_nonneg_left (seeley_reflection_multilinear_bound k m A) (abs_nonneg _)
    _ = _ := by ring

set_option maxHeartbeats 800000 in
/-- The coefficient moments reproduce the entire derivative tensor, including
every mixture of normal and tangential directions. -/
theorem seeley_tensor_reproduction (m : ℕ)
    (A : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E) :
    (∑' k : ℕ, seeleyCoeff k • A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)) = A := by
  have hex : (fun k : ℕ => seeleyCoeff k • A.compContinuousLinearMap (fun _ => seeleyReflection (X := X) k)) =
      (fun k : ℕ => ∑ s : Finset (Fin m), (seeleyCoeff k * seeleyNode k ^ s.card) •
        A.compContinuousLinearMap (seeleyTensorSlot s)) := by
    funext k
    rw [seeley_tensor_expansion k m A,Finset.smul_sum]
    simp only [smul_smul]
  rw [hex]
  rw [Summable.tsum_finsetSum (fun s _ => (seeley_moment_summable s.card).smul_const
    (A.compContinuousLinearMap (seeleyTensorSlot s)))]
  calc
    _ = ∑ s : Finset (Fin m), A.compContinuousLinearMap (seeleyTensorSlot s) := by
      apply Finset.sum_congr rfl
      intro s hs
      rw [(seeley_moment_summable s.card).tsum_smul_const,seeley_moment,one_smul]
    _ = A := seeley_tensor_slots_sum m A

end EllipticSquareFunction
