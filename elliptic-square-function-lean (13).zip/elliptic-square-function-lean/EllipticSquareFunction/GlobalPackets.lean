import EllipticSquareFunction.GlobalAssembly

/-! # Whole-plane finite packet estimate

This removes the spatial-position bound in corrected (4.14). The fixed
discrete setup must still have enough position, observation, and frequency
margin. These explicit geometric hypotheses are not new analytic inputs.
-/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The spatially global, one-profile assertion of Proposition 2, with its
fixed-setup margins explicit and no restriction on packet positions.
Constants are chosen before the loss parameters, scale, and finite array. -/
theorem global_single_profile_packets {ι : Type*}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F)
    (hQ₂ : 3≤S.C₂) (M : ℝ) (hM : 2<M) :
    ∃ A : ℝ, 1≤A ∧ (A+1≤S.C₁ →
      ∃ Z : ℝ, 0<Z ∧ (F+Z≤S.frequencyBound →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
        ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
          let N : ℝ := (2:ℝ)^j
          ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
            (ν : ι → Plane) (v : ι → IntPlane → Plane),
          (∀ i ∈ s, ‖ν i‖≤F) →
          (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
          (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
          l3 (fun y => ∑ i ∈ s, ∑ p ∈ pbox i,
            a i p*freePacket S.φ b N (ν i) (v i p) y)
            (volume.restrict (timeSlab (N^2))) ≤
          ENNReal.ofReal (C*packetConstant P κ η (N^2))*
            densityCubeRoot (spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
              (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M) (N^2))) := by
  classical
  obtain ⟨A,Cf,hA,hCf,hfar⟩ := far_packets_outside_ball hphase b hb hbs hc hσ hF
    (by norm_num : (0:ℝ)≤2) M
  refine ⟨A,hA,?_⟩
  intro hA₁
  obtain ⟨Z,hZ,hlocal⟩ := corrected_equation_4_14_centered (ι := ι)
    S hphase hinput b hb hbs hc hσ hF (by linarith : 0≤A)
      (by norm_num : (0:ℝ)≤2) hA₁ (by linarith) M hM
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  obtain ⟨Cn,hCn,hlocal⟩ := hlocal hFZ
  let J : ℝ := ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ)
  have hJ : 0≤J := Real.rpow_nonneg (Nat.cast_nonneg _) _
  obtain ⟨C,hC,hcoeff⟩ := global_packet_coefficient_bound hCn.le hCf.le hJ
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hlocal⟩ := hlocal κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N s pbox a ν v hν hsep hpos
  have hN : 1≤N := one_le_pow₀ (by norm_num)
  have hN0 : N≠0 := ne_of_gt (by linarith)
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩
    exact hφ
  have hnear (m : IntPlane) :
      LocalProfileEstimate S.φ b
        (s.sigma (fun i => (pbox i).filter (fun p => ‖v i p-spatialTileCenter N m‖≤A*N^2)))
        (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
        N M P κ η Cn (spatialTile N m) := by
    apply hlocal j hj s
      (fun i => (pbox i).filter (fun p => ‖v i p-spatialTileCenter N m‖≤A*N^2))
      a ν v (spatialTileCenter N m) hν hsep
    · intro i hi p hp q hq hpq
      exact hpos i hi p (Finset.mem_filter.mp hp).1 q (Finset.mem_filter.mp hq).1 hpq
    · intro i hi p hp
      exact (Finset.mem_filter.mp hp).2
    · intro x hx
      exact Metric.mem_closedBall.mpr (by
        simpa only [dist_eq_norm] using spatialTile_radius hN0 m hx)
  have hf (m : IntPlane) (y : Space) (hy : y ∈ localSlab (spatialTile N m) (N^2)) :=
    hfar N hN s pbox a ν v hν hsep hpos (spatialTileCenter N m) y
      (spatialTile_radius hN0 m hy.1)
      (by rw [abs_of_nonneg hy.2.1]; exact hy.2.2)
  have hcubic := global_packets_cubic_of_local_far S.φ hφ.continuous b hb.continuous hbs
    s pbox a ν v hN0 M A P κ η Cn Cf hCf.le hnear hf
  have hK : 0≤packetConstant P κ η (N^2) := packetConstant_nonneg_global (by linarith) κ η
  have hco := global_packet_coefficient_bound_ennreal hCn.le hCf.le hJ hC.le hK
    (hcoeff P κ η N hP hκ.le hη.le hN)
  have hh := hcubic.trans (mul_le_mul_right' hco _)
  have hn := l3_le_of_cubic_lintegral _ _ _ _ hh
  have he : densityCubeRoot (spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
      (fun ip => velocity S.φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M) (N^2) =
      (∫⁻ y in timeSlab (N^2), ENNReal.ofReal ((spatialDensity (s.sigma pbox)
        (fun ip => a ip.1 ip.2) (fun ip => velocity S.φ (ν ip.1))
        (fun ip => v ip.1 ip.2) N M y)^(3/2:ℝ)))^(1/3:ℝ) := by
    unfold densityCubeRoot
    congr 1
    apply lintegral_congr
    intro y
    exact ENNReal.ofReal_rpow_of_nonneg (spatialDensity_nonneg_global ..) (by norm_num)
  rw [he]
  exact hn

end EllipticSquareFunction
