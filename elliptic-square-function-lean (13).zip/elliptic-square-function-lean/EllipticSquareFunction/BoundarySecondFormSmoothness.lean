import EllipticSquareFunction.BoundaryNormalValuedForm

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- Each scalar coordinate of the second form is jointly smooth in a
boundary chart, for a smooth local normal field and smooth vector fields.
All derivatives are within the chart target, so boundary points are included. -/
theorem boundary_second_form_coordinate_smooth {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f) (x : M)
    {N : Plane → EuclideanThree} {v w : Plane → Plane}
    (hN : ContDiffOn ℝ (⊤ : ℕ∞) N (extChartAt (𝓡∂ 2) x).target)
    (hv : ContDiffOn ℝ (⊤ : ℕ∞) v (extChartAt (𝓡∂ 2) x).target)
    (hw : ContDiffOn ℝ (⊤ : ℕ∞) w (extChartAt (𝓡∂ 2) x).target) :
    ContDiffOn ℝ (⊤ : ℕ∞)
      (fun p => @inner ℝ EuclideanThree _ (N p)
        (fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x)
          (extChartAt (𝓡∂ 2) x).target) (extChartAt (𝓡∂ 2) x).target p (v p) (w p)))
      (extChartAt (𝓡∂ 2) x).target := by
  have hs := uniqueDiffOn_extChartAt_target (I := 𝓡∂ 2) x
  have hd := (model_surface_param_smooth (𝓡∂ 2) hf x).fderivWithin hs (m := (⊤ : ℕ∞)) (by simp)
  have hdd := hd.fderivWithin hs (m := (⊤ : ℕ∞)) (by simp)
  exact hN.inner ℝ ((hdd.clm_apply hv).clm_apply hw)

/-- The normal-valued expression is smooth as well; its unit-normal choice
independence is supplied by boundary_normal_valued_form_normal_independent. -/
theorem boundary_normal_form_coordinate_smooth {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f) (x : M)
    {N : Plane → EuclideanThree} {v w : Plane → Plane}
    (hN : ContDiffOn ℝ (⊤ : ℕ∞) N (extChartAt (𝓡∂ 2) x).target)
    (hv : ContDiffOn ℝ (⊤ : ℕ∞) v (extChartAt (𝓡∂ 2) x).target)
    (hw : ContDiffOn ℝ (⊤ : ℕ∞) w (extChartAt (𝓡∂ 2) x).target) :
    ContDiffOn ℝ (⊤ : ℕ∞)
      (fun p => (@inner ℝ EuclideanThree _ (N p)
        (fderivWithin ℝ (fderivWithin ℝ (modelSurfaceParam (𝓡∂ 2) f x)
          (extChartAt (𝓡∂ 2) x).target) (extChartAt (𝓡∂ 2) x).target p (v p) (w p))) • N p)
      (extChartAt (𝓡∂ 2) x).target :=
  (boundary_second_form_coordinate_smooth hf x hN hv hw).smul hN

end EllipticSquareFunction
