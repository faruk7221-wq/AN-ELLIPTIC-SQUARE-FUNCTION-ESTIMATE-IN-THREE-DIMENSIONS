import EllipticSquareFunction.PacketDecay
import EllipticSquareFunction.SeparatedPositions
import EllipticSquareFunction.ProfileLabelCounting

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

/-- Weighted Cauchy--Schwarz in the form used for the far packets. -/
theorem norm_sum_decay_sq {ι : Type*} (s : Finset ι) (a B : ι → ℂ)
    (r : ι → ℝ) {C L M : ℝ} (hr : ∀ i ∈ s, 0<r i)
    (hB : ∀ i ∈ s, ‖B i‖ ≤ C*(r i)^(-L)) :
    ‖∑ i ∈ s, a i*B i‖^2 ≤
      C^2 * (∑ i ∈ s, ‖a i‖^2*(r i)^(-M)) * (∑ i ∈ s, (r i)^(M-2*L)) := by
  let f := fun i => ‖a i‖*(r i)^(-M/2)
  let g := fun i => (r i)^(M/2-L)
  have hp (i : ι) (hi : i∈s) : (r i)^(-L) = (r i)^(-M/2)*(r i)^(M/2-L) := by
    rw [← Real.rpow_add (hr i hi)]; congr 1; ring
  have hn : ‖∑ i ∈ s, a i*B i‖ ≤ C*∑ i ∈ s, f i*g i := by
    calc
      _ ≤ ∑ i ∈ s, ‖a i‖*‖B i‖ := by simpa only [norm_mul] using norm_sum_le s (fun i => a i*B i)
      _ ≤ ∑ i ∈ s, ‖a i‖*(C*(r i)^(-L)) :=
        Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_left (hB i hi) (norm_nonneg _))
      _ = _ := by
        rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro i hi
        rw [hp i hi]; dsimp [f,g]; ring
  have hpow (x e : ℝ) (hx : 0≤x) : (x^e)^2=x^(2*e) := by
    rw [← Real.rpow_natCast,← Real.rpow_mul hx]; congr 1; ring
  have hf : (∑ i ∈ s, (f i)^2) = ∑ i ∈ s, ‖a i‖^2*(r i)^(-M) := by
    apply Finset.sum_congr rfl; intro i hi
    dsimp [f]; rw [mul_pow,hpow _ _ (hr i hi).le]
    congr 2; ring
  have hg : (∑ i ∈ s, (g i)^2) = ∑ i ∈ s, (r i)^(M-2*L) := by
    apply Finset.sum_congr rfl; intro i hi
    dsimp [g]; rw [hpow _ _ (hr i hi).le]; congr 1; ring
  have hcs := Finset.sum_mul_sq_le_sq_mul_sq s f g
  rw [hf,hg] at hcs
  calc
    _ ≤ (C*∑ i ∈ s, f i*g i)^2 := pow_le_pow_left₀ (norm_nonneg _) hn 2
    _ = C^2*(∑ i ∈ s, f i*g i)^2 := mul_pow _ _ _
    _ ≤ C^2*((∑ i ∈ s, ‖a i‖^2*(r i)^(-M))*(∑ i ∈ s, (r i)^(M-2*L))) :=
      mul_le_mul_of_nonneg_left hcs (sq_nonneg _)
    _ = _ := by ring

/-- The finite separated tail after normalizing positions by the packet scale. -/
theorem separated_scaled_plane_far_sum {ι : Type*} (s : Finset ι) (v : ι → Plane)
    {N c L : ℝ} (hN : 0<N) (hc : 0<c) (hL : 3≤L)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i≠j → c*N≤‖v i-v j‖) (u : Plane)
    (hfar : ∀ i ∈ s, N≤‖N⁻¹ • (u-v i)‖) :
    (∑ i ∈ s, bracket (N⁻¹ • (u-v i))^(-L)) ≤
      (1+N)^(-(L-3))*separatedPlaneSumConstant c 3 := by
  classical
  have hs : ∀ i ∈ s, ∀ j ∈ s, i≠j → c≤‖N⁻¹ • v i-N⁻¹ • v j‖ := by
    intro i hi j hj hij
    rw [← smul_sub,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN)]
    have hh := mul_le_mul_of_nonneg_left (hsep i hi j hj hij) (inv_pos.mpr hN).le
    have he : N⁻¹*(c*N)=c := by field_simp
    rwa [he] at hh
  have hf : s.filter (fun i => N≤‖N⁻¹ • u-N⁻¹ • v i‖)=s := by
    apply Finset.filter_eq_self.mpr
    intro i hi
    simpa only [smul_sub] using hfar i hi
  have hh := separated_plane_weight_tail s (fun i => N⁻¹ • v i) hc (by norm_num : (2:ℝ)<3)
    hL hN.le hs (N⁻¹ • u)
  rw [hf] at hh
  simpa only [smul_sub] using hh

theorem far_tail_scale_bound {N E : ℝ} (hN : 1≤N) (hE : 2≤E) :
    N^2*(1+N)^(-E) ≤ 1 := by
  have hN0 : 0<N := by linarith
  have hh : (1+N)^(-E) ≤ (N^2)⁻¹ := by
    apply (Real.rpow_le_rpow_of_exponent_le (by linarith : 1≤1+N)
      (by linarith : -E≤(-2:ℝ))).trans
    simpa only [Real.rpow_neg hN0.le,Real.rpow_two] using
      Real.rpow_le_rpow_of_nonpos hN0 (by linarith : N≤1+N) (by norm_num : (-2:ℝ)≤0)
  calc
    _ ≤ N^2*(N^2)⁻¹ := mul_le_mul_of_nonneg_left hh (sq_nonneg _)
    _ = 1 := mul_inv_cancel₀ (pow_ne_zero _ hN0.ne')

/-- Spatial tails absorb the frequency count uniformly in the scale. -/
theorem separated_far_array_weight_sum {ι : Type*} (s : Finset ι)
    (pbox : ι → Finset IntPlane) (ν V : ι → Plane) (v : ι → IntPlane → Plane)
    {N c σ F L : ℝ} (hN : 1≤N) (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hL : 5≤L)
    (hν : ∀ i ∈ s, ‖ν i‖≤F)
    (hfreq : ∀ i ∈ s, ∀ j ∈ s, i≠j → σ/N≤‖ν i-ν j‖)
    (hpos : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (y : Space) (hfar : ∀ i ∈ s, ∀ p ∈ pbox i,
      N≤‖N⁻¹ • (y.1-v i p+y.2 • V i)‖) :
    (∑ i ∈ s, ∑ p ∈ pbox i, bracket (N⁻¹ • (y.1-v i p+y.2 • V i))^(-L)) ≤
      (2*((5/σ)*F+4)+3)^2*separatedPlaneSumConstant c 3 := by
  have hN0 : 0<N := by linarith
  let T := (1+N)^(-(L-3))
  let J := (2*((5/σ)*F+4)+3)^2
  let S := separatedPlaneSumConstant c 3
  have hS : 0≤S := separatedPlaneSumConstant_nonneg hc (by norm_num)
  have hT : 0≤T := by dsimp [T]; positivity
  have he (i : ι) (p : IntPlane) : y.1+y.2 • V i-v i p=y.1-v i p+y.2 • V i := by abel
  have hp (i : ι) (hi : i∈s) :
      (∑ p ∈ pbox i, bracket (N⁻¹ • (y.1-v i p+y.2 • V i))^(-L)) ≤ T*S := by
    have hh := separated_scaled_plane_far_sum (pbox i) (v i) hN0 hc (by linarith : 3≤L)
      (hpos i hi) (y.1+y.2 • V i) (by simpa only [he] using hfar i hi)
    simpa only [he] using hh
  have hcount := separated_frequency_card_bound s ν hN hσ hF hν hfreq
  have hscale := far_tail_scale_bound hN (by linarith : 2≤L-3)
  calc
    _ ≤ ∑ i ∈ s, T*S := Finset.sum_le_sum hp
    _ = (s.card : ℝ)*(T*S) := by simp
    _ ≤ (J*N^2)*(T*S) := mul_le_mul_of_nonneg_right hcount (mul_nonneg hT hS)
    _ = (J*S)*(N^2*T) := by ring
    _ ≤ (J*S)*1 := mul_le_mul_of_nonneg_left hscale (mul_nonneg (sq_nonneg _) hS)
    _ = _ := mul_one _

/-- The far-packet sum is pointwise controlled by its own square-function
density, uniformly over all finite separated arrays. -/
theorem far_packets_pointwise {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (M : ℝ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ {ι : Type*} (s : Finset ι)
      (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
      (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖≤F) →
      (∀ i ∈ s, ∀ j ∈ s, i≠j → σ/N≤‖ν i-ν j‖) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
      ∀ y : Space, |y.2|≤N^2 →
      (∀ i ∈ s, ∀ p ∈ pbox i, N≤‖N⁻¹ • (y.1-v i p+y.2 • velocity φ (ν i))‖) →
      ‖∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket φ b N (ν i) (v i p) y‖^2 ≤
        C*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y := by
  let L : ℕ := ⌈(M+5)/2⌉₊
  have hL : 5≤2*(L:ℝ)-M := by have := Nat.le_ceil ((M+5)/2); dsimp [L]; linarith
  obtain ⟨B,hB,hbound⟩ := equation_4_15 hphase b hb hbs L
  let K := (2*((5/σ)*F+4)+3)^2*separatedPlaneSumConstant c 3
  have hK : 0≤K := mul_nonneg (sq_nonneg _) (separatedPlaneSumConstant_nonneg hc (by norm_num))
  refine ⟨B^2*K+1,by positivity,?_⟩
  intro N hN ι s pbox a ν v hν hfreq hpos y ht hfar
  let r := fun ip : (i : ι) × IntPlane => bracket (N⁻¹ • (y.1-v ip.1 ip.2+y.2 • velocity φ (ν ip.1)))
  have hw := separated_far_array_weight_sum s pbox ν (fun i => velocity φ (ν i)) v
    hN hc hσ hF hL hν hfreq hpos y hfar
  have hn := norm_sum_decay_sq (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => freePacket φ b N (ν ip.1) (v ip.1 ip.2) y) r
    (M := M) (fun _ _ => bracket_pos _) (fun ip hip => hbound N hN _ _ y ht)
  have he : (∑ ip ∈ s.sigma pbox, (r ip)^(M-2*(L:ℝ))) =
      ∑ i ∈ s, ∑ p ∈ pbox i, bracket (N⁻¹ • (y.1-v i p+y.2 • velocity φ (ν i)))^(-(2*(L:ℝ)-M)) := by
    rw [Finset.sum_sigma]; dsimp [r]; congr 1; funext i; congr 1; funext p; congr 1; ring
  rw [he] at hn
  have hD : 0≤spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
      (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y := by
    unfold spatialDensity
    exact Finset.sum_nonneg (fun ip _ => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  have hh := mul_le_mul_of_nonneg_left hw (mul_nonneg (sq_nonneg B) hD)
  have hn' : ‖∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket φ b N (ν i) (v i p) y‖^2 ≤
      B^2*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y*K := by
    apply le_trans ?_ hh
    simpa only [Finset.sum_sigma,spatialDensity,spatialWeight,r] using hn
  nlinarith

/-- A packet center outside a fixed enlarged tile has normalized displacement
at least N throughout that tile and the full time slab. -/
theorem far_packet_displacement {N Q H : ℝ} (hN : 0<N) (hH : 0≤H)
    (m x v V : Plane) (t : ℝ) (hx : ‖x-m‖≤Q*N^2) (hV : ‖V‖≤H)
    (ht : |t|≤N^2) (hv : (Q+H+1)*N^2≤‖v-m‖) :
    N≤‖N⁻¹ • (x-v+t • V)‖ := by
  have htri : ‖v-m‖ ≤ ‖x-v+t • V‖+‖x-m‖+‖t • V‖ := by
    calc
      _ = ‖(-(x-v+t • V)+(x-m))+t • V‖ := by congr 1; module
      _ ≤ ‖-(x-v+t • V)+(x-m)‖+‖t • V‖ := norm_add_le _ _
      _ ≤ (‖x-v+t • V‖+‖x-m‖)+‖t • V‖ := by
        simpa only [norm_neg] using add_le_add_right (norm_add_le (-(x-v+t • V)) (x-m)) ‖t • V‖
  have htV : ‖t • V‖≤N^2*H := by
    rw [norm_smul,Real.norm_eq_abs]
    exact mul_le_mul ht hV (norm_nonneg _) (sq_nonneg _)
  have hlow : N^2≤‖x-v+t • V‖ := by nlinarith
  rw [norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN)]
  have hh := mul_le_mul_of_nonneg_left hlow (inv_pos.mpr hN).le
  convert hh using 1 <;> field_simp <;> ring

theorem continuedPhase_velocity_on_ball {φ : Phase} (hphase : ContinuedPhase φ)
    {F : ℝ} (hF : 0≤F) : ∃ H : ℝ, 0≤H ∧ ∀ ν : Plane, ‖ν‖≤F → ‖velocity φ ν‖≤H := by
  obtain ⟨C,hC,hbound⟩ := continuedPhase_velocity_bound hphase
  refine ⟨C*F+‖velocity φ 0‖,by positivity,?_⟩
  intro ν hν
  calc
    _ = ‖(velocity φ ν-velocity φ 0)+velocity φ 0‖ := by rw [sub_add_cancel]
    _ ≤ ‖velocity φ ν-velocity φ 0‖+‖velocity φ 0‖ := norm_add_le _ _
    _ ≤ C*F+‖velocity φ 0‖ := by
      have hh := hbound 0 ν
      rw [sub_zero] at hh
      exact add_le_add_right (hh.trans (mul_le_mul_of_nonneg_left hν hC)) _

/-- The geometric far part in Section 4.3, with the density of the complete
array on the right. Positions have no global boundedness restriction. -/
theorem far_packets_outside_ball {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    {c σ F Q : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hQ : 0≤Q) (M : ℝ) :
    ∃ A C : ℝ, 1≤A ∧ 0<C ∧ ∀ N : ℝ, 1≤N → ∀ {ι : Type*} (s : Finset ι)
      (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
      (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖≤F) →
      (∀ i ∈ s, ∀ j ∈ s, i≠j → σ/N≤‖ν i-ν j‖) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
      ∀ (m : Plane) (y : Space), ‖y.1-m‖≤Q*N^2 → |y.2|≤N^2 →
      ‖∑ i ∈ s, ∑ p ∈ (pbox i).filter (fun p => A*N^2<‖v i p-m‖),
        a i p*freePacket φ b N (ν i) (v i p) y‖^2 ≤
        C*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y := by
  classical
  obtain ⟨H,hH,hvel⟩ := continuedPhase_velocity_on_ball hphase hF
  obtain ⟨C,hC,hbound⟩ := far_packets_pointwise hphase b hb hbs hc hσ hF M
  refine ⟨Q+H+1,C,by linarith,hC,?_⟩
  intro N hN ι s pbox a ν v hν hfreq hpos m y hx ht
  let q := fun i => (pbox i).filter (fun p => (Q+H+1)*N^2<‖v i p-m‖)
  have hh := hbound N hN s q a ν v hν hfreq
    (fun i hi p hp q hq hpq => hpos i hi p (Finset.mem_filter.mp hp).1 q (Finset.mem_filter.mp hq).1 hpq)
    y ht (by
      intro i hi p hp
      exact far_packet_displacement (by linarith) hH m y.1 (v i p) (velocity φ (ν i)) y.2
        hx (hvel _ (hν i hi)) ht (Finset.mem_filter.mp hp).2.le)
  apply hh.trans
  apply mul_le_mul_of_nonneg_left _ hC.le
  unfold spatialDensity
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro ip hip
    rcases Finset.mem_sigma.mp hip with ⟨hi,hp⟩
    exact Finset.mem_sigma.mpr ⟨hi,(Finset.mem_filter.mp hp).1⟩
  · intro ip _ _
    exact mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..)

end EllipticSquareFunction
