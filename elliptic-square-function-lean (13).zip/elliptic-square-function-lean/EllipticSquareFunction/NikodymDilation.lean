import EllipticSquareFunction.TubeMeasureDilation

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Every dilated tube average is an admissible term in the rescaled
Nikodym supremum. The tube length remains fixed outside that supremum. -/
theorem nikodym_le_dilated {c : ℝ} (hc : 0<c) (τ L : ℝ) (h : Space → ℝ) (x : Space) :
    nikodym τ L (fun y => h (c • y)) x ≤ nikodym τ (c*L) h (c • x) := by
  unfold nikodym
  apply iSup_le
  intro a
  apply iSup_le
  intro b
  apply iSup_le
  intro hab
  apply iSup_le
  intro hx
  have hlen : euclideanLength (c • b-c • a)=c*L := by
    rw [← smul_sub,euclideanLength_smul,abs_of_pos hc,hab]
  have hrad : τ*(c*L)=c*(τ*L) := by ring
  have hmem : c • x∈geometricTube (c • a) (c • b) (τ*(c*L)) := by
    rw [hrad]
    exact (geometricTube_smul hc a b x (τ*L)).mpr hx
  have havg : tubeAverage h (geometricTube (c • a) (c • b) (τ*(c*L)))=
      tubeAverage (fun y => h (c • y)) (geometricTube a b (τ*L)) := by
    rw [hrad,geometricTube_eq_smul hc,tubeAverage_smul hc]
  rw [← havg]
  exact le_iSup_of_le (c • a) (le_iSup_of_le (c • b)
    (le_iSup_of_le hlen (le_iSup_of_le hmem le_rfl)))

/-- Exact covariance of the actual Nikodym maximal operator under positive
dilations, with both directions of the uncountable supremum checked. -/
theorem nikodym_smul {c : ℝ} (hc : 0<c) (τ L : ℝ) (h : Space → ℝ) (x : Space) :
    nikodym τ (c*L) h (c • x)=nikodym τ L (fun y => h (c • y)) x := by
  apply le_antisymm
  · have hh := nikodym_le_dilated (inv_pos.mpr hc) τ (c*L)
      (fun y => h (c • y)) (c • x)
    simpa only [inv_mul_cancel_left₀ hc.ne',inv_smul_smul₀ hc.ne',smul_inv_smul₀ hc.ne'] using hh
  · exact nikodym_le_dilated hc τ L h x

/-- The unit-length formulation is sufficient at every positive length. -/
theorem nikodym_unit_rescale {L : ℝ} (hL : 0<L) (τ : ℝ) (h : Space → ℝ) (x : Space) :
    nikodym τ L h (L • x)=nikodym τ 1 (fun y => h (L • y)) x := by
  simpa only [mul_one] using nikodym_smul hL τ 1 h x

end EllipticSquareFunction
