import Mathlib

/-!
# Quantitative losses

This file proves the parameter choice and logarithm absorption used after
(7.5), with no assumptions about the rate of growth of the external constants.
-/

noncomputable section
namespace EllipticSquareFunction

def lossExponent (κ η γ : ℝ) : ℝ := (10 * κ + η) / 6 + γ / 4

def packetConstant (P κ η R : ℝ) : ℝ :=
  P ^ (1 / 3 : ℝ) * R ^ ((10 * κ + η) / 6) * Real.log (2 + R) ^ (2 / 3 : ℝ)

def totalConstant (P M κ η γ R : ℝ) : ℝ :=
  P ^ (1 / 3 : ℝ) * M ^ (1 / 2 : ℝ) *
    R ^ lossExponent κ η γ * Real.log (2 + R) ^ (2 / 3 : ℝ)

theorem choose_loss_parameters {ε : ℝ} (hε : 0 < ε) :
    ∃ κ η γ : ℝ, 0 < κ ∧ κ < 1 / 10 ∧ 0 < η ∧ η ≤ 1 ∧
      0 < γ ∧ γ ≤ 1 ∧ lossExponent κ η γ ≤ ε / 2 := by
  let t := min (ε / 16) (1 / 100)
  have ht : 0 < t := lt_min (by positivity) (by norm_num)
  have htε : t ≤ ε / 16 := min_le_left _ _
  have ht1 : t ≤ 1 / 100 := min_le_right _ _
  refine ⟨t, t, t, ht, by linarith, ht, by linarith, ht, by linarith, ?_⟩
  unfold lossExponent
  linarith

theorem two_thirds_power_le_one_add {x : ℝ} (hx : 0 ≤ x) :
    x ^ (2 / 3 : ℝ) ≤ 1 + x := by
  by_cases h : x ≤ 1
  · exact (Real.rpow_le_one hx h (by norm_num)).trans (by linarith)
  · have h' : 1 ≤ x := le_of_lt (lt_of_not_ge h)
    have := Real.rpow_le_rpow_of_exponent_le h' (by norm_num : (2 / 3 : ℝ) ≤ 1)
    rw [Real.rpow_one] at this
    linarith

/-- An explicit, nonoptimal constant for absorbing the `log^(2/3)` loss. -/
theorem log_loss_bound {a R : ℝ} (ha : 0 < a) (hR : 2 ≤ R) :
    Real.log (2 + R) ^ (2 / 3 : ℝ) ≤ (1 + 2 ^ a / a) * R ^ a := by
  have hR0 : 0 ≤ R := by linarith
  have hR1 : 1 ≤ R := by linarith
  have hlog : 0 ≤ Real.log (2 + R) := Real.log_nonneg (by linarith)
  have h1 : Real.log (2 + R) ≤ (2 + R) ^ a / a :=
    Real.log_le_rpow_div (by linarith) ha
  have h2 : (2 + R) ^ a / a ≤ (2 * R) ^ a / a := by
    exact div_le_div_of_nonneg_right
      (Real.rpow_le_rpow (by linarith) (by linarith) ha.le) ha.le
  have h3 : 1 ≤ R ^ a := Real.one_le_rpow hR1 ha.le
  calc
    _ ≤ 1 + Real.log (2 + R) := two_thirds_power_le_one_add hlog
    _ ≤ 1 + (2 * R) ^ a / a := add_le_add_left (h1.trans h2) _
    _ ≤ (1 + 2 ^ a / a) * R ^ a := by
      rw [Real.mul_rpow (by norm_num : (0 : ℝ) ≤ 2) hR0]
      calc
        _ = 1 + (2 ^ a / a) * R ^ a := by ring
        _ ≤ R ^ a + (2 ^ a / a) * R ^ a := add_le_add_right h3 _
        _ = _ := by ring

/-- The last step of the paper: all parameter constants are fixed before `R`
varies, and no polynomial bound on their dependence is needed. -/
theorem absorb_totalConstant {P M κ η γ ε : ℝ}
    (hP : 0 ≤ P) (hM : 0 ≤ M) (hε : 0 < ε)
    (hexp : lossExponent κ η γ ≤ ε / 2) :
    ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      totalConstant P M κ η γ R ≤ C * R ^ ε := by
  let B := P ^ (1 / 3 : ℝ) * M ^ (1 / 2 : ℝ)
  let L := 1 + 2 ^ (ε / 2) / (ε / 2)
  have hB : 0 ≤ B := mul_nonneg (Real.rpow_nonneg hP _) (Real.rpow_nonneg hM _)
  have hL : 0 < L := by dsimp [L]; positivity
  refine ⟨B * L + 1, by positivity, ?_⟩
  intro R hR
  have hR0 : 0 < R := by linarith
  have hrpow : R ^ lossExponent κ η γ ≤ R ^ (ε / 2) :=
    Real.rpow_le_rpow_of_exponent_le (by linarith) hexp
  have hlog := log_loss_bound (by linarith : 0 < ε / 2) hR
  have hmain : totalConstant P M κ η γ R ≤ B * L * R ^ ε := by
    calc
      _ = B * (R ^ lossExponent κ η γ * Real.log (2 + R) ^ (2 / 3 : ℝ)) := by
        unfold totalConstant B
        ring
      _ ≤ B * (R ^ (ε / 2) * (L * R ^ (ε / 2))) := by
        apply mul_le_mul_of_nonneg_left _ hB
        exact mul_le_mul hrpow hlog
          (Real.rpow_nonneg (Real.log_nonneg (by linarith)) _)
          (Real.rpow_nonneg hR0.le _)
      _ = B * L * R ^ ε := by
        rw [show R ^ (ε / 2) * (L * R ^ (ε / 2)) =
          L * (R ^ (ε / 2) * R ^ (ε / 2)) by ring,
          ← Real.rpow_add hR0]
        rw [show ε / 2 + ε / 2 = ε by ring]
        ring
  exact hmain.trans (by nlinarith [Real.rpow_nonneg hR0.le ε])

/-- The exact cube of the packet constant at the parabolic scale. -/
theorem packetConstant_cube {P N κ η : ℝ} (hP : 0 ≤ P) (hN : 0 ≤ N) :
    packetConstant P κ η (N^2) ^ 3 =
      P * N ^ (10*κ+η) * Real.log (2+N^2)^2 := by
  have hl : 0 ≤ Real.log (2+N^2) := Real.log_nonneg (by nlinarith [sq_nonneg N])
  unfold packetConstant
  rw [mul_pow, mul_pow, ← Real.rpow_mul_natCast hP,
    ← Real.rpow_mul_natCast (sq_nonneg N), ← Real.rpow_mul_natCast hl]
  norm_num
  rw [show (10*κ+η)/6*(3 : ℝ) = (10*κ+η)/2 by ring]
  rw [← Real.rpow_natCast_mul hN 2]
  norm_num
  rw [show (2 : ℝ) * ((10*κ+η)/2) = 10*κ+η by ring]
  simp

def localLossAbsorptionConstant : ℝ := 1 + (Real.log 3)^(-2 : ℝ)

theorem localLossAbsorptionConstant_pos : 0 < localLossAbsorptionConstant := by
  unfold localLossAbsorptionConstant
  have h := Real.log_pos (by norm_num : (1 : ℝ) < 3)
  positivity

/-- Both the external logarithm and the additive tail term fit the exact
packet constant with one parameter-independent multiplicative constant. -/
theorem local_loss_absorption {P N κ η : ℝ} (hP : 1 ≤ P) (hN : 1 ≤ N)
    (hκ : 0 ≤ κ) (hη : 0 ≤ η) :
    P*N^(10*κ+η)*Real.log (2+N)^2 + 1 ≤
      localLossAbsorptionConstant * packetConstant P κ η (N^2)^3 := by
  have hN0 : 0 ≤ N := by linarith
  have hpow : 1 ≤ N^(10*κ+η) := Real.one_le_rpow hN (by positivity)
  have hPN : 1 ≤ P*N^(10*κ+η) := by nlinarith
  have hlog0 : 0 < Real.log 3 := Real.log_pos (by norm_num)
  have hlog : Real.log 3 ≤ Real.log (2+N^2) :=
    Real.log_le_log (by norm_num) (by nlinarith)
  have hlogN : Real.log (2+N) ≤ Real.log (2+N^2) :=
    Real.log_le_log (by linarith) (by nlinarith)
  have hl0 : 0 ≤ Real.log (2+N) := Real.log_nonneg (by linarith)
  have hw : P*N^(10*κ+η)*Real.log (2+N)^2 ≤
      P*N^(10*κ+η)*Real.log (2+N^2)^2 :=
    mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hl0 hlogN 2) (by positivity)
  have hlower : (Real.log 3)^2 ≤ P*N^(10*κ+η)*Real.log (2+N^2)^2 := by
    calc
      _ ≤ Real.log (2+N^2)^2 := pow_le_pow_left₀ hlog0.le hlog 2
      _ ≤ _ := le_mul_of_one_le_left (sq_nonneg _) hPN
  have hinv : 0 < (Real.log 3)^(-2 : ℝ) := Real.rpow_pos_of_pos hlog0 _
  have he : (Real.log 3)^(-2 : ℝ) * (Real.log 3)^2 = 1 := by
    rw [show (-2 : ℝ) = -(2 : ℝ) by norm_num, Real.rpow_neg hlog0.le]
    norm_num [Real.rpow_two]
  have hone := mul_le_mul_of_nonneg_left hlower hinv.le
  rw [he] at hone
  rw [packetConstant_cube (by linarith) hN0]
  unfold localLossAbsorptionConstant
  nlinarith

end EllipticSquareFunction
