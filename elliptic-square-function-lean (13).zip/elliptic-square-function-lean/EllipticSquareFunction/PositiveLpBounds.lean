import EllipticSquareFunction.NikodymNormDilation

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- L3 Minkowski for nonnegative extended-real functions. -/
theorem positive_l3_add_le {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (f g : α → ℝ≥0∞) (hf : AEMeasurable f μ) (hg : AEMeasurable g μ) :
    eLpNorm (fun x => f x+g x) 3 μ ≤ eLpNorm f 3 μ+eLpNorm g 3 μ := by
  simpa only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3:ℝ≥0∞)≠0)
    (by norm_num : (3:ℝ≥0∞)≠⊤),ENNReal.toReal_ofNat,enorm_eq_self,Pi.add_apply] using
    ENNReal.lintegral_Lp_add_le hf hg (by norm_num : (1:ℝ)≤3)

/-- Exact constant multiplication for positive L3 norms, including infinite
values. The multiplier is finite, so no integrability premise is hidden. -/
theorem positive_l3_const_mul {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (f : α → ℝ≥0∞) (C : ℝ≥0∞) (hC : C≠⊤) :
    eLpNorm (fun x => C*f x) 3 μ=C*eLpNorm f 3 μ := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3:ℝ≥0∞)≠0)
    (by norm_num : (3:ℝ≥0∞)≠⊤),ENNReal.toReal_ofNat,enorm_eq_self]
  simp_rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0:ℝ)≤3)]
  rw [lintegral_const_mul' _ _ (ENNReal.rpow_ne_top_of_nonneg (by norm_num) hC),
    ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0:ℝ)≤1/3),← ENNReal.rpow_mul]
  norm_num

/-- Finite positive-family L3 triangle inequality. -/
theorem positive_l3_finset_sum_le {α ι : Type*} [MeasurableSpace α]
    (μ : Measure α) (s : Finset ι) (f : ι → α → ℝ≥0∞)
    (hf : ∀ i∈s, Measurable (f i)) :
    eLpNorm (fun x => ∑ i∈s, f i x) 3 μ ≤ ∑ i∈s, eLpNorm (f i) 3 μ := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    simp only [Finset.sum_insert hi]
    exact (positive_l3_add_le μ (f i) (fun x => ∑ j∈s, f j x)
      (hf i (Finset.mem_insert_self ..)).aemeasurable
      (Finset.measurable_sum s (fun j hj => hf j (Finset.mem_insert_of_mem hj))).aemeasurable).trans
      (add_le_add_left (ih (fun j hj => hf j (Finset.mem_insert_of_mem hj))) _)

end EllipticSquareFunction
