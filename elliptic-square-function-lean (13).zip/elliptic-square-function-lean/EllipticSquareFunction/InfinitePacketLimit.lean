import EllipticSquareFunction.RebasedReconstruction
import EllipticSquareFunction.PropositionTwo

noncomputable section
open MeasureTheory Set Filter
open scoped ENNReal BigOperators Topology
namespace EllipticSquareFunction

/-- Fatou's lemma passes a uniform finite-truncation norm bound to a genuine
pointwise convergent series. No norm convergence is presumed. -/
theorem l3_hasSum_bound {ι : Type*} [Countable ι] (μ : Measure Space)
    (f : ι → Space → ℂ) (F : Space → ℂ) (A : ℝ≥0∞)
    (hf : ∀ i, Continuous (f i)) (hs : ∀ y, HasSum (fun i => f i y) (F y))
    (hbound : ∀ q : Finset ι, l3 (fun y => ∑ i ∈ q, f i y) μ ≤ A) :
    l3 F μ ≤ A := by
  classical
  obtain ⟨q,hqmono,hq⟩ := exists_seq_monotone_tendsto_atTop_atTop (Finset ι)
  have hm (n : ℕ) : AEStronglyMeasurable (fun y => ∑ i ∈ q n, f i y) μ :=
    (continuous_finset_sum (q n) (fun i hi => hf i)).aestronglyMeasurable
  have ht : ∀ᵐ y ∂μ, Tendsto (fun n => ∑ i ∈ q n, f i y) atTop (𝓝 (F y)) :=
    Eventually.of_forall (fun y => (hs y).comp hq)
  apply (MeasureTheory.Lp.eLpNorm_lim_le_liminf_eLpNorm hm F ht).trans
  exact liminf_le_of_frequently_le (Frequently.of_forall (fun n => hbound (q n)))

/-- The exact rebased synthesis inherits any uniform estimate proved for
its finite spatial truncations. This closes the abstract limit argument;
the following applications still have to supply the truncation estimate. -/
theorem rebased_synthesis_l3_bound {ι : Type*} (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : 0<N) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) :
    ∃ q : Finset IntPlane, ∀ (Δ : ℝ) (A : ℝ≥0∞),
      (∀ p : Finset IntPlane,
        l3 (fun y => ∑ n ∈ p, ∑ m ∈ q, (((S.D:ℝ)^2)⁻¹:ℝ) •
          (rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
            (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)*
            freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m)
              (latticePoint (N/S.D) n) y)) (volume.restrict (timeSlab (N^2))) ≤ A) →
      l3 (fun y => ∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p)
        (y.1,y.2+Δ*N^2)) (volume.restrict (timeSlab (N^2))) ≤ A := by
  obtain ⟨q,hq⟩ := equation_5_5 S hφ b hb hbs hN s pbox a ν v
  refine ⟨q,?_⟩
  intro Δ A hbound
  apply l3_hasSum_bound _ _ _ A _ (hq Δ) hbound
  intro n
  apply continuous_finset_sum q
  intro m hm
  apply Continuous.const_smul
  apply continuous_const.mul
  exact continuous_freePacket S.φ hφ _ (Complex.continuous_ofReal.comp S.χ_smooth.continuous)
    (S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero) hN.ne' _ _

end EllipticSquareFunction
