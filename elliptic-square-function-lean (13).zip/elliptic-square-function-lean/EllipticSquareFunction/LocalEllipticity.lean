import EllipticSquareFunction.LocalSurfaceGraphs

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1400000

theorem bilinear_diagonal_norm_le (B : Plane →L[ℝ] Plane →L[ℝ] ℝ) (v : Plane) :
    |B v v| ≤ ‖B‖*‖v‖^2 := by
  calc
    _ = ‖B v v‖ := (Real.norm_eq_abs _).symm
    _ ≤ ‖B v‖*‖v‖ := (B v).le_opNorm v
    _ ≤ (‖B‖*‖v‖)*‖v‖ := mul_le_mul_of_nonneg_right (B.le_opNorm v) (norm_nonneg _)
    _ = _ := by ring

/-- Positive definiteness in finite dimension implies a quantitative lower
bound; no ellipticity constant is assumed in this lemma. -/
theorem positive_bilinear_coercive (B : Plane →L[ℝ] Plane →L[ℝ] ℝ)
    (hpos : ∀ v : Plane, v ≠ 0 → 0 < B v v) :
    ∃ c : ℝ, 0 < c ∧ ∀ v : Plane, c*‖v‖^2 ≤ B v v := by
  have hcont : Continuous (fun v : Plane => B v v) := B.continuous.clm_apply continuous_id
  obtain ⟨c,hc,hbound⟩ := (isCompact_sphere (0 : Plane) 1).exists_forall_le'
    hcont.continuousOn (fun v hv => hpos v (by
      intro he
      simp [he] at hv))
  refine ⟨c,hc,?_⟩
  intro v
  by_cases hv : v=0
  · simp [hv]
  have hn : 0 < ‖v‖ := norm_pos_iff.mpr hv
  let u := ‖v‖⁻¹ • v
  have hu : u ∈ Metric.sphere (0 : Plane) 1 := by
    simp only [Metric.mem_sphere,dist_zero_right,u,norm_smul,Real.norm_eq_abs,
      abs_of_pos (inv_pos.mpr hn),inv_mul_cancel₀ hn.ne']
  have he : B u u = B v v/‖v‖^2 := by
    simp only [u,map_smul,ContinuousLinearMap.smul_apply,smul_eq_mul]
    field_simp
    simp [pow_two]
  have hh := hbound u hu
  rw [he] at hh
  exact (le_div_iff₀ (sq_pos_of_pos hn)).mp hh

/-- Strictly positive Hessian at a point persists with uniform two-sided
ellipticity bounds in a neighborhood. -/
theorem local_uniform_ellipticity {φ : Phase} {U : Set Plane} (hU : IsOpen U)
    (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U) {x : Plane} (hx : x ∈ U)
    (hpos : ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ φ) x v v) :
    ∃ V : Set Plane, IsOpen V ∧ x ∈ V ∧ V ⊆ U ∧ UniformlyEllipticOn φ V := by
  let H := fun y => fderiv ℝ (fderiv ℝ φ) y
  obtain ⟨c,hc,hcoerc⟩ := positive_bilinear_coercive (H x) hpos
  have hcont : ContinuousAt H x := by
    have h₁ := hφ.fderiv_of_isOpen hU (m := 2) (by norm_cast)
    have h₂ := h₁.fderiv_of_isOpen hU (m := 1) (by norm_num)
    exact h₂.continuousOn.continuousAt (hU.mem_nhds hx)
  have ht := hcont.preimage_mem_nhds (Metric.ball_mem_nhds (H x) (show 0 < c/2 by positivity))
  obtain ⟨r,hr,hclose⟩ := Metric.mem_nhds_iff.mp ht
  let V := U ∩ Metric.ball x r
  refine ⟨V,hU.inter Metric.isOpen_ball,⟨hx,Metric.mem_ball_self hr⟩,Set.inter_subset_left,
    c/2,‖H x‖+c/2+1,by positivity,by positivity,?_⟩
  intro y hy v
  have hdiff : ‖H y-H x‖ < c/2 := by
    simpa only [dist_eq_norm] using hclose hy.2
  have herr : |H y v v-H x v v| ≤ (c/2)*‖v‖^2 := by
    have hh := bilinear_diagonal_norm_le (H y-H x) v
    simp only [ContinuousLinearMap.sub_apply] at hh
    exact hh.trans (mul_le_mul_of_nonneg_right hdiff.le (sq_nonneg _))
  have hbase := bilinear_diagonal_norm_le (H x) v
  have hlow := hcoerc v
  have hlo := (abs_le.mp herr).1
  have hhi := (abs_le.mp herr).2
  have hbase' := (le_abs_self (H x v v)).trans hbase
  change (c/2)*‖v‖^2 ≤ H y v v ∧ H y v v ≤ (‖H x‖+c/2+1)*‖v‖^2
  constructor <;> nlinarith [sq_nonneg ‖v‖]

end EllipticSquareFunction
