import EllipticSquareFunction.RebasedWindowMatrix
import EllipticSquareFunction.SeparatedSchur

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

def rebasedCoefficient {ι : Type*} (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N Δ : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) (μ w : Plane) : ℂ :=
  ∑ i ∈ s, ∑ p ∈ pbox i, rebasedWindowMatrix φ b χ N Δ μ w (ν i) (v i p)*a i p

theorem spatialWeight_drift_time (N M Δ : ℝ) (V v : Plane) (y : Space) :
    spatialWeight N M V (v-(Δ*N^2) • V) y =
      spatialWeight N M V v (y.1,y.2+Δ*N^2) := by
  unfold spatialWeight
  have he : y.1-(v-(Δ*N^2) • V)+y.2 • V = y.1-v+(y.2+Δ*N^2) • V := by
    rw [add_smul]
    abel
  rw [he]

/-- The finite-target form of (5.9), before the fixed D⁻² coefficient factor.
The bound is independent of both finite target truncations. Its time loss is
explicitly polynomial; no boundedness of Δ is assumed. -/
theorem equation_5_9_finite {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    {c d σ M : ℝ} (hc : 0<c) (hd : 0<d) (hσ : 0<σ) (hM : 0≤M) :
    ∃ C : ℝ, 0<C ∧ ∃ B : ℕ, ∀ N : ℝ, 1≤N → ∀ Δ : ℝ,
      ∀ {ι : Type*} (s : Finset ι) (pbox : ι → Finset IntPlane)
        (q : Finset IntPlane) (qpos : IntPlane → Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v i p-v i r‖) →
      ∀ y : Space, |y.2|≤N^2 →
      (∑ m ∈ q, ∑ n ∈ qpos m,
        ‖rebasedCoefficient φ b χ N Δ s pbox a ν v (latticePoint N⁻¹ m) (N • latticePoint d n)‖^2*
          spatialWeight N M (velocity φ (latticePoint N⁻¹ m)) (N • latticePoint d n) y) ≤
      C*(1+|Δ|)^B*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M (y.1,y.2+Δ*N^2) := by
  classical
  obtain ⟨A,hA,hcut⟩ := rebasedWindowMatrix_frequency_cutoff φ b hbs χ hχs
  obtain ⟨H,hH,hvel⟩ := continuedPhase_velocity_bound hphase
  let L : ℕ := ⌈M+3⌉₊
  have hLM : 2<(L:ℝ)-M := by have := Nat.le_ceil (M+3); dsimp [L]; linarith
  have hL : 2<(L:ℝ) := by linarith
  obtain ⟨C,hC,hdecay⟩ := rebasedWindowMatrix_uniform_decay hphase b hb hbs χ hχ A L
  let K := (integerPlaneBox ⌈(5/σ)*A+4⌉₊).card
  let E := H*A
  let T : ℝ := C^2*((K:ℝ)*separatedPlaneSumConstant c L)*
    (((integerPlaneBox ⌈A+2⌉₊).card:ℝ)*(scaledLatticeSumConstant d ((L:ℝ)-M)*(1+E)^M))
  have hE : 0≤E := mul_nonneg hH hA.le
  have hsc : 0≤scaledLatticeSumConstant d ((L:ℝ)-M) := by
    simpa using scaled_lattice_finite_sum_le hd hLM (0:Plane) ∅
  have hsepC := separatedPlaneSumConstant_nonneg hc hL
  have hT : 0≤T := by dsimp [T]; positivity
  refine ⟨T+1,by positivity,2*L,?_⟩
  intro N hN Δ ι s pbox q qpos a ν v hfreq hpos y ht
  have hN0 : 0<N := by linarith
  let v' := fun i p => v i p-(Δ*N^2) • velocity φ (ν i)
  let Kmat := fun (mn : Σ _ : IntPlane, IntPlane) (ip : Σ _ : ι, IntPlane) =>
    rebasedWindowMatrix φ b χ N Δ (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2)
      (ν ip.1) (v ip.1 ip.2)
  have hpos' : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v' i p-v' i r‖ := by
    intro i hi p hp r hr hpr
    have he : v' i p-v' i r=v i p-v i r := by dsimp [v']; abel
    rw [he]
    exact hpos i hi p hp r hr hpr
  have hv : ∀ m ∈ q, ∀ i ∈ s, ‖latticePoint N⁻¹ m-ν i‖≤A/N →
      ‖velocity φ (latticePoint N⁻¹ m)-velocity φ (ν i)‖≤E/N := by
    intro m hm i hi hnear
    apply (hvel (ν i) (latticePoint N⁻¹ m)).trans
    have hh := mul_le_mul_of_nonneg_left hnear hH
    simpa only [E,mul_div_assoc] using hh
  have hdec : ∀ mn ∈ q.sigma qpos, ∀ ip ∈ s.sigma pbox,
      ‖latticePoint N⁻¹ mn.1-ν ip.1‖≤A/N →
      ‖Kmat mn ip‖≤(C*(1+|Δ|)^L)*
        bracket (N⁻¹ • (N • latticePoint d mn.2-v' ip.1 ip.2))^(-(L:ℝ)) := by
    intro mn hmn ip hip hnear
    have hscaled : ‖N • (ν ip.1-latticePoint N⁻¹ mn.1)‖≤A := by
      rw [norm_smul,Real.norm_eq_abs,abs_of_pos hN0,norm_sub_rev]
      have hh := (le_div_iff₀ hN0).mp hnear
      nlinarith
    have hh := hdecay N hN Δ (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2)
      (ν ip.1) (v ip.1 ip.2) hscaled
    have he : N • latticePoint d mn.2-v' ip.1 ip.2 =
        N • latticePoint d mn.2-v ip.1 ip.2+(Δ*N^2) • velocity φ (ν ip.1) := by dsimp [v']; abel
    rw [he]
    exact hh
  have hh := separated_matrix_weighted_density s pbox q qpos a ν (fun i => velocity φ (ν i)) v'
    (fun m => velocity φ (latticePoint N⁻¹ m)) Kmat hN0 hc hd hE hM hLM y ht K hpos'
    (fun m hm => frequencyOverlap_of_separated s ν hN0 hσ hfreq _)
    hv (fun mn hmn ip hip hnear => hcut N hN0 Δ _ _ _ _ hnear) hdec
  have hdensity : spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
      (fun ip => velocity φ (ν ip.1)) (fun ip => v' ip.1 ip.2) N M y =
      spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
      (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M (y.1,y.2+Δ*N^2) := by
    unfold spatialDensity
    simp only [v',spatialWeight_drift_time]
  rw [hdensity] at hh
  simp only [Finset.sum_sigma,Kmat] at hh
  have hpow : ((1+|Δ|)^L)^2=(1+|Δ|)^(2*L) := by rw [← pow_mul,Nat.mul_comm]
  rw [mul_pow,hpow] at hh
  have he : C^2*(1+|Δ|)^(2*L)*((K:ℝ)*separatedPlaneSumConstant c L)*
      (((integerPlaneBox ⌈A+2⌉₊).card:ℝ)*(scaledLatticeSumConstant d ((L:ℝ)-M)*(1+E)^M)) =
      T*(1+|Δ|)^(2*L) := by dsimp [T]; ring
  rw [he] at hh
  apply hh.trans
  apply mul_le_mul_of_nonneg_right
  · exact mul_le_mul_of_nonneg_right (by linarith) (by positivity)
  · exact Finset.sum_nonneg (fun ip hip => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))

/-- The complete rebased coefficient density is summable and satisfies the
same bound as every finite target truncation. -/
theorem equation_5_9_countable {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    {c d σ M : ℝ} (hc : 0<c) (hd : 0<d) (hσ : 0<σ) (hM : 0≤M) :
    ∃ C : ℝ, 0<C ∧ ∃ B : ℕ, ∀ N : ℝ, 1≤N → ∀ Δ : ℝ,
      ∀ {ι : Type*} (s : Finset ι) (pbox : ι → Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ∀ k ∈ s, i≠k → σ/N≤‖ν i-ν k‖) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ r ∈ pbox i, p≠r → c*N≤‖v i p-v i r‖) →
      ∀ y : Space, |y.2|≤N^2 →
      let f := fun mn : IntPlane × IntPlane =>
        ‖rebasedCoefficient φ b χ N Δ s pbox a ν v
          (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2)‖^2*
          spatialWeight N M (velocity φ (latticePoint N⁻¹ mn.1)) (N • latticePoint d mn.2) y
      Summable f ∧ (∑' mn, f mn) ≤
        C*(1+|Δ|)^B*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
          (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M (y.1,y.2+Δ*N^2) := by
  classical
  obtain ⟨C,hC,B,hbound⟩ := equation_5_9_finite hphase b hb hbs χ hχ hχs hc hd hσ hM
  refine ⟨C,hC,B,?_⟩
  intro N hN Δ ι s pbox a ν v hfreq hpos y ht f
  have hnn (mn : IntPlane × IntPlane) : 0≤f mn :=
    mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..)
  have hfin (T : Finset (IntPlane × IntPlane)) : (∑ mn ∈ T, f mn) ≤
      C*(1+|Δ|)^B*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M (y.1,y.2+Δ*N^2) := by
    have hh := hbound N hN Δ s pbox (T.image Prod.fst) (fun _ => T.image Prod.snd)
      a ν v hfreq hpos y ht
    have hsub : T⊆(T.image Prod.fst) ×ˢ (T.image Prod.snd) := by
      intro mn hmn
      exact Finset.mem_product.mpr ⟨Finset.mem_image.mpr ⟨mn,hmn,rfl⟩,
        Finset.mem_image.mpr ⟨mn,hmn,rfl⟩⟩
    have hs := Finset.sum_le_sum_of_subset_of_nonneg hsub (fun mn _ _ => hnn mn)
    apply hs.trans
    simpa only [Finset.sum_product,f] using hh
  have hs : Summable f := summable_of_sum_le hnn hfin
  exact ⟨hs,hs.tsum_le_of_sum_le hfin⟩

end EllipticSquareFunction
