import EllipticSquareFunction.BoundaryChartDerivatives

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- The tangent coordinate change of two overlapping boundary charts is an
actual continuous linear equivalence, with the reverse transition as inverse. -/
def boundaryTangentCoordEquiv (x y z : M)
    (hzx : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (hzy : z ∈ (extChartAt (𝓡∂ 2) y).source) : Plane ≃L[ℝ] Plane :=
  ContinuousLinearEquiv.equivOfInverse (tangentCoordChange (𝓡∂ 2) x y z)
    (tangentCoordChange (𝓡∂ 2) y x z)
    (fun v => by
      rw [tangentCoordChange_comp (show z ∈
        ((extChartAt (𝓡∂ 2) x).source ∩ (extChartAt (𝓡∂ 2) y).source) ∩
          (extChartAt (𝓡∂ 2) x).source from ⟨⟨hzx,hzy⟩,hzx⟩)]
      exact tangentCoordChange_self hzx)
    (fun v => by
      rw [tangentCoordChange_comp (show z ∈
        ((extChartAt (𝓡∂ 2) y).source ∩ (extChartAt (𝓡∂ 2) x).source) ∩
          (extChartAt (𝓡∂ 2) y).source from ⟨⟨hzy,hzx⟩,hzy⟩)]
      exact tangentCoordChange_self hzy)

/-- A globally defined family of bilinear forms on the actual Mathlib
tangent fibers. The normal N may be chosen separately at each point. -/
def boundarySecondFundamentalForm (f : M → EuclideanThree) (N : EuclideanThree) (z : M) :
    LinearMap.BilinForm ℝ (TangentSpace (𝓡∂ 2) z) where
  toFun v :=
    { toFun := fun w => modelSecondForm (𝓡∂ 2) f z N v w
      map_add' := by intros; simp [modelSecondForm,map_add,inner_add_right]
      map_smul' := by intros; simp [modelSecondForm,map_smul,inner_smul_right] }
  map_add' := by
    intro v w
    apply LinearMap.ext
    intro u
    exact model_second_form_add_left (𝓡∂ 2) f z N v w u
  map_smul' := by
    intro c v
    apply LinearMap.ext
    intro w
    exact model_second_form_smul_left (𝓡∂ 2) f z N v w c

theorem boundary_second_fundamental_form_symmetric {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (N : EuclideanThree) (z : M) (v w : TangentSpace (𝓡∂ 2) z) :
    boundarySecondFundamentalForm f N z v w = boundarySecondFundamentalForm f N z w v :=
  model_second_form_symmetric (𝓡∂ 2) hf z N v w

/-- The global fiber form agrees with its expression in every boundary chart. -/
theorem boundary_second_fundamental_form_in_chart {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0)
    (v w : TangentSpace (𝓡∂ 2) z) :
    boundarySecondFundamentalForm f N z v w = boundaryChartSecondForm f x z N
      (tangentCoordChange (𝓡∂ 2) z x z v) (tangentCoordChange (𝓡∂ 2) z x z w) :=
  boundary_intrinsic_second_form_in_chart hf x z hz N hN v w

/-- Positive curvature is independent of the boundary chart used to test it. -/
theorem boundary_chart_second_form_positive_iff {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source) (N : EuclideanThree)
    (hN : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    (∀ v : TangentSpace (𝓡∂ 2) z, v ≠ 0 → 0 < boundarySecondFundamentalForm f N z v v) ↔
      ∀ v : Plane, v ≠ 0 → 0 < boundaryChartSecondForm f x z N v v := by
  let L := boundaryTangentCoordEquiv z x z (mem_extChartAt_source z) hz
  have he : ∀ v : Plane, boundarySecondFundamentalForm f N z v v =
      boundaryChartSecondForm f x z N (L v) (L v) :=
    fun v => boundary_second_fundamental_form_in_chart hf x z hz N hN v v
  constructor
  · intro hp v hv
    have hh := hp (L.symm v) (fun h => hv (L.symm.injective (h.trans (map_zero _).symm)))
    simpa only [he,L.apply_symm_apply] using hh
  · intro hp v hv
    rw [he]
    exact hp (L v) (fun h => hv (L.injective (h.trans (map_zero _).symm)))

end EllipticSquareFunction
