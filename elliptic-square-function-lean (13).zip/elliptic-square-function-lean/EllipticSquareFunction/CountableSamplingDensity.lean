import EllipticSquareFunction.SamplingDensity

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction

/-- Monotone passage from finite sample densities to the full nonnegative
density. This requires no prior summability or finiteness of either side. -/
theorem countable_density_of_sample_majorants {ι : Type*}
    (μ : Measure Space) (a W : ι → ℝ≥0∞) (F H : Space → ℝ≥0∞)
    (K : ι → Space → ℝ≥0∞) (hF : AEMeasurable F μ)
    (hK : ∀ i, AEMeasurable (K i) μ)
    (ha : ∀ i, a i ≤ ∫⁻ z, F z*K i z ∂μ)
    (hconv : ∀ (T : Finset ι) z, (∑ i ∈ T, K i z*W i) ≤ H z) :
    (∑' i, a i*W i) ≤ ∫⁻ z, F z*H z ∂μ := by
  rw [ENNReal.tsum_eq_iSup_sum]
  exact iSup_le (fun T => finite_density_of_sample_majorants T μ a W F H K hF
    (fun i _ => hK i) (fun i _ => ha i) (hconv T))

/-- The entire sampling lattice obeys the density bound once its local sample
estimates are supplied. This does not assert Fourier reconstruction. -/
theorem full_sampling_density_from_local_majorants {R A B M L : ℝ}
    (hR : 0<R) (hA : 0<A) (hB : 0<B) (hM : 0≤M) (hLM : 2<L-M)
    (V : Plane) (a : IntPlane × ℤ → ℝ≥0∞)
    (F : Space → ℝ≥0∞) (hF : AEMeasurable F volume)
    (ha : ∀ i, a i ≤ ∫⁻ z, F z*ENNReal.ofReal
      (packetWeight R L V
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).1
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).2 z))
    (y : Space) :
    let p := fun i : IntPlane × ℤ =>
      samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2
    (∑' i, a i*ENNReal.ofReal (packetWeight R M V (p i).1 (p i).2 y)) ≤
      ∫⁻ z, F z*ENNReal.ofReal
        ((scaledLatticeSumConstant A⁻¹ (L-M)*scaledTimeSumConstant B⁻¹ (L-M))*
          packetWeight R M V 0 0 (y-z)) := by
  dsimp only
  rw [ENNReal.tsum_eq_iSup_sum]
  exact iSup_le (fun T => sampling_density_from_local_majorants hR hA hB hM hLM
    V T a F hF (fun i _ => ha i) y)

end EllipticSquareFunction
