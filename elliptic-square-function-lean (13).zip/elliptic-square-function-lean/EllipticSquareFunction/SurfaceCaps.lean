import EllipticSquareFunction.GeneralGraphTheorem

noncomputable section
namespace EllipticSquareFunction

/-- The distance-thickened surface caps of (8.1), in a specified ambient metric. -/
def surfaceCap {E : Type*} [PseudoMetricSpace E] (carrier : Set E) (p : E) (δ C : ℝ) : Set E :=
  Metric.cthickening (C*δ^2) (carrier ∩ Metric.ball p (C*δ))

structure SurfaceSetup where
  carrier : Set Space
  compact_carrier : IsCompact carrier
  c₀ : ℝ
  C₀ : ℝ
  c₀_pos : 0 < c₀
  C₀_pos : 0 < C₀

def SurfaceAdmissibleFamily (S : SurfaceSetup) (R : ℝ) {n : ℕ}
    (p : Fin n → Space) (f : Fin n → SchwartzMap Space ℂ) : Prop :=
  (∀ i, p i ∈ S.carrier) ∧
  (∀ i j, i ≠ j → S.c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) ∧
  (∀ i, Function.support (fourierTransform (f i)) ⊆ surfaceCap S.carrier (p i) (Real.sqrt R)⁻¹ S.C₀)

def SurfaceReverseSquareFunction (S : SurfaceSetup) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
    ∀ (n : ℕ) (p : Fin n → Space) (f : Fin n → SchwartzMap Space ℂ),
    SurfaceAdmissibleFamily S R p f →
    l3 (fun y => ∑ i, f i y) ≤ ENNReal.ofReal (C*R^ε)*
      l3Real (squareFunction Finset.univ (fun i => f i))

/-- A local geometric graph atlas. At boundary points only inclusion in an
extended smooth elliptic graph is required. Deriving these data from a
manifold's definite second fundamental form is a separate obligation. -/
def LocalEllipticGraphAtlas (carrier : Set Space) : Prop :=
  ∀ p ∈ carrier, ∃ (W : Set Space) (A : Space ≃ᵃ[ℝ] Space) (G : GraphSetup),
    IsOpen W ∧ p ∈ W ∧ GraphHypotheses G ∧
      ∀ q ∈ carrier ∩ W, (A q).1 ∈ G.K ∧ (A q).2=G.φ (A q).1

theorem surfaceCap_nearby_point {E : Type*} [NormedAddCommGroup E]
    {carrier : Set E} (hcarrier : IsCompact carrier)
    {p z : E} {δ C : ℝ} (hC : 0 ≤ C) (hz : z ∈ surfaceCap carrier p δ C) :
    ∃ q ∈ carrier, ‖q-p‖ ≤ C*δ ∧ ‖z-q‖ ≤ C*δ^2 := by
  have hc : IsCompact (carrier ∩ Metric.closedBall p (C*δ)) :=
    hcarrier.inter_right Metric.isClosed_closedBall
  have hm : z ∈ Metric.cthickening (C*δ^2) (carrier ∩ Metric.closedBall p (C*δ)) :=
    Metric.cthickening_subset_of_subset _ (Set.inter_subset_inter_right _ Metric.ball_subset_closedBall) hz
  rw [hc.cthickening_eq_biUnion_closedBall (mul_nonneg hC (sq_nonneg δ))] at hm
  obtain ⟨q,hq,hzq⟩ := Set.mem_iUnion₂.mp hm
  exact ⟨q,hq.1,by simpa only [Metric.mem_closedBall,dist_eq_norm] using hq.2,
    by simpa only [Metric.mem_closedBall,dist_eq_norm] using hzq⟩

/-- Local slope bounds and compactness also give a bound between arbitrary
points of the compact parameter set, even when that set is not convex. -/
theorem graph_phase_compact_bound (G : GraphSetup) (hG : GraphHypotheses G) :
    ∃ H : ℝ, 0 < H ∧ ∀ ξ ∈ G.K, ∀ ν ∈ G.K,
      |G.φ ξ-G.φ ν| ≤ H*‖ξ-ν‖ := by
  obtain ⟨r,H,hr,hH,hlocal⟩ := graph_phase_local_bound G hG
  obtain ⟨U,hU,hKU,hφ,hell⟩ := hG
  obtain ⟨F,hF⟩ := G.compact_K.exists_bound_of_continuousOn (hφ.continuousOn.mono hKU)
  let M := max F 0
  refine ⟨H+2*M/r,by dsimp [M]; positivity,?_⟩
  intro ξ hξ ν hν
  by_cases hnear : ‖ξ-ν‖ < r
  · exact (hlocal ν hν ξ hnear).trans (mul_le_mul_of_nonneg_right
      (le_add_of_nonneg_right (show 0 ≤ 2*M/r by dsimp [M]; positivity)) (norm_nonneg _))
  · have hd : r ≤ ‖ξ-ν‖ := le_of_not_gt hnear
    have hdiff : |G.φ ξ-G.φ ν| ≤ 2*M := by
      have hξ' : |G.φ ξ| ≤ M := (hF ξ hξ).trans (le_max_left _ _)
      have hν' : |G.φ ν| ≤ M := (hF ν hν).trans (le_max_left _ _)
      exact (abs_sub _ _).trans (by linarith)
    have hh : 2*M ≤ (2*M/r)*‖ξ-ν‖ := by
      calc
        _ = (2*M/r)*r := by field_simp
        _ ≤ _ := mul_le_mul_of_nonneg_left hd (by dsimp [M]; positivity)
    exact hdiff.trans (hh.trans (by nlinarith [mul_nonneg hH.le (norm_nonneg (ξ-ν))]))

theorem finite_surface_graph_cover (S : SurfaceSetup) (hatlas : LocalEllipticGraphAtlas S.carrier) :
    ∃ (s : Finset S.carrier) (W : S.carrier → Set Space) (A : S.carrier → Space ≃ᵃ[ℝ] Space)
      (G : S.carrier → GraphSetup) (r : ℝ), 0 < r ∧
      (∀ j ∈ s, GraphHypotheses (G j) ∧
        ∀ q ∈ S.carrier ∩ W j, (A j q).1 ∈ (G j).K ∧ (A j q).2=(G j).φ (A j q).1) ∧
      (∀ p ∈ S.carrier, ∃ j ∈ s, Metric.ball p r ⊆ W j) := by
  classical
  have hp (p : S.carrier) := hatlas p p.property
  choose W A G hW hmem hG hgraph using hp
  have hcover : S.carrier ⊆ ⋃ p : S.carrier, W p := by
    intro p hp
    exact Set.mem_iUnion.mpr ⟨⟨p,hp⟩,hmem ⟨p,hp⟩⟩
  obtain ⟨s,hs⟩ := S.compact_carrier.elim_finite_subcover W hW hcover
  have hs' : S.carrier ⊆ ⋃ i : s, W i := by
    intro x hx
    obtain ⟨i,hi,hxW⟩ := Set.mem_iUnion₂.mp (hs hx)
    exact Set.mem_iUnion.mpr ⟨⟨i,hi⟩,hxW⟩
  obtain ⟨r,hr,hball⟩ := lebesgue_number_lemma_of_metric S.compact_carrier (fun i : s => hW i) hs'
  refine ⟨s,W,A,G,r,hr,fun j _ => ⟨hG j,hgraph j⟩,?_⟩
  intro p hp
  obtain ⟨j,hj⟩ := hball p hp
  exact ⟨j,j.property,hj⟩

end EllipticSquareFunction
