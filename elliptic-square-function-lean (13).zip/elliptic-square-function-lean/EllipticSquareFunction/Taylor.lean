import EllipticSquareFunction.Coordinates
import EllipticSquareFunction.ExternalInputs

/-! # Uniform Taylor bounds and the cap/box comparison

The quadratic remainder bound is intentionally nonoptimal. Its constant is
uniform in the cap center and the scale, which is what Sections 2 and 6 need.
-/

noncomputable section
open Set
namespace EllipticSquareFunction

theorem fderiv_eq_inner_velocity (φ : Phase) (ν h : Plane) :
    fderiv ℝ φ ν h = @inner ℝ Plane _ (velocity φ ν) h := by
  rw [velocity, gradient, ← InnerProductSpace.toDual_apply,
    (InnerProductSpace.toDual ℝ Plane).apply_symm_apply]

/-- The operator-norm Hessian bound gives a Lipschitz bound for the derivative. -/
theorem derivative_difference_bound (φ : Phase) {U : Set Plane} {C : ℝ}
    (hU : Convex ℝ U) (hφ : ∀ z ∈ U, DifferentiableAt ℝ (fderiv ℝ φ) z)
    (hH : ∀ z ∈ U, ‖fderiv ℝ (fderiv ℝ φ) z‖ ≤ C)
    {x y : Plane} (hx : x ∈ U) (hy : y ∈ U) :
    ‖fderiv ℝ φ y - fderiv ℝ φ x‖ ≤ C * ‖y - x‖ :=
  hU.norm_image_sub_le_of_norm_fderiv_le hφ hH hx hy

/-- Taylor's estimate on a convex region, proved using the mean-value theorem
twice. The constant `C` may replace the sharper constant `C/2`. -/
theorem quadratic_remainder_bound (φ : Phase) {U : Set Plane} {C : ℝ}
    (hC : 0 ≤ C) (hU : Convex ℝ U)
    (hφ : ∀ z ∈ U, DifferentiableAt ℝ φ z)
    (hφ' : ∀ z ∈ U, DifferentiableAt ℝ (fderiv ℝ φ) z)
    (hH : ∀ z ∈ U, ‖fderiv ℝ (fderiv ℝ φ) z‖ ≤ C)
    {ν ξ : Plane} (hν : ν ∈ U) (hξ : ξ ∈ U) :
    |φ ξ - φ ν - @inner ℝ Plane _ (velocity φ ν) (ξ - ν)| ≤ C * ‖ξ - ν‖ ^ 2 := by
  have hs := hU.segment_subset hν hξ
  have hd : ∀ z ∈ segment ℝ ν ξ,
      ‖fderiv ℝ φ z - fderiv ℝ φ ν‖ ≤ C * ‖ξ - ν‖ := by
    intro z hz
    exact (derivative_difference_bound φ hU hφ' hH hν (hs hz)).trans
      (mul_le_mul_of_nonneg_left (norm_sub_le_of_mem_segment hz) hC)
  have h := (convex_segment ν ξ).norm_image_sub_le_of_norm_fderiv_le'
    (fun z hz => hφ z (hs hz)) hd (left_mem_segment ℝ ν ξ) (right_mem_segment ℝ ν ξ)
  rw [fderiv_eq_inner_velocity, Real.norm_eq_abs] at h
  nlinarith [h]

/-- The affine vertical coordinate of a curved cap has size `O(δ²)`. -/
theorem cap_affine_height_bound (φ : Phase) {U : Set Plane} {C C₀ δ : ℝ}
    (hC : 0 ≤ C) (hU : Convex ℝ U)
    (hφ : ∀ z ∈ U, DifferentiableAt ℝ φ z)
    (hφ' : ∀ z ∈ U, DifferentiableAt ℝ (fderiv ℝ φ) z)
    (hH : ∀ z ∈ U, ‖fderiv ℝ (fderiv ℝ φ) z‖ ≤ C)
    {ν : Plane} {ζ : Space} (hν : ν ∈ U) (hξ : ζ.1 ∈ U)
    (hcap : ζ ∈ cap φ ν δ C₀) :
    |ζ.2 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)| ≤
      (C₀ + C * C₀ ^ 2) * δ ^ 2 := by
  have ht := quadratic_remainder_bound φ hC hU hφ hφ' hH hν hξ
  have hn : ‖ζ.1 - ν‖ ^ 2 ≤ (C₀ * δ) ^ 2 :=
    pow_le_pow_left₀ (norm_nonneg _) hcap.1 2
  have he : ζ.2 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν) =
      (ζ.2 - φ ζ.1) + (φ ζ.1 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)) := by ring
  rw [he]
  calc
    _ ≤ |ζ.2 - φ ζ.1| + |φ ζ.1 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)| := abs_add _ _
    _ ≤ C₀ * δ ^ 2 + C * (C₀ * δ) ^ 2 :=
      add_le_add hcap.2 (ht.trans (mul_le_mul_of_nonneg_left hn hC))
    _ = _ := by ring

/-- Convert the article's iterated-derivative norm to the operator Hessian norm. -/
theorem hessian_norm_eq_iterated (φ : Phase) (ξ : Plane) :
    ‖fderiv ℝ (fderiv ℝ φ) ξ‖ = ‖iteratedFDeriv ℝ 2 φ ξ‖ := by
  rw [← norm_iteratedFDeriv_fderiv (n := 1)]
  rw [← iteratedFDerivWithin_univ, norm_iteratedFDerivWithin_one _
    (uniqueDiffOn_univ ξ (mem_univ ξ)), fderivWithin_univ]

/-- A continued phase has a global quadratic remainder bound with one constant. -/
theorem continuedPhase_quadratic_bound {φ : Phase} (h : ContinuedPhase φ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ ν ξ : Plane,
      |φ ξ - φ ν - @inner ℝ Plane _ (velocity φ ν) (ξ - ν)| ≤ C * ‖ξ - ν‖ ^ 2 := by
  obtain ⟨ρ, ζ, hρ, hρ', hζ, hcζ, hbζ, hζone, hsζ, he, hφ, hell, hder⟩ := h
  obtain ⟨C, hC⟩ := hder 2 le_rfl
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0)
  refine ⟨C, hC0, fun ν ξ => ?_⟩
  exact quadratic_remainder_bound φ hC0 convex_univ
    (fun z _ => hφ.differentiable (by norm_num) z)
    (fun z _ => (hφ.fderiv_right (m := 1) (by norm_cast)).differentiable (by norm_num) z)
    (fun z _ => by rw [hessian_norm_eq_iterated]; exact hC z) (mem_univ ν) (mem_univ ξ)

/-- Zeroth-order bound for the normalized remainder in (5.7), uniform in scale. -/
theorem phaseRemainder_bound {φ : Phase} {C : ℝ}
    (hTaylor : ∀ ν ξ : Plane,
      |φ ξ - φ ν - @inner ℝ Plane _ (velocity φ ν) (ξ - ν)| ≤ C * ‖ξ - ν‖ ^ 2)
    (ν η : Plane) {r : ℝ} (hr : 0 < r) :
    |phaseRemainder φ ν (velocity φ ν) r (r ^ 2) η| ≤ C * ‖η‖ ^ 2 := by
  have ht := hTaylor ν (ν + r⁻¹ • η)
  simp only [add_sub_cancel_left, norm_smul, Real.norm_eq_abs,
    abs_inv, abs_of_pos hr, inner_smul_right] at ht
  have he : C * ‖η‖ ^ 2 = r ^ 2 * (C * (r⁻¹ * ‖η‖) ^ 2) := by field_simp
  rw [he]
  unfold phaseRemainder
  rw [abs_mul, abs_of_nonneg (sq_nonneg r)]
  exact mul_le_mul_of_nonneg_left ht (sq_nonneg r)

/-- The affine frequency coordinates used for the sampling box in Section 6. -/
def affineFrequencyCoordinates (φ : Phase) (ν : Plane) (r R : ℝ) (ζ : Space) : Space :=
  (r • (ζ.1 - ν), R * (ζ.2 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)))

theorem cap_normalized_coordinates {φ : Phase} {C : ℝ} (hC : 0 ≤ C)
    (hTaylor : ∀ ν ξ : Plane,
      |φ ξ - φ ν - @inner ℝ Plane _ (velocity φ ν) (ξ - ν)| ≤ C * ‖ξ - ν‖ ^ 2)
    (ν : Plane) {r C₀ : ℝ} (hr : 0 < r) {ζ : Space}
    (hcap : ζ ∈ cap φ ν r⁻¹ C₀) :
    ‖(affineFrequencyCoordinates φ ν r (r ^ 2) ζ).1‖ ≤ C₀ ∧
    |(affineFrequencyCoordinates φ ν r (r ^ 2) ζ).2| ≤ C₀ + C * C₀ ^ 2 := by
  have hsp : r * ‖ζ.1 - ν‖ ≤ C₀ := by
    have h := mul_le_mul_of_nonneg_left hcap.1 hr.le
    have he : r * (C₀ * r⁻¹) = C₀ := by field_simp
    simpa only [he] using h
  have hn : r ^ 2 * ‖ζ.1 - ν‖ ^ 2 ≤ C₀ ^ 2 := by
    have h := pow_le_pow_left₀ (mul_nonneg hr.le (norm_nonneg _)) hsp 2
    nlinarith [h]
  refine ⟨by simpa only [affineFrequencyCoordinates, norm_smul, Real.norm_eq_abs,
    abs_of_pos hr] using hsp, ?_⟩
  have hv : r ^ 2 * |ζ.2 - φ ζ.1| ≤ C₀ := by
    have h := mul_le_mul_of_nonneg_left hcap.2 (sq_nonneg r)
    have he : r ^ 2 * (C₀ * (r⁻¹) ^ 2) = C₀ := by field_simp
    simpa only [he] using h
  have he : ζ.2 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν) =
      (ζ.2 - φ ζ.1) + (φ ζ.1 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)) := by ring
  change |r ^ 2 * _| ≤ _
  rw [abs_mul, abs_of_nonneg (sq_nonneg r), he]
  calc
    _ ≤ r ^ 2 * (|ζ.2 - φ ζ.1| +
        |φ ζ.1 - φ ν - @inner ℝ Plane _ (velocity φ ν) (ζ.1 - ν)|) :=
      mul_le_mul_of_nonneg_left (abs_add _ _) (sq_nonneg r)
    _ ≤ C₀ + C * C₀ ^ 2 := by
      have ht := mul_le_mul_of_nonneg_left (hTaylor ν ζ.1) (sq_nonneg r)
      have hh := mul_le_mul_of_nonneg_left hn hC
      nlinarith

/-- Continued phases admit one sampling-box size for every cap and every scale. -/
theorem continuedPhase_cap_box {φ : Phase} (h : ContinuedPhase φ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (ν : Plane) (r C₀ : ℝ), 0 < r → ∀ ζ ∈ cap φ ν r⁻¹ C₀,
      ‖(affineFrequencyCoordinates φ ν r (r ^ 2) ζ).1‖ ≤ C₀ ∧
      |(affineFrequencyCoordinates φ ν r (r ^ 2) ζ).2| ≤ C₀ + C * C₀ ^ 2 := by
  obtain ⟨C, hC, hT⟩ := continuedPhase_quadratic_bound h
  exact ⟨C, hC, fun ν _ _ hr _ hc => cap_normalized_coordinates hC hT ν hr hc⟩

end EllipticSquareFunction
