import EllipticSquareFunction.CubicAssembly

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The elementary cubic near/far inequality. -/
theorem norm_add_cube_le (z w : ℂ) :
    ‖z+w‖^3 ≤ 4*(‖z‖^3+‖w‖^3) := by
  have h := norm_add_le z w
  have hz := norm_nonneg z
  have hw := norm_nonneg w
  have hh := pow_le_pow_left₀ (norm_nonneg (z+w)) h 3
  nlinarith [sq_nonneg (‖z‖-‖w‖), mul_nonneg (add_nonneg hz hw) (sq_nonneg (‖z‖-‖w‖))]

/-- Cubic assembly on the disjoint spatial partition. All quantities are
extended nonnegative reals, so no finiteness of the desired integral is used. -/
theorem cubic_tile_assembly (N R : ℝ) (F : Space → ℂ)
    (U V : IntPlane → Space → ℂ) (D : Space → ℝ≥0∞)
    (hU : ∀ m, Measurable (U m)) (hD : Measurable D)
    (A B J I : ℝ≥0∞) (Inear : IntPlane → ℝ≥0∞)
    (hsplit : ∀ m y, y ∈ localSlab (spatialTile N m) R → F y=U m y+V m y)
    (hnear : ∀ m, (∫⁻ y in localSlab (spatialTile N m) R,
      ENNReal.ofReal (‖U m y‖^3)) ≤ A*Inear m)
    (hfar : ∀ m y, y ∈ localSlab (spatialTile N m) R →
      ENNReal.ofReal (‖V m y‖^3) ≤ B*D y)
    (hoverlap : (∑' m, Inear m) ≤ J*I)
    (hfull : (∫⁻ y in timeSlab R, D y) ≤ I) :
    (∫⁻ y in timeSlab R, ENNReal.ofReal (‖F y‖^3)) ≤ 4*(A*J+B)*I := by
  have htile (m : IntPlane) :
      (∫⁻ y in localSlab (spatialTile N m) R, ENNReal.ofReal (‖F y‖^3)) ≤
        4*(A*Inear m+B*(∫⁻ y in localSlab (spatialTile N m) R, D y)) := by
    have hu : Measurable (fun y => ENNReal.ofReal (‖U m y‖^3)) := by fun_prop
    calc
      _ ≤ ∫⁻ y in localSlab (spatialTile N m) R,
          4*(ENNReal.ofReal (‖U m y‖^3)+B*D y) := by
        apply setLIntegral_mono' ((measurableSet_spatialTile N m).prod measurableSet_Icc)
        intro y hy
        rw [hsplit m y hy]
        calc
          _ ≤ ENNReal.ofReal (4*(‖U m y‖^3+‖V m y‖^3)) :=
            ENNReal.ofReal_le_ofReal (norm_add_cube_le _ _)
          _ = 4*(ENNReal.ofReal (‖U m y‖^3)+ENNReal.ofReal (‖V m y‖^3)) := by
            rw [ENNReal.ofReal_mul (by norm_num), ENNReal.ofReal_add (by positivity) (by positivity)]
            norm_num
          _ ≤ _ := mul_le_mul_left' (add_le_add_left (hfar m y hy) _) _
      _ = 4*((∫⁻ y in localSlab (spatialTile N m) R, ENNReal.ofReal (‖U m y‖^3))+
          B*(∫⁻ y in localSlab (spatialTile N m) R, D y)) := by
        rw [lintegral_const_mul _ (hu.add (measurable_const.mul hD)),
          lintegral_add_left hu,lintegral_const_mul _ hD]
      _ ≤ _ := mul_le_mul_left' (add_le_add_right (hnear m) _) _
  rw [lintegral_spatial_tiles N R]
  calc
    _ ≤ ∑' m, 4*(A*Inear m+B*(∫⁻ y in localSlab (spatialTile N m) R, D y)) :=
      ENNReal.tsum_le_tsum htile
    _ = 4*(A*(∑' m, Inear m)+B*(∫⁻ y in timeSlab R, D y)) := by
      rw [ENNReal.tsum_mul_left,ENNReal.tsum_add,ENNReal.tsum_mul_left,
        ENNReal.tsum_mul_left,← lintegral_spatial_tiles]
    _ ≤ 4*(A*(J*I)+B*I) := by gcongr
    _ = _ := by ring

/-- Recover the norm estimate from an extended-real cubic estimate. -/
theorem l3_le_of_cubic_lintegral (μ : Measure Space) (F : Space → ℂ)
    (A D : ℝ≥0∞)
    (h : (∫⁻ y, ENNReal.ofReal (‖F y‖^3) ∂μ) ≤ A^3*D) :
    l3 F μ ≤ A*D^(1/3:ℝ) := by
  have hh := ENNReal.rpow_le_rpow h (by norm_num : (0:ℝ)≤1/3)
  rw [← l3_cube_eq_lintegral, ENNReal.mul_rpow_of_nonneg _ _ (by norm_num)] at hh
  have he (x : ℝ≥0∞) : (x^3)^(1/3:ℝ)=x := by
    rw [← ENNReal.rpow_natCast, ← ENNReal.rpow_mul]
    norm_num
  simpa only [he] using hh

theorem spatialDensity_nonneg_global {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N M : ℝ) (y : Space) : 0≤spatialDensity s a V v N M y :=
  Finset.sum_nonneg (fun _ _ => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))

/-- Assembly for the actual packets. The two analytic estimates are explicit
premises here; the next theorem supplies them from the proved local and far bounds. -/
theorem global_packets_cubic_of_local_far {ι : Type*}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane)
    {N : ℝ} (hN : N≠0) (M A P κ η Cnear Cf : ℝ) (hCf : 0≤Cf)
    (hnear : ∀ m : IntPlane,
      LocalProfileEstimate φ b
        (s.sigma (fun i => (pbox i).filter (fun p => ‖v i p-spatialTileCenter N m‖≤A*N^2)))
        (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
        N M P κ η Cnear (spatialTile N m))
    (hfar : ∀ (m : IntPlane) (y : Space), y ∈ localSlab (spatialTile N m) (N^2) →
      ‖∑ i ∈ s, ∑ p ∈ (pbox i).filter (fun p => A*N^2<‖v i p-spatialTileCenter N m‖),
        a i p*freePacket φ b N (ν i) (v i p) y‖^2 ≤
      Cf*spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M y) :
    (∫⁻ y in timeSlab (N^2), ENNReal.ofReal
      (‖∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket φ b N (ν i) (v i p) y‖^3)) ≤
      4*((ENNReal.ofReal (Cnear*packetConstant P κ η (N^2)))^3*
        ENNReal.ofReal (((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ))+
        ENNReal.ofReal (Cf^(3/2:ℝ)))*
      ∫⁻ y in timeSlab (N^2), ENNReal.ofReal ((spatialDensity (s.sigma pbox)
        (fun ip => a ip.1 ip.2) (fun ip => velocity φ (ν ip.1))
        (fun ip => v ip.1 ip.2) N M y)^(3/2:ℝ)) := by
  classical
  let q := fun m i => (pbox i).filter (fun p => ‖v i p-spatialTileCenter N m‖≤A*N^2)
  let U := fun m y => ∑ i ∈ s, ∑ p ∈ q m i, a i p*freePacket φ b N (ν i) (v i p) y
  let V := fun m y => ∑ i ∈ s, ∑ p ∈ (pbox i).filter
    (fun p => A*N^2<‖v i p-spatialTileCenter N m‖), a i p*freePacket φ b N (ν i) (v i p) y
  let H := spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M
  let Hnear := fun m => spatialDensity (s.sigma (q m)) (fun ip => a ip.1 ip.2)
    (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) N M
  have hnn (m : IntPlane) (y : Space) : 0≤Hnear m y := spatialDensity_nonneg_global ..
  have hD : Measurable (fun y => ENNReal.ofReal ((H y)^(3/2:ℝ))) := by
    have hh : Measurable H := measurable_spatialDensity ..
    fun_prop
  refine cubic_tile_assembly N (N^2) _ U V _ ?_ hD
    ((ENNReal.ofReal (Cnear*packetConstant P κ η (N^2)))^3)
    (ENNReal.ofReal (Cf^(3/2:ℝ))) _ _
    (fun m => ∫⁻ y in timeSlab (N^2), ENNReal.ofReal ((Hnear m y)^(3/2:ℝ)))
    ?_ ?_ ?_ ?_ le_rfl
  · intro m
    apply Continuous.measurable
    exact continuous_finset_sum s (fun i hi => continuous_finset_sum (q m i) (fun p hp =>
      continuous_const.mul (continuous_freePacket φ hφ b hb hbs hN _ _)))
  · intro m y hy
    exact packet_sum_near_far φ b s pbox a ν v N A (spatialTileCenter N m) y
  · intro m
    have hh := hnear m
    unfold LocalProfileEstimate densityCubeRoot at hh
    simp only [Finset.sum_sigma] at hh
    have he : (∫⁻ y in timeSlab (N^2), (ENNReal.ofReal (Hnear m y))^(3/2:ℝ)) =
        ∫⁻ y in timeSlab (N^2), ENNReal.ofReal ((Hnear m y)^(3/2:ℝ)) := by
      apply lintegral_congr
      intro y
      exact ENNReal.ofReal_rpow_of_nonneg (p := (3/2:ℝ)) (hnn m y) (by norm_num)
    have hh' := cubic_lintegral_le_of_l3 _ _ hh
    change (∫⁻ y in localSlab (spatialTile N m) (N^2), ENNReal.ofReal (‖U m y‖^3)) ≤
      _*(∫⁻ y in timeSlab (N^2), (ENNReal.ofReal (Hnear m y))^(3/2:ℝ)) at hh'
    rwa [he] at hh'
  · intro m y hy
    have hh := norm_cube_le_of_norm_sq hCf
      (spatialDensity_nonneg_global (s.sigma pbox) _ _ _ N M y) (hfar m y hy)
    calc
      _ ≤ ENNReal.ofReal (Cf^(3/2:ℝ)*(H y)^(3/2:ℝ)) := ENNReal.ofReal_le_ofReal hh
      _ = _ := ENNReal.ofReal_mul (Real.rpow_nonneg hCf _)
  · simpa only [Hnear,q,sigma_filter_near_positions] using
      spatial_tile_density_integrated_overlap (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1)) (fun ip => v ip.1 ip.2) hN M A (N^2)

theorem packetConstant_nonneg_global {P N : ℝ} (hP : 0≤P) (κ η : ℝ) :
    0≤packetConstant P κ η (N^2) := by
  have hl : 0≤Real.log (2+N^2) := Real.log_nonneg (by nlinarith [sq_nonneg N])
  unfold packetConstant
  positivity

/-- The far contribution is absorbed with a constant fixed before the loss
parameters and the scale. -/
theorem global_packet_coefficient_bound {Cn Cf J : ℝ}
    (hCn : 0≤Cn) (hCf : 0≤Cf) (hJ : 0≤J) :
    ∃ C : ℝ, 0<C ∧ ∀ P κ η N : ℝ, 1≤P → 0≤κ → 0≤η → 1≤N →
      4*((Cn*packetConstant P κ η (N^2))^3*J+Cf^(3/2:ℝ)) ≤
        (C*packetConstant P κ η (N^2))^3 := by
  let B := localLossAbsorptionConstant
  let D := 4*(Cn^3*J+Cf^(3/2:ℝ)*B)
  have hB : 0≤B := localLossAbsorptionConstant_pos.le
  have hCf' : 0≤Cf^(3/2:ℝ) := Real.rpow_nonneg hCf _
  have hD : 0≤D := by dsimp [D]; positivity
  have hDcube : D≤(D+1)^3 := by nlinarith [sq_nonneg D, pow_nonneg hD 3]
  refine ⟨D+1,by positivity,?_⟩
  intro P κ η N hP hκ hη hN
  let K := packetConstant P κ η (N^2)
  have hK : 0≤K := packetConstant_nonneg_global (by linarith) κ η
  have hK3 : 0≤K^3 := pow_nonneg hK _
  have habs : 1≤B*K^3 := by
    have hh := local_loss_absorption hP hN hκ hη
    have hnn : 0≤P*N^(10*κ+η)*Real.log (2+N)^2 := by positivity
    dsimp [B,K]
    linarith
  have hf := mul_le_mul_of_nonneg_left habs hCf'
  calc
    _ ≤ D*K^3 := by dsimp [D,K] at *; nlinarith
    _ ≤ (D+1)^3*K^3 := mul_le_mul_of_nonneg_right hDcube hK3
    _ = _ := by ring

/-- Conversion of the coefficient bound to the extended-real coefficient
used by the assembled integral. -/
theorem global_packet_coefficient_bound_ennreal {Cn Cf J C K : ℝ}
    (hCn : 0≤Cn) (hCf : 0≤Cf) (hJ : 0≤J) (hC : 0≤C) (hK : 0≤K)
    (h : 4*((Cn*K)^3*J+Cf^(3/2:ℝ))≤(C*K)^3) :
    4*((ENNReal.ofReal (Cn*K))^3*ENNReal.ofReal J+ENNReal.ofReal (Cf^(3/2:ℝ))) ≤
      (ENNReal.ofReal (C*K))^3 := by
  have hh := ENNReal.ofReal_le_ofReal h
  rw [ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤4),
    ENNReal.ofReal_add (by positivity) (Real.rpow_nonneg hCf _),
    ENNReal.ofReal_mul (by positivity), ENNReal.ofReal_pow (by positivity),
    ENNReal.ofReal_pow (by positivity)] at hh
  norm_num at hh ⊢
  exact hh

end EllipticSquareFunction
