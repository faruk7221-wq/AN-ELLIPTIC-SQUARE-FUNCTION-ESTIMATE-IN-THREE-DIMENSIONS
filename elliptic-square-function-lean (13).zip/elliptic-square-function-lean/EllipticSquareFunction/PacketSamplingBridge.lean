import EllipticSquareFunction.ScaleComparisonAnalytic

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- The internal packet/sampling bridge is derived from the actual discrete
external input, for every real R≥2. The constructed setup has adequate label
bounds. Its initial smooth partition window and spacing are supplied by T₀. -/
theorem packetSamplingEstimates_from_discrete (G : GraphSetup) (T₀ : DiscreteSetup)
    (heφ : T₀.φ=G.φ) (hphase : ContinuedPhase G.φ) {M : ℝ} (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=G.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      (DiscreteDensityInput S → PacketSamplingEstimates G M) := by
  obtain ⟨S,hSφ,hSχ,hSD,hdyadic⟩ := dyadic_packet_sampling_bridge
    (enlargedCapGraph G) T₀ heφ hphase hM
  refine ⟨S,hSφ,hSχ,hSD,?_⟩
  intro hinput κ η hκ hκ' hη hη'
  obtain ⟨A,B,hA,hB,hbound⟩ := hdyadic hinput κ η hκ hκ' hη hη'
  let α := (10*κ+η)/6
  let C := (4:ℝ)^α*2^(2/3:ℝ)
  let K := ((4:ℝ)^M)^2
  have hα : 0≤α := by dsimp [α]; positivity
  have hC : 0<C := by dsimp [C]; positivity
  have hK : 0<K := by dsimp [K]; positivity
  refine ⟨A*C,B*K,mul_pos hA hC,mul_pos hB hK,?_⟩
  intro R hR n ν f hf
  obtain ⟨j,hj,hRS,hSR⟩ := exists_upper_dyadic_square hR
  have hR₀ : 0<R := by linarith
  have hadm := admissibleFamily_upper_scale G hR₀ hRS hSR ν f hf
  obtain ⟨H,hH,hpacket,hdensity⟩ := hbound j hj n ν f hadm
  refine ⟨H,hH,?_,?_⟩
  · apply hpacket.trans
    apply mul_le_mul_right'
    apply ENNReal.ofReal_le_ofReal
    have hh := mul_le_mul_of_nonneg_left (packet_loss_upper_scale hR hRS hSR hα) hA.le
    simpa only [α,C,mul_assoc] using hh
  · intro y
    have hh := mul_le_mul_of_nonneg_left (smoothedSquareDensity_upper_scale G hR₀ hRS hSR hM ν f y) hB.le
    exact (hdensity y).trans (by simpa only [K,mul_assoc] using hh)

end EllipticSquareFunction
