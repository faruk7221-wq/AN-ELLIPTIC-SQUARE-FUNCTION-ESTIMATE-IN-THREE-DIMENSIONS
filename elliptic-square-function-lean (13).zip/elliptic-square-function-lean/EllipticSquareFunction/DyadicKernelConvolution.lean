import EllipticSquareFunction.PositiveTubeKernels

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- The pointwise normalized tube series really is summable. -/
theorem normalized_dyadic_kernel_summable {R M : ℝ} (hR : 0<R) (hM : 0<M)
    (V : Plane) (y : Space) :
    Summable (fun m : ℕ => ((2:ℝ)^m)^(-(M-3))*
      symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V y) := by
  have hs := (dyadic_bracket_majorant hM (shearScale (Real.sqrt R) R V y)).1.mul_left ((R^2)⁻¹)
  simp_rw [dyadic_tube_normalization hR M V] at hs
  apply (summable_mul_left_iff (by positivity : 2*Real.pi≠0)).mp
  simpa only [mul_assoc] using hs

/-- The real dyadic majorant transferred to nonnegative extended reals. -/
theorem ofReal_tubeKernel_dyadic_majorant {R M : ℝ} (hR : 0<R) (hM : 0<M)
    (V : Plane) (y : Space) :
    ENNReal.ofReal (tubeKernel R M V y) ≤ ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*
      ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
        ENNReal.ofReal (symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V y) := by
  have hh := ENNReal.ofReal_le_ofReal (tubeKernel_normalized_dyadic_majorant hR hM V y)
  rw [ENNReal.ofReal_mul (by positivity), ENNReal.ofReal_tsum_of_nonneg
    (fun m => mul_nonneg (by positivity) (symmetricTubeAverageKernel_nonneg ..))
    (normalized_dyadic_kernel_summable hR hM V y)] at hh
  simpa only [ENNReal.ofReal_mul (by positivity : 0≤((2:ℝ)^(_ : ℕ))^(-(M-3)))] using hh

/-- Tonelli passes the dyadic kernel majorant through positive convolution.
No finiteness assumption on the tested nonnegative function is used. -/
theorem positive_tubeKernel_dyadic_convolution {R M : ℝ} (hR : 0<R) (hM : 0<M)
    (V : Plane) (g : Space → ℝ≥0∞) (hg : Measurable g) :
    (∫⁻ z, ENNReal.ofReal (tubeKernel R M V z)*g z) ≤
      ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*∑' m : ℕ,
        ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
          (∫⁻ z, ENNReal.ofReal (symmetricTubeAverageKernel
            ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V z)*g z) := by
  have hm (m : ℕ) : Measurable (fun z => ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
      (ENNReal.ofReal (symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V z)*g z)) :=
    measurable_const.mul ((measurable_symmetricTubeAverageKernel ..).ennreal_ofReal.mul hg)
  calc
    _ ≤ ∫⁻ z, (ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*
        ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
          ENNReal.ofReal (symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V z))*g z :=
      lintegral_mono (fun z => mul_le_mul_right' (ofReal_tubeKernel_dyadic_majorant hR hM V z) _)
    _ = _ := by
      simp only [mul_assoc, ← ENNReal.tsum_mul_right]
      rw [lintegral_const_mul'' _ (Measurable.ennreal_tsum hm).aemeasurable,
        lintegral_tsum (fun m => (hm m).aemeasurable)]
      congr 1
      apply tsum_congr
      intro m
      exact lintegral_const_mul'' _ ((measurable_symmetricTubeAverageKernel ..).ennreal_ofReal.mul hg).aemeasurable

/-- The actual positive kernel convolution is dominated by a weighted sum of
Nikodym operators. Their aspect ratio is fixed across scales and directions;
the lengths are explicitly summed, never put in an uncontrolled supremum. -/
theorem tubeKernel_convolution_le_nikodym_sum {R M F : ℝ} (hR : 1≤R)
    (hM : 0<M) (hF : 0≤F) (V : Plane) (hV : ‖V‖≤F)
    (h : Space → ℝ) (hh : Measurable h) (x : Space) :
    (∫⁻ z, ENNReal.ofReal (tubeKernel R M V z)*ENNReal.ofReal |h (x+z)|) ≤
      ENNReal.ofReal ((2*Real.pi)*(2:ℝ)^M)*ENNReal.ofReal (2*(1+F)^3)*
        ∑' m : ℕ, ENNReal.ofReal (((2:ℝ)^m)^(-(M-3)))*
          nikodym (Real.sqrt R/(2*(1+F)*R)) (2*(1+F)*((2:ℝ)^m*R)) h x := by
  have hR₀ : 0<R := by linarith
  have hsR : Real.sqrt R≤R := by
    apply (Real.sqrt_le_iff).mpr
    constructor
    · exact hR₀.le
    · nlinarith
  have hbase := positive_tubeKernel_dyadic_convolution hR₀ hM V
    (fun z => ENNReal.ofReal |h (x+z)|)
    ((hh.comp ((measurable_const : Measurable (fun _ : Space => x)).add measurable_id)).abs.ennreal_ofReal)
  apply hbase.trans
  simp only [mul_assoc]
  apply mul_le_mul_left'
  rw [← ENNReal.tsum_mul_left]
  apply ENNReal.tsum_le_tsum
  intro m
  have hterm := normalized_tube_kernel_le_nikodym h hh x
    (by positivity : 0<(2:ℝ)^m*Real.sqrt R) (by positivity : 0<(2:ℝ)^m*R)
    (mul_le_mul_of_nonneg_left hsR (by positivity : 0≤(2:ℝ)^m)) hF V hV
  have he : ((2:ℝ)^m*Real.sqrt R)/(2*(1+F)*((2:ℝ)^m*R))=
      Real.sqrt R/(2*(1+F)*R) := by
    field_simp
    ring
  rw [he] at hterm
  have hb := mul_le_mul_left' hterm (ENNReal.ofReal (((2:ℝ)^m)^(-(M-3))))
  simpa only [mul_assoc,mul_left_comm] using hb

end EllipticSquareFunction
