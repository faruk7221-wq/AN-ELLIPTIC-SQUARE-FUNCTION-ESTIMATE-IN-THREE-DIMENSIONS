import EllipticSquareFunction.ImmersionGraphConstruction

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- A fixed continuous linear functional commutes with the second derivative. -/
theorem hessian_continuous_linear_comp {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F : Plane → E} {a : Plane} (hF : ContDiffAt ℝ 2 F a)
    (l : E →L[ℝ] ℝ) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (fun b => l (F b))) a v w =
      l (fderiv ℝ (fderiv ℝ F) a v w) := by
  have he : fderiv ℝ (fun b => l (F b)) =ᶠ[𝓝 a]
      (fun b => l.comp (fderiv ℝ F b)) := by
    filter_upwards [hF.eventually (by norm_num)] with b hb
    exact (l.hasFDerivAt.comp b (hb.differentiableAt (by norm_num)).hasFDerivAt).fderiv
  rw [he.fderiv_eq]
  have hd := (hF.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num)
  rw [fderiv_clm_comp (differentiableAt_const l) hd]
  simp

/-- Normal Hessian equals the normal component of the second derivative of
the immersion. Dividing by the Euclidean norm of N gives the second
fundamental form for the corresponding unit normal. -/
theorem normalHeight_hessian {F : Plane → Space} {a : Plane}
    (hF : ContDiffAt ℝ 2 F a) (N : Space) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (normalHeight F N)) a v w =
      spacePair N (fderiv ℝ (fderiv ℝ F) a v w) :=
  hessian_continuous_linear_comp hF (spacePairLinear N).toContinuousLinearMap v w

/-- The standard scalar second fundamental form in a smooth parametrization,
when N is a unit normal at a. Normality and unit length are separate geometric
conditions, so this expression is defined for every N. -/
def euclideanSecondFundamentalForm (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a v w : Plane) : ℝ :=
  @inner ℝ EuclideanThree _ N (fderiv ℝ (fderiv ℝ F) a v w)

theorem euclidean_normal_height_hessian {F : Plane → EuclideanThree} {a : Plane}
    (hF : ContDiffAt ℝ 2 F a) (N : EuclideanThree) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (fun b => @inner ℝ EuclideanThree _ N (F b))) a v w =
      euclideanSecondFundamentalForm F N a v w :=
  hessian_continuous_linear_comp hF (innerSL ℝ N) v w

end EllipticSquareFunction
