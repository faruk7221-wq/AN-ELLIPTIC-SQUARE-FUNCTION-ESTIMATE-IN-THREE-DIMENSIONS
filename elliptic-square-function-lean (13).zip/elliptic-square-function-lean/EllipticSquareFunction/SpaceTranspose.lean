import EllipticSquareFunction.AffineFrequency
import EllipticSquareFunction.AffineSquareFunctionNorm

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- The Euclidean Fourier pairing on product spacetime, independently of
the equivalent product norm used for its topology. -/
def spacePairLinear : Space →ₗ[ℝ] Module.Dual ℝ Space where
  toFun y :=
    { toFun := fun z => spacePair y z
      map_add' := by intros; simp [spacePair,inner_add_right]; ring
      map_smul' := by intros; simp [spacePair,inner_smul_right]; ring }
  map_add' := by
    intro x y
    apply LinearMap.ext
    intro z
    change spacePair (x+y) z=spacePair x z+spacePair y z
    simp [spacePair,inner_add_left]
    ring
  map_smul' := by
    intro c x
    apply LinearMap.ext
    intro z
    change spacePair (c • x) z=c*spacePair x z
    simp [spacePair,inner_smul_left]
    ring

theorem spacePairLinear_injective : Function.Injective spacePairLinear := by
  apply LinearMap.ker_eq_bot.mp
  apply LinearMap.ker_eq_bot'.mpr
  intro y hy
  have hsp := congrArg (fun l : Module.Dual ℝ Space => l (y.1,0)) hy
  have ht := congrArg (fun l : Module.Dual ℝ Space => l (0,1)) hy
  have hy₁ : y.1=0 := by
    have hh : @inner ℝ Plane _ y.1 y.1=0 := by simpa [spacePairLinear,spacePair] using hsp
    exact inner_self_eq_zero.mp hh
  have hy₂ : y.2=0 := by simpa [spacePairLinear,spacePair] using ht
  exact Prod.ext hy₁ hy₂

def spacePairEquiv : Space ≃ₗ[ℝ] Module.Dual ℝ Space :=
  LinearEquiv.ofBijective spacePairLinear ⟨spacePairLinear_injective,
    (LinearMap.injective_iff_surjective_of_finrank_eq_finrank
      (Subspace.dual_finrank_eq (K := ℝ) (V := Space)).symm).mp spacePairLinear_injective⟩

/-- The actual transpose for the Fourier pairing, as a continuous linear equivalence. -/
def spaceTranspose (L : Space ≃L[ℝ] Space) : Space ≃L[ℝ] Space :=
  ((spacePairEquiv.trans L.toLinearEquiv.dualMap).trans spacePairEquiv.symm).toContinuousLinearEquiv

theorem spaceTranspose_pair (L : Space ≃L[ℝ] Space) (y z : Space) :
    spacePair (spaceTranspose L y) z=spacePair y (L z) := by
  have hh := spacePairEquiv.apply_symm_apply (L.toLinearEquiv.dualMap (spacePairEquiv y))
  have he := congrArg (fun l : Module.Dual ℝ Space => l z) hh
  exact he

end EllipticSquareFunction
