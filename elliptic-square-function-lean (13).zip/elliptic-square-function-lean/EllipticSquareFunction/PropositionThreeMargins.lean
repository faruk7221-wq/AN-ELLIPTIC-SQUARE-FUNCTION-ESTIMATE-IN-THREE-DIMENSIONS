import EllipticSquareFunction.PropositionThree
import EllipticSquareFunction.RebasedUniformMargins

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

theorem proposition_three_unit_uniform_setup_margins {ι : Type*}
    (T₀ : DiscreteSetup) (hphase : ContinuedPhase T₀.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (ψ : SchwartzMap ℝ ℂ)
    {c σ F M : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M) :
    ∃ Z A Z' : ℝ, 0<Z ∧ 1≤A ∧ 0<Z' ∧
      ∀ S : DiscreteSetup, S.φ=T₀.φ → S.χ=T₀.χ → DiscreteDensityInput S →
        3≤S.C₂ → A+1≤S.C₁ → F+Z+Z'≤S.frequencyBound →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
          ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j →
          let N : ℝ := (2:ℝ)^j
          ∀ (T : Finset ℤ) (d : ℤ → FinitePacketArray ι),
          (∀ k ∈ T, SeparatedPacketArray (d k) N c σ F) →
          l3 (fun y => ∑ k ∈ T, arrayTimePacket (d k) T₀.φ b ψ N ((k:ℝ)*N^2) y) volume ≤
            ENNReal.ofReal (C*packetConstant P κ η (N^2))*
              (∫⁻ y, (ENNReal.ofReal (∑ k ∈ T,
                arrayPacketDensity (d k) T₀.φ N M ((k:ℝ)*N^2) y))^(3/2:ℝ))^(1/3:ℝ) := by
  have hφ : ContDiff ℝ (⊤ : ℕ∞) T₀.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  obtain ⟨Z,A,Z',hZ,hA,hZ',hbound⟩ := equation_5_10_uniform_setup_margins (ι := ι)
    T₀ hphase b hb hbs hc hσ hF hM
  refine ⟨Z,A,Z',hZ,hA,hZ',?_⟩
  intro S heφ heχ hinput hQ₂ hA₁ hFZ
  obtain ⟨Cp,Cd,hCp,hCd,B,hbound⟩ := hbound S heφ heχ hinput hQ₂ hA₁ hFZ
  obtain ⟨Ct,hCt,htime⟩ := time_packet_estimate_of_rebased ψ B (by linarith : 0≤M) hCd.le
  refine ⟨Ct*Cp,mul_pos hCt hCp,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj N T d hd
  have hN : 0<N := by positivity
  have hK : 0≤Cp*packetConstant P κ η (N^2) :=
    mul_nonneg hCp.le (packetConstant_nonneg_global (by linarith) κ η)
  have hf (k : ℤ) (hk : k∈T) (Δ : ℝ) :=
    hbound j hj (d k).labels (d k).positions (d k).coefficient (d k).frequency (d k).position
      (hd k hk).1 (hd k hk).2.1 (hd k hk).2.2 Δ
  have hh := htime (N^2) (Cp*packetConstant P κ η (N^2)) T
    (fun k => arrayPacketSum (d k) T₀.φ b N) (fun k => arraySpatialDensity (d k) T₀.φ N M)
    (sq_pos_of_pos hN) hK
    (fun k _ => continuous_arrayPacketSum (d k) T₀.φ hφ.continuous b hb.continuous hbs hN.ne')
    (fun k _ => continuous_arraySpatialDensity (d k) T₀.φ N M)
    (fun k _ y => spatialDensity_nonneg_global ..)
    (fun k hk Δ => by simpa only [arrayPacketSum,arraySpatialDensity,bracket,Real.norm_eq_abs] using hf k hk Δ)
  simpa only [arrayTimePacket,arrayPacketDensity,mul_assoc] using hh


end EllipticSquareFunction
