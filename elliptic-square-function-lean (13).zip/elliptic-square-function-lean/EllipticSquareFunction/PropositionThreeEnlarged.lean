import EllipticSquareFunction.PropositionThreeMargins

/-! Proposition 3 for finite profile families with constructed setup margins. -/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- An adequate setup is constructed before requiring its external density input.
Constants remain uniform in loss parameters, scales, time origins and arrays. -/
theorem proposition_three_enlarged_setup {ι : Type*} {n : ℕ}
    (T₀ : DiscreteSetup) (hphase : ContinuedPhase T₀.φ)
    (b : Fin n → Plane → ℂ) (hb : ∀ r, ContDiff ℝ (⊤ : ℕ∞) (b r))
    (hbs : ∀ r, HasCompactSupport (b r)) (ψ : Fin n → SchwartzMap ℝ ℂ)
    {c σ F M : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F) (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=T₀.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      T₀.frequencyBound≤S.frequencyBound ∧ T₀.C₁≤S.C₁ ∧ T₀.C₂≤S.C₂ ∧
      (DiscreteDensityInput S →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
          ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ (T : Fin n → Finset ℤ)
          (d : Fin n → ℤ → FinitePacketArray ι) (s : Fin n → ℝ),
          (∀ r, ∀ k ∈ T r, SeparatedPacketArray (d r k) ((2:ℝ)^j) c σ F) →
          l3 (fun y => ∑ r, ∑ k ∈ T r, arrayTimePacket (d r k) T₀.φ (b r) (ψ r)
            ((2:ℝ)^j) (s r+(k:ℝ)*((2:ℝ)^j)^2) y) volume ≤
          ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
            (∫⁻ y, (ENNReal.ofReal (∑ r, ∑ k ∈ T r,
              arrayPacketDensity (d r k) T₀.φ ((2:ℝ)^j) M (s r+(k:ℝ)*((2:ℝ)^j)^2) y))^(3/2:ℝ))^(1/3:ℝ)) := by
  classical
  have hφ : ContDiff ℝ (⊤ : ℕ∞) T₀.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩; exact hφ
  have hs (r : Fin n) := proposition_three_unit_uniform_setup_margins (ι := ι)
    T₀ hphase (b r) (hb r) (hbs r) (ψ r) hc hσ hF hM
  choose Z A Z' hZ hA hZ' hs using hs
  let Fmax := ∑ r, (F+Z r+Z' r)
  let Amax := ∑ r, (A r+1)
  have hfreq (r : Fin n) : F+Z r+Z' r≤Fmax :=
    Finset.single_le_sum (fun q (_ : q∈(Finset.univ : Finset (Fin n))) =>
      (by linarith [hZ q,hZ' q] : 0≤F+Z q+Z' q)) (Finset.mem_univ r)
  have hpos (r : Fin n) : A r+1≤Amax :=
    Finset.single_le_sum (fun q (_ : q∈(Finset.univ : Finset (Fin n))) =>
      (by linarith [hA q] : 0≤A q+1)) (Finset.mem_univ r)
  let S := enlargeSetup T₀ Fmax Amax 3
  refine ⟨S,rfl,rfl,rfl,le_max_left _ _,le_max_left _ _,le_max_left _ _,?_⟩
  intro hinput
  apply uniform_finite_time_profiles T₀.φ hφ.continuous b (fun r => (hb r).continuous) hbs
    (fun r => (ψ r : ℝ → ℂ)) (fun r => (ψ r).continuous) c σ F M
  intro r
  obtain ⟨C,hC,hbound⟩ := hs r S rfl rfl hinput (le_max_right _ _)
    ((hpos r).trans (le_max_right _ _)) ((hfreq r).trans (le_max_right _ _))
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  exact ⟨P,hP,uniform_time_profile_of_unit T₀.φ hφ.continuous (b r) (hb r).continuous
    (hbs r) (ψ r) (ψ r).continuous c σ F M C P κ η hbound⟩


end EllipticSquareFunction
