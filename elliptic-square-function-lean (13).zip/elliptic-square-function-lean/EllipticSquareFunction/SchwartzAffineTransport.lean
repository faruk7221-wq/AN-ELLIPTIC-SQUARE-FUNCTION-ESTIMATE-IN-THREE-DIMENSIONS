import EllipticSquareFunction.AffineFourierTransport
import EllipticSquareFunction.PolynomialRebasing

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- A linear Fourier phase has bounded derivatives of every fixed order. -/
theorem oscillation_linear_temperate (l : Space →L[ℝ] ℝ) :
    Function.HasTemperateGrowth (fun y => oscillation (l y)) := by
  refine ⟨contDiff_oscillation.comp l.contDiff,?_⟩
  intro n
  refine ⟨0,‖iteratedFDeriv ℝ n oscillation 0‖*‖l‖^n,?_⟩
  intro y
  simp only [pow_zero,mul_one]
  change ‖iteratedFDeriv ℝ n (oscillation ∘ l) y‖≤_
  rw [l.iteratedFDeriv_comp_right contDiff_oscillation y (by exact_mod_cast (le_top : (n:ℕ∞)≤⊤))]
  have hb := (iteratedFDeriv ℝ n oscillation (l y)).norm_compContinuousLinearMap_le (fun _ => l)
  simpa only [oscillation_derivative_norm_constant,Finset.prod_const,Finset.card_univ,Fintype.card_fin] using hb

/-- Affine frequency transport preserves the actual Schwartz function class. -/
def schwartzModulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : SchwartzMap Space ℂ) : SchwartzMap Space ℂ :=
  SchwartzMap.bilinLeftCLM (ContinuousLinearMap.mul ℂ ℂ)
    (oscillation_linear_temperate (LinearMap.toContinuousLinearMap (spacePairLinear b)))
    (SchwartzMap.compCLMOfContinuousLinearEquiv ℂ L f)

theorem schwartzModulatedLinearPullback_apply (L : Space ≃L[ℝ] Space) (b : Space)
    (f : SchwartzMap Space ℂ) (y : Space) :
    schwartzModulatedLinearPullback L b f y=modulatedLinearPullback L b f y := by
  change f (L y)*oscillation (spacePair b y)=oscillation (spacePair b y)*f (L y)
  exact mul_comm _ _

/-- Exact Fourier-support transport; geometric cap containment can now be
checked on the inverse-transpose preimage without another analytic premise. -/
theorem support_fourier_modulatedLinearPullback (L : Space ≃L[ℝ] Space) (b : Space)
    (f : Space → ℂ) :
    Function.support (fourierTransform (modulatedLinearPullback L b f))=
      (fun η => spaceTranspose L.symm (η-b)) ⁻¹' Function.support (fourierTransform f) := by
  have hJ : (((|(LinearMap.det L.toLinearMap)⁻¹|:ℝ):ℂ))≠0 := by
    exact_mod_cast (abs_ne_zero.mpr (inv_ne_zero L.toLinearEquiv.isUnit_det'.ne_zero))
  ext η
  simp only [Function.mem_support,Set.mem_preimage,fourierTransform_modulatedLinearPullback,
    mul_ne_zero_iff]
  exact ⟨And.right,fun h => ⟨hJ,h⟩⟩

end EllipticSquareFunction
