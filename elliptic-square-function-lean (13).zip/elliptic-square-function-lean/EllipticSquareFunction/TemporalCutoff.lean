import EllipticSquareFunction.TimeTiles

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

theorem schwartz_bracket_bound (ψ : SchwartzMap ℝ ℂ) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ u : ℝ, ‖ψ u‖*bracket u^L≤C := by
  let C := (2:ℝ)^L*(Finset.Iic (L,0)).sup (fun m => SchwartzMap.seminorm ℝ m.1 m.2) ψ
  have hh (u : ℝ) : ‖ψ u‖*bracket u^L≤C := by
    have h := SchwartzMap.one_add_le_sup_seminorm_apply (𝕜 := ℝ)
      (m := (L,0)) (k := L) (n := 0) le_rfl le_rfl ψ u
    simpa only [norm_iteratedFDeriv_zero,bracket,mul_comm] using h
  have hC : 0≤C := (mul_nonneg (norm_nonneg _) (pow_nonneg (bracket_pos (0:ℝ)).le _)).trans (hh 0)
  exact ⟨C+1,by linarith,fun u => (hh u).trans (by linarith)⟩

/-- A Schwartz cutoff absorbs any fixed polynomial rebasing loss uniformly
on a unit slab. Both integer exponents are fixed before the time origins. -/
theorem schwartz_absorbs_time_loss (ψ : SchwartzMap ℝ ℂ) (A B : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ u a : ℝ, (0≤u-a ∧ u-a≤1) →
      ‖ψ u‖*bracket a^B ≤ C*bracket a^(-(A:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := schwartz_bracket_bound ψ (A+B)
  refine ⟨C*2^(A+B),by positivity,?_⟩
  intro u a h
  have hp := pow_le_pow_left₀ (bracket_pos a).le (bracket_time_slab_comparison h).2 (A+B)
  rw [mul_pow] at hp
  have hh := mul_le_mul_of_nonneg_left hp (norm_nonneg (ψ u))
  have hh' := mul_le_mul_of_nonneg_right (hbound u) (by positivity : (0:ℝ)≤2^(A+B))
  have htot : (‖ψ u‖*bracket a^B)*bracket a^A≤C*2^(A+B) := by
    rw [pow_add] at hh
    nlinarith
  rw [Real.rpow_neg (bracket_pos a).le,Real.rpow_natCast]
  exact (le_div_iff₀ (pow_pos (bracket_pos a) A)).mpr htot

theorem sqrt_polynomial_time_loss {C : ℝ} (hC : 0≤C) (B : ℕ) (a : ℝ) :
    Real.sqrt (C*bracket a^B) ≤ Real.sqrt C*bracket a^B := by
  rw [Real.sqrt_mul hC]
  apply mul_le_mul_of_nonneg_left _ (Real.sqrt_nonneg C)
  have hp : 1≤bracket a^B := one_le_pow₀ (by dsimp [bracket]; exact le_add_of_nonneg_right (abs_nonneg _))
  apply (Real.sqrt_le_iff).mpr
  constructor
  · linarith
  · nlinarith

theorem l3_bounded_multiplier (μ : Measure Space) (f g : Space → ℂ) {C : ℝ}
    (hC : 0≤C) (h : ∀ᵐ y ∂μ, ‖g y‖≤C) :
    l3 (fun y => g y*f y) μ≤ENNReal.ofReal C*l3 f μ := by
  have hh : eLpNorm (fun y => g y*f y) 3 μ ≤ eLpNorm (fun y => C*‖f y‖) 3 μ := by
    apply eLpNorm_mono_ae_real
    filter_upwards [h] with y hy
    rw [norm_mul]
    exact mul_le_mul_of_nonneg_right hy (norm_nonneg _)
  rw [eLpNorm_nonneg_const_mul μ 3 _ hC,eLpNorm_norm] at hh
  exact hh

/-- Quantitative cutoff multiplication, preserving a polynomial-loss
estimate while replacing it by arbitrary prescribed temporal decay. -/
theorem cutoff_slab_norm_bound (ψ : SchwartzMap ℝ ℂ) (A B : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ (μ : Measure Space) (F : Space → ℂ) (u : Space → ℝ) (a K Cd : ℝ)
      (D : ℝ≥0∞), 0≤K → 0≤Cd →
      (∀ᵐ y ∂μ, 0≤u y-a ∧ u y-a≤1) →
      l3 F μ≤ENNReal.ofReal (K*Real.sqrt (Cd*bracket a^B))*D →
      l3 (fun y => ψ (u y)*F y) μ ≤
        ENNReal.ofReal (C*K*Real.sqrt Cd)*ENNReal.ofReal (bracket a^(-(A:ℝ)))*D := by
  obtain ⟨C,hC,hbound⟩ := schwartz_absorbs_time_loss ψ A B
  refine ⟨C,hC,?_⟩
  intro μ F u a K Cd D hK hCd hu hF
  let q := bracket a^(-(A:ℝ))
  let w := bracket a^B
  have hw : 0<w := pow_pos (bracket_pos a) B
  have hq : 0<q := Real.rpow_pos_of_pos (bracket_pos a) _
  have hm : ∀ᵐ y ∂μ, ‖ψ (u y)‖≤C*q/w := by
    filter_upwards [hu] with y hy
    exact (le_div_iff₀ hw).mpr (hbound (u y) a hy)
  have hh := l3_bounded_multiplier μ F (fun y => ψ (u y)) (by positivity : 0≤C*q/w) hm
  have hp := mul_le_mul_of_nonneg_left (sqrt_polynomial_time_loss hCd B a) hK
  have hF' := hF.trans (mul_le_mul_right' (ENNReal.ofReal_le_ofReal hp) D)
  apply (hh.trans (mul_le_mul_left' hF' _)).trans
  have he : (C*q/w)*(K*(Real.sqrt Cd*w))=(C*K*Real.sqrt Cd)*q := by
    field_simp
    ring
  rw [← mul_assoc,← ENNReal.ofReal_mul (by positivity : 0≤C*q/w),he,
    ENNReal.ofReal_mul (by positivity : 0≤C*K*Real.sqrt Cd)]

end EllipticSquareFunction
