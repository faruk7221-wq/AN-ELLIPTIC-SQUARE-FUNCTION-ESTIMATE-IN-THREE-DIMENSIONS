import EllipticSquareFunction.OscillatoryDecay

/-! # Uniform oscillatory bounds for compact parameter families

Compactness is applied to the spatial derivatives of a jointly smooth
amplitude. This supplies a single decay constant for all times in `[0,1]`,
as required in (4.6).
-/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

set_option maxHeartbeats 800000

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]

/-- Spatial derivatives of a jointly smooth amplitude are jointly continuous. -/
theorem continuous_iteratedFDeriv_slice (H : E × Plane → ℂ)
    (hH : ContDiff ℝ (⊤ : ℕ∞) H) (k : ℕ) :
    Continuous (fun p : E × Plane => iteratedFDeriv ℝ k (fun ξ => H (p.1, ξ)) p.2) := by
  let A : Plane →L[ℝ] (E × Plane) := ContinuousLinearMap.inr ℝ E Plane
  have he (t : E) (ξ : Plane) : iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ =
      (iteratedFDeriv ℝ k H (t, ξ)).compContinuousLinearMap (fun _ => A) := by
    have hs : ContDiff ℝ (⊤ : ℕ∞) (fun p : E × Plane => H ((t, 0) + p)) :=
      hH.comp (contDiff_const.add contDiff_id)
    have hh := A.iteratedFDeriv_comp_right hs ξ
      (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤))
    simpa only [Function.comp_def, iteratedFDeriv_comp_add_left', A,
      ContinuousLinearMap.inr_apply, Prod.mk_add_mk, add_zero, zero_add] using hh
  simp_rw [he]
  exact (ContinuousMultilinearMap.compContinuousLinearMapL (fun _ : Fin k => A)).continuous.comp
    (hH.continuous_iteratedFDeriv (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤)))

/-- Uniform L¹ bounds for every fixed spatial derivative, with compact
parameter set and one common compact support. -/
theorem uniform_slice_derivative_integral (H : E × Plane → ℂ)
    (hH : ContDiff ℝ (⊤ : ℕ∞) H) {T : Set E} {K : Set Plane}
    (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ξ => H (t, ξ)) ⊆ K) (k : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t ∈ T, (∫ ξ, ‖iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ‖) ≤ C := by
  obtain ⟨B, hB⟩ := (hT.prod hK).exists_bound_of_continuousOn
    (continuous_iteratedFDeriv_slice H hH k).continuousOn
  refine ⟨max B 0 * volume.real K, by positivity, ?_⟩
  intro t ht
  have he : (∫ ξ in K, ‖iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ‖) =
      ∫ ξ, ‖iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ‖ := by
    apply setIntegral_eq_integral_of_forall_compl_eq_zero
    intro ξ hξ
    have hz : iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ = 0 := by
      by_contra hn
      exact hξ (hs t ht (support_iteratedFDeriv_subset k hn))
    rw [hz, norm_zero]
  rw [← he]
  calc
    _ ≤ ‖∫ ξ in K, ‖iteratedFDeriv ℝ k (fun ζ => H (t, ζ)) ξ‖‖ := le_abs_self _
    _ ≤ max B 0 * volume.real K := by
      apply norm_setIntegral_le_of_norm_le_const_ae' hK.measure_lt_top
      filter_upwards with ξ hξ
      simpa only [Real.norm_eq_abs, abs_norm] using (hB (t, ξ) ⟨ht, hξ⟩).trans (le_max_left B 0)

theorem uniform_slice_derivativeMass (H : E × Plane → ℂ)
    (hH : ContDiff ℝ (⊤ : ℕ∞) H) {T : Set E} {K : Set Plane}
    (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ξ => H (t, ξ)) ⊆ K) (L : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t ∈ T, derivativeMass L (fun ξ => H (t, ξ)) ≤ C := by
  choose B hB hb using fun k => uniform_slice_derivative_integral H hH hT hK hs k
  refine ⟨∑ k ∈ Finset.range (L + 1), B k, Finset.sum_nonneg (fun k _ => hB k), ?_⟩
  intro t ht
  exact Finset.sum_le_sum (fun k _ => hb k t ht)

/-- The uniform integration-by-parts principle used for the terminal kernel. -/
theorem uniform_oscillatory_decay (H : E × Plane → ℂ)
    (hH : ContDiff ℝ (⊤ : ℕ∞) H) {T : Set E} {K : Set Plane}
    (hT : IsCompact T) (hK : IsCompact K)
    (hs : ∀ t ∈ T, tsupport (fun ξ => H (t, ξ)) ⊆ K) (L : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ t ∈ T, ∀ z : Plane,
      ‖∫ ξ, H (t, ξ) * oscillation (@inner ℝ Plane _ z ξ)‖ ≤ C * bracket z ^ (-(L : ℝ)) := by
  obtain ⟨B, hB, hb⟩ := uniform_slice_derivativeMass H hH hT hK hs L
  refine ⟨2 ^ L * (1 + 2 ^ L) * B + 1, by positivity, ?_⟩
  intro t ht z
  have hf : ContDiff ℝ (⊤ : ℕ∞) (fun ξ => H (t, ξ)) :=
    hH.comp (contDiff_const.prodMk contDiff_id)
  have hfs : HasCompactSupport (fun ξ => H (t, ξ)) :=
    hK.of_isClosed_subset isClosed_closure (hs t ht)
  apply (oscillatoryIntegral_bracket_decay _ hf hfs L z).trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by dsimp [bracket]; positivity) _)
  have hm := mul_le_mul_of_nonneg_left (hb t ht) (by positivity : 0 ≤ (2 : ℝ) ^ L * (1 + 2 ^ L))
  linarith

theorem contDiff_oscillation : ContDiff ℝ (⊤ : ℕ∞) oscillation := by
  unfold oscillation
  apply (Complex.contDiff_exp : ContDiff ℂ (⊤ : ℕ∞) Complex.exp).restrict_scalars ℝ |>.comp
  exact (Complex.ofRealCLM.contDiff.comp (contDiff_const.mul contDiff_id)).mul contDiff_const

/-- Equation (4.6): one constant works for every `u ∈ [0,1]` and every
spatial argument. No derivative-bound hypothesis is added. -/
theorem window_kernel_uniform_decay (φ : Phase) (hφ : ContDiff ℝ (⊤ : ℕ∞) φ)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (hχs : HasCompactSupport χ)
    (L : ℕ) : ∃ C : ℝ, 0 < C ∧ ∀ u ∈ Icc (0 : ℝ) 1, ∀ z : Plane,
      ‖windowKernel φ χ z u‖ ≤ C * bracket z ^ (-(L : ℝ)) := by
  let H : ℝ × Plane → ℂ := fun p => (χ p.2 : ℂ) * oscillation (p.1 * φ p.2)
  have hχ' : ContDiff ℝ (⊤ : ℕ∞) (fun ξ => (χ ξ : ℂ)) :=
    Complex.ofRealCLM.contDiff.comp hχ
  have hH : ContDiff ℝ (⊤ : ℕ∞) H :=
    (hχ'.comp contDiff_snd).mul (contDiff_oscillation.comp
      (contDiff_fst.mul (hφ.comp contDiff_snd)))
  have hK : IsCompact (tsupport (fun ξ => (χ ξ : ℂ))) :=
    hχs.comp_left (g := Complex.ofReal) Complex.ofReal_zero
  have hs : ∀ u ∈ Icc (0 : ℝ) 1, tsupport (fun ξ => H (u, ξ)) ⊆
      tsupport (fun ξ => (χ ξ : ℂ)) := fun _ _ => tsupport_mul_subset_left
  obtain ⟨C, hC, hc⟩ := uniform_oscillatory_decay H hH isCompact_Icc hK hs L
  refine ⟨C, hC, ?_⟩
  intro u hu z
  have he : windowKernel φ χ z u = ∫ ξ, H (u, ξ) * oscillation (@inner ℝ Plane _ z ξ) := by
    apply integral_congr_ae
    filter_upwards with ξ
    dsimp only [H]
    rw [mul_assoc, ← oscillation_add]
    congr 2
    exact add_comm _ _
  rw [he]
  exact hc u hu z

/-- A common constant for any fixed finite collection of terminal windows. -/
theorem finite_window_kernel_decay {ι : Type*} (s : Finset ι)
    (φ : Phase) (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (χ : ι → Plane → ℝ)
    (hχ : ∀ i, ContDiff ℝ (⊤ : ℕ∞) (χ i)) (hχs : ∀ i, HasCompactSupport (χ i))
    (L : ℕ) : ∃ C : ℝ, 0 < C ∧ ∀ i ∈ s, ∀ u ∈ Icc (0 : ℝ) 1, ∀ z : Plane,
      ‖windowKernel φ (χ i) z u‖ ≤ C * bracket z ^ (-(L : ℝ)) := by
  choose C hC hc using fun i => window_kernel_uniform_decay φ hφ (χ i) (hχ i) (hχs i) L
  have hs : 0 ≤ ∑ i ∈ s, C i := Finset.sum_nonneg (fun i _ => (hC i).le)
  refine ⟨(∑ i ∈ s, C i) + 1, by linarith, ?_⟩
  intro i hi u hu z
  apply (hc i u hu z).trans
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg (by dsimp [bracket]; positivity) _)
  have h := Finset.single_le_sum (f := C) (fun k _ => (hC k).le) hi
  linarith

/-- The normalized oscillatory estimate underlying (4.10). The constant is
uniform over a compact set of frequency-window translations. -/
theorem translated_window_uniform_decay (b : Plane → ℂ)
    (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (A : ℝ) (L : ℕ) :
    ∃ C : ℝ, 0 < C ∧ ∀ a ∈ Metric.closedBall (0 : Plane) A, ∀ w : Plane,
      ‖∫ ζ, b ζ * (χ (ζ + a) : ℂ) * oscillation (@inner ℝ Plane _ w ζ)‖ ≤
        C * bracket w ^ (-(L : ℝ)) := by
  let H : Plane × Plane → ℂ := fun p => b p.2 * (χ (p.2 + p.1) : ℂ)
  have hχ' : ContDiff ℝ (⊤ : ℕ∞) (fun ξ => (χ ξ : ℂ)) :=
    Complex.ofRealCLM.contDiff.comp hχ
  have hH : ContDiff ℝ (⊤ : ℕ∞) H :=
    (hb.comp contDiff_snd).mul (hχ'.comp (contDiff_snd.add contDiff_fst))
  exact uniform_oscillatory_decay H hH (isCompact_closedBall _ _) hbs
    (fun _ _ => tsupport_mul_subset_left) L

end EllipticSquareFunction
