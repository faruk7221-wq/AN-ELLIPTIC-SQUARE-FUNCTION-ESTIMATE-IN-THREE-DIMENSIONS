import EllipticSquareFunction.SchwartzSmoothingRegularity
import EllipticSquareFunction.PositiveKernelDuality
import EllipticSquareFunction.KernelMaximalBound

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000
attribute [local instance] space_volume_neg_invariant space_volume_add_left_invariant

/-- Each finite adjoint kernel maximum is measurable. -/
theorem measurable_finiteKernelMax {ι : Type*} (s : Finset ι) (R M : ℝ)
    (V : ι → Plane) (h : Space → ℝ) (hh : Measurable h) :
    Measurable (finiteKernelMax s R M V h) := by
  classical
  have hk (i : ι) : Measurable (tubeKernel R M (V i)) := by
    unfold tubeKernel packetWeight bracket
    fun_prop
  have hi (i : ι) : Measurable (fun x => ∫⁻ z,
      ENNReal.ofReal (tubeKernel R M (V i) z)*ENNReal.ofReal |h (x+z)|) :=
    (((hk i).ennreal_ofReal.comp measurable_snd).mul
      ((hh.comp (measurable_fst.add measurable_snd)).abs.ennreal_ofReal)).lintegral_prod_right
  unfold finiteKernelMax
  induction s using Finset.induction_on with
  | empty => simpa using (measurable_const : Measurable (fun _ : Space => (0:ℝ≥0∞)))
  | @insert i s hnot ih =>
    simp only [Finset.sup_insert]
    exact (hi i).sup ih

/-- The Bochner convolution of squared Schwartz data equals the actual
positive integral in the duality calculation, in the same orientation. -/
theorem ofReal_schwartz_convolution (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) (y : Space) :
    ENNReal.ofReal (positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V) y)=
      ∫⁻ z, ENNReal.ofReal (‖f (y-z)‖^2)*ENNReal.ofReal (tubeKernel R M V z) := by
  simp_rw [← ENNReal.ofReal_mul (sq_nonneg _)]
  exact ofReal_integral_eq_lintegral_ofReal
    (by simpa only [sub_sub_cancel] using
      (schwartz_square_tube_integrable f hR hM V y).comp_sub_left y)
    (Filter.Eventually.of_forall (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..)))

/-- Lemma 5 for the squared Schwartz data required by the graph reduction.
All finiteness and dual-test hypotheses are proved, and the constant is
uniform in scale, family cardinality, directions and data. -/
theorem schwartz_tube_smoothing_bound (hinput : NikodymInput)
    {M F γ : ℝ} (hM : 3<M) (hF : 0≤F) (hγ : 0<γ) (hγ₁ : γ≤1) :
    ∃ A : ℝ, 0<A ∧ ∀ {ι : Type*} (s : Finset ι) (R : ℝ), 1≤R →
      ∀ V : ι → Plane, (∀ i∈s, ‖V i‖≤F) → ∀ f : ι → SchwartzMap Space ℂ,
      eLpNorm (fun y => ∑ i∈s, positiveConvolution (fun z => ‖f i z‖^2)
        (tubeKernel R M (V i)) y) (3/2) volume ≤
        ENNReal.ofReal (A*R^(γ/2))*eLpNorm (fun y => ∑ i∈s, ‖f i y‖^2) (3/2) volume := by
  classical
  obtain ⟨A,hA,hmax⟩ := finiteKernelMax_l3_bound hinput hM hF hγ hγ₁
  refine ⟨A,hA,?_⟩
  intro ι s R hR V hV f
  have hR₀ : 0<R := by linarith
  have hM₂ : 2<M := by linarith
  let D : Space → ℝ := fun y => ∑ i∈s,
    positiveConvolution (fun z => ‖f i z‖^2) (tubeKernel R M (V i)) y
  let G : Space → ℝ := fun y => ∑ i∈s, ‖f i y‖^2
  have hDpos : ∀ y, 0≤D y := fun y => Finset.sum_nonneg
    (fun i hi => integral_nonneg (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..)))
  have hGpos : ∀ y, 0≤G y := fun y => Finset.sum_nonneg (fun i hi => sq_nonneg _)
  have hDm : Measurable D := Finset.measurable_sum s (fun i hi =>
    (schwartz_square_convolution_regular (f i) hR₀ hM₂ (V i)).1.measurable)
  have hGm : Measurable G := Finset.measurable_sum s (fun i hi => (f i).continuous.norm.pow 2 |>.measurable)
  have hDlp : MemLp D (3/2) volume := memLp_finset_sum s (fun i hi =>
    schwartz_square_convolution_memLp (f i) hR₀ hM₂ (V i))
  apply lThreeHalves_le_of_positive_tests volume D hDpos hDm hDlp
  intro h hpos hm hlp
  have ht := finite_positive_kernel_duality_bound s
    (fun i y => ENNReal.ofReal (‖f i y‖^2))
    (fun i y => ENNReal.ofReal (tubeKernel R M (V i) y))
    (fun y => ENNReal.ofReal (h y))
    (fun i hi => ((f i).continuous.norm.pow 2).measurable.ennreal_ofReal)
    (fun i hi => by unfold tubeKernel packetWeight bracket; fun_prop)
    hm.ennreal_ofReal
  have hDe (y : Space) : ENNReal.ofReal (D y)=∑ i∈s,
      ∫⁻ z, ENNReal.ofReal (‖f i (y-z)‖^2)*ENNReal.ofReal (tubeKernel R M (V i) z) := by
    dsimp only [D]
    have hp : ∀ i∈s, 0≤positiveConvolution (fun z => ‖f i z‖^2) (tubeKernel R M (V i)) y :=
      fun i hi => integral_nonneg (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..))
    rw [ENNReal.ofReal_sum_of_nonneg hp]
    exact Finset.sum_congr rfl (fun i hi => ofReal_schwartz_convolution (f i) hR₀ hM₂ (V i) y)
  have hGe (x : Space) : ENNReal.ofReal (G x)=∑ i∈s, ENNReal.ofReal (‖f i x‖^2) :=
    ENNReal.ofReal_sum_of_nonneg (fun i hi => sq_nonneg _)
  have hmmax := measurable_finiteKernelMax s R M V h hm
  have hhld := positive_holder_three_halves volume (fun x => ENNReal.ofReal (G x))
    (finiteKernelMax s R M V h) hGm.ennreal_ofReal.aemeasurable hmmax.aemeasurable
  rw [eLpNorm_ofReal_nonneg volume G hGpos] at hhld
  have ht' : (∫⁻ y, ENNReal.ofReal (D y)*ENNReal.ofReal (h y)) ≤
      ∫⁻ x, ENNReal.ofReal (G x)*finiteKernelMax s R M V h x := by
    simpa only [hDe,hGe,finiteKernelMax,abs_of_nonneg (hpos _)] using ht
  exact (ht'.trans hhld).trans (by
    have hx := mul_le_mul_left' (hmax s R hR V hV h hm hlp) (eLpNorm G (3/2) volume)
    simpa only [mul_assoc,mul_left_comm,mul_comm] using hx)

end EllipticSquareFunction
