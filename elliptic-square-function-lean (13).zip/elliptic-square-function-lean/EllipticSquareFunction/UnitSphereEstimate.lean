import EllipticSquareFunction.SphericalCurvature
import EllipticSquareFunction.ManifoldDerivativeInterface
import Mathlib.Geometry.Manifold.Instances.Sphere

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

local instance : Fact (Module.finrank ℝ EuclideanThree = 2+1) :=
  ⟨finrank_euclideanSpace_fin⟩

/-- The canonical parametrizations of the unit sphere satisfy all the
immersion and curvature premises of the general manifold adapter. -/
theorem unit_sphere_elliptic_immersion :
    ManifoldEllipticImmersion (Subtype.val : Metric.sphere (0 : EuclideanThree) 1 → EuclideanThree) := by
  let f : Metric.sphere (0 : EuclideanThree) 1 → EuclideanThree := Subtype.val
  have hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f :=
    contMDiff_coe_sphere
  intro x
  let F := manifoldSurfaceParam f x
  let U := (chartAt Plane x).target
  let a := chartAt Plane x x
  have ha : a ∈ U := mem_chart_target Plane x
  have hU : IsOpen U := (chartAt Plane x).open_target
  have hF : ContDiffOn ℝ 2 F U := (manifold_surface_param_smooth hf x).of_le (by norm_cast)
  have hD : Function.Injective (fderiv ℝ F a) := by
    rw [← manifold_derivative_eq_chart_derivative hf x]
    exact mfderiv_coe_sphere_injective x
  have hn : ∀ b ∈ U, ‖F b‖=1 := by
    intro b _
    exact mem_sphere_zero_iff_norm.mp ((chartAt Plane x).symm b).property
  refine ⟨hD,F a,hn a ha,?_,unit_sphere_param_definite hU ha hF hn hD⟩
  exact constant_norm_param_normal hU ha
    ((hF.contDiffAt (hU.mem_nhds ha)).differentiableAt (by norm_num)) hn

theorem unit_sphere_surface_charts :
    SmoothEllipticSurfaceWithBoundary (Metric.sphere (0 : EuclideanThree) 1) := by
  have hh := manifold_embedding_surface_charts
    (contMDiff_coe_sphere (m := (⊤ : ℕ∞)) (n := 2) (E := EuclideanThree))
    Topology.IsEmbedding.subtypeVal unit_sphere_elliptic_immersion
  simpa only [Subtype.range_coe_subtype,Set.setOf_mem_eq] using hh

/-- A concrete closed curved surface: the theorem for the entire unit
sphere, with geometry fully discharged and only the external inputs left. -/
theorem unit_sphere_estimate {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Metric.sphere (0 : EuclideanThree) 1) c₀ C₀ :=
  article_surface_theorem (isCompact_sphere _ _) hc₀ hC₀ unit_sphere_surface_charts
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
