import EllipticSquareFunction.SmoothLocalInverse

noncomputable section
open scoped Topology
namespace EllipticSquareFunction

/-- A parametrization with invertible planar derivative and positive normal
second derivative becomes a positive-Hessian graph after reparametrization.
No inverse function or graph phase is part of the hypotheses. -/
theorem positive_graph_of_parametrization {g : Plane → Plane} {h : Phase}
    {U : Set Plane} {a : Plane} (hU : IsOpen U) (ha : a ∈ U)
    (hg : ContDiffOn ℝ (⊤ : ℕ∞) g U) (hh : ContDiffOn ℝ (⊤ : ℕ∞) h U)
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a)
    (hzero : fderiv ℝ h a = 0)
    (hpos : ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ h) a v v) :
    ∃ (e : PartialHomeomorph Plane Plane) (φ : Phase),
      (e : Plane → Plane) = g ∧ a ∈ e.source ∧ e.source ⊆ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) φ e.target ∧
      (∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ φ) (g a) v v) ∧
      ∀ b ∈ e.source, h b = φ (g b) := by
  obtain ⟨e,he,hae,heU,hei,hdi⟩ := smooth_local_inverse hU ha hg L hL
  let φ : Phase := h ∘ e.symm
  have ht : g a ∈ e.target := by simpa only [he] using e.map_source hae
  have hi : e.symm (g a)=a := by simpa only [he] using e.left_inv hae
  have hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ e.target :=
    hh.comp hei (fun y hy => heU (e.map_target hy))
  refine ⟨e,φ,he,hae,heU,hφ,?_,?_⟩
  · intro v hv
    have hha : ContDiffAt ℝ 2 h (e.symm (g a)) := by
      rw [hi]
      exact (hh.contDiffAt (hU.mem_nhds ha)).of_le (by norm_cast)
    have hia : ContDiffAt ℝ 2 e.symm (g a) :=
      (hei.contDiffAt (e.open_target.mem_nhds ht)).of_le (by norm_cast)
    have hz : fderiv ℝ h (e.symm (g a))=0 := by simpa only [hi] using hzero
    change 0 < fderiv ℝ (fderiv ℝ (h ∘ e.symm)) (g a) v v
    rw [critical_hessian_comp hha hia hz,hi,hdi.fderiv]
    exact hpos (L.symm v) (fun hz => hv (L.symm.injective (hz.trans (map_zero L.symm).symm)))
  · intro b hb
    change h b=h (e.symm (g b))
    rw [← he,e.left_inv hb]

end EllipticSquareFunction
