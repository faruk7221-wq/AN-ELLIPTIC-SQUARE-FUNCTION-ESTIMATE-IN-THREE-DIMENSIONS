import EllipticSquareFunction.PositiveLpTruncation

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Positive L^(3/2) duality without assuming a finite density norm.
Bounded finite-measure truncations justify the tests; monotone convergence
then proves the assertion even for extended-valued densities. -/
theorem positive_lThreeHalves_le_of_tests {α : Type*} [MeasurableSpace α]
    (μ : Measure α) [SigmaFinite μ] (f : α → ℝ≥0∞) (hf : Measurable f)
    (B : ℝ≥0∞)
    (htest : ∀ h : α → ℝ, (∀ x, 0≤h x) → Measurable h → MemLp h 3 μ →
      (∫⁻ x, f x*ENNReal.ofReal (h x) ∂μ) ≤ B*eLpNorm h 3 μ) :
    eLpNorm f (3/2) μ≤B := by
  have happrox : f=(fun x => ⨆ n, positiveTruncation μ f n x) :=
    funext (fun x => (positiveTruncation_iSup μ f x).symm)
  rw [happrox,positive_three_halves_iSup μ _
    (fun n => measurable_positiveTruncation μ f hf n) (positiveTruncation_mono μ f)]
  apply iSup_le
  intro n
  let g : α → ℝ := fun x => (positiveTruncation μ f n x).toReal
  have hgpos : ∀ x, 0≤g x := fun x => ENNReal.toReal_nonneg
  have hgm : Measurable g := (measurable_positiveTruncation μ f hf n).ennreal_toReal
  have he (x : α) : ENNReal.ofReal (g x)=positiveTruncation μ f n x :=
    ENNReal.ofReal_toReal (ne_top_of_le_ne_top (ENNReal.natCast_ne_top n)
      (positiveTruncation_le_nat μ f n x))
  have hnorm : eLpNorm (positiveTruncation μ f n) (3/2) μ=eLpNorm g (3/2) μ := by
    rw [← eLpNorm_ofReal_nonneg μ g hgpos]
    congr 1
    funext x
    exact (he x).symm
  rw [hnorm]
  apply lThreeHalves_le_of_positive_tests μ g hgpos hgm
    (positiveTruncation_toReal_memLp μ f hf n) B
  intro h hpos hm hlp
  apply le_trans _ (htest h hpos hm hlp)
  apply lintegral_mono
  intro x
  dsimp only
  rw [he]
  exact mul_le_mul_right' (positiveTruncation_le μ f n x) _

end EllipticSquareFunction
