import EllipticSquareFunction.PlacedChartEstimate

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1800000

theorem cap_scale_threshold {C r : ℝ} (hC : 0 ≤ C) (hr : 0 < r) :
    ∃ T : ℝ, 2 ≤ T ∧ ∀ R : ℝ, T ≤ R → C*(Real.sqrt R)⁻¹ < r := by
  refine ⟨(C/r+1)^2+2,by nlinarith [sq_nonneg (C/r+1)],?_⟩
  intro R hR
  have hroot : C/r+1 < Real.sqrt R := Real.lt_sqrt_of_sq_lt (by linarith)
  have hrootpos : 0 < Real.sqrt R := by
    have := div_nonneg hC hr.le
    linarith
  rw [← div_eq_mul_inv,div_lt_iff₀ hrootpos]
  have hh := (div_lt_iff₀ hr).mp (show C/r < Real.sqrt R by linarith)
  simpa only [mul_comm] using hh

/-- The general graph estimate at all sufficiently large real scales, using
whole-cap assignment to a finite placed cover. No chart multiplier or internal
cap-transport estimate is assumed. -/
theorem general_graph_large_scale (G : GraphSetup) (hG : GraphHypotheses G)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ S : DiscreteSetup, ContinuedPhase S.φ → DiscreteDensityInput S)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ T C : ℝ, 2 ≤ T ∧ 0 < C ∧ ∀ R : ℝ, T ≤ R →
      ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
      AdmissibleFamily G R ν f →
      l3 (fun y => ∑ i, f i y) ≤ ENNReal.ofReal (C*R^ε)*
        l3Real (squareFunction Finset.univ (fun i => f i)) := by
  classical
  obtain ⟨s,W,O,A,Φ,r₀,hr₀,hcharts,hcover⟩ := finite_placement_cover hplacement G hG
  have hlocal (j : s) := placed_chart_estimate G hG (A j)
    (hcharts j j.property).2.2.1 (hcharts j j.property).2.2.2 hnikodym
    (fun S hS => hdiscrete S (by rw [hS]; exact (hcharts j j.property).2.2.1)) hε
  choose r C hr hC hbound using hlocal
  obtain ⟨T₀,hT₀,hscale₀⟩ := cap_scale_threshold G.C₀_pos.le hr₀
  have hscale (j : s) := cap_scale_threshold G.C₀_pos.le (hr j)
  choose T hT hscale using hscale
  let Ttotal := T₀+∑ j : s, T j
  let Ctotal := 1+∑ j : s, C j
  have hsumT : 0 ≤ ∑ j : s, T j := Finset.sum_nonneg (fun j _ => by linarith [hT j])
  have hsumC : 0 ≤ ∑ j : s, C j := Finset.sum_nonneg (fun j _ => (hC j).le)
  have hTtotal : 2 ≤ Ttotal := by dsimp only [Ttotal]; linarith
  have hCtotal : 0 < Ctotal := by dsimp only [Ctotal]; linarith
  refine ⟨Ttotal,Ctotal,hTtotal,hCtotal,?_⟩
  intro R hR n ν f had
  have hR2 : 2 ≤ R := hTtotal.trans hR
  have hRpos : 0 < R := by linarith
  have hsmall₀ : G.C₀*(Real.sqrt R)⁻¹ < r₀ := hscale₀ R (by dsimp only [Ttotal] at hR; linarith)
  have hsmall (j : s) : G.C₀*(Real.sqrt R)⁻¹ < r j := by
    apply hscale j R
    have hs := Finset.single_le_sum (s := Finset.univ) (fun k _ => show 0 ≤ T k by linarith [hT k])
      (Finset.mem_univ j)
    dsimp only [Ttotal] at hR
    linarith
  have hassign (i : Fin n) : ∃ j : s, Metric.ball (ν i) r₀ ⊆ W j := by
    obtain ⟨j,hj,hball⟩ := hcover (ν i) (had.1 i)
    exact ⟨⟨j,hj⟩,hball⟩
  choose a ha using hassign
  let fiber (j : s) : Finset (Fin n) := Finset.univ.filter (fun i => a i=j)
  let pieces (j : s) : Space → ℂ := fun y => ∑ i ∈ fiber j, f i y
  have hpiece (j : s) : l3 (pieces j) ≤ ENNReal.ofReal (C j*R^ε)*
      l3Real (squareFunction Finset.univ (fun i => f i)) := by
    have hW (i : Fin n) (hi : i ∈ fiber j) : ν i ∈ W j := by
      have he : a i=j := (Finset.mem_filter.mp hi).2
      simpa only [he] using ha i (Metric.mem_ball_self hr₀)
    have hSW (i : Fin n) (hi : i ∈ fiber j) (z : Space)
        (hz : z ∈ Function.support (fourierTransform (f i))) : z.1 ∈ W j := by
      have he : a i=j := (Finset.mem_filter.mp hi).2
      have hb : z.1 ∈ Metric.ball (ν i) r₀ := by
        exact (show ‖z.1-ν i‖ < r₀ from (had.2.2 i hz).1.trans_lt hsmall₀)
      simpa only [he] using ha i hb
    have hb := hbound j R hR2 (hsmall j) (fiber j) ν f
      (fun i _ => had.1 i) hW (fun i _ k _ hik => had.2.1 i k hik)
      (fun i _ => had.2.2 i) hSW
    exact hb.trans (mul_le_mul_left' (l3_squareFunction_mono_subfamily
      (Finset.subset_univ (fiber j)) (fun i => (f i : Space → ℂ))) _)
  have hm (j : s) (_ : j ∈ (Finset.univ : Finset s)) : AEStronglyMeasurable (pieces j) volume :=
    (continuous_finset_sum (fiber j) (fun i _ => (f i).continuous)).aestronglyMeasurable
  have he (y : Space) : (∑ i, f i y)=∑ j : s, pieces j y := by
    exact (Finset.sum_fiberwise Finset.univ a (fun i => f i y)).symm
  have hb := finite_chart_l3_assembly Finset.univ (fun y => ∑ i, f i y) pieces
    (squareFunction Finset.univ (fun i => (f i : Space → ℂ)))
    (fun j => ENNReal.ofReal (C j*R^ε)) hm he (fun j _ => hpiece j)
  apply hb.trans
  apply mul_le_mul_right'
  rw [← ENNReal.ofReal_sum_of_nonneg (fun j _ => mul_nonneg (hC j).le (Real.rpow_nonneg hRpos.le ε)),
    ← Finset.sum_mul]
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hRpos.le ε)
  dsimp only [Ctotal]
  linarith

end EllipticSquareFunction
