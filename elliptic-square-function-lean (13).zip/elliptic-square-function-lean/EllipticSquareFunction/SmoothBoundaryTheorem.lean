import EllipticSquareFunction.SeeleyPlaneExtension

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- Every smooth canonical chart parametrization of a surface with boundary
has a smooth local extension to an open subset of the ambient plane. -/
theorem halfspace_extensions_of_smooth {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) :
    HasSmoothModelExtensions (𝓡∂ 2) f := by
  intro x
  have hn := extChartAt_target_mem_nhdsWithin (I := 𝓡∂ 2) x
  rw [range_modelWithCornersEuclideanHalfSpace] at hn
  obtain ⟨r,hr,hsub⟩ := Metric.mem_nhdsWithin_iff.mp hn
  have hs : ContDiffOn ℝ (⊤ : ℕ∞) (modelSurfaceParam (𝓡∂ 2) f x)
      ({p : Plane | 0 ≤ p 0} ∩ Metric.ball (extChartAt (𝓡∂ 2) x x) r) :=
    (model_surface_param_smooth (𝓡∂ 2) hf x).mono
      (fun _ hp => hsub ⟨hp.2,hp.1⟩)
  obtain ⟨F,U,hU,ha,hF,heq⟩ := smooth_plane_halfspace_extension Metric.isOpen_ball
    (Metric.mem_ball_self hr) hs
  refine ⟨F,U,hU,ha,hF,fun p hp => heq ⟨hp.1,?_⟩⟩
  have hh := extChartAt_target_subset_range (I := 𝓡∂ 2) x hp.2
  rwa [range_modelWithCornersEuclideanHalfSpace] at hh

/-- Surface estimate for a compact smooth embedded manifold with boundary.
The smooth extension property is constructed, not assumed. The three external
analytic inputs remain explicit hypotheses. -/
theorem compact_smooth_boundary_surface_estimate [CompactSpace M]
    {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f)
    (himm : ∀ x, Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm (𝓡∂ 2) f x N)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ :=
  compact_model_surface_estimate (𝓡∂ 2) hf hemb
    (halfspace_extensions_of_smooth hf) himm hcurv hc₀ hC₀
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
