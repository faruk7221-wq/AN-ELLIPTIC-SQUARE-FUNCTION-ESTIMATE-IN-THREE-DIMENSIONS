import EllipticSquareFunction.Lattice

/-! # Temporal lattice sums and product spatial/temporal summability -/
noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

theorem regularized_time_lattice_summable {b : ℝ} (hb : 1 < b) :
    Summable (fun n : ℤ => bracket (n : ℝ) ^ (-b)) := by
  classical
  have hs := (hasSum_ite_eq (0 : ℤ) (1 : ℝ)).summable.add (Real.summable_abs_int_rpow hb)
  apply hs.of_nonneg_of_le (fun n => Real.rpow_nonneg (bracket_pos _).le _)
  intro n
  by_cases hn : n = 0
  · simp [hn, bracket, Real.zero_rpow (by linarith : -b ≠ 0)]
  · simp only [if_neg hn, zero_add]
    exact Real.rpow_le_rpow_of_nonpos (abs_pos.mpr (Int.cast_ne_zero.mpr hn))
      (by simp [bracket, Real.norm_eq_abs]) (by linarith)

theorem translated_time_lattice_majorant (t : ℝ) (n : ℤ) {b : ℝ} (hb : 0 ≤ b) :
    bracket (t - n) ^ (-b) ≤ (2 : ℝ) ^ b * bracket ((n - ⌊t⌋ : ℤ) : ℝ) ^ (-b) := by
  have htri := bracket_sub_le_mul (n : ℝ) t (⌊t⌋ : ℝ)
  have hsym : bracket ((n : ℝ) - t) = bracket (t - n) := by simp only [bracket, norm_sub_rev]
  rw [hsym] at htri
  have hq : bracket (t - (⌊t⌋ : ℝ)) ≤ 2 := by
    simp only [bracket, Real.norm_eq_abs, Int.self_sub_floor,
      abs_of_nonneg (Int.fract_nonneg t)]
    linarith [Int.fract_lt_one t]
  have hm : bracket ((n - ⌊t⌋ : ℤ) : ℝ) ≤ bracket (t - n) * 2 := by
    rw [Int.cast_sub]
    exact htri.trans (mul_le_mul_of_nonneg_left hq (bracket_pos _).le)
  have h := Real.rpow_le_rpow_of_nonpos (bracket_pos (((n - ⌊t⌋ : ℤ) : ℝ))) hm (neg_nonpos.mpr hb)
  rw [Real.mul_rpow (bracket_pos _).le (by norm_num : (0 : ℝ) ≤ 2),
    Real.rpow_neg (by norm_num : (0 : ℝ) ≤ 2)] at h
  have h2 : 0 < (2 : ℝ) ^ b := Real.rpow_pos_of_pos (by norm_num) _
  have h' := mul_le_mul_of_nonneg_left h h2.le
  have he : (2 : ℝ) ^ b * (bracket (t - n) ^ (-b) * (2 ^ b)⁻¹) = bracket (t - n) ^ (-b) := by
    field_simp
  rw [he] at h'
  exact h'

def timeLatticeSumConstant (b : ℝ) : ℝ :=
  2 ^ b * ∑' n : ℤ, bracket (n : ℝ) ^ (-b)

theorem translated_time_lattice_summable (t : ℝ) {b : ℝ} (hb : 1 < b) :
    Summable (fun n : ℤ => bracket (t - n) ^ (-b)) := by
  have hs := (Equiv.subRight ⌊t⌋).summable_iff.mpr (regularized_time_lattice_summable hb)
  exact (hs.mul_left (2 ^ b)).of_nonneg_of_le
    (fun n => Real.rpow_nonneg (bracket_pos _).le _)
    (fun n => translated_time_lattice_majorant t n (by linarith))

theorem translated_time_lattice_sum_le (t : ℝ) {b : ℝ} (hb : 1 < b) :
    (∑' n : ℤ, bracket (t - n) ^ (-b)) ≤ timeLatticeSumConstant b := by
  have hs := (Equiv.subRight ⌊t⌋).summable_iff.mpr (regularized_time_lattice_summable hb)
  calc
    _ ≤ ∑' n : ℤ, 2 ^ b * bracket ((n - ⌊t⌋ : ℤ) : ℝ) ^ (-b) :=
      Summable.tsum_le_tsum (fun n => translated_time_lattice_majorant t n (by linarith))
        (translated_time_lattice_summable t hb) (hs.mul_left _)
    _ = timeLatticeSumConstant b := by
      rw [tsum_mul_left]
      exact congrArg (fun x : ℝ => 2 ^ b * x)
        ((Equiv.subRight ⌊t⌋).tsum_eq (fun n : ℤ => bracket (n : ℝ) ^ (-b)))

/-- The temporal version of (2.2), with no summability hypothesis. -/
theorem time_lattice_convolution (t s : ℝ) {a b : ℝ} (ha : 0 ≤ a) (hab : 1 < b - a) :
    (∑' n : ℤ, bracket (t - n) ^ (-b) * bracket ((n : ℝ) - s) ^ (-a)) ≤
      timeLatticeSumConstant (b - a) * bracket (t - s) ^ (-a) :=
  infinite_weight_convolution (fun n : ℤ => (n : ℝ)) t s ha
    (translated_time_lattice_summable t hab) (translated_time_lattice_sum_le t hab)

theorem product_lattice_summable (u : Plane) (t : ℝ) {b c : ℝ} (hb : 2 < b) (hc : 1 < c) :
    Summable (fun i : IntPlane × ℤ =>
      bracket (u - latticePoint 1 i.1) ^ (-b) * bracket (t - i.2) ^ (-c)) :=
  (translated_lattice_summable u hb).mul_of_nonneg (translated_time_lattice_summable t hc)
    (fun _ => Real.rpow_nonneg (bracket_pos _).le _)
    (fun _ => Real.rpow_nonneg (bracket_pos _).le _)

/-- A uniform summable bound for the normalized spacetime sampling lattice. -/
theorem product_lattice_sum_le (u : Plane) (t : ℝ) {b c : ℝ} (hb : 2 < b) (hc : 1 < c) :
    (∑' i : IntPlane × ℤ,
      bracket (u - latticePoint 1 i.1) ^ (-b) * bracket (t - i.2) ^ (-c)) ≤
      latticeSumConstant b * timeLatticeSumConstant c := by
  rw [← tsum_mul_tsum (translated_lattice_summable u hb)
    (translated_time_lattice_summable t hc) (product_lattice_summable u t hb hc)]
  apply mul_le_mul (translated_lattice_sum_le u hb) (translated_time_lattice_sum_le t hc)
    (tsum_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _))
  exact (tsum_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _)).trans (translated_lattice_sum_le u hb)

end EllipticSquareFunction
