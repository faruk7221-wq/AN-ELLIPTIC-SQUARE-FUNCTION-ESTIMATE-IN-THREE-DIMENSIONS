import EllipticSquareFunction.NormalSecondFundamentalForm

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- On a set with unique derivatives, the derivative of a differentiable
extension agrees with the derivative within the original set. -/
theorem extension_fderivWithin {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F G : Plane → E} {U S : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (has : a ∈ S)
    (hs : UniqueDiffWithinAt ℝ S a) (hF : DifferentiableAt ℝ F a)
    (heq : Set.EqOn F G (U ∩ S)) :
    fderivWithin ℝ G S a = fderiv ℝ F a := by
  have he : F =ᶠ[𝓝[S] a] G := by
    filter_upwards [mem_nhdsWithin_of_mem_nhds (hU.mem_nhds ha),self_mem_nhdsWithin]
      with b hbU hbS
    exact heq ⟨hbU,hbS⟩
  rw [← he.fderivWithin_eq (heq ⟨ha,has⟩)]
  exact fderivWithin_eq_fderiv hs hF

/-- A twice differentiable extension determines the intrinsic iterated
derivative within the model set, including points on its boundary. -/
theorem extension_second_fderivWithin {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F G : Plane → E} {U S : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (has : a ∈ S)
    (hs : UniqueDiffOn ℝ S) (hF : ContDiffOn ℝ 2 F U)
    (heq : Set.EqOn F G (U ∩ S)) :
    fderivWithin ℝ (fderivWithin ℝ G S) S a = fderiv ℝ (fderiv ℝ F) a := by
  apply extension_fderivWithin hU ha has (hs a has)
    (((hF.contDiffAt (hU.mem_nhds ha)).fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num))
  intro b hb
  exact (extension_fderivWithin hU hb.1 hb.2 (hs b hb.2)
    ((hF.contDiffAt (hU.mem_nhds hb.1)).differentiableAt (by norm_num)) heq).symm

/-- The second derivative at a model point is independent of the chosen
smooth extension; equality on the model set suffices. -/
theorem smooth_extension_second_derivative_unique
    {F G : Plane → EuclideanThree} {U S : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (has : a ∈ S)
    (hs : UniqueDiffOn ℝ S) (hF : ContDiffOn ℝ 2 F U) (hG : ContDiffOn ℝ 2 G U)
    (heq : Set.EqOn F G (U ∩ S)) :
    fderiv ℝ (fderiv ℝ F) a = fderiv ℝ (fderiv ℝ G) a := by
  rw [← extension_second_fderivWithin hU ha has hs hF heq,
    extension_second_fderivWithin hU ha has hs hG (fun _ _ => rfl)]

end EllipticSquareFunction
