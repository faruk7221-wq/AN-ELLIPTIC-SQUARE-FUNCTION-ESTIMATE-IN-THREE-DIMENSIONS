import EllipticSquareFunction.RebasedReconstruction

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

theorem rebasedCoefficient_zero_of_frequency {ι : Type*}
    (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ) {N F Z : ℝ}
    (hN : 1≤N) (hZ : 0≤Z) (Δ : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane)
    (μ w : Plane) (hν : ∀ i ∈ s, ‖ν i‖≤F) (hμ : F+Z<‖μ‖)
    (hcut : ∀ μ w ν v : Plane, Z/N<‖μ-ν‖ → rebasedWindowMatrix φ b χ N Δ μ w ν v=0) :
    rebasedCoefficient φ b χ N Δ s pbox a ν v μ w=0 := by
  apply Finset.sum_eq_zero
  intro i hi
  apply Finset.sum_eq_zero
  intro p hp
  have htri : ‖μ‖≤‖μ-ν i‖+‖ν i‖ := by
    simpa only [sub_add_cancel] using norm_add_le (μ-ν i) (ν i)
  have hdiv : Z/N≤Z := div_le_self hZ hN
  rw [hcut μ w (ν i) (v i p) (by linarith [hν i hi]),zero_mul]

/-- The exact rebased frame can be restricted to a uniformly bounded fine
frequency set. The set and its radius are independent of the time shift. -/
theorem rebased_profile_bounded_frequencies {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b) :
    ∃ Z : ℝ, 0<Z ∧ ∀ N F : ℝ, 1≤N →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖≤F) → ∃ q : Finset IntPlane,
      (∀ m ∈ q, ‖latticePoint N⁻¹ m‖≤F+Z) ∧ ∀ (Δ : ℝ) (y : Space),
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D:ℝ)^2)⁻¹:ℝ) •
        (rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p)
          (y.1,y.2+Δ*N^2)) := by
  classical
  obtain ⟨Z,hZ,hcut⟩ := rebasedWindowMatrix_frequency_cutoff S.φ b hbs S.χ S.χ_compact
  refine ⟨Z,hZ,?_⟩
  intro N F hN s pbox a ν v hν
  obtain ⟨q,hq⟩ := equation_5_5 S hφ b hb hbs (by linarith : 0<N) s pbox a ν v
  refine ⟨q.filter (fun m => ‖latticePoint N⁻¹ m‖≤F+Z),
    fun m hm => (Finset.mem_filter.mp hm).2,?_⟩
  intro Δ y
  apply (hq Δ y).congr
  intro ns
  apply Finset.sum_congr rfl
  intro n hn
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro m hm hmn
  have hfar : F+Z<‖latticePoint N⁻¹ m‖ := by
    apply lt_of_not_ge
    intro hh
    exact hmn (Finset.mem_filter.mpr ⟨hm,hh⟩)
  have hz := rebasedCoefficient_zero_of_frequency S.φ b S.χ hN hZ.le Δ s pbox a ν v
    (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) hν hfar (hcut N (by linarith) Δ)
  simp only [hz,zero_mul,smul_zero]

end EllipticSquareFunction
