import EllipticSquareFunction.SeeleyFiniteMoments
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Analysis.SpecificLimits.Normed

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

def seeleyMajorant (k : ℕ) : ℝ := ∏ j ∈ Finset.range k, 4/(2 : ℝ)^(j+1)

theorem seeley_majorant_pos (k : ℕ) : 0 < seeleyMajorant k := by
  apply Finset.prod_pos
  intro j hj
  positivity

theorem seeley_majorant_succ (k : ℕ) :
    seeleyMajorant (k+1)=seeleyMajorant k*(4/(2 : ℝ)^(k+1)) :=
  Finset.prod_range_succ _ _

theorem seeley_ratio_aux {A B : ℝ} (hA : 2 ≤ A) (hB : 1 ≤ B) :
    (1+B)/(B*A-B) ≤ 4/A := by
  have ha : 0 < A := by linarith
  have hd : 0 < B*A-B := by nlinarith
  rw [div_le_div_iff₀ hd ha]
  nlinarith [mul_nonneg (sub_nonneg.mpr hB) (show 0 ≤ 3*A-4 by linarith)]

theorem seeley_lower_factor_bound {j k : ℕ} (hjk : j < k) :
    |(1+(2 : ℝ)^j)/(2^j-2^k)| ≤ 4/(2 : ℝ)^(k-j) := by
  have hp : (2 : ℝ)^j < 2^k := (pow_right_strictMono₀ (by norm_num : (1 : ℝ)<2)) hjk
  have hpow : (2 : ℝ)^k=2^j*2^(k-j) := by
    rw [← pow_add,Nat.add_sub_of_le hjk.le]
  rw [abs_div,abs_of_pos (by positivity : 0 < 1+(2 : ℝ)^j),
    abs_of_neg (sub_neg.mpr hp)]
  have hA : (2 : ℝ) ≤ 2^(k-j) := by
    calc (2 : ℝ) = 2^1 := by norm_num
         _ ≤ 2^(k-j) := pow_le_pow_right₀ (by norm_num) (by omega)
  have hB : (1 : ℝ) ≤ 2^j := one_le_pow₀ (by norm_num)
  convert seeley_ratio_aux hA hB using 1 <;> rw [hpow] <;> ring

/-- The diagonal interpolation coefficient has a super-polynomially
decaying majorant independent of any later truncation order. -/
theorem seeley_diagonal_bound (k : ℕ) : |seeleyFiniteCoeff k k| ≤ seeleyMajorant k := by
  have he : (Finset.range (k+1)).erase k=Finset.range k := by
    ext j
    simp only [Finset.mem_erase,Finset.mem_range]
    omega
  rw [seeley_finite_coeff_product le_rfl,he,Finset.abs_prod]
  unfold seeleyMajorant
  rw [← Finset.prod_range_reflect (fun j => 4/(2 : ℝ)^(j+1)) k]
  apply Finset.prod_le_prod
  · intro j hj
    exact abs_nonneg _
  · intro j hj
    have hjk := Finset.mem_range.mp hj
    have he : k-1-j+1=k-j := by omega
    rw [he]
    exact seeley_lower_factor_bound hjk

theorem seeley_upper_factor_bound (k n : ℕ) :
    (1+(2 : ℝ)^(k+n+1))/(2^(k+n+1)-2^k) ≤ 1+4/(2 : ℝ)^(n+1) := by
  have hA : (2 : ℝ) ≤ 2^(n+1) := by
    calc (2 : ℝ) = 2^1 := by norm_num
         _ ≤ 2^(n+1) := pow_le_pow_right₀ (by norm_num) (by omega)
  have hB : (1 : ℝ) ≤ 2^k := one_le_pow₀ (by norm_num)
  have hp : (2 : ℝ)^(k+n+1)=2^k*2^(n+1) := by rw [← pow_add]; congr 1 <;> omega
  have hd : (2 : ℝ)^k*2^(n+1)-2^k ≠ 0 := by nlinarith
  rw [hp]
  calc
    (1+(2 : ℝ)^k*2^(n+1))/(2^k*2^(n+1)-2^k) =
        1+(1+2^k)/(2^k*2^(n+1)-2^k) := by field_simp; ring
    _ ≤ 1+4/(2 : ℝ)^(n+1) := add_le_add_left (seeley_ratio_aux hA hB) 1

theorem seeley_geometric_sum_bound (n : ℕ) :
    ∑ j ∈ Finset.range n, (4/(2 : ℝ)^(j+1)) ≤ 4 := by
  have he : ∑ j ∈ Finset.range n, (4/(2 : ℝ)^(j+1)) = 4-4/(2 : ℝ)^n := by
    induction n with
    | zero => norm_num
    | succ n ih => rw [Finset.sum_range_succ,ih,pow_succ]; field_simp; ring
  rw [he]
  exact sub_le_self _ (by positivity)

end EllipticSquareFunction
