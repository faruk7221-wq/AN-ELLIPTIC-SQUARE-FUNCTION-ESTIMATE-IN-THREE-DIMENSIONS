import EllipticSquareFunction.PolynomialRebasing
import EllipticSquareFunction.WindowMatrix

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- The matrix entry before the fixed D⁻² synthesis normalization. -/
def rebasedWindowMatrix (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N Δ : ℝ) (μ w ν v : Plane) : ℂ :=
  N^2 • ∫ ξ, b (N • (ξ-ν))*(χ (N • (ξ-μ)) : ℂ)*
    oscillation (@inner ℝ Plane _ (w-v) ξ+(Δ*N^2)*φ ξ)

theorem rebasedWindowMatrix_eq_freePacket (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    (N Δ : ℝ) (μ w ν v : Plane) :
    rebasedWindowMatrix φ b χ N Δ μ w ν v =
      freePacket φ (fun ζ => b ζ*(χ (ζ+N • (ν-μ)) : ℂ)) N ν v (w,Δ*N^2) := by
  unfold rebasedWindowMatrix freePacket
  simp only [Complex.real_smul]
  congr 1
  apply integral_congr_ae
  filter_upwards with ξ
  have he : N • (ξ-ν)+N • (ν-μ)=N • (ξ-μ) := by
    rw [← smul_add]
    congr 1
    abel
  simp only [he]

/-- The exact normalization behind (5.6), including the drifting center and
the constant phase. -/
theorem rebasedWindowMatrix_normalization (φ : Phase) (b : Plane → ℂ) (χ : Plane → ℝ)
    {N : ℝ} (hN : 0<N) (Δ : ℝ) (μ w ν v : Plane) :
    rebasedWindowMatrix φ b χ N Δ μ w ν v =
      oscillation (@inner ℝ Plane _ (w-v) ν+(Δ*N^2)*φ ν)*
        rebasingKernel φ b χ N ν (N • (ν-μ))
          (N⁻¹ • (w-v+(Δ*N^2) • velocity φ ν)) Δ := by
  rw [rebasedWindowMatrix_eq_freePacket, freePacket_normalization φ _ hN]
  simp only [mul_div_cancel_right₀ Δ (pow_ne_zero 2 hN.ne')]
  congr 1
  unfold rebasingKernel
  apply integral_congr_ae
  filter_upwards with ζ
  rw [oscillation_add]
  ring

/-- The actual rebasing matrix has polynomial time loss and arbitrary
spatial decay, uniformly in scale and packet labels. -/
theorem rebasedWindowMatrix_uniform_decay {φ : Phase} (hphase : ContinuedPhase φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ) (A : ℝ) (L : ℕ) :
    ∃ C : ℝ, 0<C ∧ ∀ N : ℝ, 1≤N → ∀ (Δ : ℝ) (μ w ν v : Plane),
      ‖N • (ν-μ)‖≤A →
      ‖rebasedWindowMatrix φ b χ N Δ μ w ν v‖ ≤ C*(1+|Δ|)^L*
        bracket (N⁻¹ • (w-v+(Δ*N^2) • velocity φ ν))^(-(L:ℝ)) := by
  obtain ⟨C,hC,hbound⟩ := equation_5_8 hphase b hb hbs χ hχ A L
  refine ⟨C,hC,?_⟩
  intro N hN Δ μ w ν v hνμ
  rw [rebasedWindowMatrix_normalization φ b χ (by linarith),
    norm_mul,norm_oscillation,one_mul]
  exact hbound N hN ν _ _ Δ hνμ

/-- Time modulation cannot create new frequency-window interactions. -/
theorem rebasedWindowMatrix_frequency_cutoff (φ : Phase)
    (b : Plane → ℂ) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχs : HasCompactSupport χ) :
    ∃ A : ℝ, 0<A ∧ ∀ N : ℝ, 0<N → ∀ (Δ : ℝ) (μ w ν v : Plane),
      A/N<‖μ-ν‖ → rebasedWindowMatrix φ b χ N Δ μ w ν v=0 := by
  obtain ⟨B,hB⟩ := hbs.exists_bound_of_continuousOn continuous_id.continuousOn
  obtain ⟨C,hC⟩ := hχs.exists_bound_of_continuousOn continuous_id.continuousOn
  let A := max B 0+max C 0+1
  refine ⟨A,by dsimp [A]; positivity,?_⟩
  intro N hN Δ μ w ν v hfar
  rw [rebasedWindowMatrix_normalization φ b χ hN]
  have hz : rebasingKernel φ b χ N ν (N • (ν-μ))
      (N⁻¹ • (w-v+(Δ*N^2) • velocity φ ν)) Δ=0 := by
    apply integral_eq_zero_of_ae
    filter_upwards with ζ
    by_cases hbζ : b ζ=0
    · simp [hbζ]
    by_cases hχζ : χ (ζ+N • (ν-μ))=0
    · simp [hχζ]
    have hb' := hB ζ (subset_closure hbζ)
    have hc' := hC (ζ+N • (ν-μ)) (subset_closure hχζ)
    simp only [id_eq] at hb' hc'
    have htri : ‖N • (ν-μ)‖≤B+C := by
      calc
        _ = ‖(ζ+N • (ν-μ))-ζ‖ := by congr 1; abel
        _ ≤ ‖ζ+N • (ν-μ)‖+‖ζ‖ := norm_sub_le _ _
        _ ≤ B+C := by linarith
    rw [norm_smul,Real.norm_eq_abs,abs_of_pos hN,norm_sub_rev] at htri
    have hf : A<N*‖μ-ν‖ := by
      have := (div_lt_iff₀ hN).mp hfar
      nlinarith
    have hBC : B+C<A := by dsimp [A]; linarith [le_max_left B 0,le_max_left C 0]
    exact (not_lt_of_ge htri) (hBC.trans hf) |>.elim
  rw [hz,mul_zero]

end EllipticSquareFunction
