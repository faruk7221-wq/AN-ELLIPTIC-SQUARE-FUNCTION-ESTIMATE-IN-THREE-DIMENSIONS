import EllipticSquareFunction.TerminalCoefficients
import EllipticSquareFunction.LabelCounting
import EllipticSquareFunction.CoreGeometry

/-! # The omitted terminal synthesis and its integrated error -/

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

def terminalTail (S : DiscreteSetup) (q : Finset IntPlane) (N A R : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ) (y : Space) : ℂ :=
  (((S.D : ℝ) ^ 2)⁻¹ : ℝ) • ∑ m ∈ q, ∑' n : IntPlane,
    if (A + 1) * R < ‖latticePoint (S.D : ℝ)⁻¹ n‖ then
      terminalCoefficient S N s d (m, n, j) *
        windowKernel S.φ (canonicalWindow S m) (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2
    else 0

/-- The per-window tails combine into the actual normalized omitted synthesis. -/
theorem terminalTail_norm_bound (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane) (L : ℕ) (hL : 3 ≤ L) :
    ∃ C : ℝ, 0 < C ∧ ∀ N : ℝ, 0 < N →
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ)
        (A R : ℝ), 0 ≤ R → ∀ y : Space, ‖y.1‖ ≤ A * R → y.2 ∈ Icc (0 : ℝ) 1 →
      ‖terminalTail S q N A R s d j y‖ ≤
        C * (∑ k ∈ s, ‖d k‖) * (1 + R) ^ (-((L : ℝ) - 3)) := by
  classical
  obtain ⟨B, hB, hb⟩ := terminal_synthesis_tail_bound S hφ q L hL
  let a : ℝ := ((S.D : ℝ) ^ 2)⁻¹
  let K := scaledLatticeSumConstant (S.D : ℝ)⁻¹ 3
  have hK : 0 ≤ K := by
    have hD : 0 < (S.D : ℝ)⁻¹ := inv_pos.mpr (by exact_mod_cast S.D_pos)
    simpa [K] using scaled_lattice_finite_sum_le hD (by norm_num : (2 : ℝ) < 3)
      (0 : Plane) ∅
  refine ⟨a * q.card * B * K + 1, by dsimp [a]; positivity, ?_⟩
  intro N hN s d j A R hR y hy hu
  let f := fun m : IntPlane => ∑' n : IntPlane,
    if (A + 1) * R < ‖latticePoint (S.D : ℝ)⁻¹ n‖ then
      terminalCoefficient S N s d (m, n, j) *
        windowKernel S.φ (canonicalWindow S m) (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2 else 0
  have hh : ‖∑ m ∈ q, f m‖ ≤
      (q.card : ℝ) * (B * (∑ k ∈ s, ‖d k‖) * ((1 + R) ^ (-((L : ℝ) - 3)) * K)) := by
    apply (norm_sum_le _ _).trans
    calc
      (∑ m ∈ q, ‖f m‖) ≤ ∑ _m ∈ q,
          B * (∑ k ∈ s, ‖d k‖) * ((1 + R) ^ (-((L : ℝ) - 3)) * K) :=
        Finset.sum_le_sum (fun m hm => (hb N hN s d m hm j y.2 hu A R hR y.1 hy).2)
      _ = _ := by simp only [Finset.sum_const, nsmul_eq_mul]
  change ‖a • ∑ m ∈ q, f m‖ ≤ _
  rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg (by dsimp [a]; positivity : 0 ≤ a)]
  calc
    _ ≤ a * ((q.card : ℝ) * (B * (∑ k ∈ s, ‖d k‖) *
        ((1 + R) ^ (-((L : ℝ) - 3)) * K))) :=
      mul_le_mul_of_nonneg_left hh (by dsimp [a]; positivity)
    _ ≤ _ := by
      have hsum : 0 ≤ ∑ k ∈ s, ‖d k‖ := Finset.sum_nonneg (fun _ _ => norm_nonneg _)
      have hp : 0 ≤ (1 + R) ^ (-((L : ℝ) - 3)) := Real.rpow_nonneg (by linarith) _
      nlinarith

/-- A finite retained part plus the complementary series recovers any
convergent synthesis. This handles truncation without assuming convergence. -/
theorem hasSum_omitted_finset {α : Type*} [DecidableEq α] (p : Finset α) (f : α → ℂ) {z : ℂ}
    (hf : HasSum f z) :
    HasSum (fun n => if n ∈ p then 0 else f n) (z - ∑ n ∈ p, f n) := by
  classical
  have hp : HasSum (fun n => if n ∈ p then f n else 0) (∑ n ∈ p, f n) := by
    convert hasSum_sum_of_ne_finset_zero (s := p)
      (f := fun n => if n ∈ p then f n else 0) (by intros; simp_all) using 1
    exact (Finset.sum_congr rfl (fun n hn => if_pos hn)).symm
  convert hf.sub hp using 1
  funext n
  by_cases hn : n ∈ p <;> simp [hn]

theorem finite_scaled_lattice_ball {a : ℝ} (ha : 0 < a) (B : ℝ) :
    {n : IntPlane | ‖latticePoint a n‖ ≤ B}.Finite := by
  apply (integerPlaneBox ⌈a⁻¹ * B⌉₊).finite_toSet.subset
  intro n hn
  apply mem_integerPlaneBox_of_norm_le
  have he : latticePoint 1 n = a⁻¹ • latticePoint a n := by
    rw [← latticePoint_mul, inv_mul_cancel₀ ha.ne']
  rw [he, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr ha)]
  exact mul_le_mul_of_nonneg_left hn (inv_pos.mpr ha).le

def retainedPositions (S : DiscreteSetup) (B : ℝ) : Finset IntPlane :=
  (finite_scaled_lattice_ball (a := (S.D : ℝ)⁻¹)
    (inv_pos.mpr (by exact_mod_cast S.D_pos)) B).toFinset

@[simp] theorem mem_retainedPositions (S : DiscreteSetup) (B : ℝ) (n : IntPlane) :
    n ∈ retainedPositions S B ↔ ‖latticePoint (S.D : ℝ)⁻¹ n‖ ≤ B := by
  simp [retainedPositions]

def retainedTerminal (S : DiscreteSetup) (q p : Finset IntPlane) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ) (y : Space) : ℂ :=
  ∑ n ∈ p, ∑ m ∈ q, (((S.D : ℝ) ^ 2)⁻¹ : ℝ) •
    (terminalCoefficient S N s d (m, n, j) *
      windowKernel S.φ (canonicalWindow S m) (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2)

theorem continuous_retainedTerminal (S : DiscreteSetup) (hφ : Continuous S.φ)
    (q p : Finset IntPlane) (N : ℝ) (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ) :
    Continuous (retainedTerminal S q p N s d j) := by
  apply continuous_finset_sum
  intro n _
  apply continuous_finset_sum
  intro m _
  apply Continuous.const_smul
  have hk := continuous_windowKernel S.φ hφ (canonicalWindow S m)
    (canonicalWindow_smooth S m).continuous (canonicalWindow_compact S m)
  have ht : Continuous (fun y : Space => (y.1 - latticePoint (S.D : ℝ)⁻¹ n, y.2)) :=
    (continuous_fst.sub continuous_const).prodMk continuous_snd
  have hc := hk.comp ht
  dsimp only [Function.comp_def] at hc
  exact (continuous_const : Continuous (fun _ : Space => terminalCoefficient S N s d (m,n,j))).mul hc

theorem continuous_discreteExtension (S : DiscreteSetup) (hφ : Continuous S.φ)
    {N : ℝ} (hN : 1 ≤ N) (s : Finset PacketIndex) (d : PacketIndex → ℂ)
    (hs : discreteLabelsAllowed S N s) : Continuous (discreteExtension S N s d) := by
  obtain ⟨K, hK, hsupport⟩ := discreteFrequency_uniform_support S
  have hg := continuous_discreteFrequency S N s d
  apply continuous_iff_continuousOn_univ.mpr
  apply continuousOn_integral_of_compact_support (μ := volume) hK
  · apply Continuous.continuousOn
    exact (hg.comp continuous_snd).mul
      (continuous_oscillation.comp ((continuous_fst.fst.inner continuous_snd).add
        (continuous_fst.snd.mul (hφ.comp continuous_snd))))
  · intro y ξ _ hξ
    have hz : discreteFrequency S N s d ξ = 0 :=
      image_eq_zero_of_nmem_tsupport (fun h => hξ (hsupport N hN s d hs h))
    simp [hz]

/-- Exact identification of the convergent omitted synthesis with the
extension minus the retained finite sum, on the local unit slab. -/
theorem terminalTail_eq_sub (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (q : Finset IntPlane)
    {N A R : ℝ} (hN : 0 < N) (hR : 0 ≤ R)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ)
    (y : Space) (hy : ‖y.1‖ ≤ A * R) (hu : y.2 ∈ Icc (0 : ℝ) 1)
    (hr : HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ) ^ 2)⁻¹ : ℝ) •
      (terminalCoefficient S N s d (m,n,j) * windowKernel S.φ (canonicalWindow S m)
        (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2))
      (discreteExtension S N s d (y.1, (j : ℝ) + y.2))) :
    terminalTail S q N A R s d j y =
      discreteExtension S N s d (y.1, (j : ℝ) + y.2) -
        retainedTerminal S q (retainedPositions S ((A+1)*R)) N s d j y := by
  classical
  obtain ⟨C, _, hc⟩ := terminal_synthesis_tail_bound S hφ q 3 (by omega)
  let f := fun m n : IntPlane => if (A+1)*R < ‖latticePoint (S.D : ℝ)⁻¹ n‖ then
    terminalCoefficient S N s d (m,n,j) * windowKernel S.φ (canonicalWindow S m)
      (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2 else 0
  have hf : ∀ m ∈ q, Summable (f m) :=
    fun m hm => (hc N hN s d m hm j y.2 hu A R hR y.1 hy).1
  have ht := (hasSum_sum (fun m hm => (hf m hm).hasSum)).const_smul (((S.D : ℝ)^2)⁻¹ : ℝ)
  have ho := hasSum_omitted_finset (retainedPositions S ((A+1)*R)) _ hr
  have he : (fun n => (((S.D : ℝ)^2)⁻¹ : ℝ) • ∑ m ∈ q, f m n) =
      (fun n => if n ∈ retainedPositions S ((A+1)*R) then 0 else
        ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
          (terminalCoefficient S N s d (m,n,j) * windowKernel S.φ (canonicalWindow S m)
            (y.1 - latticePoint (S.D : ℝ)⁻¹ n) y.2)) := by
    funext n
    by_cases hn : ‖latticePoint (S.D : ℝ)⁻¹ n‖ ≤ (A+1)*R
    · simp [f, hn, not_lt.mpr hn]
    · simp [f, hn, lt_of_not_ge hn, Finset.smul_sum]
  rw [he] at ht
  exact ht.unique ho

def terminalRemainder (S : DiscreteSetup) (q : Finset IntPlane) (N A R : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (j : ℕ) (y : Space) : ℂ :=
  discreteExtension S N s d (y.1, (j : ℝ) + y.2) -
    retainedTerminal S q (retainedPositions S ((A+1)*R)) N s d j y

theorem continuous_terminalRemainder (S : DiscreteSetup) (hφ : Continuous S.φ)
    (q : Finset IntPlane) {N : ℝ} (hN : 1 ≤ N) (A R : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (hs : discreteLabelsAllowed S N s) (j : ℕ) :
    Continuous (terminalRemainder S q N A R s d j) := by
  have ht : Continuous (fun y : Space => (y.1, (j : ℝ) + y.2)) :=
    continuous_fst.prodMk (continuous_const.add continuous_snd)
  have h := (continuous_discreteExtension S hφ hN s d hs).comp ht
  exact h.sub (continuous_retainedTerminal S hφ q _ N s d j)

theorem compact_local_unit_slab (B : ℝ) : IsCompact (coreTube B 1 0 0) := by
  have he : coreTube B 1 0 0 = Metric.closedBall (0 : Plane) B ×ˢ Icc (0 : ℝ) 1 := by
    ext y
    simp [coreTube, Metric.mem_closedBall, dist_zero_right, and_comm]
  rw [he]
  exact (isCompact_closedBall _ _).prod isCompact_Icc

theorem terminalRemainder_integrable_cubed (S : DiscreteSetup) (hφ : Continuous S.φ)
    (q : Finset IntPlane) {N : ℝ} (hN : 1 ≤ N) (A R : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (hs : discreteLabelsAllowed S N s) (j : ℕ) :
    IntegrableOn (fun y => ‖terminalRemainder S q N A R s d j y‖ ^ 3)
      (coreTube (A*R) 1 0 0) volume :=
  ContinuousOn.integrableOn_compact (compact_local_unit_slab _)
    ((continuous_terminalRemainder S hφ q hN A R s d hs j).norm.pow 3).continuousOn

/-- Integrating the actual reconstruction error over a bounded spatial
region and a unit time slab. The chosen frequency family works at every scale. -/
theorem terminalRemainder_cubed_bound (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) :
    ∃ q : Finset IntPlane, ∀ L : ℕ, 3 ≤ L → ∃ C : ℝ, 0 < C ∧
      ∀ N : ℝ, 1 ≤ N → ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ),
      discreteLabelsAllowed S N s → ∀ (j : ℕ) (A R : ℝ), 0 ≤ A → 0 ≤ R →
      (∫ y in coreTube (A*R) 1 0 0, ‖terminalRemainder S q N A R s d j y‖ ^ 3) ≤
        C * (A*R) ^ 2 * (∑ k ∈ s, ‖d k‖) ^ 3 *
          (1+R) ^ (-(3 * ((L : ℝ)-3))) := by
  classical
  obtain ⟨q, hq⟩ := discreteExtension_reconstruction S hφ.continuous
  refine ⟨q, ?_⟩
  intro L hL
  obtain ⟨B, hB, hb⟩ := terminalTail_norm_bound S hφ q L hL
  refine ⟨Real.pi * B ^ 3, by positivity, ?_⟩
  intro N hN s d hs j A R hA hR
  let T := coreTube (A*R) 1 0 0
  let b := B * (∑ k ∈ s, ‖d k‖) * (1+R) ^ (-((L : ℝ)-3))
  have hbound : ∀ y ∈ T, ‖terminalRemainder S q N A R s d j y‖ ≤ b := by
    intro y hy
    have hu : y.2 ∈ Icc (0 : ℝ) 1 := hy.1
    have hx : ‖y.1‖ ≤ A*R := by simpa [T, coreTube] using hy.2
    have he := terminalTail_eq_sub S hφ q (by linarith) hR s d j y hx hu
      (hq N hN s d hs y.1 j y.2)
    change terminalTail S q N A R s d j y = terminalRemainder S q N A R s d j y at he
    rw [← he]
    exact hb N (by linarith) s d j A R hR y hx hu
  have hi := terminalRemainder_integrable_cubed S hφ.continuous q hN A R s d hs j
  have hc : IntegrableOn (fun _ : Space => b ^ 3) T volume :=
    integrableOn_const.mpr (Or.inr ((compact_local_unit_slab (A*R)).measure_lt_top))
  have hm : volume.real T = Real.pi * (A*R)^2 := by
    have h := integral_core_indicator (A*R) 1 0 0 (mul_nonneg hA hR) (by norm_num)
    rw [integral_indicator (measurableSet_coreTube _ _ _ _), setIntegral_const] at h
    simpa [T, smul_eq_mul] using h
  calc
    _ ≤ ∫ _y in T, b ^ 3 := by
      apply integral_mono_ae hi hc
      filter_upwards [ae_restrict_mem (measurableSet_coreTube (A*R) 1 0 0)] with y hy
      exact pow_le_pow_left₀ (norm_nonneg _) (hbound y hy) 3
    _ = Real.pi * (A*R)^2 * b ^ 3 := by rw [setIntegral_const, hm, smul_eq_mul]
    _ = _ := by
      dsimp [b]
      rw [mul_pow, mul_pow, ← Real.rpow_mul_natCast (by linarith : 0 ≤ 1+R)]
      norm_num only [Nat.cast_ofNat]
      have he : (-((L : ℝ)-3)) * (3 : ℝ) = -(3*((L : ℝ)-3)) := by ring
      rw [he]
      ring

/-- At decay order five, the counted coefficient loss and local spatial
volume are completely absorbed on each unit slab. -/
theorem terminal_tail_scale_absorption (N : ℝ) :
    N ^ 12 * (1 + N ^ 2) ^ (-6 : ℝ) ≤ 1 := by
  have hp : 0 < 1 + N^2 := by positivity
  rw [show (-6 : ℝ) = -(6 : ℝ) by norm_num, Real.rpow_neg hp.le,
    show (6 : ℝ) = ((6 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
  rw [← div_eq_mul_inv, div_le_one (pow_pos hp 6)]
  have h := pow_le_pow_left₀ (sq_nonneg N) (by linarith : N^2 ≤ 1+N^2) 6
  simpa only [← pow_mul] using h

theorem terminalRemainder_unit_error_bound (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) :
    ∃ q : Finset IntPlane, ∃ C : ℝ, 0 < C ∧
      ∀ N : ℝ, 1 ≤ N → ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ),
      discreteLabelsAllowed S N s → ∀ (j : ℕ) (A : ℝ), 0 ≤ A →
      (∫ y in coreTube (A*N^2) 1 0 0,
        ‖terminalRemainder S q N A (N^2) s d j y‖ ^ 3) ≤
        C * A^2 * ∑ k ∈ s, ‖d k‖ ^ 3 := by
  obtain ⟨q, hq⟩ := terminalRemainder_cubed_bound S hφ
  obtain ⟨C, hC, hc⟩ := hq 5 (by omega)
  have hI : 0 < initialLabelCountConstant S := by
    have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
    have hf := S.frequencyBound_pos
    have hp := S.C₁_pos
    dsimp [initialLabelCountConstant]
    positivity
  refine ⟨q, C * (initialLabelCountConstant S)^2, by positivity, ?_⟩
  intro N hN s d hs j A hA
  have hh := hc N hN s d hs j A (N^2) hA (sq_nonneg N)
  norm_num only [Nat.cast_ofNat, sub_self, neg_mul, neg_sub] at hh
  have hexp : -(3*((5 : ℝ)-3)) = (-6 : ℝ) := by norm_num
  norm_num at hh
  have hcount := discreteLabels_l1_cubed_bound S hN s d hs
  have hp : 0 ≤ (1 + N^2) ^ (-6 : ℝ) := Real.rpow_nonneg (by positivity) _
  calc
    _ ≤ C * (A*N^2)^2 * (∑ k ∈ s, ‖d k‖)^3 * (1+N^2)^(-6 : ℝ) := hh
    _ ≤ C * (A*N^2)^2 * ((initialLabelCountConstant S)^2 * N^8 *
        ∑ k ∈ s, ‖d k‖^3) * (1+N^2)^(-6 : ℝ) := by
      exact mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_left hcount (by positivity)) hp
    _ = (C * (initialLabelCountConstant S)^2 * A^2 * ∑ k ∈ s, ‖d k‖^3) *
        (N^12 * (1+N^2)^(-6 : ℝ)) := by ring
    _ ≤ _ := by
      have hnon : 0 ≤ C * (initialLabelCountConstant S)^2 * A^2 * ∑ k ∈ s, ‖d k‖^3 := by positivity
      simpa only [mul_one] using mul_le_mul_of_nonneg_left (terminal_tail_scale_absorption N) hnon

/-- The omitted error, summed over every unit slab up to `N²`, is controlled
by the actual core-density integral. No discrete external input is needed. -/
theorem terminalRemainder_sum_absorbed (S : DiscreteSetup)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ) (A : ℝ) :
    ∃ q : Finset IntPlane, ∃ C : ℝ, 0 < C ∧
      ∀ N : ℝ, 1 ≤ N → ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ),
      discreteLabelsAllowed S N s → ∀ K : ℕ, (K : ℝ) ≤ N^2 →
      (∑ j ∈ Finset.range K, ∫ y in coreTube (A*N^2) 1 0 0,
        ‖terminalRemainder S q N A (N^2) s d j y‖ ^ 3) ≤
        C * ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ) := by
  classical
  by_cases hA : 0 ≤ A
  · obtain ⟨q, B, hB, hb⟩ := terminalRemainder_unit_error_bound S hφ
    refine ⟨q, B*A^2/Real.pi + 1, by positivity, ?_⟩
    intro N hN s d hs K hK
    let D := ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3/2 : ℝ)
    have hD : 0 ≤ D := integral_nonneg (fun y => Real.rpow_nonneg
      (coreDensity_nonneg s d _ _ N (N^2) y) _)
    have hlow : Real.pi * N^4 * ∑ k ∈ s, ‖d k‖^3 ≤ D :=
      equation_4_8 s d _ _ N (by linarith)
    have hN2 : N^2 ≤ N^4 := by nlinarith [sq_nonneg (N^2-1)]
    calc
      _ ≤ ∑ _j ∈ Finset.range K, B*A^2 * ∑ k ∈ s, ‖d k‖^3 :=
        Finset.sum_le_sum (fun j _ => hb N hN s d hs j A hA)
      _ = (K : ℝ) * (B*A^2 * ∑ k ∈ s, ‖d k‖^3) := by simp
      _ ≤ N^4 * (B*A^2 * ∑ k ∈ s, ‖d k‖^3) :=
        mul_le_mul_of_nonneg_right (hK.trans hN2) (by positivity)
      _ = (B*A^2/Real.pi) * (Real.pi*N^4 * ∑ k ∈ s, ‖d k‖^3) := by
        field_simp
        ring
      _ ≤ (B*A^2/Real.pi) * D := mul_le_mul_of_nonneg_left hlow (by positivity)
      _ ≤ _ := by nlinarith
  · refine ⟨∅, 1, by norm_num, ?_⟩
    intro N hN s d hs K hK
    have he : coreTube (A*N^2) 1 0 0 = ∅ := by
      apply Set.eq_empty_iff_forall_not_mem.mpr
      intro y hy
      have hx : ‖y.1‖ ≤ A*N^2 := by simpa [coreTube] using hy.2
      have hn : A*N^2 < 0 := mul_neg_of_neg_of_pos (lt_of_not_ge hA) (by positivity)
      exact (not_lt_of_ge (norm_nonneg y.1)) (hx.trans_lt hn)
    rw [he]
    simp only [Measure.restrict_empty, integral_zero_measure, Finset.sum_const_zero, one_mul]
    exact integral_nonneg (fun y => Real.rpow_nonneg
      (coreDensity_nonneg s d _ _ N (N^2) y) _)

end EllipticSquareFunction
