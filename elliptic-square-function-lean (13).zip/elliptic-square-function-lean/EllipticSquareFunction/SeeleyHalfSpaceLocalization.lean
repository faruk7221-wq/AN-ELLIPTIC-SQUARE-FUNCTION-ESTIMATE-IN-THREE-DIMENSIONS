import EllipticSquareFunction.SeeleySmoothHalfSpace

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem seeley_iterated_derivative_zero_outside {f : ℝ × X → E} {R : ℝ}
    (hz : ∀ p : ℝ × X, R < ‖p‖ → f p = 0) (m : ℕ) {p : ℝ × X} (hp : R < ‖p‖) :
    iteratedFDerivWithin ℝ m f {q : ℝ × X | 0 ≤ q.1} p = 0 := by
  have he : f =ᶠ[𝓝 p] (fun _ => (0 : E)) := by
    filter_upwards [continuous_norm.continuousAt.preimage_mem_nhds (Ioi_mem_nhds hp)] with q hq
    exact hz q hq
  rw [(he.filter_mono nhdsWithin_le_nhds).iteratedFDerivWithin_eq (hz p hp) m]
  simp only [iteratedFDerivWithin_zero_fun,Pi.zero_apply]

theorem smooth_halfspace_derivatives_bounded_of_zero_outside [FiniteDimensional ℝ X]
    {f : ℝ × X → E} {R : ℝ}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1})
    (hz : ∀ p : ℝ × X, R < ‖p‖ → f p = 0) (m : ℕ) :
    ∃ B : ℝ, ∀ p : ℝ × X, 0 ≤ p.1 →
      ‖iteratedFDerivWithin ℝ m f {q : ℝ × X | 0 ≤ q.1} p‖ ≤ B := by
  have hc := hf.continuousOn_iteratedFDerivWithin
    (by exact_mod_cast (show (m : ℕ∞) ≤ ⊤ from le_top)) seeley_halfspace_uniqueDiffOn
  have hK : IsCompact (Metric.closedBall (0 : ℝ × X) (max R 0) ∩ {p : ℝ × X | 0 ≤ p.1}) :=
    (isCompact_closedBall (0 : ℝ × X) (max R 0)).inter_right (isClosed_le continuous_const continuous_fst)
  obtain ⟨B,hB⟩ := hK.exists_bound_of_continuousOn (hc.mono Set.inter_subset_right)
  refine ⟨max B 0,fun p hp => ?_⟩
  by_cases hr : ‖p‖ ≤ max R 0
  · exact (hB p ⟨by simpa only [Metric.mem_closedBall,dist_zero_right] using hr,hp⟩).trans (le_max_left _ _)
  · rw [seeley_iterated_derivative_zero_outside hz m
      ((le_max_left R 0).trans_lt (lt_of_not_ge hr)),norm_zero]
    exact le_max_right _ _

theorem smooth_halfspace_extension_of_zero_outside [FiniteDimensional ℝ X]
    {f : ℝ × X → E} {R : ℝ}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1})
    (hz : ∀ p : ℝ × X, R < ‖p‖ → f p = 0) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F f {p : ℝ × X | 0 ≤ p.1} :=
  smooth_halfspace_extension_of_bounded_derivatives hf
    (smooth_halfspace_derivatives_bounded_of_zero_outside hf hz)

/-- Local extension near the origin for arbitrary smooth data on a half-space.
The tangential space is finite-dimensional and the target may be any Banach space. -/
theorem smooth_halfspace_local_extension [FiniteDimensional ℝ X] {f : ℝ × X → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1}) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧
      Set.EqOn F f ({p : ℝ × X | 0 ≤ p.1} ∩ Metric.closedBall 0 1) := by
  let χ : ContDiffBump (0 : ℝ × X) := ⟨1,2,by norm_num,by norm_num⟩
  let g : ℝ × X → E := fun p => χ p • f p
  have hg : ContDiffOn ℝ (⊤ : ℕ∞) g {p : ℝ × X | 0 ≤ p.1} := χ.contDiff.contDiffOn.smul hf
  have hz : ∀ p : ℝ × X, 2 < ‖p‖ → g p = 0 := by
    intro p hp
    have hχ : χ p = 0 := χ.zero_of_le_dist (by simpa only [dist_zero_right] using le_of_lt hp)
    simp only [g,hχ,zero_smul]
  obtain ⟨F,hF,hFg⟩ := smooth_halfspace_extension_of_zero_outside hg hz
  refine ⟨F,hF,fun p hp => ?_⟩
  rw [hFg hp.1]
  have hχ : χ p = 1 := χ.one_of_mem_closedBall hp.2
  simp only [g,hχ,one_smul]

end EllipticSquareFunction
