import EllipticSquareFunction.EmbeddedSurfaceExtensions
import EllipticSquareFunction.NormalSecondFundamentalForm

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators Topology
namespace EllipticSquareFunction

/-- Definite second fundamental form at one parameter point, in either
choice of local normal orientation. -/
def EuclideanDefiniteSecondForm (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a : Plane) : Prop :=
  (∀ v : Plane, v ≠ 0 → 0 < euclideanSecondFundamentalForm F N a v v) ∨
  (∀ v : Plane, v ≠ 0 → euclideanSecondFundamentalForm F N a v v < 0)

/-- Local smooth embedded extensions in actual Euclidean three-space.
Curvature is stated using a unit normal and the second derivative of the
immersion. No graph coordinate, graph Hessian, or inverse is supplied. -/
def EuclideanEllipticSurfaceExtensions (K : Set EuclideanThree) : Prop :=
  ∀ p ∈ K, ∃ (F : Plane → EuclideanThree) (U : Set Plane) (a : Plane)
      (W : Set EuclideanThree) (N : EuclideanThree),
    IsOpen U ∧ a ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧
    Topology.IsEmbedding (fun b : U => F b) ∧ F a=p ∧
    IsOpen W ∧ p ∈ W ∧ K ∩ W ⊆ F '' U ∧
    Function.Injective (fderiv ℝ F a) ∧ ‖N‖=1 ∧
    (∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F a v)=0) ∧
    EuclideanDefiniteSecondForm F N a

theorem euclidean_extensions_to_space {K : Set EuclideanThree}
    (hs : EuclideanEllipticSurfaceExtensions K) :
    LocalEllipticSurfaceExtensions (spaceEuclideanEquiv '' K) := by
  intro p hp
  obtain ⟨q,hq,rfl⟩ := hp
  obtain ⟨F,U,a,W,N,hU,ha,hF,hemb,hFa,hW,hqW,hcover,hD,hN,horth,hdef⟩ := hs q hq
  let E := spaceEuclideanEquiv
  let G : Plane → Space := E ∘ F
  have hdF := (hF.contDiffAt (hU.mem_nhds ha)).differentiableAt (by norm_cast)
  have hdG : fderiv ℝ G a=E.toContinuousLinearMap.comp (fderiv ℝ F a) :=
    (E.hasFDerivAt.comp a hdF.hasFDerivAt).fderiv
  refine ⟨G,U,a,E '' W,E N,hU,ha,E.contDiff.comp_contDiffOn hF,
    E.toHomeomorph.isEmbedding.comp hemb,by simp only [G,Function.comp_apply,hFa,E],
    E.toHomeomorph.isOpenMap W hW,⟨q,hqW,rfl⟩,?_,?_,?_,?_,?_⟩
  · intro z hz
    obtain ⟨x,hx,rfl⟩ := hz.1
    obtain ⟨y,hy,hey⟩ := hz.2
    have hyx : y=x := E.injective hey
    obtain ⟨b,hb,hFb⟩ := hcover ⟨hx,by simpa only [hyx] using hy⟩
    exact ⟨b,hb,by simp only [G,Function.comp_apply,hFb,E]⟩
  · rw [hdG]
    exact E.injective.comp hD
  · intro hz
    have hnz : N=0 := E.injective (hz.trans (map_zero E).symm)
    simpa [hnz] using hN
  · intro v
    rw [hdG]
    exact (spaceEuclideanEquiv_pair N (fderiv ℝ F a v)).trans (horth v)
  · have he : normalHeight G (E N)=fun b => @inner ℝ EuclideanThree _ N (F b) := by
      funext b
      exact spaceEuclideanEquiv_pair N (F b)
    have hh : ∀ v, fderiv ℝ (fderiv ℝ (normalHeight G (E N))) a v v =
        euclideanSecondFundamentalForm F N a v v := by
      intro v
      rw [he]
      exact euclidean_normal_height_hessian
        ((hF.contDiffAt (hU.mem_nhds ha)).of_le (by norm_cast)) N v v
    rcases hdef with hp | hn
    · exact Or.inl (fun v hv => (hh v).symm ▸ hp v hv)
    · exact Or.inr (fun v hv => (hh v).symm ▸ hn v hv)

/-- The Euclidean surface square-function theorem, with local graph
construction and curvature-to-Hessian transfer proved internally. -/
theorem euclidean_embedded_surface_estimate {K : Set EuclideanThree} (hK : IsCompact K)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hsurface : EuclideanEllipticSurfaceExtensions K)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
      ∀ (n : ℕ) (p : Fin n → EuclideanThree) (f : Fin n → SchwartzMap EuclideanThree ℂ),
      (∀ i, p i ∈ K) →
      (∀ i j, i ≠ j → c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
      (∀ i, Function.support (Real.fourierIntegral (f i)) ⊆ surfaceCap K (p i) (Real.sqrt R)⁻¹ C₀) →
      eLpNorm (fun y => ∑ i, f i y) 3 volume ≤ ENNReal.ofReal (C*R^ε)*
        eLpNorm (fun y => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume :=
  euclidean_surface_estimate_of_positive_graphs hK hc₀ hC₀
    (positive_graph_extensions_of_embedded_surface (euclidean_extensions_to_space hsurface))
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
