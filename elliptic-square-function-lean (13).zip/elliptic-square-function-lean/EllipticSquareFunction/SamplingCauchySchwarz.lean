import EllipticSquareFunction.SamplingDensity
import Mathlib.MeasureTheory.Integral.MeanInequalities

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

/-- Weighted integral Cauchy–Schwarz, including infinite integrals. -/
theorem weighted_lintegral_cauchy_schwarz (μ : Measure Space)
    (u w : Space → ℝ≥0∞) (hu : AEMeasurable u μ) (hw : AEMeasurable w μ) :
    (∫⁻ z, u z*w z ∂μ)^2 ≤ (∫⁻ z, u z^2*w z ∂μ)*(∫⁻ z, w z ∂μ) := by
  have hp : (2:ℝ).HolderConjugate 2 := by
    apply Real.holderConjugate_iff.mpr
    norm_num
  have hh := ENNReal.lintegral_mul_le_Lp_mul_Lq μ hp
    (hu.mul (hw.pow_const (1/2:ℝ))) (hw.pow_const (1/2:ℝ))
  have he (a b : ℝ≥0∞) : (a*b^(1/2:ℝ))*b^(1/2:ℝ)=a*b := by
    rw [mul_assoc,← ENNReal.rpow_add_of_nonneg (1/2:ℝ) (1/2:ℝ) (by norm_num) (by norm_num)]
    norm_num
  have hs (a : ℝ≥0∞) : (a^(1/2:ℝ))^(2:ℝ)=a := by
    rw [← ENNReal.rpow_mul]
    norm_num
  have ht (a b : ℝ≥0∞) : (a*b^(1/2:ℝ))^(2:ℝ)=a^2*b := by
    rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num),hs]
    norm_num
  simp only [Pi.mul_apply,he,ht,hs] at hh
  have hh' := pow_le_pow_left' hh 2
  rw [mul_pow] at hh'
  have hr (a : ℝ≥0∞) : (a^(1/2:ℝ))^2=a := by
    rw [← ENNReal.rpow_natCast,← ENNReal.rpow_mul]
    norm_num
  simpa only [hr] using hh'

/-- The squared norm of a complex kernel integral is controlled by its
weighted square integral and kernel mass. No reproducing identity is assumed. -/
theorem kernel_integral_cauchy_schwarz (μ : Measure Space)
    (f K : Space → ℂ) (hf : AEStronglyMeasurable f μ) (hK : AEStronglyMeasurable K μ) :
    ENNReal.ofReal (‖∫ z, f z*K z ∂μ‖^2) ≤
      (∫⁻ z, ENNReal.ofReal (‖f z‖^2)*ENNReal.ofReal ‖K z‖ ∂μ)*
        (∫⁻ z, ENNReal.ofReal ‖K z‖ ∂μ) := by
  have hh : ENNReal.ofReal ‖∫ z, f z*K z ∂μ‖ ≤
      ∫⁻ z, ENNReal.ofReal ‖f z‖*ENNReal.ofReal ‖K z‖ ∂μ := by
    have hh := enorm_integral_le_lintegral_enorm (μ := μ) (fun z => f z*K z)
    simpa only [← ofReal_norm_eq_enorm,norm_mul,ENNReal.ofReal_mul (norm_nonneg _)] using hh
  have hs := weighted_lintegral_cauchy_schwarz μ
    (fun z => ENNReal.ofReal ‖f z‖) (fun z => ENNReal.ofReal ‖K z‖)
    hf.norm.aemeasurable.ennreal_ofReal hK.norm.aemeasurable.ennreal_ofReal
  rw [ENNReal.ofReal_pow (norm_nonneg _) 2]
  apply (pow_le_pow_left' hh 2).trans
  simpa only [ENNReal.ofReal_pow (norm_nonneg _) 2] using hs

/-- The analytic local-sample implication: a reproducing integral with a
kernel mass bound and pointwise decay has the weighted squared sample bound.
Constructing that reproducing kernel remains a separate obligation. -/
theorem local_sample_bound_from_kernel (μ : Measure Space)
    (f K : Space → ℂ) (hf : AEStronglyMeasurable f μ) (hK : AEStronglyMeasurable K μ)
    (W : Space → ℝ≥0∞) (hW : AEMeasurable W μ) (B C : ℝ≥0∞)
    (hdecay : ∀ᵐ z ∂μ, ENNReal.ofReal ‖K z‖≤C*W z)
    (hmass : (∫⁻ z, ENNReal.ofReal ‖K z‖ ∂μ)≤B) :
    ENNReal.ofReal (‖∫ z, f z*K z ∂μ‖^2) ≤
      B*C*(∫⁻ z, ENNReal.ofReal (‖f z‖^2)*W z ∂μ) := by
  have hF₂ : AEMeasurable (fun z => ENNReal.ofReal (‖f z‖^2)) μ := by
    simpa only [pow_two] using (hf.norm.aemeasurable.mul hf.norm.aemeasurable).ennreal_ofReal
  have hint : (∫⁻ z, ENNReal.ofReal (‖f z‖^2)*ENNReal.ofReal ‖K z‖ ∂μ) ≤
      C*(∫⁻ z, ENNReal.ofReal (‖f z‖^2)*W z ∂μ) := by
    calc
      _ ≤ ∫⁻ z, C*(ENNReal.ofReal (‖f z‖^2)*W z) ∂μ := by
        apply lintegral_mono_ae
        filter_upwards [hdecay] with z hz
        simpa only [mul_left_comm] using mul_le_mul_left' hz (ENNReal.ofReal (‖f z‖^2))
      _ = _ := lintegral_const_mul'' C (hF₂.mul hW)
  have hh := (kernel_integral_cauchy_schwarz μ f K hf hK).trans (mul_le_mul' hint hmass)
  simpa only [mul_comm,mul_left_comm,mul_assoc] using hh

end EllipticSquareFunction
