import EllipticSquareFunction.ActualSamplingDensity
import EllipticSquareFunction.MainReduction

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Reflection preserves the product Lebesgue measure on physical spacetime. -/
theorem space_volume_neg_invariant : (volume : Measure Space).IsNegInvariant := by
  constructor
  exact ((Measure.measurePreserving_neg (volume : Measure Plane)).prod
    (Measure.measurePreserving_neg (volume : Measure ℝ))).map_eq

/-- Translation preserves the product Lebesgue measure on spacetime. -/
theorem space_volume_add_left_invariant : (volume : Measure Space).IsAddLeftInvariant := by
  constructor
  intro p
  exact ((measurePreserving_add_left (volume : Measure Plane) p.1).prod
    (measurePreserving_add_left (volume : Measure ℝ) p.2)).map_eq

attribute [local instance] space_volume_neg_invariant space_volume_add_left_invariant


/-- The positive convolution appearing in Lemma 4 is finite at every point,
not merely almost everywhere, for Schwartz data. -/
theorem schwartz_square_tube_integrable (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) (y : Space) :
    Integrable (fun z => ‖f z‖^2*tubeKernel R M V (y-z)) volume := by
  apply ((tubeKernel_integrable hR hM V).comp_sub_left y).bdd_mul
    (f.continuous.norm.pow 2).aestronglyMeasurable
  refine ⟨(SchwartzMap.seminorm ℝ 0 0 f)^2,?_⟩
  intro z
  rw [Real.norm_eq_abs,abs_of_nonneg (sq_nonneg _)]
  exact pow_le_pow_left₀ (norm_nonneg _) (SchwartzMap.norm_le_seminorm ℝ f z) 2

/-- Positive integral and Bochner-convolution formulations agree, with
integrability proved for the actual Schwartz datum. -/
theorem lintegral_schwartz_square_tube (f : SchwartzMap Space ℂ)
    {R M : ℝ} (hR : 0<R) (hM : 2<M) (V : Plane) (y : Space) :
    (∫⁻ z, ENNReal.ofReal (‖f z‖^2)*ENNReal.ofReal (tubeKernel R M V (y-z))) =
      ENNReal.ofReal (positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M V) y) := by
  simp_rw [← ENNReal.ofReal_mul (sq_nonneg _)]
  rw [← ofReal_integral_eq_lintegral_ofReal (schwartz_square_tube_integrable f hR hM V y)
    (Filter.Eventually.of_forall (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..)))]
  congr 1
  have hh := integral_sub_left_eq_self (fun z => ‖f z‖^2*tubeKernel R M V (y-z)) volume y
  simpa only [sub_sub_cancel,positiveConvolution] using hh.symm

/-- A finite nonnegative extended-real sum gives genuine real summability. -/
theorem summable_of_ofReal_tsum_bound {ι : Type*} (a : ι → ℝ)
    (ha : ∀ i, 0≤a i) {B : ℝ} (hB : 0≤B)
    (h : (∑' i, ENNReal.ofReal (a i))≤ENNReal.ofReal B) :
    Summable a ∧ (∑' i, a i)≤B := by
  have ht : (∑' i, ENNReal.ofReal (a i))≠⊤ := ne_top_of_le_ne_top ENNReal.ofReal_ne_top h
  have hs : Summable a := by
    simpa only [ENNReal.toReal_ofReal,ha] using ENNReal.summable_toReal ht
  refine ⟨hs,?_⟩
  rw [← ENNReal.ofReal_tsum_of_nonneg ha hs] at h
  exact (ENNReal.ofReal_le_ofReal_iff hB).mp h

/-- Real-valued, summable full sampling density, dominated by the actual
positive convolution in (6.2). Constants precede R, ν, and f. -/
theorem uniform_cap_sampling_density_real {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ M A B : ℝ} (hC₀ : 0≤C₀) (hM : 2<M) (hA : 0<A) (hB : 0<B) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν : Plane) (f : SchwartzMap Space ℂ),
      Function.support (fourierTransform f) ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀ → ∀ y : Space,
      let p := fun i : IntPlane × ℤ => samplePoint (Real.sqrt R) R A B
        (velocity φ ν) (latticePoint 1 i.1) i.2
      Summable (fun i => ‖f (p i)‖^2*packetWeight R M (velocity φ ν) (p i).1 (p i).2 y) ∧
      (∑' i, ‖f (p i)‖^2*packetWeight R M (velocity φ ν) (p i).1 (p i).2 y) ≤
        C*positiveConvolution (fun z => ‖f z‖^2) (tubeKernel R M (velocity φ ν)) y := by
  obtain ⟨C,hC,hbound⟩ := uniform_cap_sampling_density (M := M) hphase hC₀ (by linarith) hA hB
  refine ⟨C,hC,?_⟩
  intro R hR ν f hcap y
  have hR₀ : 0<R := by linarith
  have hh := hbound R hR ν f hcap y
  dsimp only at hh ⊢
  rw [lintegral_schwartz_square_tube f hR₀ hM,← ENNReal.ofReal_mul hC.le] at hh
  simp_rw [← ENNReal.ofReal_mul (sq_nonneg _)] at hh
  apply summable_of_ofReal_tsum_bound _ (fun _ => mul_nonneg (sq_nonneg _) (packetWeight_nonneg ..)) _ hh
  exact mul_nonneg hC.le (integral_nonneg (fun z => mul_nonneg (sq_nonneg _) (tubeKernel_nonneg ..)))

end EllipticSquareFunction
