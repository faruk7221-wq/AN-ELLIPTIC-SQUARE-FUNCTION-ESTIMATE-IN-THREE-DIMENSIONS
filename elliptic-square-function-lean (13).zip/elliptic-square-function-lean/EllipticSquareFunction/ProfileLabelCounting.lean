import EllipticSquareFunction.FrequencyPacking

/-! # Counting bounded separated original profile labels -/
noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

theorem integerPlaneBox_card_mono {x y : ℝ} (h : x ≤ y) :
    (integerPlaneBox ⌈x⌉₊).card ≤ (integerPlaneBox ⌈y⌉₊).card := by
  rw [integerPlaneBox_card, integerPlaneBox_card]
  have hc := Nat.ceil_mono h
  exact Nat.pow_le_pow_left (by omega : 2*⌈x⌉₊+1 ≤ 2*⌈y⌉₊+1) 2

/-- An additive floor-error term is absorbed uniformly for N at least one. -/
theorem integerPlaneBox_card_affine_scale {B T N : ℝ} (hB : 0 ≤ B)
    (hT : 0 ≤ T) (hN : 1 ≤ N) :
    ((integerPlaneBox ⌈B*N+T⌉₊).card : ℝ) ≤ (2*(B+T)+3)^2*N^2 := by
  have hh : B*N+T ≤ (B+T)*N := by nlinarith
  have hc : ((integerPlaneBox ⌈B*N+T⌉₊).card : ℝ) ≤ (integerPlaneBox ⌈(B+T)*N⌉₊).card := by
    exact_mod_cast integerPlaneBox_card_mono hh
  exact hc.trans
    (integerPlaneBox_card_scale (add_nonneg hB hT) hN)

/-- Frequencies in a fixed ball and separated at scale N⁻¹ number O(N²). -/
theorem separated_frequency_card_bound {ι : Type*} (s : Finset ι) (ν : ι → Plane)
    {N σ F : ℝ} (hN : 1 ≤ N) (hσ : 0 < σ) (hF : 0 ≤ F)
    (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖) :
    (s.card : ℝ) ≤ (2*((5/σ)*F+4)+3)^2*N^2 := by
  have hN0 : 0<N := by linarith
  have hscaled : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ ≤ ‖N • ν i-N • ν j‖ := by
    intro i hi j hj hij
    rw [← smul_sub, norm_smul, Real.norm_eq_abs, abs_of_pos hN0]
    have hh := (div_le_iff₀ hN0).mp (hsep i hi j hj hij)
    nlinarith
  have hball : ∀ i ∈ s, ‖N • ν i-(0:Plane)‖ ≤ F*N := by
    intro i hi
    rw [sub_zero, norm_smul, Real.norm_eq_abs, abs_of_pos hN0]
    nlinarith [hν i hi]
  have hc := separated_plane_card_bound s (fun i => N • ν i) hσ 0 hscaled hball
  have hb := integerPlaneBox_card_affine_scale
    (B := (5/σ)*F) (T := 4) (by positivity) (by norm_num) hN
  apply (by exact_mod_cast hc : (s.card : ℝ) ≤ (integerPlaneBox ⌈(5/σ)*(F*N)+4⌉₊).card).trans
  convert hb using 1 <;> ring

/-- A translated scale-N position lattice in a radius A N² ball numbers O(N²). -/
theorem bounded_position_lattice_card {N c A : ℝ} (hN : 1 ≤ N) (hc : 0 < c)
    (hA : 0 ≤ A) (pbox : Finset IntPlane) (r : Plane)
    (hv : ∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) :
    (pbox.card : ℝ) ≤ (2*(A/c+2)+3)^2*N^2 := by
  have hN0 : 0<N := by linarith
  let u := -((N*c)⁻¹ • r)
  have hp (p : IntPlane) (hp : p ∈ pbox) : ‖u-latticePoint 1 p‖ ≤ (A/c)*N := by
    have he : u-latticePoint 1 p = -((N*c)⁻¹ • (r+N • latticePoint c p)) := by
      dsimp [u]
      rw [smul_add, smul_smul, ← latticePoint_mul]
      have hh : (N*c)⁻¹*N*c = 1 := by field_simp
      rw [hh]
      abel
    rw [he, norm_neg, norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr (mul_pos hN0 hc))]
    have hh := mul_le_mul_of_nonneg_left (hv p hp) (inv_pos.mpr (mul_pos hN0 hc)).le
    convert hh using 1 <;> field_simp <;> ring
  have hh := translated_lattice_card_bound u ((A/c)*N) pbox hp
  have hh' : (pbox.card : ℝ) ≤ (integerPlaneBox ⌈(A/c)*N+2⌉₊).card := by exact_mod_cast hh
  exact hh'.trans
    (integerPlaneBox_card_affine_scale (div_nonneg hA hc.le) (by norm_num : (0:ℝ)≤2) hN)

def profileLabelCountConstant (c σ F A : ℝ) : ℝ :=
  (2*((5/σ)*F+4)+3)^2 * (2*(A/c+2)+3)^2

theorem profileLabels_l1_cubed_bound {ι : Type*} (s : Finset ι) (pbox : Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (r : Plane)
    {N c σ F A : ℝ} (hN : 1 ≤ N) (hc : 0 < c) (hσ : 0 < σ)
    (hF : 0 ≤ F) (hA : 0 ≤ A) (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hsep : ∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i-ν j‖)
    (hv : ∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) :
    (∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖)^3 ≤
      (profileLabelCountConstant c σ F A)^2 * N^8 *
        ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖^3 := by
  have hf := separated_frequency_card_bound s ν hN hσ hF hν hsep
  have hp := bounded_position_lattice_card hN hc hA pbox r hv
  have hcard : ((s ×ˢ pbox).card : ℝ) ≤ profileLabelCountConstant c σ F A * N^4 := by
    rw [Finset.card_product, Nat.cast_mul]
    convert mul_le_mul hf hp (by positivity) (by positivity) using 1
    dsimp [profileLabelCountConstant]
    ring
  have hh := weighted_cubic_holder (s ×ˢ pbox) (fun _ => (1:ℝ)) (fun ip => ‖a ip.1 ip.2‖)
    (by intros; norm_num) (by intros; positivity)
  simp only [one_mul, Finset.sum_const, nsmul_eq_mul, mul_one, Finset.sum_product] at hh
  apply hh.trans
  have hh' := pow_le_pow_left₀ (by positivity : 0 ≤ ((s ×ˢ pbox).card : ℝ)) hcard 2
  have hsum : 0 ≤ ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖^3 :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => by positivity))
  convert mul_le_mul_of_nonneg_right hh' hsum using 1 <;> ring

end EllipticSquareFunction
