import EllipticSquareFunction.PositiveGraphSurfaceTheorem

noncomputable section
namespace EllipticSquareFunction

def graphLift (φ : Phase) (ξ : Plane) : Space := (ξ,φ ξ)

def graphNormal (φ : Phase) (ξ : Plane) : Space := (-velocity φ ξ,1)

def graphNormalLength (φ : Phase) (ξ : Plane) : ℝ := Real.sqrt (1+‖velocity φ ξ‖^2)

def graphUnitNormal (φ : Phase) (ξ : Plane) : Space :=
  (graphNormalLength φ ξ)⁻¹ • graphNormal φ ξ

theorem graphLift_hasFDerivAt {φ : Phase} {ξ : Plane} (hφ : DifferentiableAt ℝ φ ξ) :
    HasFDerivAt (graphLift φ) ((ContinuousLinearMap.id ℝ Plane).prod (fderiv ℝ φ ξ)) ξ :=
  (hasFDerivAt_id ξ).prodMk hφ.hasFDerivAt

theorem graphNormalLength_pos (φ : Phase) (ξ : Plane) : 0 < graphNormalLength φ ξ := by
  unfold graphNormalLength
  positivity

theorem graphNormal_orthogonal {φ : Phase} {ξ : Plane} (hφ : DifferentiableAt ℝ φ ξ) (v : Plane) :
    spacePair (graphNormal φ ξ) (fderiv ℝ (graphLift φ) ξ v)=0 := by
  rw [(graphLift_hasFDerivAt hφ).fderiv]
  simp [graphNormal,spacePair,inner_neg_left,fderiv_eq_inner_velocity]
  ring

theorem graphUnitNormal_euclidean_norm (φ : Phase) (ξ : Plane) :
    ‖spaceEuclideanEquiv.symm (graphUnitNormal φ ξ)‖=1 := by
  have hp := graphNormalLength_pos φ ξ
  have hpair : spacePair (graphNormal φ ξ) (graphNormal φ ξ)=graphNormalLength φ ξ^2 := by
    rw [graphNormalLength,Real.sq_sqrt (by positivity)]
    change @inner ℝ Plane _ (-velocity φ ξ) (-velocity φ ξ)+1*1=1+‖velocity φ ξ‖^2
    rw [inner_neg_neg,real_inner_self_eq_norm_sq]
    ring
  have hn : ‖spaceEuclideanEquiv.symm (graphNormal φ ξ)‖=graphNormalLength φ ξ := by
    have he := spaceEuclideanEquiv_pair (spaceEuclideanEquiv.symm (graphNormal φ ξ))
      (spaceEuclideanEquiv.symm (graphNormal φ ξ))
    simp only [ContinuousLinearEquiv.apply_symm_apply,real_inner_self_eq_norm_sq,hpair] at he
    nlinarith [norm_nonneg (spaceEuclideanEquiv.symm (graphNormal φ ξ))]
  simp only [graphUnitNormal,map_smul,norm_smul,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hp),hn,
    inv_mul_cancel₀ hp.ne']

/-- Differentiating the graph tangent-field formula gives zero planar
component and the phase Hessian in the vertical component. -/
theorem graph_tangent_field_derivative {φ : Phase} {ξ : Plane}
    (hφ : DifferentiableAt ℝ (fderiv ℝ φ) ξ) (v w : Plane) :
    fderiv ℝ (fun η : Plane => (v,fderiv ℝ φ η v) : Plane → Space) ξ w =
      (0,fderiv ℝ (fderiv ℝ φ) ξ w v) := by
  have ht := hφ.hasFDerivAt.clm_apply (hasFDerivAt_const v ξ)
  have hh := (hasFDerivAt_const v ξ).prodMk ht
  rw [hh.fderiv]
  simp

/-- The oriented normal component of the differentiated tangent field is the
graph Hessian divided by the positive normalizing length. -/
theorem graph_normal_second_derivative {φ : Phase} {ξ : Plane}
    (hφ : DifferentiableAt ℝ (fderiv ℝ φ) ξ) (v w : Plane) :
    spacePair (graphUnitNormal φ ξ)
      (fderiv ℝ (fun η : Plane => (v,fderiv ℝ φ η v) : Plane → Space) ξ w) =
      fderiv ℝ (fderiv ℝ φ) ξ w v / graphNormalLength φ ξ := by
  rw [graph_tangent_field_derivative hφ]
  simp [graphUnitNormal,graphNormal,spacePair,div_eq_mul_inv,mul_comm]

/-- For a smooth graph, the differentiated field is the actual derivative of
the differential of the immersion, evaluated on a fixed tangent vector. -/
theorem graph_immersion_normal_second_derivative {φ : Phase}
    (hφ : ContDiff ℝ 2 φ) (ξ v w : Plane) :
    spacePair (graphUnitNormal φ ξ)
      (fderiv ℝ (fun η => fderiv ℝ (graphLift φ) η v) ξ w) =
      fderiv ℝ (fderiv ℝ φ) ξ w v / graphNormalLength φ ξ := by
  have he : (fun η => fderiv ℝ (graphLift φ) η v) =
      (fun η : Plane => (v,fderiv ℝ φ η v) : Plane → Space) := by
    funext η
    rw [(graphLift_hasFDerivAt (hφ.differentiable (by norm_num) η)).fderiv]
    rfl
  rw [he]
  exact graph_normal_second_derivative
    ((hφ.fderiv_right (m := 1) (by norm_num)).differentiable (by norm_num) ξ) v w

end EllipticSquareFunction
