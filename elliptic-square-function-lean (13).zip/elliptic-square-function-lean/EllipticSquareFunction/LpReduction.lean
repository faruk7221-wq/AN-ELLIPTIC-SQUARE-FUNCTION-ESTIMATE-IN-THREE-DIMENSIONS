import EllipticSquareFunction.Definitions

/-!
# The `L³` / `L^(3/2)` reduction in Section 7

All norms here are actual Mathlib `eLpNorm`s on a measure space, not abstract
symbols standing for norms. Extended norms keep the statements valid without
silently assuming finiteness. The packet and smoothing estimates remain
explicit hypotheses of `section7_reduction`.
-/

noncomputable section
open scoped ENNReal NNReal
open MeasureTheory
namespace EllipticSquareFunction

theorem eLpNorm_sqrt {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (H : α → ℝ) (hH : ∀ x, 0 ≤ H x) :
    eLpNorm (fun x => Real.sqrt (H x)) 3 μ =
      eLpNorm H (3 / 2) μ ^ (1 / 2 : ℝ) := by
  have hf : (fun x => Real.sqrt (H x)) = (fun x => ‖H x‖ ^ (1 / 2 : ℝ)) := by
    funext x
    rw [Real.sqrt_eq_rpow, Real.norm_eq_abs, abs_of_nonneg (hH x)]
  rw [hf, eLpNorm_norm_rpow _ (by norm_num : (0 : ℝ) < 1 / 2)]
  rw [ENNReal.ofReal_div_of_pos (by norm_num : (0 : ℝ) < 2)]
  norm_num [div_eq_mul_inv]

theorem eLpNorm_nonneg_const_mul {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (p : ℝ≥0∞) (H : α → ℝ) {C : ℝ} (hC : 0 ≤ C) :
    eLpNorm (fun x => C * H x) p μ = ENNReal.ofReal C * eLpNorm H p μ := by
  change eLpNorm (C • H) p μ = _
  rw [eLpNorm_const_smul, ← ofReal_norm_eq_enorm, Real.norm_eq_abs, abs_of_nonneg hC]

/-- Taking square roots of a smoothing bound produces exactly a half-power
of its constant. This is why the `R^(γ/2)` density loss becomes `R^(γ/4)`. -/
theorem sqrt_norm_bound {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (H G : α → ℝ) {C : ℝ}
    (hH : ∀ x, 0 ≤ H x) (hG : ∀ x, 0 ≤ G x) (hC : 0 ≤ C)
    (h : eLpNorm H (3 / 2) μ ≤ ENNReal.ofReal C * eLpNorm G (3 / 2) μ) :
    eLpNorm (fun x => Real.sqrt (H x)) 3 μ ≤
      ENNReal.ofReal (Real.sqrt C) * eLpNorm (fun x => Real.sqrt (G x)) 3 μ := by
  rw [eLpNorm_sqrt μ H hH, eLpNorm_sqrt μ G hG]
  calc
    _ ≤ (ENNReal.ofReal C * eLpNorm G (3 / 2) μ) ^ (1 / 2 : ℝ) :=
      ENNReal.rpow_le_rpow h (by norm_num)
    _ = _ := by
      rw [ENNReal.mul_rpow_of_nonneg _ _ (by norm_num : (0 : ℝ) ≤ 1 / 2),
        ENNReal.ofReal_rpow_of_nonneg hC (by norm_num), ← Real.sqrt_eq_rpow]

/-- The actual norm composition in (7.5). `A` is the packet bound, `B` the
sampling-density constant, and `C` the tube-smoothing bound. -/
theorem section7_reduction {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (F : α → ℂ) (H K G : α → ℝ) {A B C : ℝ}
    (hA : 0 ≤ A) (hB : 0 ≤ B) (hC : 0 ≤ C)
    (hH : ∀ x, 0 ≤ H x) (hK : ∀ x, 0 ≤ K x) (hG : ∀ x, 0 ≤ G x)
    (hpacket : eLpNorm F 3 μ ≤ ENNReal.ofReal A *
      eLpNorm (fun x => Real.sqrt (H x)) 3 μ)
    (hdensity : ∀ x, H x ≤ B * K x)
    (hsmooth : eLpNorm K (3 / 2) μ ≤ ENNReal.ofReal C * eLpNorm G (3 / 2) μ) :
    eLpNorm F 3 μ ≤ ENNReal.ofReal (A * Real.sqrt B * Real.sqrt C) *
      eLpNorm (fun x => Real.sqrt (G x)) 3 μ := by
  have hd : eLpNorm H (3 / 2) μ ≤ ENNReal.ofReal B * eLpNorm K (3 / 2) μ := by
    calc
      _ ≤ eLpNorm (fun x => B * K x) (3 / 2) μ := by
        apply eLpNorm_mono
        intro x
        simpa only [Real.norm_eq_abs, abs_of_nonneg (hH x),
          abs_of_nonneg (mul_nonneg hB (hK x))] using hdensity x
      _ = _ := eLpNorm_nonneg_const_mul μ _ K hB
  have hs : eLpNorm H (3 / 2) μ ≤
      ENNReal.ofReal (B * C) * eLpNorm G (3 / 2) μ := by
    calc
      _ ≤ ENNReal.ofReal B * (ENNReal.ofReal C * eLpNorm G (3 / 2) μ) :=
        hd.trans (mul_le_mul_left' hsmooth _)
      _ = _ := by rw [ENNReal.ofReal_mul hB, mul_assoc]
  have hroot := sqrt_norm_bound μ H G hH hG (mul_nonneg hB hC) hs
  calc
    _ ≤ ENNReal.ofReal A * (ENNReal.ofReal (Real.sqrt (B * C)) *
        eLpNorm (fun x => Real.sqrt (G x)) 3 μ) :=
      hpacket.trans (mul_le_mul_left' hroot _)
    _ = _ := by
      rw [Real.sqrt_mul hB]
      simp only [ENNReal.ofReal_mul hA,
        ENNReal.ofReal_mul (mul_nonneg hA (Real.sqrt_nonneg B)),
        ENNReal.ofReal_mul (Real.sqrt_nonneg B), mul_assoc]

/-- Specializing the square-root identity to the article's square function. -/
theorem squareFunction_norm {ι : Type*} (s : Finset ι) (f : ι → Space → ℂ) :
    l3Real (squareFunction s f) =
      lThreeHalves (fun y => ∑ i ∈ s, ‖f i y‖ ^ 2) ^ (1 / 2 : ℝ) := by
  exact eLpNorm_sqrt volume _ (fun y => Finset.sum_nonneg (fun i _ => sq_nonneg _))

end EllipticSquareFunction
