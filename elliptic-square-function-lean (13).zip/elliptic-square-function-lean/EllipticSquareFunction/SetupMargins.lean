import EllipticSquareFunction.SeparatedFrame

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

/-- The approximation estimate with a caller-supplied frequency cutoff.
The cutoff may therefore be chosen from b and χ before the setup label bounds.
This is one supporting refactor, not a construction of compatible setups. -/
theorem separated_approximation_with_cutoff {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (Z : ℝ) (hZ : 0≤Z)
    (hcut : ∀ N : ℝ, 0<N → ∀ μ w ν v : Plane,
      Z/N<‖μ-ν‖ → windowMatrix b S.χ N μ w ν v=0)
    (L : ℕ) (hL : 3≤L) :
    ∃ B : ℝ, 0<B ∧ ∀ N : ℝ, 1≤N → ∀ A F : ℝ,
      A+1≤S.C₁ → F+Z≤S.frequencyBound →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ‖ν i‖≤F) →
      (∀ i ∈ s, ∀ p ∈ pbox i, ‖v i p‖≤A*N^2) →
      ∃ q : Finset IntPlane,
        discreteLabelsAllowed S N (q ×ˢ fineRetainedPositions S N A) ∧
        ∀ y : Space,
        ‖(∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p) y)-
          discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
            (separatedProfileCoefficient S b N s pbox a ν v) y‖ ≤
          B*(1+N)^(-((L:ℝ)-3))*(∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖) := by
  classical
  have hD : 0<(S.D:ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨C,hC,hcoeff⟩ := smooth_separatedCoefficient_absolute_tail (ι := ι)
    b hb hbs S.χ S.χ_smooth S.χ_compact (inv_pos.mpr hD) L hL
  have hχ : Integrable (fun ζ => (S.χ ζ:ℂ)) :=
    (Complex.continuous_ofReal.comp S.χ_smooth.continuous).integrable_of_hasCompactSupport
      (S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero)
  let H := ∫ ζ, ‖(S.χ ζ:ℂ)‖
  have hH : 0≤H := integral_nonneg (fun _ => norm_nonneg _)
  let u : ℝ := ((S.D:ℝ)^2)⁻¹
  have hu : 0≤u := by dsimp [u]; positivity
  refine ⟨u*H*C+1,by positivity,?_⟩
  intro N hN A F hA hF s pbox a ν v hν hv
  have hN0 : 0<N := by linarith
  obtain ⟨q,hq,hs⟩ := separated_profile_bounded_frequencies S hφ b hb.continuous hbs
    hN hZ hF s pbox a ν v hν (hcut N hN0)
  refine ⟨q,fine_retained_labels_allowed S hN0 q hq hA,?_⟩
  intro y
  obtain ⟨hc,ht⟩ := hcoeff N hN0 A s pbox q a ν v hv
  rw [← separatedSynthesisTail_eq_sub S hφ b hN0 s pbox q a ν v y (hs y),
    norm_smul,Real.norm_eq_abs,abs_of_nonneg hu]
  have ht' := separatedSynthesisTail_norm_bound S.φ b S.χ hχ hN0 s pbox q a ν v hc y
  have hp : 0≤(1+N)^(-((L:ℝ)-3)) := Real.rpow_nonneg (by linarith) _
  have ha : 0≤∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖ :=
    Finset.sum_nonneg (fun i _ => Finset.sum_nonneg (fun p _ => norm_nonneg _))
  calc
    _ ≤ u*(H*∑' n, omittedSeparatedCoefficient b S.χ N (S.D:ℝ)⁻¹ A s pbox q a ν v n) :=
      mul_le_mul_of_nonneg_left ht' hu
    _ ≤ u*(H*(C*(1+N)^(-((L:ℝ)-3))*(∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖))) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left ht hH) hu
    _ ≤ _ := by nlinarith

end EllipticSquareFunction
