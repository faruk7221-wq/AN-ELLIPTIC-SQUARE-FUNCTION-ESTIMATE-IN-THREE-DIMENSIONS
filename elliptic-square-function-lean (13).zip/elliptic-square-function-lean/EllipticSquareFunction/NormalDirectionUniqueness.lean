import EllipticSquareFunction.TangentNormalCoordinates

noncomputable section
namespace EllipticSquareFunction

/-- An immersed two-plane in three-space has a one-dimensional normal
space. Every other nonzero normal is a nonzero scalar multiple. -/
theorem normal_direction_unique (D : Plane →L[ℝ] Space) (hD : Function.Injective D)
    (N M : Space) (hN : N ≠ 0) (hM : M ≠ 0)
    (hNort : ∀ v, spacePair N (D v)=0) (hMort : ∀ v, spacePair M (D v)=0) :
    ∃ c : ℝ, c ≠ 0 ∧ M=c • N := by
  let E := tangentNormalEquiv D N hD hN hNort
  let z := E.symm M
  have hdec : M=D z.1+z.2 • N := (E.apply_symm_apply M).symm
  have hh := hMort z.1
  rw [hdec] at hh
  change spacePairLinear (D z.1+z.2 • N) (D z.1)=0 at hh
  rw [map_add,map_smul] at hh
  change spacePair (D z.1) (D z.1)+z.2*spacePair N (D z.1)=0 at hh
  rw [hNort,mul_zero,add_zero] at hh
  have hd0 : D z.1=0 := by
    by_contra hn
    exact (spacePair_self_pos hn).ne' hh
  have he : M=z.2 • N := by simpa only [hd0,zero_add] using hdec
  refine ⟨z.2,?_,he⟩
  intro hz
  exact hM (by simpa only [hz,zero_smul] using he)

/-- Unit normals to the same immersed plane differ only by sign. -/
theorem unit_normal_direction_unique (D : Plane →L[ℝ] Space) (hD : Function.Injective D)
    (N M : Space) (hN : ‖spaceEuclideanEquiv.symm N‖=1)
    (hM : ‖spaceEuclideanEquiv.symm M‖=1)
    (hNort : ∀ v, spacePair N (D v)=0) (hMort : ∀ v, spacePair M (D v)=0) :
    M=N ∨ M= -N := by
  have hn : N ≠ 0 := by intro hz; simp [hz] at hN
  have hm : M ≠ 0 := by intro hz; simp [hz] at hM
  obtain ⟨c,_,he⟩ := normal_direction_unique D hD N M hn hm hNort hMort
  have hc : |c|=1 := by simpa only [he,map_smul,norm_smul,Real.norm_eq_abs,hN,mul_one] using hM
  rcases (abs_eq (by norm_num : (0 : ℝ) ≤ 1)).mp hc with hc | hc
  · left
    simpa only [hc,one_smul] using he
  · right
    simpa only [hc,neg_smul,one_smul] using he

end EllipticSquareFunction
