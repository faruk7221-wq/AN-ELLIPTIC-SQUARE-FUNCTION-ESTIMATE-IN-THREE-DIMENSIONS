import EllipticSquareFunction.FrameReconstruction

/-! # Quantitative decay of oscillatory Fourier kernels

Integration by parts is supplied by Mathlib's theorem for the Fourier
transform of iterated derivatives. The constants are expressed using L¹
norms of finitely many derivatives.
-/

noncomputable section
open MeasureTheory
open scoped BigOperators FourierTransform
namespace EllipticSquareFunction

def derivativeMass (L : ℕ) (f : Plane → ℂ) : ℝ :=
  ∑ k ∈ Finset.range (L + 1), ∫ ξ, ‖iteratedFDeriv ℝ k f ξ‖

theorem derivativeMass_nonneg (L : ℕ) (f : Plane → ℂ) : 0 ≤ derivativeMass L f :=
  Finset.sum_nonneg (fun _ _ => integral_nonneg (fun _ => norm_nonneg _))

theorem smooth_compact_derivative_integrable (f : Plane → ℂ)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hfs : HasCompactSupport f) (k : ℕ) :
    Integrable (iteratedFDeriv ℝ k f) volume :=
  (hf.continuous_iteratedFDeriv (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤))).integrable_of_hasCompactSupport
    (hfs.iteratedFDeriv k)

theorem fourier_polynomial_decay (f : Plane → ℂ)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hfs : HasCompactSupport f) (L : ℕ) (w : Plane) :
    ‖w‖ ^ L * ‖Real.fourierIntegral f w‖ ≤ 2 ^ L * derivativeMass L f := by
  have hi (k n : ℕ) (hk : k ≤ (0 : ℕ∞)) (_hn : n ≤ (⊤ : ℕ∞)) :
      Integrable (fun ξ => ‖ξ‖ ^ k * ‖iteratedFDeriv ℝ n f ξ‖) volume := by
    have hk0 : k = 0 := by exact_mod_cast (le_antisymm hk (by simp))
    subst k
    simpa using (smooth_compact_derivative_integrable f hf hfs n).norm
  have h := Real.pow_mul_norm_iteratedFDeriv_fourierIntegral_le (K := (0 : ℕ∞))
    hf hi (k := 0) (n := L) (by simp) (by simp) w
  simpa [derivativeMass, norm_iteratedFDeriv_zero] using h

theorem derivativeMass_zero_le (L : ℕ) (f : Plane → ℂ) :
    derivativeMass 0 f ≤ derivativeMass L f := by
  simp only [derivativeMass, Nat.zero_add, Finset.range_one, Finset.sum_singleton]
  apply Finset.single_le_sum (a := 0) (f := fun k => ∫ ξ : Plane, ‖iteratedFDeriv ℝ k f ξ‖)
  · intro k _
    exact integral_nonneg (fun _ => norm_nonneg _)
  · simp

/-- Polynomial decay with an explicit constant, valid also at the origin. -/
theorem fourier_bracket_decay (f : Plane → ℂ)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hfs : HasCompactSupport f) (L : ℕ) (w : Plane) :
    ‖Real.fourierIntegral f w‖ ≤
      (2 ^ L * (1 + 2 ^ L) * derivativeMass L f) * bracket w ^ (-(L : ℝ)) := by
  have h₀ : ‖Real.fourierIntegral f w‖ ≤ derivativeMass L f := by
    have h := fourier_polynomial_decay f hf hfs 0 w
    simp only [pow_zero, one_mul] at h
    exact h.trans (derivativeMass_zero_le L f)
  have hL := fourier_polynomial_decay f hf hfs L w
  have h := SchwartzMap.pow_mul_le_of_le_of_pow_mul_le (k := 0) (l := L)
    (norm_nonneg w) (norm_nonneg _) h₀ (by simpa only [zero_add] using hL)
  simp only [pow_zero, one_mul] at h
  convert h using 1
  dsimp [bracket]
  ring

theorem oscillatoryIntegral_eq_fourierIntegral (f : Plane → ℂ) (w : Plane) :
    (∫ ξ, f ξ * oscillation (@inner ℝ Plane _ w ξ)) = Real.fourierIntegral f (-w) := by
  rw [Real.fourierIntegral_eq]
  apply integral_congr_ae
  filter_upwards with ξ
  simp only [inner_neg_right, neg_neg, Real.fourierChar_apply, smul_eq_mul]
  rw [real_inner_comm]
  exact mul_comm _ _

theorem oscillatoryIntegral_bracket_decay (f : Plane → ℂ)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (hfs : HasCompactSupport f) (L : ℕ) (w : Plane) :
    ‖∫ ξ, f ξ * oscillation (@inner ℝ Plane _ w ξ)‖ ≤
      (2 ^ L * (1 + 2 ^ L) * derivativeMass L f) * bracket w ^ (-(L : ℝ)) := by
  rw [oscillatoryIntegral_eq_fourierIntegral]
  simpa only [bracket, norm_neg] using fourier_bracket_decay f hf hfs L (-w)

end EllipticSquareFunction
