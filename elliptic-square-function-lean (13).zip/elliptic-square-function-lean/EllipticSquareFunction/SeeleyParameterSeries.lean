import EllipticSquareFunction.SeeleyHalfLineTheorem

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [TopologicalSpace X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def seeleyParameterSeries (m : ℕ) (f : ℝ × X → E) (p : ℝ × X) : E :=
  ∑' k : ℕ, (seeleyCoeff k * seeleyNode k ^ m) • f (seeleyNode k*p.1,p.2)

theorem seeley_parameter_term_bound (m : ℕ) {f : ℝ × X → E} {B : ℝ}
    (hf : ∀ p : ℝ × X, 0 ≤ p.1 → ‖f p‖ ≤ B)
    {p : ℝ × X} (hp : p.1 ≤ 0) (k : ℕ) :
    ‖(seeleyCoeff k * seeleyNode k ^ m) • f (seeleyNode k*p.1,p.2)‖ ≤
      (|seeleyCoeff k| * (2 : ℝ)^(k*m)) * B := by
  exact seeley_jet_term_bound m (fun s hs => hf (s,p.2) hs) hp k

/-- Uniformity includes the tangential parameter, provided the bound is uniform. -/
theorem seeley_parameter_series_uniform (m : ℕ) {f : ℝ × X → E} {B : ℝ}
    (hf : ∀ p : ℝ × X, 0 ≤ p.1 → ‖f p‖ ≤ B) :
    TendstoUniformlyOn
      (fun N : ℕ => fun p : ℝ × X => ∑ k ∈ Finset.range N,
        (seeleyCoeff k * seeleyNode k ^ m) • f (seeleyNode k*p.1,p.2))
      (seeleyParameterSeries m f) atTop {p : ℝ × X | p.1 ≤ 0} := by
  exact tendstoUniformlyOn_tsum_nat ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k p hp => seeley_parameter_term_bound m hf hp k)

theorem seeley_parameter_series_continuousOn (m : ℕ) {f : ℝ × X → E} {B : ℝ}
    (hf : ∀ p : ℝ × X, 0 ≤ p.1 → ‖f p‖ ≤ B)
    (hc : ContinuousOn f {p : ℝ × X | 0 ≤ p.1}) :
    ContinuousOn (seeleyParameterSeries m f) {p : ℝ × X | p.1 ≤ 0} := by
  apply continuousOn_tsum _ ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k p hp => seeley_parameter_term_bound m hf hp k)
  intro k
  exact (hc.comp ((continuous_const.mul continuous_fst).prodMk continuous_snd).continuousOn
    (fun p hp => seeley_reflected_nonneg hp k)).const_smul _

/-- Every weighted series matches the data on the full parameter boundary. -/
theorem seeley_parameter_series_boundary (m : ℕ) (f : ℝ × X → E) (y : X) :
    seeleyParameterSeries m f (0,y) = f (0,y) := by
  simp only [seeleyParameterSeries,mul_zero]
  rw [(seeley_moment_summable m).tsum_smul_const,seeley_moment,one_smul]

/-- Joint continuity across the boundary, including the tangential parameter.
Higher joint derivatives remain a separate obligation. -/
theorem seeley_parameter_extension_continuous {f : ℝ × X → E} {B : ℝ}
    (hf : ∀ p : ℝ × X, 0 ≤ p.1 → ‖f p‖ ≤ B)
    (hc : ContinuousOn f {p : ℝ × X | 0 ≤ p.1}) :
    Continuous (fun p : ℝ × X => if 0 ≤ p.1 then f p else seeleyParameterSeries 0 f p) := by
  apply continuous_if_le continuous_const continuous_fst hc
    (seeley_parameter_series_continuousOn 0 hf hc)
  intro p hp
  have he : p = (0,p.2) := by ext <;> simp [hp.symm]
  rw [he,seeley_parameter_series_boundary]

end EllipticSquareFunction
