import EllipticSquareFunction.SurfaceCaps

noncomputable section
namespace EllipticSquareFunction

/-- A compact set in any metric space has uniformly bounded finite separated
subsets. This is used only for a fixed bounded interval of scales. -/
theorem compact_separated_cardinality {E : Type*} [MetricSpace E] {K : Set E}
    (hK : IsCompact K) {d : ℝ} (hd : 0 < d) :
    ∃ N : ℕ, ∀ (n : ℕ) (p : Fin n → E), (∀ i, p i ∈ K) →
      (∀ i j, i ≠ j → d ≤ dist (p i) (p j)) → n ≤ N := by
  classical
  let W : K → Set E := fun x => Metric.ball (x : E) (d/3)
  have hcover : K ⊆ ⋃ x : K, W x := by
    intro x hx
    exact Set.mem_iUnion.mpr ⟨⟨x,hx⟩,Metric.mem_ball_self (by positivity)⟩
  obtain ⟨s,hs⟩ := hK.elim_finite_subcover W (fun _ => Metric.isOpen_ball) hcover
  refine ⟨s.card,?_⟩
  intro n p hp hsep
  have ha (i : Fin n) : ∃ j : s, p i ∈ W j := by
    obtain ⟨j,hj,hpj⟩ := Set.mem_iUnion₂.mp (hs (hp i))
    exact ⟨⟨j,hj⟩,hpj⟩
  choose a ha using ha
  have hinj : Function.Injective a := by
    intro i j hij
    by_contra hne
    have hi : dist (p i) (a i : K) < d/3 := ha i
    have hj : dist (p j) (a i : K) < d/3 := by simpa only [hij] using ha j
    have htri := dist_triangle_right (p i) (p j) (a i : K)
    have hlow := hsep i j hne
    linarith
  have hc := Fintype.card_le_of_injective a hinj
  simpa only [Fintype.card_fin,Fintype.card_coe] using hc

theorem bounded_scale_surface_estimate (S : SurfaceSetup) {T : ℝ} (hT : 2 ≤ T) :
    ∃ B : ℝ, 0 < B ∧ ∀ R : ℝ, 2 ≤ R → R ≤ T →
      ∀ (n : ℕ) (p : Fin n → Space) (f : Fin n → SchwartzMap Space ℂ),
      SurfaceAdmissibleFamily S R p f → l3 (fun y => ∑ i, f i y) ≤
        ENNReal.ofReal B*l3Real (squareFunction Finset.univ (fun i => f i)) := by
  let d := S.c₀*(Real.sqrt T)⁻¹
  have hd : 0 < d := mul_pos S.c₀_pos (inv_pos.mpr (Real.sqrt_pos.mpr (by linarith)))
  obtain ⟨N,hN⟩ := compact_separated_cardinality S.compact_carrier hd
  refine ⟨Real.sqrt (N : ℝ)+1,by positivity,?_⟩
  intro R hR hRT n p f had
  have hδ : (Real.sqrt T)⁻¹ ≤ (Real.sqrt R)⁻¹ :=
    (inv_le_inv₀ (Real.sqrt_pos.mpr (by linarith)) (Real.sqrt_pos.mpr (by linarith))).mpr
      (Real.sqrt_le_sqrt hRT)
  have hn := hN n p had.1 (fun i j hij => by
    rw [dist_eq_norm]
    exact (mul_le_mul_of_nonneg_left hδ S.c₀_pos.le).trans (had.2.1 i j hij))
  apply (finite_family_l3_square_bound Finset.univ (fun i => (f i : Space → ℂ))).trans
  apply mul_le_mul_right'
  apply ENNReal.ofReal_le_ofReal
  simp only [Finset.card_univ,Fintype.card_fin]
  have hh := Real.sqrt_le_sqrt (show (n : ℝ) ≤ N by exact_mod_cast hn)
  linarith

end EllipticSquareFunction
