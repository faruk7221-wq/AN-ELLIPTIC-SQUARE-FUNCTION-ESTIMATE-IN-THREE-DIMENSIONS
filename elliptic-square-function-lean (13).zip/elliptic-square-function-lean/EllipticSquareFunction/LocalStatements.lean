import EllipticSquareFunction.ExternalInputs
import EllipticSquareFunction.Losses
import EllipticSquareFunction.LpReduction

/-!
# Corrected local estimates (4.9) and (4.14)

The left side is restricted to `Q × [0,R]`. The right side integrates the
density over the WHOLE spatial plane and `[0,R]`.
`LocalDiscreteEstimate` and `LocalProfileEstimate` are statements, not proved
theorems. The norm/integral identity connecting their two forms IS proved.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open MeasureTheory
namespace EllipticSquareFunction

def timeSlab (R : ℝ) : Set Space := {y | y.2 ∈ Set.Icc 0 R}

def localSlab (Q : Set Plane) (R : ℝ) : Set Space := Q ×ˢ Set.Icc 0 R

def densityCubeRoot (H : Space → ℝ) (R : ℝ) : ℝ≥0∞ :=
  (∫⁻ y in timeSlab R, (ENNReal.ofReal (H y)) ^ (3 / 2 : ℝ)) ^ (1 / 3 : ℝ)

theorem densityCubeRoot_eq_norm (H : Space → ℝ) (R : ℝ) (hH : ∀ y, 0 ≤ H y) :
    densityCubeRoot H R = l3Real (fun y => Real.sqrt (H y))
      (volume.restrict (timeSlab R)) := by
  rw [l3Real, eLpNorm_sqrt _ H hH,
    eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3 / 2 : ℝ≥0∞) ≠ 0)
      ((ENNReal.div_lt_top (by norm_num) (by norm_num)).ne : (3 / 2 : ℝ≥0∞) ≠ ∞)]
  simp only [ENNReal.toReal_div, ENNReal.toReal_ofNat]
  rw [← ENNReal.rpow_mul]
  have hn : ∀ y, ‖H y‖ₑ = ENNReal.ofReal (H y) := by
    intro y
    rw [← ofReal_norm_eq_enorm, Real.norm_eq_abs, abs_of_nonneg (hH y)]
  simp only [hn]
  norm_num [densityCubeRoot]

/-- Full formal statement of corrected (4.9), at a specified local square. -/
def LocalDiscreteEstimate (S : DiscreteSetup) (N P κ η C : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (Q : Set Plane) : Prop :=
  l3 (discreteExtension S N s d) (volume.restrict (localSlab Q (N ^ 2))) ≤
    ENNReal.ofReal (C * packetConstant P κ η (N ^ 2)) *
      densityCubeRoot (discreteCoreDensity S N s d) (N ^ 2)

/-- Full formal statement of corrected (4.14), with arbitrary finite labels. -/
def LocalProfileEstimate {ι : Type*} (φ : Phase) (b : Plane → ℂ)
    (s : Finset ι) (a : ι → ℂ) (ν v : ι → Plane)
    (N M P κ η C : ℝ) (Q : Set Plane) : Prop :=
  l3 (fun y => ∑ i ∈ s, a i * freePacket φ b N (ν i) (v i) y)
      (volume.restrict (localSlab Q (N ^ 2))) ≤
    ENNReal.ofReal (C * packetConstant P κ η (N ^ 2)) *
      densityCubeRoot (spatialDensity s a (fun i => velocity φ (ν i)) v N M) (N ^ 2)

/-- Restricting the spatial integration on the left cannot increase its norm.
This does not replace the proof of either local estimate. -/
theorem local_norm_le_full_slab (F : Space → ℂ) (Q : Set Plane) (R : ℝ) :
    l3 F (volume.restrict (localSlab Q R)) ≤ l3 F (volume.restrict (timeSlab R)) := by
  apply eLpNorm_mono_measure
  exact Measure.restrict_mono (fun y hy => hy.2) le_rfl

end EllipticSquareFunction
