import EllipticSquareFunction.Definitions

/-!
# Formal statements of the three external inputs

This file DEFINES propositions; it does not assert them as axioms or prove them.
The source cited for each input is recorded in `PROOF_STATUS.md`.
In particular, importing this file supplies no proof of any external input.
-/

noncomputable section
open scoped ENNReal NNReal
open scoped BigOperators
open MeasureTheory
namespace EllipticSquareFunction

def spherePhase (ξ : Plane) : ℝ := -Real.sqrt (1 - ‖ξ‖ ^ 2)
def quadraticPhase (ξ : Plane) : ℝ := -1 + ‖ξ‖ ^ 2 / 2

/-- The smooth-cutoff version of (3.1), including the derivative bounds. -/
def ContinuedPhase (φ : Phase) : Prop :=
  ∃ (ρ : ℝ) (ζ : Plane → ℝ), 0 < ρ ∧ 2 * ρ < 1 ∧
    ContDiff ℝ (⊤ : ℕ∞) ζ ∧ HasCompactSupport ζ ∧
    (∀ ξ, 0 ≤ ζ ξ ∧ ζ ξ ≤ 1) ∧
    (∀ ξ ∈ Metric.ball (0 : Plane) ρ, ζ ξ = 1) ∧
    tsupport ζ ⊆ Metric.ball (0 : Plane) (2 * ρ) ∧
    (∀ ξ, φ ξ = quadraticPhase ξ + ζ ξ * (spherePhase ξ - quadraticPhase ξ)) ∧
    ContDiff ℝ (⊤ : ℕ∞) φ ∧ UniformlyEllipticOn φ Set.univ ∧
    (∀ n : ℕ, 2 ≤ n → ∃ C : ℝ, ∀ ξ, ‖iteratedFDeriv ℝ n φ ξ‖ ≤ C)

def graphOver (φ : Phase) (U : Set Plane) : Set Space :=
  (fun ξ => (ξ, φ ξ)) '' U

/-- External input 1: affine placement of a neighborhood of every point.
The scale `R` and the loss parameters do not occur in this proposition. -/
def PlacementInput : Prop :=
  ∀ G : GraphSetup, GraphHypotheses G → ∀ ν ∈ G.K,
    ∃ (W O : Set Plane) (A : Space ≃ᵃ[ℝ] Space) (Φ : Phase),
      IsOpen W ∧ ν ∈ W ∧ IsOpen O ∧ ContinuedPhase Φ ∧
      A '' graphOver G.φ W = graphOver Φ O

abbrev IntPlane := Fin 2 → ℤ
abbrev PacketIndex := IntPlane × IntPlane
abbrev TerminalIndex := IntPlane × IntPlane × ℕ

def latticePoint (a : ℝ) (m : IntPlane) : Plane :=
  (WithLp.equiv 2 (Fin 2 → ℝ)).symm (fun i => a * (m i : ℝ))

structure DiscreteSetup where
  φ : Phase
  χ : Plane → ℝ
  χ_smooth : ContDiff ℝ (⊤ : ℕ∞) χ
  χ_compact : HasCompactSupport χ
  χ_nonneg : ∀ ξ, 0 ≤ χ ξ
  χ_partition : ∀ ξ, ∑' m : IntPlane, χ (ξ - latticePoint 1 m) ^ 2 = 1
  D : ℕ
  D_pos : 0 < D
  χ_support : ∀ ξ ∈ tsupport χ, ∀ i : Fin 2, |ξ i| < (D : ℝ) / 2
  frequencyBound : ℝ
  frequencyBound_pos : 0 < frequencyBound
  C₁ : ℝ
  C₁_pos : 0 < C₁
  C₂ : ℝ
  C₂_pos : 0 < C₂

def discreteFrequency (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (ξ : Plane) : ℂ :=
  (((S.D : ℝ) / N) ^ 2)⁻¹ * ∑ i ∈ s,
    d i * (S.χ (N • (ξ - latticePoint N⁻¹ i.1)) : ℂ) *
      oscillation (-@inner ℝ Plane _ (latticePoint (N / S.D) i.2) ξ)

def discreteExtension (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (y : Space) : ℂ :=
  ∫ ξ, discreteFrequency S N s d ξ * oscillation (@inner ℝ Plane _ y.1 ξ + y.2 * S.φ ξ)

def terminalCoefficient (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) (i : TerminalIndex) : ℂ :=
  ∫ ξ, discreteFrequency S N s d ξ * (S.χ (ξ - latticePoint 1 i.1) : ℂ) *
    oscillation (@inner ℝ Plane _ (latticePoint (S.D : ℝ)⁻¹ i.2.1) ξ + (i.2.2 : ℝ) * S.φ ξ)

def discreteCoreDensity (S : DiscreteSetup) (N : ℝ)
    (s : Finset PacketIndex) (d : PacketIndex → ℂ) : Space → ℝ :=
  coreDensity s d (fun i => velocity S.φ (latticePoint N⁻¹ i.1))
    (fun i => latticePoint (N / S.D) i.2) N (N ^ 2)

def discreteLabelsAllowed (S : DiscreteSetup) (N : ℝ) (s : Finset PacketIndex) : Prop :=
  ∀ i ∈ s, ‖latticePoint N⁻¹ i.1‖ ≤ S.frequencyBound ∧
    ‖latticePoint (N / S.D) i.2‖ ≤ S.C₁ * N ^ 2

/-- External input 2, in the paper's physical coordinates. A finite subset of
the retained terminal indices is allowed, as stated after (3.7).
The time index is explicitly an integer. -/
def DiscreteDensityInput (S : DiscreteSetup) : Prop :=
  ContinuedPhase S.φ → ∀ κ η : ℝ, 0 < κ → κ < 1 / 10 → 0 < η → η ≤ 1 →
    ∃ P : ℝ, 1 ≤ P ∧ ∀ j : ℕ, 1 ≤ j →
      let N : ℝ := (2 : ℝ) ^ j
      ∀ (s : Finset PacketIndex) (d : PacketIndex → ℂ), discreteLabelsAllowed S N s →
      ∀ t : Finset TerminalIndex,
        (∀ i ∈ t, (i.2.2 : ℝ) < N ^ 2 ∧
          ‖latticePoint (S.D : ℝ)⁻¹ i.2.1‖ ≤ S.C₂ * N ^ 2) →
        (∑ i ∈ t, ‖terminalCoefficient S N s d i‖ ^ 3) ≤
          P * N ^ (10 * κ + η) * Real.log (2 + N) ^ 2 *
            ∫ y : Space, (discreteCoreDensity S N s d y) ^ (3 / 2 : ℝ)

/-- Euclidean three-dimensional length. `Space`'s product norm is only used
for topology; it is not substituted for the tube's Euclidean metric. -/
def euclideanLength (y : Space) : ℝ := Real.sqrt (‖y.1‖ ^ 2 + y.2 ^ 2)

def geometricTube (a b : Space) (ρ : ℝ) : Set Space :=
  {y | ∃ s ∈ Set.Icc (0 : ℝ) 1,
    euclideanLength (y - ((1 - s) • a + s • b)) ≤ ρ}

def tubeAverage (h : Space → ℝ) (T : Set Space) : ℝ≥0∞ :=
  (volume T)⁻¹ * ∫⁻ y in T, ENNReal.ofReal |h y|

/-- Supremum in `ℝ≥0∞`, so unbounded collections are not assigned an
artificial finite value. The length is fixed outside the supremum. -/
def nikodym (τ L : ℝ) (h : Space → ℝ) (y : Space) : ℝ≥0∞ :=
  ⨆ (a : Space) (b : Space) (_hL : euclideanLength (b - a) = L)
    (_hy : y ∈ geometricTube a b (τ * L)), tubeAverage h (geometricTube a b (τ * L))

/-- External input 3 at unit length, as in (3.8). -/
def NikodymInput : Prop :=
  ∀ γ : ℝ, 0 < γ → γ ≤ 1 → ∃ M : ℝ, 1 ≤ M ∧
    ∀ τ : ℝ, 0 < τ → τ < 1 → ∀ h : Space → ℝ, MemLp h 3 volume →
      eLpNorm (nikodym τ 1 h) 3 volume ≤
        ENNReal.ofReal (M * τ ^ (-γ)) * eLpNorm h 3 volume

end EllipticSquareFunction
