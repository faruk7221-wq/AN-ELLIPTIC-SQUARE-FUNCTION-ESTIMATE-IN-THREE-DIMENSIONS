import EllipticSquareFunction.RebasedSlabEstimate

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Canonical fine arrays meet the geometric hypotheses of Proposition 2:
frequency spacing N⁻¹ and position spacing N/D. -/
theorem canonical_packet_array_separated (S : DiscreteSetup) {N F : ℝ} (hN : 0<N)
    (q p : Finset IntPlane) (a : IntPlane → IntPlane → ℂ)
    (hq : ∀ m ∈ q, ‖latticePoint N⁻¹ m‖≤F) :
    SeparatedPacketArray
      ⟨q,fun _ => p,a,latticePoint N⁻¹,fun _ => latticePoint (N/S.D)⟩
      N (S.D:ℝ)⁻¹ 1 F := by
  have hD : 0<(S.D:ℝ) := by exact_mod_cast S.D_pos
  refine ⟨hq,?_,?_⟩
  · intro m hm n hn hmn
    simpa only [one_div,rectangularLatticePoint,latticePoint] using
      rectangular_lattice_separated (fun _ => N⁻¹) (inv_pos.mpr hN) (fun _ => le_rfl) hmn
  · intro m hm n hn r hr hnr
    have hh := rectangular_lattice_separated (fun _ => N/S.D) (div_pos hN hD) (fun _ => le_rfl) hnr
    simpa only [div_eq_mul_inv,mul_comm,rectangularLatticePoint,latticePoint] using hh

/-- The finite canonical bound used in the rebasing argument is an actual
specialization of the proved single-profile Proposition 2 statement. -/
theorem canonical_packet_bound_of_uniform (S : DiscreteSetup)
    (F M C P κ η : ℝ)
    (hbound : UniformSingleProfileBound IntPlane S.φ (fun ζ => (S.χ ζ:ℂ))
      (S.D:ℝ)⁻¹ 1 F M C P κ η)
    (j : ℕ) (hj : 1≤j) (q p : Finset IntPlane) (a : IntPlane → IntPlane → ℂ)
    (hq : ∀ m ∈ q, ‖latticePoint ((2:ℝ)^j)⁻¹ m‖≤F) :
    let N : ℝ := (2:ℝ)^j
    l3 (fun y => ∑ m ∈ q, ∑ n ∈ p, a m n*
      freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y)
      (volume.restrict (timeSlab (N^2))) ≤
      ENNReal.ofReal (C*packetConstant P κ η (N^2))*
      densityCubeRoot (spatialDensity (q ×ˢ p) (fun mn => a mn.1 mn.2)
        (fun mn => velocity S.φ (latticePoint N⁻¹ mn.1))
        (fun mn => latticePoint (N/S.D) mn.2) N M) (N^2) := by
  let N : ℝ := (2:ℝ)^j
  have hN : 0<N := by positivity
  unfold UniformSingleProfileBound at hbound
  have hh := hbound j hj ⟨q,fun _ => p,a,latticePoint N⁻¹,fun _ => latticePoint (N/S.D)⟩
    (canonical_packet_array_separated S hN q p a hq)
  dsimp only [arrayPacketSum,arraySpatialDensity] at hh
  unfold spatialDensity at hh ⊢
  simpa only [Finset.sum_sigma,Finset.sum_product] using hh

end EllipticSquareFunction
