import EllipticSquareFunction.FineFrameTail
import EllipticSquareFunction.TimeAssembly

/-! # Exact fine-frame truncation and the retained discrete extension -/
noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction

def fineRetainedPositions (S : DiscreteSetup) (N A : ℝ) : Finset IntPlane :=
  retainedPositions S ((A+1)*N)

theorem mem_fineRetainedPositions (S : DiscreteSetup) {N : ℝ} (hN : 0 < N)
    (A : ℝ) (n : IntPlane) :
    n ∈ fineRetainedPositions S N A ↔
      ‖latticePoint (N/S.D) n‖ ≤ (A+1)*N^2 := by
  rw [fineRetainedPositions, mem_retainedPositions]
  have he : latticePoint (N/S.D) n = N • latticePoint (S.D : ℝ)⁻¹ n := by
    rw [← latticePoint_mul, div_eq_mul_inv]
  rw [he, norm_smul, Real.norm_eq_abs, abs_of_pos hN,
    show (A+1)*N^2 = N*((A+1)*N) by ring, mul_le_mul_left hN]

def profileFineCoefficient {ι : Type*} (S : DiscreteSetup) (b : Plane → ℂ)
    (N c : ℝ) (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r : Plane) (k : PacketIndex) : ℂ :=
  changedCoefficient b S.χ N c s pbox a ν r
    (latticePoint N⁻¹ k.1) (latticePoint (N/S.D) k.2)

/-- The fine retained packet sum is exactly the discrete extension (3.3). -/
theorem discreteExtension_eq_freePackets (S : DiscreteSetup) (hφ : Continuous S.φ)
    {N : ℝ} (hN : 0 < N) (s : Finset PacketIndex) (d : PacketIndex → ℂ) (y : Space) :
    discreteExtension S N s d y = (((S.D : ℝ)^2)⁻¹ : ℝ) •
      ∑ k ∈ s, d k * freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N
        (latticePoint N⁻¹ k.1) (latticePoint (N/S.D) k.2) y := by
  have hχ : Continuous (fun ζ => (S.χ ζ : ℂ)) := Complex.continuous_ofReal.comp S.χ_smooth.continuous
  have hχs : HasCompactSupport (fun ζ => (S.χ ζ : ℂ)) := S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero
  have hD : (S.D : ℝ) ≠ 0 := by exact_mod_cast S.D_pos.ne'
  have he (ξ : Plane) : discreteFrequency S N s d ξ =
      (((S.D : ℝ)^2)⁻¹ : ℝ) • profileFrequency (fun ζ => (S.χ ζ : ℂ)) N s d
        (fun k => latticePoint N⁻¹ k.1) (fun k => latticePoint (N/S.D) k.2) ξ := by
    unfold discreteFrequency profileFrequency
    rw [smul_smul]
    simp only [Complex.real_smul]
    congr 1
    push_cast
    field_simp
  unfold discreteExtension
  simp_rw [he, smul_mul_assoc]
  rw [integral_smul, profileFrequency_extension S.φ hφ _ hχ hχs hN]

/-- The complementary convergent series equals the exact truncation error. -/
theorem fineSynthesisTail_eq_sub {ι : Type*} (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) {N c A : ℝ} (hN : 0 < N)
    (s : Finset ι) (pbox q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r : Plane) (y : Space)
    (hs : HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
      (profileFineCoefficient S b N c s pbox a ν r (m,n) *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
          (latticePoint (N/S.D) n) y))
      (∑ i ∈ s, ∑ p ∈ pbox, a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y)) :
    (((S.D : ℝ)^2)⁻¹ : ℝ) •
      fineSynthesisTail S.φ b S.χ N c (S.D : ℝ)⁻¹ A s pbox q a ν r y =
      (∑ i ∈ s, ∑ p ∈ pbox, a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y) -
      discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
        (profileFineCoefficient S b N c s pbox a ν r) y := by
  classical
  have he (n : IntPlane) : N • latticePoint (S.D : ℝ)⁻¹ n = latticePoint (N/S.D) n := by
    rw [← latticePoint_mul, div_eq_mul_inv]
  have ht := (hasSum_omitted_finset (fineRetainedPositions S N A) _ hs).tsum_eq
  rw [discreteExtension_eq_freePackets S hφ hN]
  have hfin : (∑ n ∈ fineRetainedPositions S N A, ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
      (profileFineCoefficient S b N c s pbox a ν r (m,n) *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) y)) =
      (((S.D : ℝ)^2)⁻¹ : ℝ) • ∑ k ∈ q ×ˢ fineRetainedPositions S N A,
        profileFineCoefficient S b N c s pbox a ν r k *
        freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ k.1) (latticePoint (N/S.D) k.2) y := by
    simp only [Finset.sum_product, Finset.smul_sum]
    rw [Finset.sum_comm]
  rw [hfin] at ht
  rw [← ht, fineSynthesisTail]
  simp only [Complex.real_smul]
  rw [← tsum_mul_left]
  apply tsum_congr
  intro n
  by_cases hn : n ∈ fineRetainedPositions S N A
  · have hn' := (mem_fineRetainedPositions S hN A n).mp hn
    simp [he, hn, not_lt_of_ge hn']
  · have hn' : (A+1)*N^2 < ‖latticePoint (N/S.D) n‖ :=
      lt_of_not_ge (fun hh => hn ((mem_fineRetainedPositions S hN A n).mpr hh))
    simp [he, hn, hn', Finset.smul_sum, Finset.mul_sum, profileFineCoefficient]

/-- Far fine-frequency labels have zero analyzed coefficient. -/
theorem changedCoefficient_zero_of_frequency {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c F Z : ℝ} (hN : 1 ≤ N) (hZ : 0 ≤ Z)
    (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r μ w : Plane) (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hμ : F+Z < ‖μ‖)
    (hcut : ∀ μ w ν v : Plane, Z/N < ‖μ-ν‖ → windowMatrix b χ N μ w ν v = 0) :
    changedCoefficient b χ N c s pbox a ν r μ w = 0 := by
  apply Finset.sum_eq_zero
  intro i hi
  apply Finset.sum_eq_zero
  intro p hp
  have htri := norm_sub_le μ (ν i)
  have htri' : ‖μ‖ ≤ ‖μ-ν i‖ + ‖ν i‖ := by
    simpa only [sub_add_cancel] using norm_add_le (μ-ν i) (ν i)
  have hdiv : Z/N ≤ Z := div_le_self hZ hN
  rw [hcut μ w (ν i) (r+N • latticePoint c p) (by linarith [hν i hi]), zero_mul]

/-- The exact fine synthesis can be restricted to allowed frequency labels,
provided the fixed setup contains the original supports with a cutoff margin. -/
theorem profile_fine_frame_bounded_frequencies {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N c F Z : ℝ} (hN : 1 ≤ N) (hZ : 0 ≤ Z) (hFZ : F+Z ≤ S.frequencyBound)
    (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (r : Plane) (hν : ∀ i ∈ s, ‖ν i‖ ≤ F)
    (hcut : ∀ μ w ν v : Plane, Z/N < ‖μ-ν‖ → windowMatrix b S.χ N μ w ν v = 0) :
    ∃ q : Finset IntPlane,
      (∀ m ∈ q, ‖latticePoint N⁻¹ m‖ ≤ S.frequencyBound) ∧
      ∀ y : Space,
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D : ℝ)^2)⁻¹ : ℝ) •
        (profileFineCoefficient S b N c s pbox a ν r (m,n) *
          freePacket S.φ (fun ζ => (S.χ ζ : ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox, a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y) := by
  classical
  obtain ⟨q, hq⟩ := profile_fine_frame_reconstruction S hφ b hb hbs (by linarith : 0<N) s pbox a ν r
  refine ⟨q.filter (fun m => ‖latticePoint N⁻¹ m‖ ≤ S.frequencyBound),
    fun m hm => (Finset.mem_filter.mp hm).2, ?_⟩
  intro y
  apply (hq y).congr
  intro ns
  apply Finset.sum_congr rfl
  intro n hn
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro m hm hmn
  have hfar : S.frequencyBound < ‖latticePoint N⁻¹ m‖ := by
    apply lt_of_not_ge
    intro hh
    exact hmn (Finset.mem_filter.mpr ⟨hm,hh⟩)
  have hz := changedCoefficient_zero_of_frequency (c := c) b S.χ hN hZ s pbox a ν r
    (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) hν (hFZ.trans_lt hfar) hcut
  simp only [profileFineCoefficient, hz, zero_mul, smul_zero]

/-- Retained fine labels satisfy the exact hypotheses of the discrete input. -/
theorem fine_retained_labels_allowed (S : DiscreteSetup) {N A : ℝ} (hN : 0 < N)
    (q : Finset IntPlane) (hq : ∀ m ∈ q, ‖latticePoint N⁻¹ m‖ ≤ S.frequencyBound)
    (hA : A+1 ≤ S.C₁) :
    discreteLabelsAllowed S N (q ×ˢ fineRetainedPositions S N A) := by
  intro k hk
  obtain ⟨hm,hn⟩ := Finset.mem_product.mp hk
  exact ⟨hq k.1 hm, ((mem_fineRetainedPositions S hN A k.2).mp hn).trans
    (mul_le_mul_of_nonneg_right hA (sq_nonneg N))⟩

/-- Exact finite discrete approximation with a uniform rapidly decreasing
error. Both the frequency margin and error constant depend only on the fixed
windows and chosen decay order. -/
theorem profile_fine_discrete_approximation {ι : Type*}
    (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b) (hbs : HasCompactSupport b)
    (L : ℕ) (hL : 3 ≤ L) :
    ∃ Z B : ℝ, 0 < Z ∧ 0 < B ∧ ∀ N : ℝ, 1 ≤ N → ∀ c A F : ℝ,
      A+1 ≤ S.C₁ → F+Z ≤ S.frequencyBound →
      ∀ (s : Finset ι) (pbox : Finset IntPlane) (a : ι → IntPlane → ℂ)
        (ν : ι → Plane) (r : Plane),
      (∀ i ∈ s, ‖ν i‖ ≤ F) →
      (∀ p ∈ pbox, ‖r+N • latticePoint c p‖ ≤ A*N^2) →
      ∃ q : Finset IntPlane,
        discreteLabelsAllowed S N (q ×ˢ fineRetainedPositions S N A) ∧
        ∀ y : Space,
        ‖(∑ i ∈ s, ∑ p ∈ pbox, a i p * freePacket S.φ b N (ν i) (r+N • latticePoint c p) y) -
          discreteExtension S N (q ×ˢ fineRetainedPositions S N A)
            (profileFineCoefficient S b N c s pbox a ν r) y‖ ≤
          B * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖) := by
  classical
  have hD : 0 < (S.D : ℝ) := by exact_mod_cast S.D_pos
  obtain ⟨Z,hZ,hcut⟩ := windowMatrix_frequency_cutoff b hbs S.χ S.χ_compact
  obtain ⟨C,hC,hcoeff⟩ := smooth_changedCoefficient_absolute_tail (ι := ι)
    b hb hbs S.χ S.χ_smooth S.χ_compact (inv_pos.mpr hD) L hL
  have hχ : Integrable (fun ζ => (S.χ ζ : ℂ)) :=
    (Complex.continuous_ofReal.comp S.χ_smooth.continuous).integrable_of_hasCompactSupport
      (S.χ_compact.comp_left (g := Complex.ofReal) Complex.ofReal_zero)
  let H := ∫ ζ, ‖(S.χ ζ : ℂ)‖
  have hH : 0 ≤ H := integral_nonneg (fun _ => norm_nonneg _)
  let u : ℝ := ((S.D : ℝ)^2)⁻¹
  have hu : 0 ≤ u := by dsimp [u]; positivity
  refine ⟨Z, u*H*C+1, hZ, by positivity, ?_⟩
  intro N hN c A F hA hF s pbox a ν r hν hv
  have hN0 : 0<N := by linarith
  obtain ⟨q,hq,hs⟩ := profile_fine_frame_bounded_frequencies S hφ b hb.continuous hbs
    hN hZ.le hF s pbox a ν r hν (hcut N hN0)
  refine ⟨q, fine_retained_labels_allowed S hN0 q hq hA, ?_⟩
  intro y
  obtain ⟨hc,ht⟩ := hcoeff N hN0 c A s pbox q a ν r hv
  rw [← fineSynthesisTail_eq_sub S hφ b hN0 s pbox q a ν r y (hs y),
    norm_smul, Real.norm_eq_abs, abs_of_nonneg hu]
  have ht' := fineSynthesisTail_norm_bound S.φ b S.χ hχ hN0 s pbox q a ν r hc y
  have hp : 0 ≤ (1+N)^(-((L : ℝ)-3)) := Real.rpow_nonneg (by linarith) _
  have ha : 0 ≤ ∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖ :=
    Finset.sum_nonneg (fun i hi => Finset.sum_nonneg (fun p hp => norm_nonneg _))
  calc
    _ ≤ u * (H * ∑' n, omittedFineCoefficient b S.χ N c (S.D : ℝ)⁻¹ A s pbox q a ν r n) :=
      mul_le_mul_of_nonneg_left ht' hu
    _ ≤ u * (H * (C * (1+N)^(-((L : ℝ)-3)) * (∑ i ∈ s, ∑ p ∈ pbox, ‖a i p‖))) :=
      mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left ht hH) hu
    _ ≤ _ := by nlinarith

end EllipticSquareFunction
