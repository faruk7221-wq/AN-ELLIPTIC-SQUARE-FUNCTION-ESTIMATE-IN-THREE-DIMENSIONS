import EllipticSquareFunction.BoundaryExtensionReduction

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- For Mathlib's actual half-space model, the remaining extension
obligation is confined precisely to coordinate zero, the boundary hyperplane. -/
theorem halfspace_extensions_of_boundary_analytic {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hb : ∀ x : M, (extChartAt (𝓡∂ 2) x x) 0=0 →
      AnalyticWithinAt ℝ (modelSurfaceParam (𝓡∂ 2) f x)
        (extChartAt (𝓡∂ 2) x).target (extChartAt (𝓡∂ 2) x x)) :
    HasSmoothModelExtensions (𝓡∂ 2) f := by
  apply smooth_model_extensions_of_boundary_analytic (𝓡∂ 2) hf
  intro x hx
  have hr := extChartAt_target_subset_range (I := 𝓡∂ 2) x (mem_extChartAt_target x)
  rw [range_modelWithCornersEuclideanHalfSpace] at hr
  rw [interior_range_modelWithCornersEuclideanHalfSpace] at hx
  apply hb x
  exact le_antisymm (le_of_not_gt hx) hr

/-- Surface theorem for a compact Mathlib manifold with boundary that is
smooth throughout and analytic in its canonical coordinates at boundary
points. The smooth extension premise is discharged by the preceding proof. -/
theorem compact_boundary_analytic_surface_estimate [CompactSpace M]
    {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f)
    (hb : ∀ x : M, (extChartAt (𝓡∂ 2) x x) 0=0 →
      AnalyticWithinAt ℝ (modelSurfaceParam (𝓡∂ 2) f x)
        (extChartAt (𝓡∂ 2) x).target (extChartAt (𝓡∂ 2) x x))
    (himm : ∀ x, Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm (𝓡∂ 2) f x N)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ :=
  compact_model_surface_estimate (𝓡∂ 2) hf hemb
    (halfspace_extensions_of_boundary_analytic hf hb) himm hcurv hc₀ hC₀
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
