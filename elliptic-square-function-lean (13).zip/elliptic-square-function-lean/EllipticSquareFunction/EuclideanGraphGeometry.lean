import EllipticSquareFunction.EuclideanEmbeddedSurface

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

theorem second_derivative_linear_comp {E G : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E] [NormedAddCommGroup G] [NormedSpace ℝ G]
    {F : Plane → E} {a : Plane} (hF : ContDiffAt ℝ 2 F a)
    (l : E →L[ℝ] G) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (fun b => l (F b))) a v w =
      l (fderiv ℝ (fderiv ℝ F) a v w) := by
  have he : fderiv ℝ (fun b => l (F b)) =ᶠ[𝓝 a]
      (fun b => l.comp (fderiv ℝ F b)) := by
    filter_upwards [hF.eventually (by norm_num)] with b hb
    exact (l.hasFDerivAt.comp b (hb.differentiableAt (by norm_num)).hasFDerivAt).fderiv
  rw [he.fderiv_eq]
  rw [fderiv_clm_comp (differentiableAt_const l)
    ((hF.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num))]
  simp

theorem derivative_tangent_field {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    {F : Plane → E} {a : Plane} (hF : ContDiffAt ℝ 2 F a) (v w : Plane) :
    fderiv ℝ (fun b => fderiv ℝ F b v) a w = fderiv ℝ (fderiv ℝ F) a w v := by
  have hh := ((hF.fderiv_right (m := 1) (by norm_num)).differentiableAt
    (by norm_num)).hasFDerivAt.clm_apply (hasFDerivAt_const v a)
  rw [hh.fderiv]
  simp

def euclideanGraph (φ : Phase) : Plane → EuclideanThree :=
  fun b => spaceEuclideanEquiv.symm (graphLift φ b)

def euclideanGraphNormal (φ : Phase) (a : Plane) : EuclideanThree :=
  spaceEuclideanEquiv.symm (graphUnitNormal φ a)

theorem euclideanGraph_contDiff {φ : Phase} {n : WithTop ℕ∞} (hφ : ContDiff ℝ n φ) :
    ContDiff ℝ n (euclideanGraph φ) :=
  spaceEuclideanEquiv.symm.contDiff.comp (contDiff_id.prodMk hφ)

theorem euclideanGraph_isEmbedding {φ : Phase} (hφ : Continuous φ) :
    Topology.IsEmbedding (euclideanGraph φ) :=
  spaceEuclideanEquiv.symm.toHomeomorph.isEmbedding.comp (isEmbedding_graph hφ)

theorem euclideanGraph_fderiv_injective {φ : Phase} {a : Plane}
    (hφ : DifferentiableAt ℝ φ a) : Function.Injective (fderiv ℝ (euclideanGraph φ) a) := by
  have hd := spaceEuclideanEquiv.symm.hasFDerivAt.comp a (graphLift_hasFDerivAt hφ)
  change Function.Injective (fderiv ℝ (spaceEuclideanEquiv.symm ∘ graphLift φ) a)
  rw [hd.fderiv]
  intro v w hvw
  exact congrArg Prod.fst (spaceEuclideanEquiv.symm.injective hvw)

theorem euclideanGraphNormal_unit (φ : Phase) (a : Plane) : ‖euclideanGraphNormal φ a‖=1 :=
  graphUnitNormal_euclidean_norm φ a

theorem euclideanGraphNormal_orthogonal {φ : Phase} {a : Plane}
    (hφ : DifferentiableAt ℝ φ a) (v : Plane) :
    @inner ℝ EuclideanThree _ (euclideanGraphNormal φ a) (fderiv ℝ (euclideanGraph φ) a v)=0 := by
  have he := spaceEuclideanEquiv.symm.hasFDerivAt.comp a (graphLift_hasFDerivAt hφ)
  change @inner ℝ EuclideanThree _ (euclideanGraphNormal φ a)
    (fderiv ℝ (spaceEuclideanEquiv.symm ∘ graphLift φ) a v)=0
  rw [he.fderiv]
  rw [← spaceEuclideanEquiv_pair]
  change spacePair (graphUnitNormal φ a)
    (spaceEuclideanEquiv (spaceEuclideanEquiv.symm (v,fderiv ℝ φ a v)))=0
  rw [spaceEuclideanEquiv.apply_symm_apply]
  have ho := graphNormal_orthogonal hφ v
  rw [(graphLift_hasFDerivAt hφ).fderiv] at ho
  change spacePair (graphNormal φ a) (v,fderiv ℝ φ a v)=0 at ho
  change spacePair ((graphNormalLength φ a)⁻¹ • graphNormal φ a) (v,fderiv ℝ φ a v)=0
  change (spacePairLinear ((graphNormalLength φ a)⁻¹ • graphNormal φ a)) (v,fderiv ℝ φ a v)=0
  rw [map_smul]
  change (graphNormalLength φ a)⁻¹ * spacePair (graphNormal φ a) (v,fderiv ℝ φ a v)=0
  rw [ho,mul_zero]

theorem euclidean_graph_second_form {φ : Phase} (hφ : ContDiff ℝ 2 φ) (a v w : Plane) :
    euclideanSecondFundamentalForm (euclideanGraph φ) (euclideanGraphNormal φ a) a v w =
      fderiv ℝ (fderiv ℝ φ) a v w / graphNormalLength φ a := by
  have hgraph : ContDiff ℝ 2 (graphLift φ) := contDiff_id.prodMk hφ
  unfold euclideanSecondFundamentalForm euclideanGraph
  have he := second_derivative_linear_comp (a := a) hgraph.contDiffAt spaceEuclideanEquiv.symm.toContinuousLinearMap v w
  change fderiv ℝ (fderiv ℝ (fun b => spaceEuclideanEquiv.symm (graphLift φ b))) a v w = _ at he
  rw [he]
  rw [← spaceEuclideanEquiv_pair]
  change spacePair (graphUnitNormal φ a)
    (spaceEuclideanEquiv (spaceEuclideanEquiv.symm (fderiv ℝ (fderiv ℝ (graphLift φ)) a v w)))=_
  rw [spaceEuclideanEquiv.apply_symm_apply,← derivative_tangent_field hgraph.contDiffAt]
  exact graph_immersion_normal_second_derivative hφ a w v

end EllipticSquareFunction
