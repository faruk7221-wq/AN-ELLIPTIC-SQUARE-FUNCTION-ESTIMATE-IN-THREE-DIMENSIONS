import EllipticSquareFunction.CompactPhaseBounds

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1600000

/-- Every fixed affine placement has uniform cap and separation constants.
They precede the scale and the family. The only localization requirement on
a cap point is that its base lies in the placement domain. -/
theorem uniform_affine_caps (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) {Φ : Phase} (hΦ : ContDiff ℝ (⊤ : ℕ∞) Φ)
    {W O : Set Plane} (hmap : A '' graphOver G.φ W = graphOver Φ O) :
    ∃ r c D : ℝ, 0 < r ∧ 0 < c ∧ 0 < D ∧
      (∀ ξ ∈ G.K, ∀ ν ∈ G.K, ξ ∈ W → ν ∈ W →
        c*‖ξ-ν‖ ≤ ‖graphCenterMap A G.φ ξ-graphCenterMap A G.φ ν‖) ∧
      (∀ δ : ℝ, 0 ≤ δ → δ ≤ 1 → G.C₀*δ < r → ∀ ν ∈ G.K, ∀ z : Space,
        z ∈ cap G.φ ν δ G.C₀ → z.1 ∈ W →
        A z ∈ cap Φ (graphCenterMap A G.φ ν) δ D) := by
  obtain ⟨r₀,H,hr₀,hH,hsource⟩ := graph_phase_local_bound G hG
  have hcompact := graphCenterMap_compact G hG A
  obtain ⟨F,hF⟩ := hcompact.exists_bound_of_continuousOn
    (continuous_id : Continuous (id : Plane → Plane)).continuousOn
  let Q := max F 0+affineSize A*(1+H)+affineSize A*G.C₀
  obtain ⟨L,hL,htarget⟩ := smooth_phase_ball_bound hΦ Q
  let B := affineSize A.symm*(1+L)+1
  have hB : 0 < B := by
    dsimp [B]
    nlinarith [affineSize_nonneg A.symm]
  let D := affineSize A*G.C₀*(H+L+3)+1
  have ha := affineSize_nonneg A
  have hC := G.C₀_pos
  have hD : 0 < D := by dsimp [D]; positivity
  have hcenter (ν : Plane) (hν : ν ∈ G.K) : ‖graphCenterMap A G.φ ν‖ ≤ max F 0 :=
    (hF _ ⟨ν,hν,rfl⟩).trans (le_max_left _ _)
  have hQ : max F 0 ≤ Q := by
    dsimp [Q]
    nlinarith [mul_nonneg ha hC.le,mul_nonneg ha hH.le]
  refine ⟨min r₀ 1,B⁻¹,D,lt_min hr₀ (by norm_num),inv_pos.mpr hB,hD,?_,?_⟩
  · intro ξ hξ ν hν hξW hνW
    have hphase := htarget (graphCenterMap A G.φ ξ) (graphCenterMap A G.φ ν)
      ((hcenter ξ hξ).trans hQ) ((hcenter ν hν).trans hQ)
    have hinv := graphCenterMap_norm_sub_le A.symm Φ hL.le hphase
    have hinv' : ‖graphCenterMap A.symm Φ (graphCenterMap A G.φ ξ)-
        graphCenterMap A.symm Φ (graphCenterMap A G.φ ν)‖ ≤
        B*‖graphCenterMap A G.φ ξ-graphCenterMap A G.φ ν‖ :=
      hinv.trans (mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) (norm_nonneg _))
    have hh := placed_centers_separated hmap hξW hνW hB le_rfl hinv'
    simpa only [div_eq_mul_inv,mul_comm] using hh
  · intro δ hδ hδ1 hδr ν hν z hz hzW
    have hnear : ‖z.1-ν‖ < r₀ := hz.1.trans_lt (hδr.trans_le (min_le_left _ _))
    have hnear1 : ‖z.1-ν‖ ≤ 1 := hz.1.trans (hδr.le.trans (min_le_right _ _))
    have hsrc := hsource ν hν z.1 hnear
    have hdiff := graphCenterMap_norm_sub_le A G.φ hH.le hsrc
    have hsmall : δ^2 ≤ 1 := by nlinarith
    have hξbound : ‖graphCenterMap A G.φ z.1‖ ≤ max F 0+affineSize A*(1+H) := by
      calc
        _ ≤ ‖graphCenterMap A G.φ z.1-graphCenterMap A G.φ ν‖+
            ‖graphCenterMap A G.φ ν‖ := by
          simpa only [sub_add_cancel] using norm_add_le
            (graphCenterMap A G.φ z.1-graphCenterMap A G.φ ν) (graphCenterMap A G.φ ν)
        _ ≤ affineSize A*(1+H)*1+max F 0 := add_le_add
          (hdiff.trans (mul_le_mul_of_nonneg_left hnear1 (by positivity))) (hcenter ν hν)
        _ = _ := by ring
    have hxerr : ‖(A z).1-graphCenterMap A G.φ z.1‖ ≤ affineSize A*G.C₀ := by
      calc
        _ ≤ ‖A z-A (z.1,G.φ z.1)‖ := norm_fst_le _
        _ ≤ affineSize A*|z.2-G.φ z.1| := affine_vertical_error _ _ _
        _ ≤ affineSize A*(G.C₀*δ^2) := mul_le_mul_of_nonneg_left hz.2 ha
        _ ≤ affineSize A*(G.C₀*1) := by gcongr
        _ = _ := by ring
    have hzbound : ‖(A z).1‖ ≤ Q := by
      calc
        _ ≤ ‖(A z).1-graphCenterMap A G.φ z.1‖+‖graphCenterMap A G.φ z.1‖ := by
          simpa only [sub_add_cancel] using norm_add_le
            ((A z).1-graphCenterMap A G.φ z.1) (graphCenterMap A G.φ z.1)
        _ ≤ affineSize A*G.C₀+(max F 0+affineSize A*(1+H)) := add_le_add hxerr hξbound
        _ = Q := by dsimp [Q]; ring
    have hξQ : ‖graphCenterMap A G.φ z.1‖ ≤ Q :=
      hξbound.trans (by dsimp [Q]; nlinarith [mul_nonneg ha hC.le])
    have hp := placed_cap_point hmap hδ hδ1 hC.le hH.le hL.le hz hzW hsrc
      (htarget _ _ hzbound hξQ)
    constructor
    · exact hp.1.trans (mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) hδ)
    · exact hp.2.trans (mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) (sq_nonneg δ))

end EllipticSquareFunction
