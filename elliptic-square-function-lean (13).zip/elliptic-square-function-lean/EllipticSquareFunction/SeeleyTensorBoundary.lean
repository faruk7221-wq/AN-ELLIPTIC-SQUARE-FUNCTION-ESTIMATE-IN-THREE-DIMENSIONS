import EllipticSquareFunction.SeeleyTensorDifferentiation

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem seeley_negative_halfspace_closure :
    closure {p : ℝ × X | p.1 < 0} = {p : ℝ × X | p.1 ≤ 0} := by
  simpa only [closure_Iio] using
    (isOpenMap_fst.preimage_closure_eq_closure_preimage continuous_fst (Set.Iio (0 : ℝ))).symm

theorem seeley_tensor_series_boundary_hasFDerivWithinAt (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E}
    {J' : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin (m+1) => ℝ × X) E}
    {B B' : ℝ} (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B)
    (hJ' : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J' p‖ ≤ B')
    (hc : ContinuousOn J {p : ℝ × X | 0 ≤ p.1})
    (hc' : ContinuousOn J' {p : ℝ × X | 0 ≤ p.1})
    (hd : ∀ p : ℝ × X, 0 < p.1 → HasFDerivAt J (J' p).curryLeft p) (y : X) :
    HasFDerivWithinAt (seeleyTensorSeries m J) (J' (0,y)).curryLeft
      {p : ℝ × X | p.1 ≤ 0} (0,y) := by
  have hconv : Convex ℝ {p : ℝ × X | p.1 < 0} :=
    (convex_Iio (0 : ℝ)).linear_preimage (ContinuousLinearMap.fst ℝ ℝ X).toLinearMap
  have hsub : {p : ℝ × X | p.1 < 0} ⊆ {p : ℝ × X | p.1 ≤ 0} :=
    fun p hp => (show p.1 ≤ 0 from le_of_lt (show p.1 < 0 from hp))
  have hcont := seeley_tensor_series_continuousOn m hJ hc
  have hcont' := seeley_tensor_series_continuousOn (m+1) hJ' hc'
  have hlim : Tendsto (fun p : ℝ × X => (seeleyTensorSeries (m+1) J' p).curryLeft)
      (𝓝[{p : ℝ × X | p.1 < 0}] (0,y)) (𝓝 (J' (0,y)).curryLeft) := by
    have ht := ((continuousMultilinearCurryLeftEquiv ℝ
      (fun _ : Fin (m+1) => ℝ × X) E).continuous.continuousAt.tendsto.comp
        (hcont' (0,y) (show (0 : ℝ) ≤ 0 from le_rfl))).mono_left (nhdsWithin_mono _ hsub)
    simpa only [seeley_tensor_series_boundary] using ht
  have hderlim : Tendsto (fun p => fderiv ℝ (seeleyTensorSeries m J) p)
      (𝓝[{p : ℝ × X | p.1 < 0}] (0,y)) (𝓝 (J' (0,y)).curryLeft) := by
    apply hlim.congr'
    filter_upwards [self_mem_nhdsWithin] with p hp
    exact (seeley_tensor_series_hasFDerivAt m hJ hJ' hd hp).fderiv.symm
  have h := hasFDerivWithinAt_closure_of_tendsto_fderiv
    (s := {p : ℝ × X | p.1 < 0})
    (fun p hp => (seeley_tensor_series_hasFDerivAt m hJ hJ' hd hp).differentiableAt.differentiableWithinAt)
    hconv (isOpen_lt continuous_fst continuous_const)
    (fun p hp => (hcont p (by
      change p ∈ closure {q : ℝ × X | q.1 < 0} at hp
      rw [seeley_negative_halfspace_closure (X := X)] at hp
      exact hp)).mono hsub)
    hderlim
  rw [seeley_negative_halfspace_closure (X := X)] at h
  exact h

def seeleyGluedTensor (m : ℕ)
    (J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E)
    (p : ℝ × X) : ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E :=
  if 0 ≤ p.1 then J p else seeleyTensorSeries m J p

theorem seeley_glued_tensor_nonneg (m : ℕ)
    (J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E)
    {p : ℝ × X} (hp : 0 ≤ p.1) : seeleyGluedTensor m J p = J p := by
  simp only [seeleyGluedTensor,if_pos hp]

theorem seeley_glued_tensor_nonpos (m : ℕ)
    (J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E)
    {p : ℝ × X} (hp : p.1 ≤ 0) : seeleyGluedTensor m J p = seeleyTensorSeries m J p := by
  by_cases hh : 0 ≤ p.1
  · have he : p = (0,p.2) := Prod.ext (le_antisymm hp hh) rfl
    rw [he,seeley_glued_tensor_nonneg m J le_rfl,seeley_tensor_series_boundary]
  · simp only [seeleyGluedTensor,if_neg hh]

theorem seeley_glued_tensor_hasFDerivAt (m : ℕ)
    {J : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin m => ℝ × X) E}
    {J' : ℝ × X → ContinuousMultilinearMap ℝ (fun _ : Fin (m+1) => ℝ × X) E}
    {B B' : ℝ} (hJ : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J p‖ ≤ B)
    (hJ' : ∀ p : ℝ × X, 0 ≤ p.1 → ‖J' p‖ ≤ B')
    (hc' : ContinuousOn J' {p : ℝ × X | 0 ≤ p.1})
    (hd : ∀ p : ℝ × X, 0 ≤ p.1 → HasFDerivWithinAt J (J' p).curryLeft
      {p : ℝ × X | 0 ≤ p.1} p) (p : ℝ × X) :
    HasFDerivAt (seeleyGluedTensor m J) (seeleyGluedTensor (m+1) J' p).curryLeft p := by
  have hpos : ∀ q : ℝ × X, 0 < q.1 → HasFDerivAt J (J' q).curryLeft q := by
    intro q hq
    apply (hd q (le_of_lt hq)).hasFDerivAt
    exact (continuous_fst.continuousAt.preimage_mem_nhds (Ici_mem_nhds hq))
  rcases lt_trichotomy p.1 0 with hp | hp | hp
  · rw [seeley_glued_tensor_nonpos (m+1) J' (le_of_lt hp)]
    apply (seeley_tensor_series_hasFDerivAt m hJ hJ' hpos hp).congr_of_eventuallyEq
    filter_upwards [continuous_fst.continuousAt.preimage_mem_nhds (Iio_mem_nhds hp)] with q hq
    exact seeley_glued_tensor_nonpos m J (le_of_lt hq)
  · have he : p = (0,p.2) := Prod.ext hp rfl
    rw [he,seeley_glued_tensor_nonneg (m+1) J' le_rfl]
    have hl := (seeley_tensor_series_boundary_hasFDerivWithinAt m hJ hJ'
      (fun q hq => (hd q hq).continuousWithinAt) hc' hpos p.2).congr
      (fun q hq => seeley_glued_tensor_nonpos m J hq) (seeley_glued_tensor_nonpos m J le_rfl)
    have hr := (hd (0,p.2) le_rfl).congr
      (fun q hq => seeley_glued_tensor_nonneg m J hq) (seeley_glued_tensor_nonneg m J le_rfl)
    have hu : {q : ℝ × X | q.1 ≤ 0} ∪ {q : ℝ × X | 0 ≤ q.1} = Set.univ := by
      ext q
      simp only [Set.mem_union,Set.mem_setOf_eq,Set.mem_univ,iff_true]
      exact le_total _ _
    simpa only [hu,hasFDerivWithinAt_univ] using hl.union hr
  · rw [seeley_glued_tensor_nonneg (m+1) J' (le_of_lt hp)]
    apply (hpos p hp).congr_of_eventuallyEq
    filter_upwards [continuous_fst.continuousAt.preimage_mem_nhds (Ioi_mem_nhds hp)] with q hq
    exact seeley_glued_tensor_nonneg m J (le_of_lt hq)

end EllipticSquareFunction
