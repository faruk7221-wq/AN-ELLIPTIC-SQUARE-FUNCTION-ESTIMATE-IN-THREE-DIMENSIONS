import EllipticSquareFunction.SeeleyOpenHalfSpace

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {X E : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] [FiniteDimensional ℝ X]
  [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Every Banach-valued smooth function on a finite-dimensional closed half-space
has a global smooth extension. No boundedness or analyticity is assumed. -/
theorem smooth_halfspace_extension {f : ℝ × X → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f {p : ℝ × X | 0 ≤ p.1}) :
    ∃ F : ℝ × X → E, ContDiff ℝ (⊤ : ℕ∞) F ∧
      Set.EqOn F f {p : ℝ × X | 0 ≤ p.1} := by
  let t : ℝ × X → Set E := fun p => if 0 ≤ p.1 then {f p} else Set.univ
  have ht : ∀ p, Convex ℝ (t p) := by
    intro p
    dsimp only [t]
    split_ifs
    · exact convex_singleton _
    · exact convex_univ
  have hlocal : ∀ a : ℝ × X, ∃ U ∈ 𝓝 a, ∃ g : ℝ × X → E,
      ContMDiffOn 𝓘(ℝ,ℝ × X) 𝓘(ℝ,E) (⊤ : ℕ∞) g U ∧ ∀ p ∈ U, g p ∈ t p := by
    intro a
    obtain ⟨F,U,hU,ha,hF,hEq⟩ := smooth_open_halfspace_extension
      (f := f) isOpen_univ (a := a) (Set.mem_univ a) (by simpa only [Set.inter_univ] using hf)
    refine ⟨U,hU.mem_nhds ha,F,hF.contMDiffOn,fun p hp => ?_⟩
    dsimp only [t]
    split_ifs with h
    · exact hEq ⟨hp,h⟩
    · exact Set.mem_univ _
  obtain ⟨F,hF⟩ := exists_contMDiffOn_forall_mem_convex_of_local 𝓘(ℝ,ℝ × X) ht hlocal
  refine ⟨F,F.contMDiff.contDiff,fun p hp => ?_⟩
  change 0 ≤ p.1 at hp
  have hh := hF p
  simpa only [t,if_pos hp,Set.mem_singleton_iff] using hh

end EllipticSquareFunction
