import EllipticSquareFunction.BoundaryExtensionReduction
import Mathlib.LinearAlgebra.Lagrange

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

def seeleyNode (k : ℕ) : ℝ := -(2 : ℝ)^k

def seeleyFiniteCoeff (N k : ℕ) : ℝ :=
  if k ≤ N then (Lagrange.basis (Finset.range (N+1)) seeleyNode k).eval 1 else 0

theorem seeley_node_injective : Function.Injective seeleyNode := by
  intro i j h
  have he : (2 : ℝ)^i=2^j := neg_injective h
  exact (pow_right_strictMono₀ (by norm_num : (1 : ℝ)<2)).injective he

theorem seeley_finite_coeff_zero {N k : ℕ} (h : N < k) : seeleyFiniteCoeff N k=0 := by
  simp [seeleyFiniteCoeff,not_le.mpr h]

theorem seeley_finite_coeff_product {N k : ℕ} (hk : k ≤ N) :
    seeleyFiniteCoeff N k =
      ∏ j ∈ (Finset.range (N+1)).erase k, ((1+(2 : ℝ)^j)/(2^j-2^k)) := by
  simp only [seeleyFiniteCoeff,if_pos hk,Lagrange.basis,Polynomial.eval_prod,
    Lagrange.basisDivisor,Polynomial.eval_mul,Polynomial.eval_C,Polynomial.eval_sub,Polynomial.eval_X]
  apply Finset.prod_congr rfl
  intro j hj
  simp only [seeleyNode]
  ring

/-- Finite reflected-node interpolation matches every moment through N. -/
theorem seeley_finite_moment (N m : ℕ) (hm : m ≤ N) :
    ∑ k ∈ Finset.range (N+1), seeleyFiniteCoeff N k * seeleyNode k ^ m = 1 := by
  have hd : (Polynomial.X^m : Polynomial ℝ).degree < (Finset.range (N+1)).card := by
    simp only [Polynomial.degree_X_pow,Finset.card_range]
    exact_mod_cast Nat.lt_succ_of_le hm
  have he := congrArg (Polynomial.eval (1 : ℝ))
    (Lagrange.eq_interpolate (s := Finset.range (N+1)) seeley_node_injective.injOn hd)
  simp only [Polynomial.eval_pow,Polynomial.eval_X,one_pow,Lagrange.interpolate_apply,
    Polynomial.eval_finset_sum,Polynomial.eval_mul,Polynomial.eval_C] at he
  rw [he]
  apply Finset.sum_congr rfl
  intro k hk
  simp only [seeleyFiniteCoeff,if_pos (Nat.le_of_lt_succ (Finset.mem_range.mp hk)),
    Polynomial.eval_pow,Polynomial.eval_X,smul_eq_mul]
  ring

theorem seeley_finite_coeff_succ {N k : ℕ} (hk : k ≤ N) :
    seeleyFiniteCoeff (N+1) k = seeleyFiniteCoeff N k *
      ((1+(2 : ℝ)^(N+1))/(2^(N+1)-2^k)) := by
  rw [seeley_finite_coeff_product (hk.trans (Nat.le_succ N)),seeley_finite_coeff_product hk,
    Finset.range_add_one,Finset.erase_insert_of_ne (by omega),
    Finset.prod_insert (by simp),mul_comm]

end EllipticSquareFunction
