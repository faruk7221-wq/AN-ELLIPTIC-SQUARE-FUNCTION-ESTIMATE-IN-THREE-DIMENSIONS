import EllipticSquareFunction.AffineGraphCoordinates

noncomputable section
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

def affineSize (A : Space ≃ᵃ[ℝ] Space) : ℝ :=
  ‖A.linear.toContinuousLinearEquiv.toContinuousLinearMap‖

theorem affineSize_nonneg (A : Space ≃ᵃ[ℝ] Space) : 0 ≤ affineSize A := norm_nonneg _

theorem affine_norm_sub_le (A : Space ≃ᵃ[ℝ] Space) (z w : Space) :
    ‖A z-A w‖ ≤ affineSize A*‖z-w‖ := by
  rw [affine_sub_eq_linear]
  exact A.linear.toContinuousLinearEquiv.toContinuousLinearMap.le_opNorm _

theorem graphCenterMap_norm_sub_le (A : Space ≃ᵃ[ℝ] Space) (φ : Phase)
    {H : ℝ} (hH : 0 ≤ H) {ξ ν : Plane}
    (hφ : |φ ξ-φ ν| ≤ H*‖ξ-ν‖) :
    ‖graphCenterMap A φ ξ-graphCenterMap A φ ν‖ ≤
      affineSize A*(1+H)*‖ξ-ν‖ := by
  have hp : ‖(ξ,φ ξ)-(ν,φ ν)‖ ≤ (1+H)*‖ξ-ν‖ := by
    rw [Prod.norm_def]
    simp only [Prod.fst_sub,Prod.snd_sub,Real.norm_eq_abs]
    apply max_le
    · nlinarith [norm_nonneg (ξ-ν)]
    · nlinarith [norm_nonneg (ξ-ν)]
  calc
    _ ≤ ‖A (ξ,φ ξ)-A (ν,φ ν)‖ := norm_fst_le _
    _ ≤ affineSize A*‖(ξ,φ ξ)-(ν,φ ν)‖ := affine_norm_sub_le _ _ _
    _ ≤ affineSize A*((1+H)*‖ξ-ν‖) := mul_le_mul_of_nonneg_left hp (affineSize_nonneg A)
    _ = _ := by ring

/-- An affine map sends a vertical graph error to an error of the same order. -/
theorem affine_vertical_error (A : Space ≃ᵃ[ℝ] Space) (φ : Phase) (z : Space) :
    ‖A z-A (z.1,φ z.1)‖ ≤ affineSize A*|z.2-φ z.1| := by
  have hp : ‖z-(z.1,φ z.1)‖=|z.2-φ z.1| := by
    rw [Prod.norm_def]
    simp
  simpa only [hp] using affine_norm_sub_le A z (z.1,φ z.1)

/-- Quantitative cap transport. The two scalar Lipschitz bounds are exactly
the local estimates subsequently supplied by smoothness on fixed charts.
The new aperture is independent of the cap scale. -/
theorem placed_cap_point {A : Space ≃ᵃ[ℝ] Space} {φ Φ : Phase}
    {W O : Set Plane} (hmap : A '' graphOver φ W = graphOver Φ O)
    {δ C H L : ℝ} (hδ : 0 ≤ δ) (hδ1 : δ ≤ 1) (hC : 0 ≤ C)
    (hH : 0 ≤ H) (hL : 0 ≤ L) {ν : Plane} {z : Space}
    (hz : z ∈ cap φ ν δ C) (hzW : z.1 ∈ W)
    (hφ : |φ z.1-φ ν| ≤ H*‖z.1-ν‖)
    (hΦ : |Φ (A z).1-Φ (graphCenterMap A φ z.1)| ≤
      L*‖(A z).1-graphCenterMap A φ z.1‖) :
    A z ∈ cap Φ (graphCenterMap A φ ν) δ (affineSize A*C*(H+L+3)) := by
  obtain ⟨hzbase,hzheight⟩ := hz
  obtain ⟨_,hgraph⟩ := placed_graph_point hmap hzW
  have ha := affineSize_nonneg A
  have herr : ‖A z-A (z.1,φ z.1)‖ ≤ affineSize A*C*δ^2 :=
    (affine_vertical_error A φ z).trans (by
      calc
        _ ≤ affineSize A*(C*δ^2) := mul_le_mul_of_nonneg_left hzheight ha
        _ = _ := by ring)
  have hxerr : ‖(A z).1-graphCenterMap A φ z.1‖ ≤ affineSize A*C*δ^2 :=
    (norm_fst_le (A z-A (z.1,φ z.1))).trans herr
  have hterr : |(A z).2-Φ (graphCenterMap A φ z.1)| ≤ affineSize A*C*δ^2 := by
    have hh := (norm_snd_le (A z-A (z.1,φ z.1))).trans herr
    rw [hgraph] at hh
    simpa only [Prod.snd_sub,Real.norm_eq_abs] using hh
  have hbase := graphCenterMap_norm_sub_le A φ hH hφ
  have hbase' : ‖graphCenterMap A φ z.1-graphCenterMap A φ ν‖ ≤
      affineSize A*(1+H)*(C*δ) :=
    hbase.trans (mul_le_mul_of_nonneg_left hzbase (mul_nonneg ha (by linarith)))
  have hsmall : δ^2 ≤ δ := by nlinarith
  have hcoef : 0 ≤ affineSize A*C := mul_nonneg ha hC
  constructor
  · calc
      _ ≤ ‖(A z).1-graphCenterMap A φ z.1‖+
          ‖graphCenterMap A φ z.1-graphCenterMap A φ ν‖ := by
        simpa only [dist_eq_norm] using
          dist_triangle (A z).1 (graphCenterMap A φ z.1) (graphCenterMap A φ ν)
      _ ≤ affineSize A*C*δ^2+affineSize A*(1+H)*(C*δ) := add_le_add hxerr hbase'
      _ ≤ affineSize A*C*δ+affineSize A*(1+H)*(C*δ) := by
        exact add_le_add_right (mul_le_mul_of_nonneg_left hsmall hcoef) _
      _ ≤ affineSize A*C*(H+L+3)*δ := by
        nlinarith [mul_nonneg hcoef (mul_nonneg hL hδ),mul_nonneg hcoef hδ]
  · have hlip := hΦ.trans (mul_le_mul_of_nonneg_left hxerr hL)
    calc
      _ ≤ |(A z).2-Φ (graphCenterMap A φ z.1)|+
          |Φ (graphCenterMap A φ z.1)-Φ (A z).1| := abs_sub_le _ _ _
      _ ≤ affineSize A*C*δ^2+L*(affineSize A*C*δ^2) := by
        rw [abs_sub_comm (Φ (graphCenterMap A φ z.1))]
        exact add_le_add hterr hlip
      _ ≤ affineSize A*C*(H+L+3)*δ^2 := by
        nlinarith [mul_nonneg hcoef (sq_nonneg δ),mul_nonneg (mul_nonneg hcoef hH) (sq_nonneg δ)]

/-- A Lipschitz inverse of graph coordinates preserves quantitative separation. -/
theorem placed_centers_separated {A : Space ≃ᵃ[ℝ] Space} {φ Φ : Phase}
    {W O : Set Plane} (hmap : A '' graphOver φ W = graphOver Φ O)
    {ξ ν : Plane} (hξ : ξ ∈ W) (hν : ν ∈ W) {B d : ℝ}
    (hB : 0 < B) (hsep : d ≤ ‖ξ-ν‖)
    (hinv : ‖graphCenterMap A.symm Φ (graphCenterMap A φ ξ)-
        graphCenterMap A.symm Φ (graphCenterMap A φ ν)‖ ≤
      B*‖graphCenterMap A φ ξ-graphCenterMap A φ ν‖) :
    d/B ≤ ‖graphCenterMap A φ ξ-graphCenterMap A φ ν‖ := by
  rw [placed_graph_inverse hmap hξ,placed_graph_inverse hmap hν] at hinv
  exact (div_le_iff₀ hB).mpr (by simpa only [mul_comm] using hsep.trans hinv)

end EllipticSquareFunction
