import EllipticSquareFunction.ActualSampleBounds
import EllipticSquareFunction.CountableSamplingDensity

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Full-lattice coefficient density for actual cap-supported functions,
uniform in scale and cap center. The samples here are unnormalized; multiplying
by the Fourier-series coefficient D^-3 only reduces this bound when D≥1. -/
theorem uniform_cap_sampling_density {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ M A B : ℝ} (hC₀ : 0≤C₀) (hM : 0≤M) (hA : 0<A) (hB : 0<B) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν : Plane) (f : SchwartzMap Space ℂ),
      Function.support (fourierTransform f) ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀ → ∀ y : Space,
      let p := fun i : IntPlane × ℤ => samplePoint (Real.sqrt R) R A B
        (velocity φ ν) (latticePoint 1 i.1) i.2
      (∑' i, ENNReal.ofReal (‖f (p i)‖^2)*
        ENNReal.ofReal (packetWeight R M (velocity φ ν) (p i).1 (p i).2 y)) ≤
      ENNReal.ofReal C*(∫⁻ z, ENNReal.ofReal (‖f z‖^2)*
        ENNReal.ofReal (tubeKernel R M (velocity φ ν) (y-z))) := by
  obtain ⟨L,hL⟩ := exists_nat_gt (M+2)
  have hLM : 2<(L:ℝ)-M := by linarith
  obtain ⟨C,hC,hlocal⟩ := uniform_cap_sample_bound hphase hC₀ L (by linarith)
  let S := scaledLatticeSumConstant A⁻¹ ((L:ℝ)-M)*scaledTimeSumConstant B⁻¹ ((L:ℝ)-M)
  have hs₁ : 0≤scaledLatticeSumConstant A⁻¹ ((L:ℝ)-M) :=
    (tsum_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _)).trans
      (scaled_translated_lattice_sum_le (inv_pos.mpr hA) hLM 0)
  have hs₂ : 0≤scaledTimeSumConstant B⁻¹ ((L:ℝ)-M) :=
    (tsum_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _)).trans
      (scaled_time_sum_le (inv_pos.mpr hB) (by linarith) 0)
  have hS : 0≤S := mul_nonneg hs₁ hs₂
  refine ⟨C*S+1,by positivity,?_⟩
  intro R hR ν f hcap y
  have hR₀ : 0<R := by linarith
  let p := fun i : IntPlane × ℤ => samplePoint (Real.sqrt R) R A B
    (velocity φ ν) (latticePoint 1 i.1) i.2
  let F := fun z : Space => ENNReal.ofReal (‖f z‖^2)
  have hF : AEMeasurable F volume := (f.continuous.norm.pow 2).measurable.ennreal_ofReal.aemeasurable
  have ha (i : IntPlane × ℤ) : ENNReal.ofReal (‖f (p i)‖^2) ≤
      ∫⁻ z, (ENNReal.ofReal (C*(R^2)⁻¹)*F z)*ENNReal.ofReal
        (packetWeight R L (velocity φ ν) (p i).1 (p i).2 z) := by
    have hw : AEMeasurable (fun z => ENNReal.ofReal
        (packetWeight R L (velocity φ ν) (p i).1 (p i).2 z)) volume := by
      apply Measurable.aemeasurable
      apply Measurable.ennreal_ofReal
      unfold packetWeight bracket
      fun_prop
    simp only [mul_assoc]
    rw [lintegral_const_mul'' _ (hF.mul hw)]
    exact hlocal R hR ν f hcap (p i)
  have hh := full_sampling_density_from_local_majorants hR₀ hA hB hM hLM
    (velocity φ ν) (fun i => ENNReal.ofReal (‖f (p i)‖^2))
    (fun z => ENNReal.ofReal (C*(R^2)⁻¹)*F z) (hF.const_mul _) ha y
  have hw : AEMeasurable (fun z => ENNReal.ofReal
      (tubeKernel R M (velocity φ ν) (y-z))) volume := by
    apply Measurable.aemeasurable
    apply Measurable.ennreal_ofReal
    unfold tubeKernel packetWeight bracket
    fun_prop
  apply hh.trans
  calc
    _ = ENNReal.ofReal (C*S)*(∫⁻ z, F z*ENNReal.ofReal
        (tubeKernel R M (velocity φ ν) (y-z))) := by
      rw [← lintegral_const_mul'' _ (hF.mul hw)]
      apply lintegral_congr
      intro z
      change (ENNReal.ofReal (C*(R^2)⁻¹)*F z)*ENNReal.ofReal (S*packetWeight R M (velocity φ ν) 0 0 (y-z)) = _
      simp only [tubeKernel,ENNReal.ofReal_mul hC.le,ENNReal.ofReal_mul hS,
        ENNReal.ofReal_mul (by positivity : 0≤(R^2)⁻¹)]
      ac_rfl
    _ ≤ _ := mul_le_mul_right' (ENNReal.ofReal_le_ofReal (by linarith : C*S≤C*S+1)) _

end EllipticSquareFunction
