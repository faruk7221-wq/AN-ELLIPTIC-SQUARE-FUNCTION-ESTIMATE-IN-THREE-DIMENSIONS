import EllipticSquareFunction.AffineCapGeometry

noncomputable section
open Set
open scoped NNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Smoothness near a compact set supplies a uniform local slope bound and
a positive radius, both chosen before any cap center or cap scale. -/
theorem compact_phase_local_bound {φ : Phase} {K U : Set Plane}
    (hK : IsCompact K) (hU : IsOpen U) (hKU : K ⊆ U)
    (hφ : ContDiffOn ℝ (⊤ : ℕ∞) φ U) :
    ∃ r H : ℝ, 0 < r ∧ 0 < H ∧ ∀ ν ∈ K, ∀ ξ : Plane,
      ‖ξ-ν‖ < r → |φ ξ-φ ν| ≤ H*‖ξ-ν‖ := by
  classical
  have hl (ν : K) : ∃ (L : ℝ≥0) (r : ℝ), 0 < r ∧
      LipschitzOnWith L φ (Metric.ball (ν : Plane) r) := by
    have hc : ContDiffAt ℝ 1 φ (ν : Plane) :=
      ((hφ ν (hKU ν.property)).contDiffAt (hU.mem_nhds (hKU ν.property))).of_le (by norm_num)
    obtain ⟨L,t,ht,hL⟩ := hc.exists_lipschitzOnWith
    obtain ⟨r,hr,hball⟩ := Metric.mem_nhds_iff.mp ht
    exact ⟨L,r,hr,hL.mono hball⟩
  choose L ρ hρ hlip using hl
  let W : K → Set Plane := fun ν => Metric.ball (ν : Plane) (ρ ν)
  have hcover : K ⊆ ⋃ ν : K, W ν := by
    intro ν hν
    exact Set.mem_iUnion.mpr ⟨⟨ν,hν⟩,Metric.mem_ball_self (hρ ⟨ν,hν⟩)⟩
  obtain ⟨s,hs⟩ := hK.elim_finite_subcover W (fun _ => Metric.isOpen_ball) hcover
  have hs' : K ⊆ ⋃ i : s, W i := by
    intro x hx
    obtain ⟨i,hi,hxW⟩ := Set.mem_iUnion₂.mp (hs hx)
    exact Set.mem_iUnion.mpr ⟨⟨i,hi⟩,hxW⟩
  obtain ⟨r,hr,hball⟩ := lebesgue_number_lemma_of_metric hK
    (fun _ : s => Metric.isOpen_ball) hs'
  let H : ℝ := 1+∑ i ∈ s, (L i : ℝ)
  have hsum : 0 ≤ ∑ i ∈ s, (L i : ℝ) := Finset.sum_nonneg (fun i hi => (L i).coe_nonneg)
  refine ⟨r,H,hr,by dsimp [H]; linarith,?_⟩
  intro ν hν ξ hξ
  obtain ⟨i,hi⟩ := hball ν hν
  have hνi : ν ∈ W i := hi (Metric.mem_ball_self hr)
  have hξi : ξ ∈ W i := hi (by simpa only [Metric.mem_ball,dist_eq_norm] using hξ)
  have hh := (hlip i).dist_le_mul ξ hξi ν hνi
  simp only [Real.dist_eq,dist_eq_norm] at hh
  have hiL : (L i : ℝ) ≤ H := by
    have hsingle := Finset.single_le_sum (fun j (_ : j ∈ s) => (L j).coe_nonneg) i.property
    dsimp [H]
    linarith
  exact hh.trans (mul_le_mul_of_nonneg_right hiL (norm_nonneg _))

/-- A globally smooth phase has a uniform Lipschitz bound on each fixed ball. -/
theorem smooth_phase_ball_bound {φ : Phase} (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (F : ℝ) :
    ∃ H : ℝ, 0 < H ∧ ∀ ξ ν : Plane, ‖ξ‖ ≤ F → ‖ν‖ ≤ F →
      |φ ξ-φ ν| ≤ H*‖ξ-ν‖ := by
  obtain ⟨B,hB⟩ := (isCompact_closedBall (0 : Plane) F).exists_bound_of_continuousOn
    (hφ.continuous_fderiv (by norm_num)).continuousOn
  let H := max B 0+1
  have hH : 0 < H := by dsimp [H]; linarith [le_max_right B 0]
  refine ⟨H,hH,?_⟩
  intro ξ ν hξ hν
  have hh := (convex_closedBall (0 : Plane) F).norm_image_sub_le_of_norm_fderiv_le
    (fun x _ => hφ.differentiable (by norm_num) x)
    (fun x hx => (hB x hx).trans (show B ≤ H by dsimp [H]; linarith [le_max_left B 0]))
    (by simpa using hν : ν ∈ Metric.closedBall 0 F)
    (by simpa using hξ : ξ ∈ Metric.closedBall 0 F)
  simpa only [Real.norm_eq_abs] using hh

theorem graph_phase_local_bound (G : GraphSetup) (hG : GraphHypotheses G) :
    ∃ r H : ℝ, 0 < r ∧ 0 < H ∧ ∀ ν ∈ G.K, ∀ ξ : Plane,
      ‖ξ-ν‖ < r → |G.φ ξ-G.φ ν| ≤ H*‖ξ-ν‖ := by
  obtain ⟨U,hU,hKU,hφ,_⟩ := hG
  exact compact_phase_local_bound G.compact_K hU hKU hφ

theorem graphCenterMap_continuousOn {φ : Phase} {K : Set Plane}
    (hφ : ContinuousOn φ K) (A : Space ≃ᵃ[ℝ] Space) :
    ContinuousOn (graphCenterMap A φ) K := by
  have he : graphCenterMap A φ = fun ξ =>
      (A.linear.toContinuousLinearEquiv (ξ,φ ξ)+A 0).1 := by
    funext ξ
    unfold graphCenterMap
    rw [affine_apply_eq_linear_add]
    rfl
  rw [he]
  exact ((A.linear.toContinuousLinearEquiv.continuous.comp_continuousOn
    (continuousOn_id.prodMk hφ)).add continuousOn_const).fst

theorem graphCenterMap_compact (G : GraphSetup) (hG : GraphHypotheses G)
    (A : Space ≃ᵃ[ℝ] Space) : IsCompact (graphCenterMap A G.φ '' G.K) := by
  obtain ⟨U,hU,hKU,hφ,_⟩ := hG
  exact G.compact_K.image_of_continuousOn (graphCenterMap_continuousOn (hφ.continuousOn.mono hKU) A)

end EllipticSquareFunction
