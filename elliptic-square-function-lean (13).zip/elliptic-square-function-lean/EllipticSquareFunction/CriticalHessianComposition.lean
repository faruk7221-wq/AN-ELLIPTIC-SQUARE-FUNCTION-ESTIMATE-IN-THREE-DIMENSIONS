import EllipticSquareFunction.GraphNormalGeometry
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.ContDiff

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- At a critical point, the second derivative of a composition is the
pullback of the outer Hessian. The acceleration term vanishes. -/
theorem critical_hessian_comp {h : Phase} {g : Plane → Plane} {x : Plane}
    (hh : ContDiffAt ℝ 2 h (g x)) (hg : ContDiffAt ℝ 2 g x)
    (hzero : fderiv ℝ h (g x) = 0) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (h ∘ g)) x v w =
      fderiv ℝ (fderiv ℝ h) (g x) (fderiv ℝ g x v) (fderiv ℝ g x w) := by
  have hdg := hg.differentiableAt (by norm_num)
  have hdh := hh.differentiableAt (by norm_num)
  have he : fderiv ℝ (h ∘ g) =ᶠ[𝓝 x]
      (fun y => (fderiv ℝ h (g y)).comp (fderiv ℝ g y)) := by
    have eg := hg.eventually (by norm_num)
    have eh := hdg.continuousAt.eventually (hh.eventually (by norm_num))
    filter_upwards [eg,eh] with y hy hyh
    exact fderiv_comp y (hyh.differentiableAt (by norm_num))
      (hy.differentiableAt (by norm_num))
  rw [he.fderiv_eq]
  have hH := (hh.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num)
  have hG := (hg.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num)
  change fderiv ℝ (fun y => ((fderiv ℝ h ∘ g) y).comp (fderiv ℝ g y)) x v w = _
  rw [fderiv_clm_comp (hH.comp x hdg) hG, fderiv_comp x hH hdg]
  simp [hzero]

end EllipticSquareFunction
