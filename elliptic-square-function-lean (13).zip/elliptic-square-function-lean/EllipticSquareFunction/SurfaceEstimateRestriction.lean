import EllipticSquareFunction.UnitSphereEstimate

noncomputable section
namespace EllipticSquareFunction

theorem surface_cap_mono_carrier {E : Type*} [PseudoMetricSpace E]
    {K L : Set E} (hKL : K ⊆ L) (p : E) (δ C : ℝ) :
    surfaceCap K p δ C ⊆ surfaceCap L p δ C := by
  exact Metric.cthickening_subset_of_subset _ (Set.inter_subset_inter_left _ hKL)

/-- Restricting the carrier preserves the estimate with the very same
constants: centers and distance caps remain admissible for the larger carrier. -/
theorem euclidean_surface_estimate_mono {K L : Set EuclideanThree} (hKL : K ⊆ L)
    {c₀ C₀ : ℝ} (hL : EuclideanSurfaceEstimate L c₀ C₀) :
    EuclideanSurfaceEstimate K c₀ C₀ := by
  intro ε hε
  obtain ⟨C,hC,hbound⟩ := hL ε hε
  refine ⟨C,hC,?_⟩
  intro R hR n p f hp hsep hcap
  exact hbound R hR n p f (fun i => hKL (hp i)) hsep
    (fun i => (hcap i).trans (surface_cap_mono_carrier hKL _ _ _))

/-- Arbitrary portions of the unit sphere inherit its estimate, including
spherical patches with boundary. No regularity of that boundary is needed. -/
theorem unit_sphere_portion_estimate {K : Set EuclideanThree}
    (hK : K ⊆ Metric.sphere (0 : EuclideanThree) 1)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ :=
  euclidean_surface_estimate_mono hK (unit_sphere_estimate hc₀ hC₀ hplacement hnikodym hdiscrete)

end EllipticSquareFunction
