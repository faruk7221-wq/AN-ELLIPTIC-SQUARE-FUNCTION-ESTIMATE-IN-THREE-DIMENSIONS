import EllipticSquareFunction.NormalizedPhase
import Mathlib.Analysis.Calculus.ContDiff.Bounds

noncomputable section
open Set
namespace EllipticSquareFunction

variable {E F : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
  [NormedAddCommGroup F] [NormedSpace ℝ F]

theorem iteratedFDeriv_affine_rescale (f : E → F)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (a x : E) (c : ℝ) (k : ℕ) :
    iteratedFDeriv ℝ k (fun z => f (a+c • z)) x =
      c^k • iteratedFDeriv ℝ k f (a+c • x) := by
  let A : E →L[ℝ] E := c • ContinuousLinearMap.id ℝ E
  have hs := hf.comp (contDiff_const.add contDiff_id :
    ContDiff ℝ (⊤ : ℕ∞) (fun z : E => a+z))
  have hh := A.iteratedFDeriv_comp_right hs x
    (by exact_mod_cast (le_top : (k : ℕ∞) ≤ ⊤))
  simp only [Function.comp_def,iteratedFDeriv_comp_add_left',A,
    ContinuousLinearMap.smul_apply,ContinuousLinearMap.id_apply] at hh
  rw [hh]
  ext m
  simp only [ContinuousMultilinearMap.compContinuousLinearMap_apply,
    ContinuousLinearMap.smul_apply,ContinuousLinearMap.id_apply,
    ContinuousMultilinearMap.smul_apply]
  rw [ContinuousMultilinearMap.map_smul_univ]
  simp

theorem iteratedFDeriv_sub_const_positive (f : E → F)
    (hf : ContDiff ℝ (⊤ : ℕ∞) f) (a : F) (x : E) {k : ℕ} (hk : k≠0) :
    iteratedFDeriv ℝ k (fun z => f z-a) x = iteratedFDeriv ℝ k f x := by
  simp only [sub_eq_add_neg]
  rw [iteratedFDeriv_add_apply' (hf.of_le (by exact_mod_cast
    (le_top : (k : ℕ∞) ≤ ⊤))).contDiffAt contDiffAt_const,
    iteratedFDeriv_const_of_ne hk]
  simp

theorem phaseRemainder_high_derivative_norm (φ : Phase)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) {N : ℝ} (hN : 0<N)
    (ν η : Plane) (k : ℕ) :
    ‖iteratedFDeriv ℝ (k+2) (phaseRemainder φ ν (velocity φ ν) N (N^2)) η‖ =
      N⁻¹^k * ‖iteratedFDeriv ℝ (k+2) φ (ν+N⁻¹ • η)‖ := by
  have hd : ContDiff ℝ (⊤ : ℕ∞) (fderiv ℝ φ) :=
    hφ.fderiv_right (by simp)
  have he : fderiv ℝ (phaseRemainder φ ν (velocity φ ν) N (N^2)) =
      fun z => N • (fderiv ℝ φ (ν+N⁻¹ • z)-fderiv ℝ φ ν) := by
    funext z
    exact (phaseRemainder_hasFDerivAt φ ν z hN.ne' (hφ.differentiable (by norm_num) _)).fderiv
  have hc : ContDiff ℝ (⊤ : ℕ∞) (fun z => fderiv ℝ φ (ν+N⁻¹ • z)-fderiv ℝ φ ν) := (hd.comp (contDiff_const.add (contDiff_id.const_smul N⁻¹))).sub contDiff_const
  rw [show k+2=(k+1)+1 by omega,← norm_iteratedFDeriv_fderiv,he]
  rw [iteratedFDeriv_const_smul_apply' (hc.of_le (by exact_mod_cast
    (le_top : ((k+1 : ℕ) : ℕ∞) ≤ ⊤))).contDiffAt]
  rw [iteratedFDeriv_sub_const_positive (fun z => fderiv ℝ φ (ν+N⁻¹ • z))
    (hd.comp (contDiff_const.add (contDiff_id.const_smul N⁻¹))) (fderiv ℝ φ ν) η (by omega)]
  rw [iteratedFDeriv_affine_rescale _ hd]
  rw [norm_smul,Real.norm_eq_abs,abs_of_pos hN,norm_smul,Real.norm_eq_abs,
    abs_of_nonneg (pow_nonneg (inv_nonneg.mpr hN.le) _),norm_iteratedFDeriv_fderiv]
  rw [pow_succ]
  field_simp
  ring

theorem phaseRemainder_contDiff (φ : Phase)
    (hφ : ContDiff ℝ (⊤ : ℕ∞) φ) (ν : Plane) (N : ℝ) :
    ContDiff ℝ (⊤ : ℕ∞) (phaseRemainder φ ν (velocity φ ν) N (N^2)) := by
  unfold phaseRemainder
  exact contDiff_const.mul (((hφ.comp (contDiff_const.add (contDiff_id.const_smul N⁻¹))).sub
    contDiff_const).sub (contDiff_const.mul (contDiff_const.inner ℝ contDiff_id)))

theorem phaseRemainder_high_derivative_bound {φ : Phase} (hphase : ContinuedPhase φ)
    (k : ℕ) : ∃ H : ℝ, 0≤H ∧ ∀ N : ℝ, 1≤N → ∀ ν η : Plane,
      ‖iteratedFDeriv ℝ (k+2) (phaseRemainder φ ν (velocity φ ν) N (N^2)) η‖ ≤ H := by
  obtain ⟨ρ, ζ, hρ, hρ', hζ, hcζ, hbζ, hζone, hsζ, he, hφ, hell, hder⟩ := hphase
  obtain ⟨H,hH⟩ := hder (k+2) (by omega)
  have hH0 : 0≤H := (norm_nonneg _).trans (hH 0)
  refine ⟨H,hH0,?_⟩
  intro N hN ν η
  have hN0 : 0<N := by linarith
  rw [phaseRemainder_high_derivative_norm φ hφ hN0]
  have hp : N⁻¹^k ≤ 1 := pow_le_one₀ (inv_nonneg.mpr hN0.le) (inv_le_one_of_one_le₀ hN)
  calc
    _ ≤ N⁻¹^k * H := mul_le_mul_of_nonneg_left (hH _) (pow_nonneg (inv_nonneg.mpr hN0.le) _)
    _ ≤ H := by nlinarith

/-- Every fixed derivative order is uniformly bounded on a fixed profile ball,
independently of the cap center and of every real scale `N≥1`. -/
theorem phaseRemainder_derivative_bound_on_ball {φ : Phase}
    (hphase : ContinuedPhase φ) {B : ℝ} (hB : 0≤B) (k : ℕ) :
    ∃ H : ℝ, 0≤H ∧ ∀ N : ℝ, 1≤N → ∀ ν η : Plane, ‖η‖≤B →
      ‖iteratedFDeriv ℝ k (phaseRemainder φ ν (velocity φ ν) N (N^2)) η‖ ≤ H := by
  rcases k with _ | k
  · obtain ⟨C,hC,hT⟩ := continuedPhase_quadratic_bound hphase
    refine ⟨C*B^2,by positivity,?_⟩
    intro N hN ν η hη
    rw [norm_iteratedFDeriv_zero,Real.norm_eq_abs]
    exact (phaseRemainder_bound hT ν η (by linarith)).trans
      (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (norm_nonneg _) hη 2) hC)
  rcases k with _ | k
  · obtain ⟨H,hH,hbound⟩ := phaseRemainder_fderiv_bound hphase
    refine ⟨H*B,mul_nonneg hH hB,?_⟩
    intro N hN ν η hη
    rw [← norm_iteratedFDeriv_fderiv (n := 0),norm_iteratedFDeriv_zero]
    exact (hbound N (by linarith) ν η).trans (mul_le_mul_of_nonneg_left hη hH)
  · obtain ⟨H,hH,hbound⟩ := phaseRemainder_high_derivative_bound hphase k
    exact ⟨H,hH,fun N hN ν η _ => hbound N hN ν η⟩

end EllipticSquareFunction
