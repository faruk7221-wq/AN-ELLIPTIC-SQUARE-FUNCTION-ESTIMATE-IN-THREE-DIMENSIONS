import EllipticSquareFunction.SeparatedDensityTransport

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Finite weighted Schur transport. Both row and weighted column bounds
are visible; in the packet application they are supplied by lattice geometry. -/
theorem finite_weighted_schur_density {ι τ : Type*} (s : Finset ι) (t : Finset τ)
    (a : ι → ℂ) (K : τ → ι → ℂ) (W : τ → ι → ℝ) (H : τ → ℝ) (D : ι → ℝ)
    {C B E : ℝ} (hB : 0≤B) (hH : ∀ j ∈ t, 0≤H j)
    (hW : ∀ j ∈ t, ∀ i ∈ s, 0≤W j i)
    (hK : ∀ j ∈ t, ∀ i ∈ s, ‖K j i‖≤C*W j i)
    (hrow : ∀ j ∈ t, (∑ i ∈ s, W j i)≤B)
    (hcol : ∀ i ∈ s, (∑ j ∈ t, W j i*H j)≤E*D i) :
    (∑ j ∈ t, ‖∑ i ∈ s, K j i*a i‖^2*H j) ≤
      C^2*B*E*(∑ i ∈ s, ‖a i‖^2*D i) := by
  calc
    _ ≤ ∑ j ∈ t, (C^2*B*(∑ i ∈ s, W j i*‖a i‖^2))*H j := by
      apply Finset.sum_le_sum
      intro j hj
      exact mul_le_mul_of_nonneg_right
        (norm_weighted_matrix_sum_sq s (K j) a (W j) (hW j hj) (hK j hj) (hrow j hj)) (hH j hj)
    _ = C^2*B*(∑ i ∈ s, ‖a i‖^2*(∑ j ∈ t, W j i*H j)) := by
      simp_rw [Finset.mul_sum,Finset.sum_mul]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro i hi
      apply Finset.sum_congr rfl
      intro j hj
      ring
    _ ≤ C^2*B*(∑ i ∈ s, ‖a i‖^2*(E*D i)) := by
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg (sq_nonneg _) hB)
      exact Finset.sum_le_sum (fun i hi => mul_le_mul_of_nonneg_left (hcol i hi) (sq_nonneg _))
    _ = _ := by
      simp_rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro i hi
      ring

/-- Replacement of the velocity in a full spatial weight on a short slab. -/
theorem spatialWeight_velocity_comparison {N E M : ℝ} (hN : 0<N) (hE : 0≤E) (hM : 0≤M)
    (V U v : Plane) (y : Space) (ht : |y.2|≤N^2) (hVU : ‖V-U‖≤E/N) :
    spatialWeight N M V v y ≤ (1+E)^M*spatialWeight N M U v y := by
  let x := N⁻¹ • v
  let z := N⁻¹ • (y.1+y.2 • V)
  let w := N⁻¹ • (y.1+y.2 • U)
  have hzw : ‖z-w‖≤E := by
    have he : z-w=N⁻¹ • (y.2 • (V-U)) := by
      dsimp [z,w]
      simp only [smul_sub,smul_add]
      abel
    rw [he,norm_smul,norm_smul,Real.norm_eq_abs,Real.norm_eq_abs,abs_of_pos (inv_pos.mpr hN)]
    calc
      _ ≤ N⁻¹*(N^2*(E/N)) :=
        mul_le_mul_of_nonneg_left (mul_le_mul ht hVU (norm_nonneg _) (sq_nonneg _)) (inv_pos.mpr hN).le
      _ = E := by field_simp; ring
  have hh := bracket_weight_nearby hE hM hzw (u := x)
  have heV : bracket (x-z)=bracket (N⁻¹ • (y.1-v+y.2 • V)) := by
    have he : x-z= -(N⁻¹ • (y.1-v+y.2 • V)) := by
      dsimp [x,z]
      simp only [smul_sub,smul_add]
      abel
    rw [he,bracket,norm_neg]
    rfl
  have heU : bracket (x-w)=bracket (N⁻¹ • (y.1-v+y.2 • U)) := by
    have he : x-w= -(N⁻¹ • (y.1-v+y.2 • U)) := by
      dsimp [x,w]
      simp only [smul_sub,smul_add]
      abel
    rw [he,bracket,norm_neg]
    rfl
  simpa only [heV,heU,spatialWeight] using hh

/-- Full-weight spatial convolution, not merely a bound on a core tube. -/
theorem matrix_spatial_weight_convolution (q : Finset IntPlane)
    {N d M L : ℝ} (hN : 0<N) (hd : 0<d) (hM : 0≤M) (hLM : 2<L-M)
    (V v : Plane) (y : Space) :
    (∑ n ∈ q, bracket (N⁻¹ • (N • latticePoint d n-v))^(-L)*
      spatialWeight N M V (N • latticePoint d n) y) ≤
      scaledLatticeSumConstant d (L-M)*spatialWeight N M V v y := by
  let u := N⁻¹ • v
  let z := N⁻¹ • (y.1+y.2 • V)
  have he1 (n : IntPlane) : bracket (N⁻¹ • (N • latticePoint d n-v)) =
      bracket (u-latticePoint d n) := by
    simp only [smul_sub,smul_smul,inv_mul_cancel₀ hN.ne',one_smul,u,bracket,norm_sub_rev]
  have he2 (n : IntPlane) : spatialWeight N M V (N • latticePoint d n) y =
      bracket (latticePoint d n-z)^(-M) := by
    have he : N⁻¹ • (y.1-N • latticePoint d n+y.2 • V) = z-latticePoint d n := by
      dsimp [z]
      simp only [smul_sub,smul_add,smul_smul,inv_mul_cancel₀ hN.ne',one_smul]
      abel
    simp only [spatialWeight,he,bracket,norm_sub_rev]
  have he3 : bracket (u-z)^(-M)=spatialWeight N M V v y := by
    have he : u-z= -(N⁻¹ • (y.1-v+y.2 • V)) := by
      dsimp [u,z]
      simp only [smul_sub,smul_add]
      abel
    simp only [he,bracket,norm_neg,spatialWeight]
  simp_rw [he1,he2]
  rw [← he3]
  exact finite_weight_convolution q (latticePoint d) u z hM
    (scaled_lattice_finite_sum_le hd hLM u q)

end EllipticSquareFunction
