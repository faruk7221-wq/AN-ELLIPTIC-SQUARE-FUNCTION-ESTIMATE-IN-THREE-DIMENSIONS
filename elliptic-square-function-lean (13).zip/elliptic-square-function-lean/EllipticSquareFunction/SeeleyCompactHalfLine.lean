import EllipticSquareFunction.SeeleyHalfLineExtension

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

theorem halfline_iterated_deriv_zero_tail {f : ℝ → E} {R : ℝ}
    (hf : ∀ s, R < s → f s = 0) (m : ℕ) {s : ℝ} (hs : R < s) :
    iteratedDerivWithin m f (Set.Ici 0) s = 0 := by
  induction m generalizing s with
  | zero => simpa only [iteratedDerivWithin_zero] using hf s hs
  | succ m ih =>
    rw [iteratedDerivWithin_succ]
    have he : iteratedDerivWithin m f (Set.Ici 0) =ᶠ[𝓝 s] (fun _ => (0 : E)) := by
      filter_upwards [Ioi_mem_nhds hs] with t ht
      exact ih ht
    rw [(he.filter_mono nhdsWithin_le_nhds).derivWithin_eq (ih hs)]
    simp only [derivWithin_const, Pi.zero_apply]

theorem smooth_halfline_derivatives_bounded_of_zero_tail {f : ℝ → E} {R : ℝ}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0))
    (hz : ∀ s, R < s → f s = 0) (m : ℕ) :
    ∃ B : ℝ, ∀ s : ℝ, 0 ≤ s → ‖iteratedDerivWithin m f (Set.Ici 0) s‖ ≤ B := by
  have hc := hf.continuousOn_iteratedDerivWithin (m := m)
    (by exact_mod_cast (show (m : ℕ∞) ≤ ⊤ from le_top)) (uniqueDiffOn_Ici 0)
  obtain ⟨B,hB⟩ := (isCompact_Icc : IsCompact (Set.Icc (0 : ℝ) (max R 0))).exists_bound_of_continuousOn
    (hc.mono (fun s hs => hs.1))
  refine ⟨max B 0, fun s hs => ?_⟩
  by_cases hr : s ≤ max R 0
  · exact (hB s ⟨hs,hr⟩).trans (le_max_left _ _)
  · rw [halfline_iterated_deriv_zero_tail hz m ((le_max_left R 0).trans_lt (lt_of_not_ge hr)), norm_zero]
    exact le_max_right _ _

theorem smooth_halfline_extension_of_zero_tail {f : ℝ → E} {R : ℝ}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0))
    (hz : ∀ s, R < s → f s = 0) :
    ∃ F : ℝ → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F f (Set.Ici 0) :=
  smooth_halfline_extension_of_bounded_derivatives hf
    (smooth_halfline_derivatives_bounded_of_zero_tail hf hz)

end EllipticSquareFunction
