import EllipticSquareFunction.SeparatedPositions

/-! # Density transport for arbitrary separated original positions -/
noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

def separatedCoefficient {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    (N : ℝ) (s : Finset ι) (pbox : ι → Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν : ι → Plane) (v : ι → IntPlane → Plane) (μ w : Plane) : ℂ :=
  ∑ i ∈ s, ∑ p ∈ pbox i, windowMatrix b χ N μ w (ν i) (v i p) * a i p

theorem separatedCoefficient_sq_le_near {ι : Type*} (b : Plane → ℂ) (χ : Plane → ℝ)
    {N c A C L : ℝ} (hN : 0 < N) (hc : 0 < c) (hL : 2 < L)
    (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) (μ w : Plane) (K : ℕ)
    (hpositions : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hoverlap : FrequencyOverlap N A s ν μ K)
    (hcut : ∀ i ∈ s, A / N < ‖μ - ν i‖ →
      ∀ p ∈ pbox i, windowMatrix b χ N μ w (ν i)
        (v i p) = 0)
    (hdecay : ∀ i ∈ s, ∀ p ∈ pbox i,
      ‖windowMatrix b χ N μ w (ν i) (v i p)‖ ≤
        C * bracket (N⁻¹ • (w - (v i p))) ^ (-L)) :
    ‖separatedCoefficient b χ N s pbox a ν v μ w‖ ^ 2 ≤
      C ^ 2 * ((K : ℝ) * separatedPlaneSumConstant c L) *
        ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A / N), ∑ p ∈ pbox i,
          bracket (N⁻¹ • (w - (v i p))) ^ (-L) * ‖a i p‖ ^ 2 := by
  classical
  let near : ι → Prop := fun i => ‖μ - ν i‖ ≤ A / N
  let wt : (Σ _ : ι, IntPlane) → ℝ := fun ip =>
    if near ip.1 then bracket (N⁻¹ • (w - (v ip.1 ip.2))) ^ (-L) else 0
  let t := (s.filter near).sigma pbox
  have hrewrite : separatedCoefficient b χ N s pbox a ν v μ w =
      ∑ ip ∈ t, windowMatrix b χ N μ w (ν ip.1)
        (v ip.1 ip.2) * a ip.1 ip.2 := by
    rw [separatedCoefficient]
    have hprod := Finset.sum_sigma s pbox (fun ip =>
      windowMatrix b χ N μ w (ν ip.1) (v ip.1 ip.2) * a ip.1 ip.2)
    rw [← hprod]
    symm
    apply Finset.sum_subset
    · intro ip hip
      exact Finset.mem_sigma.mpr
        ⟨(Finset.filter_subset near s) (Finset.mem_sigma.mp hip).1,
          (Finset.mem_sigma.mp hip).2⟩
    intro ip hip hnot
    have his : ip.1 ∈ s := (Finset.mem_sigma.mp hip).1
    have hp : ip.2 ∈ pbox ip.1 := (Finset.mem_sigma.mp hip).2
    have hnnear : ¬ near ip.1 := by
      intro hn
      exact hnot (Finset.mem_sigma.mpr ⟨Finset.mem_filter.mpr ⟨his, hn⟩, hp⟩)
    rw [hcut ip.1 his (lt_of_not_ge hnnear) ip.2 hp, zero_mul]
  have hwt (ip : Σ _ : ι, IntPlane) (hip : ip ∈ t) :
      wt ip = bracket (N⁻¹ • (w - (v ip.1 ip.2))) ^ (-L) := by
    dsimp only [wt]
    rw [if_pos (Finset.mem_filter.mp (Finset.mem_sigma.mp hip).1).2]
  have hw_nonneg : ∀ ip ∈ t, 0 ≤ wt ip := by
    intro ip hip
    rw [hwt ip hip]
    exact Real.rpow_nonneg (bracket_pos _).le _
  have hmatrix : ∀ ip ∈ t,
      ‖windowMatrix b χ N μ w (ν ip.1) (v ip.1 ip.2)‖ ≤ C * wt ip := by
    intro ip hip
    rw [hwt ip hip]
    exact hdecay ip.1 (Finset.mem_filter.mp (Finset.mem_sigma.mp hip).1).1
      ip.2 (Finset.mem_sigma.mp hip).2
  have hconst : 0 ≤ separatedPlaneSumConstant c L := separatedPlaneSumConstant_nonneg hc hL
  have hweights : ∑ ip ∈ t, wt ip ≤ (K : ℝ) * separatedPlaneSumConstant c L := by
    rw [Finset.sum_sigma]
    calc
      _ = ∑ i ∈ s.filter near, ∑ p ∈ pbox i,
          bracket (N⁻¹ • (w-v i p))^(-L) := by
        apply Finset.sum_congr rfl
        intro i hi
        apply Finset.sum_congr rfl
        intro p hp
        exact hwt ⟨i,p⟩ (Finset.mem_sigma.mpr ⟨hi,hp⟩)
      _ ≤ ∑ _i ∈ s.filter near, separatedPlaneSumConstant c L :=
        Finset.sum_le_sum (fun i hi => separated_scaled_plane_weight_sum (pbox i) (v i)
          hN hc hL (hpositions i (Finset.mem_filter.mp hi).1) w)
      _ = ((s.filter near).card : ℝ) * separatedPlaneSumConstant c L := by simp
      _ ≤ (K : ℝ) * separatedPlaneSumConstant c L :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast hoverlap)
          hconst
  rw [hrewrite]
  have hmain := norm_weighted_matrix_sum_sq t
    (fun ip => windowMatrix b χ N μ w (ν ip.1) (v ip.1 ip.2))
    (fun ip => a ip.1 ip.2) wt hw_nonneg hmatrix hweights
  apply hmain.trans_eq
  congr 1
  rw [Finset.sum_sigma]
  apply Finset.sum_congr rfl
  intro i hi
  apply Finset.sum_congr rfl
  intro p hp
  rw [hwt ⟨i,p⟩ (Finset.mem_sigma.mpr ⟨hi, hp⟩)]


theorem separatedCoefficient_position_density_near {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c d A C E L : ℝ}
    (hN : 0 < N) (hc : 0 < c) (hd : 0 < d) (hE : 0 ≤ E) (hL : 2 < L)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (a : ι → IntPlane → ℂ)
    (ν Vν : ι → Plane) (v : ι → IntPlane → Plane) (μ : Plane) (Vμ : Plane) (y : Space) (K : ℕ)
    (hpositions : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hoverlap : FrequencyOverlap N A s ν μ K)
    (hvel : ∀ i ∈ s, ‖μ - ν i‖ ≤ A / N → ‖Vμ - Vν i‖ ≤ E / N)
    (hcut : ∀ (w : Plane) (i : ι), i ∈ s → A / N < ‖μ - ν i‖ →
      ∀ p ∈ pbox i, windowMatrix b χ N μ w (ν i)
        (v i p) = 0)
    (hdecay : ∀ (w : Plane) (i : ι), i ∈ s → ∀ p ∈ pbox i,
      ‖windowMatrix b χ N μ w (ν i) (v i p)‖ ≤
        C * bracket (N⁻¹ • (w - (v i p))) ^ (-L))
    (hq : ∀ n ∈ q, y ∈ coreTube N (N^2) Vμ (N • latticePoint d n)) :
    (∑ n ∈ q,
      ‖separatedCoefficient b χ N s pbox a ν v μ (N • latticePoint d n)‖^2) ≤
      ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) *
          ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox i, ‖a i p‖^2 *
            spatialWeight N L (Vν i) (v i p) y := by
  classical
  let D := ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox i, ‖a i p‖^2 *
    spatialWeight N L (Vν i) (v i p) y
  have hconst : 0 ≤ separatedPlaneSumConstant c L := separatedPlaneSumConstant_nonneg hc hL
  have hpoint (n : IntPlane) (hn : n ∈ q) :
      ‖separatedCoefficient b χ N s pbox a ν v μ (N • latticePoint d n)‖^2 ≤
        (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D := by
    have hy := hq n hn
    have hcfs := separatedCoefficient_sq_le_near b χ hN hc hL s pbox a ν v μ
      (N • latticePoint d n) K hpositions hoverlap
      (hcut (N • latticePoint d n)) (hdecay (N • latticePoint d n))
    have hsum : (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox i,
        bracket (N⁻¹ • (N • latticePoint d n - (v i p))) ^ (-L) *
          ‖a i p‖ ^ 2) ≤ (2+E)^L * D := by
      calc
        _ ≤ ∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox i,
            ((2+E)^L * spatialWeight N L (Vν i) (v i p) y) *
              ‖a i p‖^2 := by
          apply Finset.sum_le_sum
          intro i hi
          apply Finset.sum_le_sum
          intro p hp
          exact mul_le_mul_of_nonneg_right
            (matrixWeight_le_spatialWeight_on_core hN hE (by linarith) Vμ (Vν i)
              (N • latticePoint d n) (v i p) y hy
              (hvel i (Finset.mem_filter.mp hi).1 (Finset.mem_filter.mp hi).2))
            (sq_nonneg _)
        _ = (2+E)^L * (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N),
            ∑ p ∈ pbox i, ‖a i p‖^2 *
              spatialWeight N L (Vν i) (v i p) y) := by
          simp_rw [mul_assoc, ← Finset.mul_sum]
          congr 1
          apply Finset.sum_congr rfl
          intro i hi
          apply Finset.sum_congr rfl
          intro p hp
          ring
    calc
      _ ≤ C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) *
          (∑ i ∈ s.filter (fun i => ‖μ - ν i‖ ≤ A/N), ∑ p ∈ pbox i,
            bracket (N⁻¹ • (N • latticePoint d n - (v i p))) ^ (-L) *
              ‖a i p‖ ^ 2) := hcfs
      _ ≤ C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * ((2+E)^L * D) :=
        mul_le_mul_of_nonneg_left hsum
          (mul_nonneg (sq_nonneg C) (mul_nonneg (Nat.cast_nonneg K) hconst))
      _ = _ := by ring
  have hcard : q.card ≤ (integerPlaneBox ⌈d⁻¹+2⌉₊).card :=
    canonical_core_position_count hN hd Vμ y q hq
  change (∑ n ∈ q, ‖separatedCoefficient b χ N s pbox a ν v μ
      (N • latticePoint d n)‖^2) ≤
    ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
      (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D
  calc
    _ ≤ ∑ _n ∈ q, (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D :=
      Finset.sum_le_sum hpoint
    _ = (q.card : ℝ) *
        (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D := by
      simp
      ring
    _ ≤ ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D := by
      have hD : 0 ≤ D := Finset.sum_nonneg (fun i hi =>
        Finset.sum_nonneg (fun p hp => mul_nonneg (sq_nonneg _)
          (spatialWeight_nonneg N L (Vν i) (v i p) y)))
      have hfac : 0 ≤ (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) * D :=
        mul_nonneg (mul_nonneg
          (mul_nonneg (sq_nonneg C) (mul_nonneg (Nat.cast_nonneg K) hconst))
          (Real.rpow_nonneg (by linarith) L)) hD
      rw [mul_assoc, mul_assoc]
      have hcardR : (q.card : ℝ) ≤ ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) := by
        exact_mod_cast hcard
      convert mul_le_mul_of_nonneg_right hcardR hfac using 1 <;> ring

theorem separatedCoefficient_global_density {ι : Type*}
    (b : Plane → ℂ) (χ : Plane → ℝ) {N c d A C E L : ℝ}
    (hN : 0 < N) (hc : 0 < c) (hd : 0 < d) (hE : 0 ≤ E) (hL : 2 < L)
    (s : Finset ι) (pbox : ι → Finset IntPlane) (q : Finset IntPlane) (qpos : IntPlane → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν Vν : ι → Plane) (v : ι → IntPlane → Plane)
    (Vμ : IntPlane → Plane) (y : Space) (K : ℕ)
    (hpositions : ∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖)
    (hoverlap : ∀ m ∈ q, FrequencyOverlap N A s ν (latticePoint N⁻¹ m) K)
    (hvel : ∀ m ∈ q, ∀ i ∈ s, ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N →
      ‖Vμ m - Vν i‖ ≤ E/N)
    (hcut : ∀ m ∈ q, ∀ (w : Plane) (i : ι), i ∈ s →
      A/N < ‖latticePoint N⁻¹ m - ν i‖ → ∀ p ∈ pbox i,
      windowMatrix b χ N (latticePoint N⁻¹ m) w (ν i) (v i p) = 0)
    (hdecay : ∀ m ∈ q, ∀ (w : Plane) (i : ι), i ∈ s → ∀ p ∈ pbox i,
      ‖windowMatrix b χ N (latticePoint N⁻¹ m) w (ν i) (v i p)‖ ≤
        C * bracket (N⁻¹ • (w - (v i p))) ^ (-L))
    (hcore : ∀ m ∈ q, ∀ n ∈ qpos m, y ∈ coreTube N (N^2) (Vμ m) (N • latticePoint d n)) :
    (∑ m ∈ q, ∑ n ∈ qpos m,
      ‖separatedCoefficient b χ N s pbox a ν v (latticePoint N⁻¹ m) (N • latticePoint d n)‖^2) ≤
      (((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
        (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L) *
          ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)) *
            ∑ i ∈ s, ∑ p ∈ pbox i, ‖a i p‖^2 *
              spatialWeight N L (Vν i) (v i p) y := by
  classical
  let T : ℝ := ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
    (C^2 * ((K : ℝ) * separatedPlaneSumConstant c L) * (2+E)^L)
  let F : ι → ℝ := fun i => ∑ p ∈ pbox i, ‖a i p‖^2 *
    spatialWeight N L (Vν i) (v i p) y
  have hF : ∀ i ∈ s, 0 ≤ F i := fun i _ => Finset.sum_nonneg
    (fun p _ => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  have hconst : 0 ≤ separatedPlaneSumConstant c L := separatedPlaneSumConstant_nonneg hc hL
  have hT : 0 ≤ T := by dsimp [T]; positivity
  have hsum := sum_near_frequency_le s q
    (fun m i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N) F
    (integerPlaneBox ⌈A+2⌉₊).card hF
    (fun i _ => canonical_frequency_near_count hN (ν i) q)
  calc
    _ ≤ ∑ m ∈ q, T * ∑ i ∈ s.filter (fun i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N), F i := by
      apply Finset.sum_le_sum
      intro m hm
      exact separatedCoefficient_position_density_near b χ hN hc hd hE hL s pbox (qpos m) a ν Vν v
        (latticePoint N⁻¹ m) (Vμ m) y K hpositions (hoverlap m hm) (hvel m hm)
        (hcut m hm) (hdecay m hm) (hcore m hm)
    _ = T * ∑ m ∈ q, ∑ i ∈ s.filter (fun i => ‖latticePoint N⁻¹ m - ν i‖ ≤ A/N), F i :=
      (Finset.mul_sum ..).symm
    _ ≤ T * (((integerPlaneBox ⌈A+2⌉₊).card : ℝ) * ∑ i ∈ s, F i) :=
      mul_le_mul_of_nonneg_left hsum hT
    _ = _ := by dsimp [T, F]; ring


/-- Density transport for arbitrary finite fine-frame truncations, with a
constant uniform in scale and both finite coefficient arrays.
All matrix, packing, and velocity assumptions have been discharged. In the
saved manuscript this is the density display (4.12), following the matrix
bound (4.11); earlier project reports called this step (4.11). -/
theorem separated_fine_frame_density_transport {ι : Type*} {φ : Phase}
    (hφ : ContinuedPhase φ) (b : Plane → ℂ) (hb : ContDiff ℝ (⊤ : ℕ∞) b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : ContDiff ℝ (⊤ : ℕ∞) χ)
    (hχs : HasCompactSupport χ) {c d σ : ℝ} (hc : 0 < c) (hd : 0 < d) (hσ : 0 < σ)
    (L : ℕ) (hL : 2 < L) :
    ∃ B : ℝ, 0 < B ∧ ∀ {N : ℝ}, 0 < N →
      ∀ (s : Finset ι) (pbox : ι → Finset IntPlane) (q nbox : Finset IntPlane)
        (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane),
      (∀ i ∈ s, ∀ p ∈ pbox i, ∀ q ∈ pbox i, p≠q → c*N≤‖v i p-v i q‖) →
      (∀ i ∈ s, ∀ j ∈ s, i ≠ j → σ/N ≤ ‖ν i - ν j‖) → ∀ y : Space,
      coreDensity (q ×ˢ nbox)
        (fun mn => separatedCoefficient b χ N s pbox a ν v
          (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2))
        (fun mn => velocity φ (latticePoint N⁻¹ mn.1))
        (fun mn => N • latticePoint d mn.2) N (N^2) y ≤
      B * spatialDensity (s.sigma pbox) (fun ip => a ip.1 ip.2)
        (fun ip => velocity φ (ν ip.1))
        (fun ip => v ip.1 ip.2) N (L : ℝ) y := by
  classical
  obtain ⟨A, hA, hcut⟩ := windowMatrix_frequency_cutoff b hbs χ hχs
  obtain ⟨C, hC, hdecay⟩ := windowMatrix_decay b hb hbs χ hχ hχs L
  obtain ⟨H, hH, hvelocity⟩ := continuedPhase_velocity_bound hφ
  let K := (integerPlaneBox ⌈(5/σ)*A+4⌉₊).card
  let B := ((integerPlaneBox ⌈d⁻¹+2⌉₊).card : ℝ) *
    (C^2 * ((K : ℝ) * separatedPlaneSumConstant c (L : ℝ)) * (2+H*A)^(L : ℝ)) *
      ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)
  refine ⟨max B 1, lt_of_lt_of_le zero_lt_one (le_max_right _ _), ?_⟩
  intro N hN s pbox q nbox a ν v hpositions hsep y
  let qpos := fun m => nbox.filter (fun n =>
    y ∈ coreTube N (N^2) (velocity φ (latticePoint N⁻¹ m)) (N • latticePoint d n))
  have hglobal := separatedCoefficient_global_density (L := (L : ℝ)) b χ hN hc hd (mul_nonneg hH hA.le)
    (by exact_mod_cast hL) s pbox q qpos a ν (fun i => velocity φ (ν i)) v
    (fun m => velocity φ (latticePoint N⁻¹ m)) y K hpositions
    (fun m _ => frequencyOverlap_of_separated s ν hN hσ hsep _)
    (by
      intro m hm i hi hnear
      calc
        _ ≤ H * ‖latticePoint N⁻¹ m - ν i‖ := hvelocity (ν i) _
        _ ≤ H * (A/N) := mul_le_mul_of_nonneg_left hnear hH
        _ = (H*A)/N := by ring)
    (by intro m hm w i hi hfar p hp; exact hcut N hN _ w _ _ hfar)
    (by intro m hm w i hi p hp; exact hdecay N hN _ w _ _)
    (by intro m hm n hn; exact (Finset.mem_filter.mp hn).2)
  have he : coreDensity (q ×ˢ nbox)
        (fun mn => separatedCoefficient b χ N s pbox a ν v
          (latticePoint N⁻¹ mn.1) (N • latticePoint d mn.2))
        (fun mn => velocity φ (latticePoint N⁻¹ mn.1))
        (fun mn => N • latticePoint d mn.2) N (N^2) y =
      ∑ m ∈ q, ∑ n ∈ qpos m, ‖separatedCoefficient b χ N s pbox a ν v
        (latticePoint N⁻¹ m) (N • latticePoint d n)‖^2 := by
    simp only [coreDensity, Finset.sum_product, Set.indicator_apply, qpos, Finset.sum_filter]
  rw [he]
  apply hglobal.trans
  change B * _ ≤ max B 1 * _
  rw [spatialDensity, Finset.sum_sigma]
  exact mul_le_mul_of_nonneg_right (le_max_left B 1)
    (Finset.sum_nonneg fun i _ => Finset.sum_nonneg fun p _ =>
      mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))

end EllipticSquareFunction
