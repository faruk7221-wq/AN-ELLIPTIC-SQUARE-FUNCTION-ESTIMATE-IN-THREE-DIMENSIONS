import EllipticSquareFunction.SurfaceWithBoundary

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- The actual Euclidean surface estimate, with constants uniform in scale,
cap centers, cap count, and Schwartz data. -/
def EuclideanSurfaceEstimate (K : Set EuclideanThree) (c₀ C₀ : ℝ) : Prop :=
  ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧ ∀ R : ℝ, 2 ≤ R →
    ∀ (n : ℕ) (p : Fin n → EuclideanThree) (f : Fin n → SchwartzMap EuclideanThree ℂ),
    (∀ i, p i ∈ K) →
    (∀ i j, i ≠ j → c₀*(Real.sqrt R)⁻¹ ≤ ‖p i-p j‖) →
    (∀ i, Function.support (Real.fourierIntegral (f i)) ⊆ surfaceCap K (p i) (Real.sqrt R)⁻¹ C₀) →
    eLpNorm (fun y => ∑ i, f i y) 3 volume ≤ ENNReal.ofReal (C*R^ε)*
      eLpNorm (fun y => Real.sqrt (∑ i, ‖f i y‖^2)) 3 volume

/-- The two conclusions of Theorem 1. Smooth surfaces are interpreted using
the explicit embedded extension charts of SurfaceWithBoundary. -/
def ArticleMainConclusion : Prop :=
  (∀ G : GraphSetup, GraphHypotheses G → ReverseSquareFunction G) ∧
  ∀ K : Set EuclideanThree, IsCompact K → SmoothEllipticSurfaceWithBoundary K →
    ∀ c₀ C₀ : ℝ, 0 < c₀ → 0 < C₀ → EuclideanSurfaceEstimate K c₀ C₀

/-- Theorem 1: graph and surface estimates follow from exactly the three
external input propositions. No packet, graph-atlas, or geometric reduction
is left as an additional analytic hypothesis. -/
theorem article_main_theorem
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    ArticleMainConclusion := by
  constructor
  · intro G hG
    exact general_graph_reverse_square_function G hG hplacement hnikodym hdiscrete
  · intro K hK hsurface c₀ C₀ hc₀ hC₀
    exact article_surface_theorem hK hc₀ hC₀ hsurface hplacement hnikodym hdiscrete

/-- A stronger surface conclusion also permits arbitrary portions of local
elliptic extensions, beyond smooth-boundary carriers. -/
theorem article_extension_surface_theorem {K : Set EuclideanThree} (hK : IsCompact K)
    (hsurface : EuclideanEllipticSurfaceExtensions K) {c₀ C₀ : ℝ}
    (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ :=
  euclidean_embedded_surface_estimate hK hc₀ hC₀ hsurface hplacement hnikodym hdiscrete

end EllipticSquareFunction
