import EllipticSquareFunction.ProfileAssembly
import EllipticSquareFunction.TimeTranslation

/-! # Proposition 2 with explicit fixed-setup margins

The theorem below supplies the finite-profile whole-plane bound directly
from the stated external discrete input. Its fixed setup must meet the
constructed position and frequency margins. The companion theorem gives
arbitrary common time origins without changing any constants.
-/
noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Proposition 2 for a fixed finite collection of profiles, conditional only
on the external input, the phase hypotheses, and the explicit setup margins.
No local-estimate, far-estimate, or global-integrability premise remains. -/
theorem proposition_two_fixed_setup {ι : Type*} {n : ℕ}
    (S : DiscreteSetup) (hphase : ContinuedPhase S.φ) (hinput : DiscreteDensityInput S)
    (b : Fin n → Plane → ℂ) (hb : ∀ r, ContDiff ℝ (⊤ : ℕ∞) (b r))
    (hbs : ∀ r, HasCompactSupport (b r))
    {c σ F : ℝ} (hc : 0<c) (hσ : 0<σ) (hF : 0≤F)
    (hQ₂ : 3≤S.C₂) (M : ℝ) (hM : 2<M) :
    ∃ A : Fin n → ℝ, (∀ r, 1≤A r) ∧ ((∀ r, A r+1≤S.C₁) →
      ∃ Z : Fin n → ℝ, (∀ r, 0<Z r) ∧ ((∀ r, F+Z r≤S.frequencyBound) →
        ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
        ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ d : Fin n → FinitePacketArray ι,
          (∀ r, SeparatedPacketArray (d r) ((2:ℝ)^j) c σ F) →
          l3 (fun y => ∑ r, arrayPacketSum (d r) S.φ (b r) ((2:ℝ)^j) y)
            (volume.restrict (timeSlab (((2:ℝ)^j)^2))) ≤
          ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
            densityCubeRoot (fun y => ∑ r, arraySpatialDensity (d r) S.φ ((2:ℝ)^j) M y)
              (((2:ℝ)^j)^2))) := by
  have hsing (r : Fin n) := global_single_profile_packets (ι := ι)
    S hphase hinput (b r) (hb r) (hbs r) hc hσ hF hQ₂ M hM
  choose A hA hsing using hsing
  refine ⟨A,hA,?_⟩
  intro hA₁
  choose Z hZ hsing using fun r => hsing r (hA₁ r)
  refine ⟨Z,hZ,?_⟩
  intro hFZ
  have hφ : ContDiff ℝ (⊤ : ℕ∞) S.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hφ,_⟩
    exact hφ
  apply uniform_finite_profiles_of_single S.φ hφ.continuous b (fun r => (hb r).continuous)
    hbs c σ F M
  intro r
  obtain ⟨C,hC,hbound⟩ := hsing r (hFZ r)
  refine ⟨C,hC,?_⟩
  intro κ η hκ hκ' hη hη'
  obtain ⟨P,hP,hbound⟩ := hbound κ η hκ hκ' hη hη'
  refine ⟨P,hP,?_⟩
  intro j hj d hd
  exact hbound j hj d.labels d.positions d.coefficient d.frequency d.position hd.1 hd.2.1 hd.2.2

/-- The finite-profile estimate at any common time origin, with precisely the
same coefficient as at the origin zero. Apply this to the preceding theorem. -/
theorem finite_profile_estimate_common_time_origin {ι : Type*} {n : ℕ}
    (φ : Phase) (hφ : Continuous φ) (b : Fin n → Plane → ℂ)
    (hb : ∀ r, Continuous (b r)) (hbs : ∀ r, HasCompactSupport (b r))
    (d : Fin n → FinitePacketArray ι) {N : ℝ} (hN : N≠0) (M C : ℝ)
    (h : l3 (fun y => ∑ r, arrayPacketSum (d r) φ (b r) N y)
      (volume.restrict (timeSlab (N^2))) ≤ ENNReal.ofReal C*
      densityCubeRoot (fun y => ∑ r, arraySpatialDensity (d r) φ N M y) (N^2))
    (t₀ : ℝ) :
    l3 (fun y => ∑ r, arrayPacketSum (d r) φ (b r) N (y.1,y.2-t₀))
      (volume.restrict (shiftedTimeSlab t₀ (N^2))) ≤ ENNReal.ofReal C*
      (∫⁻ y in shiftedTimeSlab t₀ (N^2),
        (ENNReal.ofReal (∑ r, arraySpatialDensity (d r) φ N M (y.1,y.2-t₀)))^(3/2:ℝ))^(1/3:ℝ) := by
  have hF : Continuous (fun y => ∑ r, arrayPacketSum (d r) φ (b r) N y) :=
    continuous_finset_sum Finset.univ (fun r _ =>
      continuous_arrayPacketSum (d r) φ hφ (b r) (hb r) (hbs r) hN)
  rw [time_translation_l3 _ hF t₀ (N^2)]
  rw [time_translation_densityCubeRoot
    (fun y => ∑ r, arraySpatialDensity (d r) φ N M y) t₀ (N^2)]
  exact h

end EllipticSquareFunction
