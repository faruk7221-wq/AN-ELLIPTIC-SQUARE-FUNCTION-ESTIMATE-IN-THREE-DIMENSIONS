import EllipticSquareFunction.FarPackets
import EllipticSquareFunction.LocalStatements

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 800000

def spatialTileCenter (N : ℝ) (m : IntPlane) : Plane := N^2 • latticePoint 1 m

def spatialTile (N : ℝ) (m : IntPlane) : Set Plane :=
  {x | floorPoint ((N^2)⁻¹ • x)=m}

theorem measurableSet_spatialTile (N : ℝ) (m : IntPlane) : MeasurableSet (spatialTile N m) := by
  have hf : Measurable (fun x : Plane => floorPoint ((N^2)⁻¹ • x)) := by
    apply measurable_pi_lambda
    intro i
    unfold floorPoint
    apply Measurable.floor
    fun_prop
  exact (measurableSet_singleton m).preimage hf

theorem spatialTile_cover (N : ℝ) : (⋃ m : IntPlane, spatialTile N m)=univ := by
  ext x
  simp only [mem_iUnion,mem_univ,iff_true]
  exact ⟨floorPoint ((N^2)⁻¹ • x),rfl⟩

theorem spatialTile_disjoint (N : ℝ) : Pairwise (fun m n => Disjoint (spatialTile N m) (spatialTile N n)) := by
  intro m n hmn
  apply disjoint_left.mpr
  intro x hx hn
  exact hmn (hx.symm.trans hn)

theorem spatialTile_radius {N : ℝ} (hN : N≠0) (m : IntPlane) {x : Plane}
    (hx : x∈spatialTile N m) : ‖x-spatialTileCenter N m‖≤2*N^2 := by
  have hh := norm_sub_floorPoint_le ((N^2)⁻¹ • x)
  change floorPoint ((N^2)⁻¹ • x)=m at hx
  rw [hx] at hh
  have he : x-spatialTileCenter N m=N^2 • ((N^2)⁻¹ • x-latticePoint 1 m) := by
    simp [spatialTileCenter,smul_sub,smul_smul,hN]
  rw [he,norm_smul,Real.norm_eq_abs,abs_of_nonneg (sq_nonneg _)]
  nlinarith [mul_le_mul_of_nonneg_left hh (sq_nonneg N)]

/-- Countable assembly over the disjoint spatial tiles, including boundary
points through the floor convention. -/
theorem lintegral_spatial_tiles (N R : ℝ) (f : Space → ℝ≥0∞) :
    (∫⁻ y in timeSlab R, f y) =
      ∑' m : IntPlane, ∫⁻ y in localSlab (spatialTile N m) R, f y := by
  have hm (m : IntPlane) : MeasurableSet (localSlab (spatialTile N m) R) :=
    (measurableSet_spatialTile N m).prod measurableSet_Icc
  have hd : Pairwise (fun m n : IntPlane => Disjoint (localSlab (spatialTile N m) R) (localSlab (spatialTile N n) R)) := by
    intro m n hmn
    apply disjoint_left.mpr
    intro y hy hn
    exact disjoint_left.mp (spatialTile_disjoint N hmn) hy.1 hn.1
  have he : (⋃ m : IntPlane, localSlab (spatialTile N m) R)=timeSlab R := by
    ext y
    constructor
    · intro hy
      obtain ⟨m,hm⟩ := mem_iUnion.mp hy
      exact hm.2
    · intro hy
      exact mem_iUnion.mpr ⟨floorPoint ((N^2)⁻¹ • y.1),rfl,hy⟩
  rw [← he]
  exact lintegral_iUnion hm hd f

/-- Each packet center belongs to only a fixed number of enlarged tiles. -/
theorem spatial_tile_near_count {N A : ℝ} (hN : N≠0) (v : Plane) (T : Finset IntPlane) :
    (T.filter (fun m => ‖v-spatialTileCenter N m‖≤A*N^2)).card ≤
      (integerPlaneBox ⌈A+2⌉₊).card := by
  classical
  apply translated_lattice_card_bound ((N^2)⁻¹ • v) A
  intro m hm
  have hv := (Finset.mem_filter.mp hm).2
  have he : (N^2)⁻¹ • v-latticePoint 1 m=(N^2)⁻¹ • (v-spatialTileCenter N m) := by
    simp [spatialTileCenter,smul_sub,smul_smul,hN]
  rw [he,norm_smul,Real.norm_eq_abs,abs_of_nonneg (inv_nonneg.mpr (sq_nonneg N))]
  have hh := mul_le_mul_of_nonneg_left hv (inv_nonneg.mpr (sq_nonneg N))
  convert hh using 1 <;> field_simp

/-- The near densities obey a uniform finite overlap bound. -/
theorem spatial_tile_density_overlap {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N : ℝ} (hN : N≠0) (M A : ℝ) (T : Finset IntPlane) (y : Space) :
    (∑ m ∈ T, spatialDensity (s.filter (fun i => ‖v i-spatialTileCenter N m‖≤A*N^2))
      a V v N M y) ≤
      ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)*spatialDensity s a V v N M y := by
  classical
  exact sum_near_frequency_le s T (fun m i => ‖v i-spatialTileCenter N m‖≤A*N^2)
    (fun i => ‖a i‖^2*spatialWeight N M (V i) (v i) y) _
    (fun i hi => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
    (fun i hi => spatial_tile_near_count hN (v i) T)

theorem spatial_tile_density_cubic_overlap {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N : ℝ} (hN : N≠0) (M A : ℝ) (T : Finset IntPlane) (y : Space) :
    (∑ m ∈ T, (spatialDensity (s.filter (fun i => ‖v i-spatialTileCenter N m‖≤A*N^2))
      a V v N M y)^(3/2:ℝ)) ≤
      ((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ)*(spatialDensity s a V v N M y)^(3/2:ℝ) := by
  have hnonneg (q : Finset ι) : 0≤spatialDensity q a V v N M y :=
    Finset.sum_nonneg (fun i hi => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  exact bounded_overlap_density T _ (fun _ _ => hnonneg _) (hnonneg _) (Nat.cast_nonneg _)
    (spatial_tile_density_overlap s a V v hN M A T y)

theorem spatial_tile_density_cubic_tsum {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N : ℝ} (hN : N≠0) (M A : ℝ) (y : Space) :
    (∑' m : IntPlane, ENNReal.ofReal ((spatialDensity
      (s.filter (fun i => ‖v i-spatialTileCenter N m‖≤A*N^2)) a V v N M y)^(3/2:ℝ))) ≤
      ENNReal.ofReal (((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ)*
        (spatialDensity s a V v N M y)^(3/2:ℝ)) := by
  classical
  apply ENNReal.summable.tsum_le_of_sum_le
  intro T
  have hnn (m : IntPlane) : 0≤(spatialDensity
      (s.filter (fun i => ‖v i-spatialTileCenter N m‖≤A*N^2)) a V v N M y)^(3/2:ℝ) := by
    apply Real.rpow_nonneg
    exact Finset.sum_nonneg (fun i hi => mul_nonneg (sq_nonneg _) (spatialWeight_nonneg ..))
  rw [← ENNReal.ofReal_sum_of_nonneg (fun m (_ : m∈T) => hnn m)]
  exact ENNReal.ofReal_le_ofReal (spatial_tile_density_cubic_overlap s a V v hN M A T y)

theorem measurable_spatialDensity {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) (N M : ℝ) : Measurable (spatialDensity s a V v N M) := by
  unfold spatialDensity spatialWeight bracket
  fun_prop

/-- The near-density overlap bound survives countable summation and integration. -/
theorem spatial_tile_density_integrated_overlap {ι : Type*} (s : Finset ι) (a : ι → ℂ)
    (V v : ι → Plane) {N : ℝ} (hN : N≠0) (M A R : ℝ) :
    (∑' m : IntPlane, ∫⁻ y in timeSlab R, ENNReal.ofReal ((spatialDensity
      (s.filter (fun i => ‖v i-spatialTileCenter N m‖≤A*N^2)) a V v N M y)^(3/2:ℝ))) ≤
      ENNReal.ofReal (((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ))*
        ∫⁻ y in timeSlab R, ENNReal.ofReal ((spatialDensity s a V v N M y)^(3/2:ℝ)) := by
  classical
  have hm (q : Finset ι) : Measurable (fun y => ENNReal.ofReal ((spatialDensity q a V v N M y)^(3/2:ℝ))) := by
    have hd := measurable_spatialDensity q a V v N M
    fun_prop
  rw [← lintegral_tsum (fun m => (hm _).aemeasurable)]
  calc
    _ ≤ ∫⁻ y in timeSlab R, ENNReal.ofReal (((integerPlaneBox ⌈A+2⌉₊).card : ℝ)^(3/2:ℝ)*
        (spatialDensity s a V v N M y)^(3/2:ℝ)) :=
      lintegral_mono (spatial_tile_density_cubic_tsum s a V v hN M A)
    _ = _ := by
      simp_rw [ENNReal.ofReal_mul (Real.rpow_nonneg (Nat.cast_nonneg _) _)]
      exact lintegral_const_mul _ (hm s)

end EllipticSquareFunction
