import EllipticSquareFunction.ParametrizedGraphConstruction
import EllipticSquareFunction.TangentNormalCoordinates

noncomputable section
open Filter
open scoped Topology
namespace EllipticSquareFunction

/-- Constant scalar multiplication commutes with the Hessian. -/
theorem hessian_const_smul {h : Phase} {a : Plane} (hh : ContDiffAt ℝ 2 h a)
    (c : ℝ) (v w : Plane) :
    fderiv ℝ (fderiv ℝ (fun b => c*h b)) a v w =
      c*fderiv ℝ (fderiv ℝ h) a v w := by
  have he : fderiv ℝ (fun b => c*h b) =ᶠ[𝓝 a] (fun b => c • fderiv ℝ h b) := by
    filter_upwards [hh.eventually (by norm_num)] with b hb
    exact fderiv_const_smul (hb.differentiableAt (by norm_num)) c
  rw [he.fderiv_eq,fderiv_const_smul
    ((hh.fderiv_right (m := 1) (by norm_num)).differentiableAt (by norm_num)) c]
  rfl

/-- The normal component of a parametrized surface, with the normal frozen
at the base point. Its Hessian is the unnormalized second fundamental form. -/
def normalHeight (F : Plane → Space) (N : Space) : Phase := fun b => spacePair N (F b)

theorem normalHeight_contDiffOn {F : Plane → Space} {U : Set Plane}
    (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U) (N : Space) :
    ContDiffOn ℝ (⊤ : ℕ∞) (normalHeight F N) U :=
  (spacePairLinear N).toContinuousLinearMap.contDiff.comp_contDiffOn hF

/-- The inverse-function construction for a smooth immersion with positive
normal second derivative. The affine coordinates and graph are constructed. -/
theorem positive_graph_of_immersion {F : Plane → Space} {U : Set Plane} {a : Plane}
    (hU : IsOpen U) (ha : a ∈ U) (hF : ContDiffOn ℝ (⊤ : ℕ∞) F U)
    (hD : Function.Injective (fderiv ℝ F a)) (N : Space) (hN : N ≠ 0)
    (horth : ∀ v, spacePair N (fderiv ℝ F a v)=0)
    (hpos : ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ (normalHeight F N)) a v v) :
    ∃ (A : Space ≃ᵃ[ℝ] Space) (e : PartialHomeomorph Plane Plane) (φ : Phase),
      a ∈ e.source ∧ e.source ⊆ U ∧
      ContDiffOn ℝ (⊤ : ℕ∞) φ e.target ∧
      (∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ φ) (A (F a)).1 v v) ∧
      ∀ b ∈ e.source, (A (F b)).1 ∈ e.target ∧ (A (F b)).2=φ (A (F b)).1 := by
  let D := fderiv ℝ F a
  let E := tangentNormalEquiv D N hD hN horth
  let A : Space ≃ᵃ[ℝ] Space := E.symm.toLinearEquiv.toAffineEquiv
  let g : Plane → Plane := fun b => (E.symm (F b)).1
  let h : Phase := fun b => (E.symm (F b)).2
  have hEF : ContDiffOn ℝ (⊤ : ℕ∞) (fun b => E.symm (F b)) U :=
    E.symm.contDiff.comp_contDiffOn hF
  have hdF := (hF.contDiffAt (hU.mem_nhds ha)).differentiableAt (by norm_cast)
  have hdEF := E.symm.hasFDerivAt.comp a hdF.hasFDerivAt
  have hdg : HasFDerivAt g (ContinuousLinearMap.id ℝ Plane) a := by
    convert hdEF.fst using 1
    apply ContinuousLinearMap.ext
    intro v
    exact (congrArg Prod.fst (tangentNormalEquiv_symm_tangent D N hD hN horth v)).symm
  have hdh : HasFDerivAt h (0 : Plane →L[ℝ] ℝ) a := by
    convert hdEF.snd using 1
    apply ContinuousLinearMap.ext
    intro v
    exact (congrArg Prod.snd (tangentNormalEquiv_symm_tangent D N hD hN horth v)).symm
  have hh_eq : h = fun b => (spacePair N N)⁻¹ * normalHeight F N b := by
    funext b
    exact tangentNormalEquiv_symm_height D N hD hN horth (F b)
  have hhp : ∀ v : Plane, v ≠ 0 → 0 < fderiv ℝ (fderiv ℝ h) a v v := by
    intro v hv
    rw [hh_eq,hessian_const_smul
      (((normalHeight_contDiffOn hF N).contDiffAt (hU.mem_nhds ha)).of_le (by norm_cast))]
    exact mul_pos (inv_pos.mpr (spacePair_self_pos hN)) (hpos v hv)
  obtain ⟨e,φ,he,hae,heU,hφ,hφpos,hgraph⟩ := positive_graph_of_parametrization
    hU ha hEF.fst hEF.snd (ContinuousLinearEquiv.refl ℝ Plane) hdg hdh.fderiv hhp
  refine ⟨A,e,φ,hae,heU,hφ,hφpos,?_⟩
  intro b hb
  exact ⟨by simpa only [he] using e.map_source hb,hgraph b hb⟩

end EllipticSquareFunction
