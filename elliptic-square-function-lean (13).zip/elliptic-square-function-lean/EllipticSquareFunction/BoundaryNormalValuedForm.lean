import EllipticSquareFunction.BoundaryTangentSecondForm

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
  [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M]

/-- The normal-valued form, written using a unit normal. Multiplying both
the scalar form and the normal by minus one leaves this bilinear map unchanged. -/
def boundaryNormalValuedForm (f : M → EuclideanThree) (N : EuclideanThree) (z : M) :
    TangentSpace (𝓡∂ 2) z →ₗ[ℝ] TangentSpace (𝓡∂ 2) z →ₗ[ℝ] EuclideanThree where
  toFun v :=
    { toFun := fun w => boundarySecondFundamentalForm f N z v w • N
      map_add' := by intros; simp [map_add,add_smul]
      map_smul' := by intros; simp [map_smul,smul_smul] }
  map_add' := by
    intro u v
    apply LinearMap.ext
    intro w
    simp [map_add,add_smul]
  map_smul' := by
    intro c v
    apply LinearMap.ext
    intro w
    simp [map_smul,smul_smul]

/-- The vector-valued form is independent of the choice of unit normal,
so it requires no global orientation of the surface. -/
theorem boundary_normal_valued_form_normal_independent {f : M → EuclideanThree} (z : M)
    (hD : Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z))
    (N P : EuclideanThree) (hN : ‖N‖=1) (hP : ‖P‖=1)
    (hn : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0)
    (hp : ∀ v, @inner ℝ EuclideanThree _ P (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    boundaryNormalValuedForm f P z = boundaryNormalValuedForm f N z := by
  rcases euclidean_unit_normal_unique _ hD N P hN hP hn hp with he | he
  · rw [he]
  · rw [he]
    apply LinearMap.ext
    intro v
    apply LinearMap.ext
    intro w
    change modelSecondForm (𝓡∂ 2) f z (-N) v w • (-N) =
      modelSecondForm (𝓡∂ 2) f z N v w • N
    simp only [modelSecondForm,inner_neg_left,neg_smul,smul_neg,neg_neg]

/-- An orientation-free family on the tangent fibers, using any existing
unit normal to the immersed tangent plane. Choice independence is proved below. -/
def boundarySecondFormVector (f : M → EuclideanThree) (z : M)
    (hD : Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z)) :
    TangentSpace (𝓡∂ 2) z →ₗ[ℝ] TangentSpace (𝓡∂ 2) z →ₗ[ℝ] EuclideanThree :=
  boundaryNormalValuedForm f (Classical.choose (immersion_unit_normal_exists _ hD)) z

theorem boundary_second_form_vector_eq_normal {f : M → EuclideanThree} (z : M)
    (hD : Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z))
    (N : EuclideanThree) (hN : ‖N‖=1)
    (hn : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0) :
    boundarySecondFormVector f z hD = boundaryNormalValuedForm f N z := by
  obtain ⟨hP,hp⟩ := Classical.choose_spec (immersion_unit_normal_exists _ hD)
  exact boundary_normal_valued_form_normal_independent z hD N _ hN hP hn hp

theorem boundary_second_form_vector_in_chart {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) (⊤ : ℕ∞) f)
    (x z : M) (hz : z ∈ (extChartAt (𝓡∂ 2) x).source)
    (hD : Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z))
    (N : EuclideanThree) (hN : ‖N‖=1)
    (hn : ∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ,EuclideanThree) f z v)=0)
    (v w : TangentSpace (𝓡∂ 2) z) :
    boundarySecondFormVector f z hD v w =
      boundaryChartSecondForm f x z N (tangentCoordChange (𝓡∂ 2) z x z v)
        (tangentCoordChange (𝓡∂ 2) z x z w) • N := by
  rw [boundary_second_form_vector_eq_normal z hD N hN hn]
  change boundarySecondFundamentalForm f N z v w • N = _
  rw [boundary_second_fundamental_form_in_chart hf x z hz N hn]

end EllipticSquareFunction
