import EllipticSquareFunction.BoundaryManifoldAdapter
import Mathlib.Analysis.Analytic.Within

noncomputable section
open Filter
open scoped Manifold Topology ContDiff
namespace EllipticSquareFunction

/-- Analytic data on a model set have a genuinely constructed smooth
extension near the base point. This does not assert the analogous C∞ result. -/
theorem analytic_within_smooth_extension {f : Plane → EuclideanThree}
    {S : Set Plane} {a : Plane} (hf : AnalyticWithinAt ℝ f S a) :
    ∃ (F : Plane → EuclideanThree) (U : Set Plane),
      IsOpen U ∧ a ∈ U ∧ ContDiffOn ℝ (⊤ : ℕ∞) F U ∧ Set.EqOn F f (U ∩ S) := by
  obtain ⟨F,_,heq,hF⟩ := hf.exists_analyticAt
  obtain ⟨r,hr,hrF⟩ := hF.exists_ball_analyticOnNhd
  refine ⟨F,Metric.ball a r,Metric.isOpen_ball,Metric.mem_ball_self hr,
    hrF.contDiffOn_of_completeSpace,?_⟩
  intro b hb
  exact (heq (Set.mem_insert_of_mem a hb.2)).symm

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
  (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]

theorem analytic_model_has_smooth_extensions [IsManifold I ω M]
    {f : M → EuclideanThree} (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) ω f) :
    HasSmoothModelExtensions I f := by
  intro x
  have hparam : ContDiffOn ℝ ω (modelSurfaceParam I f x) (extChartAt I x).target :=
    (hf.comp_contMDiffOn (contMDiffOn_extChartAt_symm (I := I) x)).contDiffOn
  exact analytic_within_smooth_extension ((hparam _ (mem_extChartAt_target x)).analyticWithinAt)

/-- The boundary extension premise is discharged for analytic embedded
manifolds, including the Euclidean half-space model of a boundary surface. -/
theorem compact_analytic_model_surface_estimate [IsManifold I ω M] [CompactSpace M]
    {f : M → EuclideanThree} (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) ω f)
    (hemb : Topology.IsEmbedding f)
    (himm : ∀ x, Function.Injective (mfderiv I 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm I f x N)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ :=
  compact_model_surface_estimate I (hf.of_le le_top) hemb
    (analytic_model_has_smooth_extensions I hf) himm hcurv hc₀ hC₀
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
