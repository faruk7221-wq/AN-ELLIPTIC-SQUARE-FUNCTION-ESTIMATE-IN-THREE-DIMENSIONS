import EllipticSquareFunction.ReproducingKernelBounds

noncomputable section
open MeasureTheory
open scoped ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Equation (6.12) for actual cap-supported physical Schwartz functions.
The constant is chosen before the scale, frequency center, function, and
sample point. The reproducing kernel is constructed, not assumed. -/
theorem uniform_cap_sample_bound {φ : Phase} (hphase : ContinuedPhase φ)
    {C₀ : ℝ} (hC₀ : 0≤C₀) (L : ℕ) (hL : 2<(L:ℝ)) :
    ∃ C : ℝ, 0<C ∧ ∀ R : ℝ, 1≤R → ∀ (ν : Plane) (f : SchwartzMap Space ℂ),
      Function.support (fourierTransform f) ⊆ cap φ ν (Real.sqrt R)⁻¹ C₀ →
      ∀ p : Space, ENNReal.ofReal (‖f p‖^2) ≤
        ENNReal.ofReal (C*(R^2)⁻¹)*
          (∫⁻ z, ENNReal.ofReal (‖f z‖^2)*
            ENNReal.ofReal (packetWeight R L (velocity φ ν) p.1 p.2 z)) := by
  obtain ⟨χ,hχ,hχs,hχone,ρ,hρs,hρone⟩ := exists_sampling_cutoffs hC₀
  obtain ⟨C,hC,hbound⟩ := curved_reproducing_kernel_bounds hphase χ hχ hχs ρ hρs L hL
  let W := spatialWeightMass L*temporalWeightMass L
  have hW : 0≤W := mul_nonneg
    (integral_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _))
    (integral_nonneg (fun _ => Real.rpow_nonneg (bracket_pos _).le _))
  have hφ : Continuous φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hs,_⟩
    exact hs.continuous
  refine ⟨(C*W)*C+1,by positivity,?_⟩
  intro R hR ν f hs p
  have hR₀ : 0<R := by linarith
  let m := curvedMultiplier φ χ ρ (Real.sqrt R) R ν
  let K := fun z => inverseSpaceTransform m (p-z)
  have hm : Continuous m := continuous_curvedMultiplier φ hφ χ hχ.continuous ρ ρ.continuous _ _ _
  have hms : HasCompactSupport m := compactSupport_curvedMultiplier φ hφ χ hχs ρ hρs
    (Real.sqrt_pos.mpr hR₀).ne' hR₀.ne' ν
  have hone : ∀ ζ ∈ Function.support (fourierTransform f), m ζ=1 := by
    intro ζ hz
    have hh := curvedMultiplier_one_on_cap φ χ ρ (Real.sqrt_pos.mpr hR₀)
      hχone hρone ν (hs hz)
    simpa only [Real.sq_sqrt hR₀.le,m] using hh
  have hrepro := reproducing_integral_of_multiplier_one f m hm hms hone p
  obtain ⟨hK,hdecay,hmass⟩ := hbound R hR ν p
  have hw : AEMeasurable (fun z => ENNReal.ofReal
      (packetWeight R L (velocity φ ν) p.1 p.2 z)) volume := by
    apply Measurable.aemeasurable
    apply Measurable.ennreal_ofReal
    unfold packetWeight bracket
    fun_prop
  have hd : ∀ᵐ z ∂volume, ENNReal.ofReal ‖K z‖ ≤
      ENNReal.ofReal (C*(R^2)⁻¹)*ENNReal.ofReal
        (packetWeight R L (velocity φ ν) p.1 p.2 z) := by
    filter_upwards with z
    rw [← ENNReal.ofReal_mul (by positivity : 0≤C*(R^2)⁻¹)]
    exact ENNReal.ofReal_le_ofReal (hdecay z)
  have hh := local_sample_bound_from_kernel volume f K f.continuous.aestronglyMeasurable
    hK.aestronglyMeasurable _ hw (ENNReal.ofReal (C*W)) (ENNReal.ofReal (C*(R^2)⁻¹)) hd hmass
  rw [hrepro] at hh
  apply hh.trans
  apply mul_le_mul_right'
  rw [← ENNReal.ofReal_mul (mul_nonneg hC.le hW)]
  apply ENNReal.ofReal_le_ofReal
  have ht : 0≤(R^2)⁻¹ := by positivity
  nlinarith

end EllipticSquareFunction
