import EllipticSquareFunction.SamplingArrays
import EllipticSquareFunction.InfinitePacketLimit

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

theorem continuous_timePacket (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    (ψ : ℝ → ℂ) (hψ : Continuous ψ) {R : ℝ} (hR : 0<R)
    (ν v : Plane) (s : ℝ) : Continuous (timePacket φ b ψ R ν v s) := by
  exact (hψ.comp ((continuous_snd.sub continuous_const).div_const R)).mul
    ((continuous_freePacket φ hφ b hb hbs (Real.sqrt_pos.mpr hR).ne' ν v).comp
      (continuous_fst.prodMk (continuous_snd.sub continuous_const)))

/-- Fatou passes Proposition 3 from finite sampling arrays to the actual
infinite expansion. No convergence in norm is assumed. -/
theorem sampling_synthesis_l3_of_uniform {n : ℕ}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (D : ℕ) (hD : 0<D) (σ F M C P κ η : ℝ) (hC : 0≤C) (hP : 0≤P)
    (hbound : UniformTimeProfileBound (Fin n) φ b ψ (D:ℝ)⁻¹ σ F M C P κ η)
    (j : ℕ) (hj : 1≤j) (ν : Fin n → Plane)
    (hν : ∀ θ, ‖ν θ‖≤F)
    (hsep : ∀ θ θ', θ≠θ' → σ/((2:ℝ)^j)≤‖ν θ-ν θ'‖)
    (a : Fin n → IntPlane × ℤ → ℂ) (f : Fin n → Space → ℂ)
    (hs : ∀ θ y,
      let p := fun i : IntPlane × ℤ => samplePoint ((2:ℝ)^j) (((2:ℝ)^j)^2) D D
        (velocity φ (ν θ)) (latticePoint 1 i.1) i.2
      HasSum (fun i => a θ i*timePacket φ b ψ (((2:ℝ)^j)^2) (ν θ) (p i).1 (p i).2 y) (f θ y))
    (hds : ∀ θ y,
      let p := fun i : IntPlane × ℤ => samplePoint ((2:ℝ)^j) (((2:ℝ)^j)^2) D D
        (velocity φ (ν θ)) (latticePoint 1 i.1) i.2
      Summable (fun i => ‖a θ i‖^2*packetWeight (((2:ℝ)^j)^2) M (velocity φ (ν θ)) (p i).1 (p i).2 y)) :
    let p := fun θ (i : IntPlane × ℤ) => samplePoint ((2:ℝ)^j) (((2:ℝ)^j)^2) D D
      (velocity φ (ν θ)) (latticePoint 1 i.1) i.2
    let H := fun y => ∑ θ, ∑' i, ‖a θ i‖^2*
      packetWeight (((2:ℝ)^j)^2) M (velocity φ (ν θ)) (p θ i).1 (p θ i).2 y
    l3 (fun y => ∑ θ, f θ y) ≤ ENNReal.ofReal ((D:ℝ)*C*packetConstant P κ η (((2:ℝ)^j)^2))*
      (∫⁻ y, (ENNReal.ofReal (H y))^(3/2:ℝ))^(1/3:ℝ) := by
  classical
  letI : NeZero D := ⟨hD.ne'⟩
  intro p H
  let N : ℝ := (2:ℝ)^j
  have hN : 0<N := by positivity
  have hD₀ : (0:ℝ)<D := by exact_mod_cast hD
  let ff := fun i y => ∑ θ, a θ i*timePacket φ b ψ (N^2) (ν θ) (p θ i).1 (p θ i).2 y
  have hff (i : IntPlane × ℤ) : Continuous (ff i) :=
    continuous_finset_sum Finset.univ (fun θ _ => continuous_const.mul
      (continuous_timePacket φ hφ b hb hbs ψ hψ (sq_pos_of_pos hN) _ _ _))
  have hsum (y : Space) : HasSum (fun i => ff i y) (∑ θ, f θ y) :=
    hasSum_sum (fun θ _ => hs θ y)
  apply l3_hasSum_bound volume ff _ _ hff hsum
  intro Q
  have hd (k : ℤ) := samplingArray_separated φ hN hD₀ ν hν hsep a Q k
  have hh := oversampled_time_profile_of_uniform φ hφ b hb hbs ψ hψ D (D:ℝ)⁻¹ σ F M C P κ η
    hC hP hbound j hj (Q.image Prod.snd) (fun k => samplingArray φ (N^2) D ν a Q k)
    (fun k _ => hd k) 0
  simp only [zero_add] at hh
  change l3 (fun y => ∑ k ∈ Q.image Prod.snd,
    arrayTimePacket (samplingArray φ (N^2) D ν a Q k) φ b ψ N ((k:ℝ)*(N^2/D)) y) volume ≤ _ at hh
  simp_rw [samplingArray_synthesis φ b ψ hN.le] at hh
  apply hh.trans
  apply mul_le_mul_left'
  apply ENNReal.rpow_le_rpow _ (by norm_num)
  apply lintegral_mono
  intro y
  apply ENNReal.rpow_le_rpow _ (by norm_num)
  apply ENNReal.ofReal_le_ofReal
  rw [samplingArray_density φ hN.le,Finset.sum_comm]
  exact Finset.sum_le_sum (fun θ _ => (hds θ y).sum_le_tsum Q
    (fun i _ => mul_nonneg (sq_nonneg _) (packetWeight_nonneg ..)))

end EllipticSquareFunction
