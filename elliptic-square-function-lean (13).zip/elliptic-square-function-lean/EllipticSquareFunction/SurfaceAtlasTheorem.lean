import EllipticSquareFunction.SurfaceChartEstimate
import EllipticSquareFunction.CompactPacking

noncomputable section
open MeasureTheory
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1800000

theorem surface_atlas_large_scale (S : SurfaceSetup)
    (hatlas : LocalEllipticGraphAtlas S.carrier)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ T C : ℝ, 2 ≤ T ∧ 0 < C ∧ ∀ R : ℝ, T ≤ R →
      ∀ (n : ℕ) (p : Fin n → Space) (f : Fin n → SchwartzMap Space ℂ),
      SurfaceAdmissibleFamily S R p f →
      l3 (fun y => ∑ i, f i y) ≤ ENNReal.ofReal (C*R^ε)*
        l3Real (squareFunction Finset.univ (fun i => f i)) := by
  classical
  obtain ⟨s,W,A,G,r₀,hr₀,hcharts,hcover⟩ := finite_surface_graph_cover S hatlas
  have hlocal (j : s) := surface_chart_estimate S (G j) (hcharts j j.property).1
    (A j) (hcharts j j.property).2 hplacement hnikodym hdiscrete hε
  choose r C hr hC hbound using hlocal
  obtain ⟨T₀,hT₀,hscale₀⟩ := cap_scale_threshold S.C₀_pos.le hr₀
  have hscale (j : s) := cap_scale_threshold S.C₀_pos.le (hr j)
  choose T hT hscale using hscale
  let Ttotal := T₀+∑ j : s, T j
  let Ctotal := 1+∑ j : s, C j
  have hsumT : 0 ≤ ∑ j : s, T j := Finset.sum_nonneg (fun j _ => by linarith [hT j])
  have hsumC : 0 ≤ ∑ j : s, C j := Finset.sum_nonneg (fun j _ => (hC j).le)
  have hTtotal : 2 ≤ Ttotal := by dsimp only [Ttotal]; linarith
  have hCtotal : 0 < Ctotal := by dsimp only [Ctotal]; linarith
  refine ⟨Ttotal,Ctotal,hTtotal,hCtotal,?_⟩
  intro R hR n p f had
  have hR2 : 2 ≤ R := hTtotal.trans hR
  have hRpos : 0 < R := by linarith
  have hsmall₀ : S.C₀*(Real.sqrt R)⁻¹ < r₀ := hscale₀ R (by dsimp only [Ttotal] at hR; linarith)
  have hsmall (j : s) : S.C₀*(Real.sqrt R)⁻¹ < r j := by
    apply hscale j R
    have hs := Finset.single_le_sum (s := Finset.univ) (fun k _ => show 0 ≤ T k by linarith [hT k])
      (Finset.mem_univ j)
    dsimp only [Ttotal] at hR
    linarith
  have hassign (i : Fin n) : ∃ j : s, Metric.ball (p i) r₀ ⊆ W j := by
    obtain ⟨j,hj,hball⟩ := hcover (p i) (had.1 i)
    exact ⟨⟨j,hj⟩,hball⟩
  choose a ha using hassign
  let fiber (j : s) : Finset (Fin n) := Finset.univ.filter (fun i => a i=j)
  let pieces (j : s) : Space → ℂ := fun y => ∑ i ∈ fiber j, f i y
  have hpiece (j : s) : l3 (pieces j) ≤ ENNReal.ofReal (C j*R^ε)*
      l3Real (squareFunction Finset.univ (fun i => f i)) := by
    have hW (i : Fin n) (hi : i ∈ fiber j) : p i ∈ S.carrier ∩ W j := by
      have he : a i=j := (Finset.mem_filter.mp hi).2
      refine ⟨had.1 i,?_⟩
      simpa only [he] using ha i (Metric.mem_ball_self hr₀)
    have hSW (i : Fin n) (hi : i ∈ fiber j) (q : Space)
        (_ : q ∈ S.carrier) (hq : ‖q-p i‖ ≤ S.C₀*(Real.sqrt R)⁻¹) : q ∈ W j := by
      have he : a i=j := (Finset.mem_filter.mp hi).2
      have hb : q ∈ Metric.ball (p i) r₀ := hq.trans_lt hsmall₀
      simpa only [he] using ha i hb
    have hb := hbound j R hR2 (hsmall j) (fiber j) p f hW
      (fun i _ k _ hik => had.2.1 i k hik) (fun i _ => had.2.2 i) hSW
    exact hb.trans (mul_le_mul_left' (l3_squareFunction_mono_subfamily
      (Finset.subset_univ (fiber j)) (fun i => (f i : Space → ℂ))) _)
  have hm (j : s) (_ : j ∈ (Finset.univ : Finset s)) : AEStronglyMeasurable (pieces j) volume :=
    (continuous_finset_sum (fiber j) (fun i _ => (f i).continuous)).aestronglyMeasurable
  have he (y : Space) : (∑ i, f i y)=∑ j : s, pieces j y := by
    exact (Finset.sum_fiberwise Finset.univ a (fun i => f i y)).symm
  have hb := finite_chart_l3_assembly Finset.univ (fun y => ∑ i, f i y) pieces
    (squareFunction Finset.univ (fun i => (f i : Space → ℂ)))
    (fun j => ENNReal.ofReal (C j*R^ε)) hm he (fun j _ => hpiece j)
  apply hb.trans
  apply mul_le_mul_right'
  rw [← ENNReal.ofReal_sum_of_nonneg (fun j _ => mul_nonneg (hC j).le (Real.rpow_nonneg hRpos.le ε)),
    ← Finset.sum_mul]
  apply ENNReal.ofReal_le_ofReal
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hRpos.le ε)
  dsimp only [Ctotal]
  linarith

/-- The surface estimate for an explicit local elliptic graph atlas, including
boundary pieces that lie in a smooth elliptic graph extension. The external
inputs remain explicit hypotheses, as in the article. -/
theorem surface_atlas_reverse_square_function (S : SurfaceSetup)
    (hatlas : LocalEllipticGraphAtlas S.carrier)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    SurfaceReverseSquareFunction S := by
  intro ε hε
  obtain ⟨T,C,hT,hC,hlarge⟩ := surface_atlas_large_scale S hatlas hplacement hnikodym hdiscrete hε
  obtain ⟨B,hB,hbounded⟩ := bounded_scale_surface_estimate S hT
  refine ⟨C+B,by positivity,?_⟩
  intro R hR n p f had
  have hp : 0 ≤ R^ε := Real.rpow_nonneg (by linarith) _
  by_cases hRT : T ≤ R
  · apply (hlarge R hRT n p f had).trans
    apply mul_le_mul_right'
    exact ENNReal.ofReal_le_ofReal (mul_le_mul_of_nonneg_right (by linarith) hp)
  · apply (hbounded R hR (le_of_not_ge hRT) n p f had).trans
    apply mul_le_mul_right'
    apply ENNReal.ofReal_le_ofReal
    have hone : 1 ≤ R^ε := Real.one_le_rpow (by linarith) hε.le
    nlinarith

end EllipticSquareFunction
