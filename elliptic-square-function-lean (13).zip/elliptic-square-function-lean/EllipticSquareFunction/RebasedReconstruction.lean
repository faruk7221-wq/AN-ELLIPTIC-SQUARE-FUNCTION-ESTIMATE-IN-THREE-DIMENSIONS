import EllipticSquareFunction.RebasedDensityTransport
import EllipticSquareFunction.SeparatedFrame

noncomputable section
open MeasureTheory Set
open scoped BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem rebased_profile_window_integrable (φ : Phase) (hφ : Continuous φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    (χ : Plane → ℝ) (hχ : Continuous χ) {N : ℝ} (hN : 0<N)
    (Δ : ℝ) (μ w ν v : Plane) :
    Integrable (fun ξ => b (N • (ξ-ν))*(χ (N • (ξ-μ)) : ℂ)*
      oscillation (@inner ℝ Plane _ (w-v) ξ+(Δ*N^2)*φ ξ)) := by
  have hs : HasCompactSupport (fun ξ => b (N • (ξ-ν))) :=
    (hbs.comp_homeomorph (Homeomorph.smulOfNeZero N hN.ne')).comp_homeomorph (Homeomorph.subRight ν)
  apply Continuous.integrable_of_hasCompactSupport _ hs.mul_right.mul_right
  exact ((hb.comp (continuous_const.smul (continuous_id.sub continuous_const))).mul
    (Complex.continuous_ofReal.comp (hχ.comp (continuous_const.smul
      (continuous_id.sub continuous_const))))).mul (continuous_oscillation.comp
        ((continuous_const.inner continuous_id).add (continuous_const.mul hφ)))

/-- Analysis of the modulated datum gives exactly the rebased matrix,
with every finite integral/sum exchange justified. -/
theorem rebased_profile_coefficient_eq_matrix {ι : Type*}
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) (χ : Plane → ℝ) (hχ : Continuous χ)
    {N : ℝ} (hN : 0<N) (Δ : ℝ) (s : Finset ι) (a : ι → ℂ)
    (ν v : ι → Plane) (μ w : Plane) :
    (∫ ξ, (profileFrequency b N s a ν v ξ*oscillation ((Δ*N^2)*φ ξ))*
      (χ (N • (ξ-μ)) : ℂ)*oscillation (@inner ℝ Plane _ w ξ)) =
      ∑ i ∈ s, rebasedWindowMatrix φ b χ N Δ μ w (ν i) (v i)*a i := by
  have he (ξ : Plane) : (profileFrequency b N s a ν v ξ*oscillation ((Δ*N^2)*φ ξ))*
      (χ (N • (ξ-μ)) : ℂ)*oscillation (@inner ℝ Plane _ w ξ) =
      N^2 • ∑ i ∈ s, a i*(b (N • (ξ-ν i))*(χ (N • (ξ-μ)) : ℂ)*
        oscillation (@inner ℝ Plane _ (w-v i) ξ+(Δ*N^2)*φ ξ)) := by
    rw [profileFrequency,smul_mul_assoc,smul_mul_assoc,smul_mul_assoc]
    congr 1
    rw [Finset.sum_mul,Finset.sum_mul,Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro i hi
    have hp : @inner ℝ Plane _ (w-v i) ξ+(Δ*N^2)*φ ξ =
        -@inner ℝ Plane _ (v i) ξ+(Δ*N^2)*φ ξ+@inner ℝ Plane _ w ξ := by
      rw [inner_sub_left]
      ring
    rw [hp,oscillation_add,oscillation_add]
    ring
  simp_rw [he]
  rw [integral_smul,integral_finset_sum s (fun i _ =>
    (rebased_profile_window_integrable φ hφ b hb hbs χ hχ hN Δ μ w (ν i) (v i)).const_mul (a i)),
    Finset.smul_sum]
  apply Finset.sum_congr rfl
  intro i hi
  rw [integral_const_mul,rebasedWindowMatrix,smul_mul_assoc]
  congr 1
  ring

/-- Equation (5.5) as a convergent, exactly normalized synthesis identity.
One finite frequency set works for every spacetime point and every time shift.
The infinite spatial sum is a genuine HasSum, not a formal series. -/
theorem equation_5_5 {ι : Type*} (S : DiscreteSetup) (hφ : Continuous S.φ)
    (b : Plane → ℂ) (hb : Continuous b) (hbs : HasCompactSupport b)
    {N : ℝ} (hN : 0<N) (s : Finset ι) (pbox : ι → Finset IntPlane)
    (a : ι → IntPlane → ℂ) (ν : ι → Plane) (v : ι → IntPlane → Plane) :
    ∃ q : Finset IntPlane, ∀ (Δ : ℝ) (y : Space),
      HasSum (fun n : IntPlane => ∑ m ∈ q, (((S.D:ℝ)^2)⁻¹:ℝ) •
        (rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
          (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)*
          freePacket S.φ (fun ζ => (S.χ ζ:ℂ)) N (latticePoint N⁻¹ m)
            (latticePoint (N/S.D) n) y))
        (∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p)
          (y.1,y.2+Δ*N^2)) := by
  classical
  let g := profileFrequency b N (s.sigma pbox) (fun ip => a ip.1 ip.2)
    (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
  have hg : Continuous g := profileFrequency_continuous b hb N _ _ _ _
  have hgs : HasCompactSupport g := profileFrequency_compact b hbs hN _ _ _ _
  obtain ⟨q,hq,_⟩ := fine_finite_partition S hN hgs
  refine ⟨q,?_⟩
  intro Δ y
  let gΔ := fun ξ => g ξ*oscillation ((Δ*N^2)*S.φ ξ)
  have hgΔ : Continuous gΔ := hg.mul (continuous_oscillation.comp (continuous_const.mul hφ))
  have hgsΔ : HasCompactSupport gΔ := hgs.mul_right
  have hp : ∀ ξ ∈ Function.support gΔ, ∑ m ∈ q, fineWindow S N m ξ^2=1 := by
    intro ξ hξ
    apply hq ξ
    apply subset_closure
    exact (mul_ne_zero_iff.mp hξ).1
  have hh := fine_frame_reconstruction S hφ hN gΔ hgΔ hgsΔ q hp y
  have hc (m n : IntPlane) : (∫ ξ, gΔ ξ*(fineWindow S N m ξ:ℂ)*
      oscillation (@inner ℝ Plane _ (latticePoint (N/S.D) n) ξ)) =
      rebasedCoefficient S.φ b S.χ N Δ s pbox a ν v
        (latticePoint N⁻¹ m) (latticePoint (N/S.D) n) := by
    simpa only [gΔ,g,fineWindow,rebasedCoefficient,Finset.sum_sigma] using
      rebased_profile_coefficient_eq_matrix S.φ hφ b hb hbs S.χ S.χ_smooth.continuous
        hN Δ (s.sigma pbox) (fun ip => a ip.1 ip.2) (fun ip => ν ip.1)
        (fun ip => v ip.1 ip.2) (latticePoint N⁻¹ m) (latticePoint (N/S.D) n)
  have he : (∫ ξ, gΔ ξ*oscillation (@inner ℝ Plane _ y.1 ξ+y.2*S.φ ξ)) =
      ∑ i ∈ s, ∑ p ∈ pbox i, a i p*freePacket S.φ b N (ν i) (v i p) (y.1,y.2+Δ*N^2) := by
    have heq (ξ : Plane) : gΔ ξ*oscillation (@inner ℝ Plane _ y.1 ξ+y.2*S.φ ξ) =
        g ξ*oscillation (@inner ℝ Plane _ y.1 ξ+(y.2+Δ*N^2)*S.φ ξ) := by
      dsimp [gΔ]
      rw [mul_assoc,← oscillation_add]
      congr 2
      ring
    simp_rw [heq]
    simpa only [g,Finset.sum_sigma] using profileFrequency_extension S.φ hφ b hb hbs hN
      (s.sigma pbox) (fun ip => a ip.1 ip.2) (fun ip => ν ip.1) (fun ip => v ip.1 ip.2)
      (y.1,y.2+Δ*N^2)
  simpa only [hc,he] using hh

end EllipticSquareFunction
