import EllipticSquareFunction.AffineSampling
import EllipticSquareFunction.Taylor

noncomputable section
open MeasureTheory Set
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- A smooth compactly supported temporal function is a Schwartz function. -/
def compactTimeSchwartz (f : ℝ → ℂ) (hf : ContDiff ℝ (⊤ : ℕ∞) f)
    (hfs : HasCompactSupport f) : SchwartzMap ℝ ℂ where
  toFun := f
  smooth' := hf
  decay' k n := by
    have hc : Continuous (fun x : ℝ => ‖x‖^k*‖iteratedFDeriv ℝ n f x‖) :=
      (continuous_id.norm.pow k).mul
        ((hf.continuous_iteratedFDeriv (by exact_mod_cast (le_top : (n:ℕ∞)≤⊤))).norm)
    have hs : HasCompactSupport (fun x : ℝ => ‖x‖^k*‖iteratedFDeriv ℝ n f x‖) :=
      (hfs.iteratedFDeriv n).norm.mul_left
    obtain ⟨C,hC⟩ := hs.exists_bound_of_continuous hc
    refine ⟨C,fun x => ?_⟩
    exact (le_abs_self _).trans (hC x)

/-- Actual compact smooth cutoffs, with the temporal cutoff packaged as Schwartz. -/
theorem exists_sampling_cutoffs {C₀ : ℝ} (hC₀ : 0≤C₀) :
    ∃ χ : Plane → ℂ, ContDiff ℝ (⊤ : ℕ∞) χ ∧ HasCompactSupport χ ∧
      (∀ ξ : Plane, ‖ξ‖≤C₀ → χ ξ=1) ∧
      ∃ ρ : SchwartzMap ℝ ℂ, HasCompactSupport (ρ : ℝ → ℂ) ∧
        (∀ t : ℝ, |t|≤C₀ → ρ t=1) := by
  let β : ContDiffBump (0:Plane) := ⟨C₀+1,C₀+2,by linarith,by linarith⟩
  let α : ContDiffBump (0:ℝ) := ⟨C₀+1,C₀+2,by linarith,by linarith⟩
  let χ := fun ξ : Plane => (β ξ:ℂ)
  let f := fun t : ℝ => (α t:ℂ)
  have hχ : ContDiff ℝ (⊤ : ℕ∞) χ := Complex.ofRealCLM.contDiff.comp β.contDiff
  have hχs : HasCompactSupport χ := β.hasCompactSupport.comp_left Complex.ofReal_zero
  have hf : ContDiff ℝ (⊤ : ℕ∞) f := Complex.ofRealCLM.contDiff.comp α.contDiff
  have hfs : HasCompactSupport f := α.hasCompactSupport.comp_left Complex.ofReal_zero
  refine ⟨χ,hχ,hχs,?_,compactTimeSchwartz f hf hfs,hfs,?_⟩
  · intro ξ hξ
    have hh := β.one_of_mem_closedBall (x := ξ) (by
      rw [Metric.mem_closedBall,dist_zero_right]
      change ‖ξ‖≤C₀+1
      linarith)
    simp only [χ,hh,Complex.ofReal_one]
  · intro t ht
    have hh := α.one_of_mem_closedBall (x := t) (by
      rw [Metric.mem_closedBall,dist_zero_right,Real.norm_eq_abs]
      change |t|≤C₀+1
      linarith)
    change (α t:ℂ)=1
    rw [hh,Complex.ofReal_one]

/-- The exact curved multiplier is one on the thickened cap. -/
theorem curvedMultiplier_one_on_cap (φ : Phase) (χ : Plane → ℂ) (ρ : ℝ → ℂ)
    {C₀ r : ℝ} (hr : 0<r)
    (hχ : ∀ ξ : Plane, ‖ξ‖≤C₀ → χ ξ=1)
    (hρ : ∀ t : ℝ, |t|≤C₀ → ρ t=1)
    (ν : Plane) {ζ : Space} (hz : ζ ∈ cap φ ν r⁻¹ C₀) :
    curvedMultiplier φ χ ρ r (r^2) ν ζ=1 := by
  have hx : ‖r • (ζ.1-ν)‖≤C₀ := by
    rw [norm_smul,Real.norm_eq_abs,abs_of_pos hr]
    have hh := mul_le_mul_of_nonneg_left hz.1 hr.le
    have he : r*(C₀*r⁻¹)=C₀ := by field_simp
    simpa only [he] using hh
  have ht : |r^2*(ζ.2-φ ζ.1)|≤C₀ := by
    rw [abs_mul,abs_of_nonneg (sq_nonneg r)]
    have hh := mul_le_mul_of_nonneg_left hz.2 (sq_nonneg r)
    have he : r^2*(C₀*(r⁻¹)^2)=C₀ := by field_simp
    simpa only [he] using hh
  simp only [curvedMultiplier,hχ _ hx,hρ _ ht,mul_one]

/-- One enlarged cap contains the multiplier support at every scale and center. -/
theorem curvedMultiplier_support_cap (χ : Plane → ℂ) (hχs : HasCompactSupport χ)
    (ρ : ℝ → ℂ) (hρs : HasCompactSupport ρ) :
    ∃ C₀ : ℝ, 0<C₀ ∧ ∀ (φ : Phase) (r : ℝ), 0<r → ∀ ν : Plane,
      Function.support (curvedMultiplier φ χ ρ r (r^2) ν) ⊆ cap φ ν r⁻¹ C₀ := by
  obtain ⟨A,hA⟩ := hχs.exists_bound_of_continuousOn continuous_id.continuousOn
  obtain ⟨B,hB⟩ := hρs.exists_bound_of_continuousOn continuous_id.continuousOn
  let C₀ := max A 0+max B 0+1
  have hAC : A≤C₀ := by dsimp [C₀]; linarith [le_max_left A 0,le_max_right B 0]
  have hBC : B≤C₀ := by dsimp [C₀]; linarith [le_max_left B 0,le_max_right A 0]
  refine ⟨C₀,by dsimp [C₀]; positivity,?_⟩
  intro φ r hr ν ζ hz
  have hx := (hA (r • (ζ.1-ν)) (subset_closure ((mul_ne_zero_iff.mp hz).1))).trans hAC
  have ht := (hB (r^2*(ζ.2-φ ζ.1)) (subset_closure ((mul_ne_zero_iff.mp hz).2))).trans hBC
  simp only [id_eq,norm_smul,Real.norm_eq_abs,abs_of_pos hr] at hx
  simp only [id_eq,Real.norm_eq_abs,abs_mul,abs_of_nonneg (sq_nonneg r)] at ht
  constructor
  · have hh := mul_le_mul_of_nonneg_left hx (inv_pos.mpr hr).le
    have he : r⁻¹*(r*‖ζ.1-ν‖)=‖ζ.1-ν‖ := by field_simp
    simpa only [he,mul_comm C₀] using hh
  · have hh := mul_le_mul_of_nonneg_left ht (inv_nonneg.mpr (sq_nonneg r))
    have he : (r^2)⁻¹*(r^2*|ζ.2-φ ζ.1|)=|ζ.2-φ ζ.1| := by field_simp
    simpa only [he,inv_pow,mul_comm C₀] using hh

/-- The multiplier has a uniform tangent-coordinate support bound, derived
from the actual compact profiles and the continued phase's Taylor estimate. -/
theorem continuedPhase_curvedMultiplier_box {φ : Phase} (hphase : ContinuedPhase φ)
    (χ : Plane → ℂ) (hχs : HasCompactSupport χ)
    (ρ : ℝ → ℂ) (hρs : HasCompactSupport ρ) :
    ∃ A B : ℝ, 0<A ∧ 0≤B ∧ ∀ r : ℝ, 0<r → ∀ ν : Plane,
      ∀ ζ ∈ Function.support (curvedMultiplier φ χ ρ r (r^2) ν),
      ‖(affineFrequencyCoordinates φ ν r (r^2) ζ).1‖≤A ∧
      |(affineFrequencyCoordinates φ ν r (r^2) ζ).2|≤B := by
  obtain ⟨A,hA,hs⟩ := curvedMultiplier_support_cap χ hχs ρ hρs
  obtain ⟨C,hC,hbox⟩ := continuedPhase_cap_box hphase
  refine ⟨A,A+C*A^2,hA,by positivity,?_⟩
  intro r hr ν ζ hz
  exact hbox ν r A hr ζ (hs φ r hr ν hz)

end EllipticSquareFunction
