import EllipticSquareFunction.TangentSecondFundamentalForm
import EllipticSquareFunction.SecondFormReparametrization

noncomputable section
namespace EllipticSquareFunction

/-- An invertible change of parameters preserves immersion. -/
theorem immersion_reparametrization {F : Plane → EuclideanThree} {g : Plane → Plane}
    {a : Plane} (hF : DifferentiableAt ℝ F (g a)) (hg : DifferentiableAt ℝ g a)
    (hD : Function.Injective (fderiv ℝ F (g a)))
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a) :
    Function.Injective (fderiv ℝ (F ∘ g) a) := by
  rw [fderiv_comp a hF hg,hL.fderiv]
  exact hD.comp L.injective

/-- The tangent plane is an ambient subspace, independent of parameters. -/
theorem euclidean_tangent_plane_reparametrization
    {F : Plane → EuclideanThree} {g : Plane → Plane} {a : Plane}
    (hF : DifferentiableAt ℝ F (g a)) (hg : DifferentiableAt ℝ g a)
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a) :
    euclideanTangentPlane (F ∘ g) a = euclideanTangentPlane F (g a) := by
  ext u
  change (∃ v, fderiv ℝ (F ∘ g) a v = u) ↔ ∃ v, fderiv ℝ F (g a) v = u
  rw [fderiv_comp a hF hg,hL.fderiv]
  constructor
  · rintro ⟨v,rfl⟩
    exact ⟨L v,rfl⟩
  · rintro ⟨v,rfl⟩
    exact ⟨L.symm v,by simp⟩

/-- The coordinate transport between the actual tangent subspaces.
The next theorem shows that this transport fixes the ambient vectors. -/
def tangentReparamEquiv (F : Plane → EuclideanThree) (g : Plane → Plane) (a : Plane)
    (hD : Function.Injective (fderiv ℝ F (g a)))
    (hDc : Function.Injective (fderiv ℝ (F ∘ g) a)) (L : Plane ≃L[ℝ] Plane) :
    euclideanTangentPlane (F ∘ g) a ≃ₗ[ℝ] euclideanTangentPlane F (g a) :=
  (((tangentParameterEquiv (F ∘ g) a hDc).symm).trans L.toLinearEquiv).trans
    (tangentParameterEquiv F (g a) hD)

theorem tangent_reparam_equiv_coe {F : Plane → EuclideanThree} {g : Plane → Plane}
    {a : Plane} (hF : DifferentiableAt ℝ F (g a)) (hg : DifferentiableAt ℝ g a)
    (hD : Function.Injective (fderiv ℝ F (g a)))
    (hDc : Function.Injective (fderiv ℝ (F ∘ g) a))
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a)
    (u : euclideanTangentPlane (F ∘ g) a) :
    (tangentReparamEquiv F g a hD hDc L u : EuclideanThree) = (u : EuclideanThree) := by
  let v := (tangentParameterEquiv (F ∘ g) a hDc).symm u
  have he : fderiv ℝ (F ∘ g) a v = (u : EuclideanThree) :=
    congrArg Subtype.val ((tangentParameterEquiv (F ∘ g) a hDc).apply_symm_apply u)
  change fderiv ℝ F (g a) (L v) = (u : EuclideanThree)
  rw [fderiv_comp a hF hg,hL.fderiv] at he
  exact he

/-- The second fundamental form on actual tangent vectors is invariant under
smooth invertible reparametrization, not only its diagonal or its sign. -/
theorem tangent_second_form_reparametrization
    {F : Plane → EuclideanThree} {g : Plane → Plane} {a : Plane}
    (hF : ContDiffAt ℝ 2 F (g a)) (hg : ContDiffAt ℝ 2 g a)
    (hD : Function.Injective (fderiv ℝ F (g a)))
    (hDc : Function.Injective (fderiv ℝ (F ∘ g) a))
    (L : Plane ≃L[ℝ] Plane) (hL : HasFDerivAt g (L : Plane →L[ℝ] Plane) a)
    (N : EuclideanThree)
    (horth : ∀ v, @inner ℝ EuclideanThree _ N (fderiv ℝ F (g a) v)=0)
    (u v : euclideanTangentPlane (F ∘ g) a) :
    tangentSecondForm (F ∘ g) N a hDc u v =
      tangentSecondForm F N (g a) hD
        (tangentReparamEquiv F g a hD hDc L u)
        (tangentReparamEquiv F g a hD hDc L v) := by
  obtain ⟨u,rfl⟩ := (tangentParameterEquiv (F ∘ g) a hDc).surjective u
  obtain ⟨v,rfl⟩ := (tangentParameterEquiv (F ∘ g) a hDc).surjective v
  simp only [tangentReparamEquiv,LinearEquiv.trans_apply,
    LinearEquiv.symm_apply_apply,ContinuousLinearEquiv.coe_toLinearEquiv]
  rw [tangent_second_form_on_parameter_vectors,tangent_second_form_on_parameter_vectors,
    euclidean_second_form_reparametrization hF hg N horth,hL.fderiv]
  rfl

end EllipticSquareFunction
