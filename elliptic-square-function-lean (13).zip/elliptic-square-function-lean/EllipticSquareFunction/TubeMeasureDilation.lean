import EllipticSquareFunction.TubeDilation

noncomputable section
open MeasureTheory Set
open scoped ENNReal Pointwise
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

local instance : (volume : Measure Space).IsAddHaarMeasure :=
  Measure.prod.instIsAddHaarMeasure (volume : Measure Plane) (volume : Measure ℝ)

/-- The Lebesgue Jacobian of a positive dilation of physical spacetime. -/
theorem space_volume_map_smul {c : ℝ} (hc : 0<c) :
    Measure.map (fun y : Space => c • y) volume = (ENNReal.ofReal (c^3))⁻¹ • volume := by
  have hd : Module.finrank ℝ Space=3 := by
    simp [Space,Plane,Module.finrank_prod,finrank_euclideanSpace]
  rw [Measure.map_addHaar_smul volume hc.ne',hd,abs_of_pos (inv_pos.mpr (pow_pos hc 3)),
    ENNReal.ofReal_inv_of_pos (pow_pos hc 3)]

/-- Positive dilations multiply every set's volume by the cubic Jacobian. -/
theorem space_volume_smul {c : ℝ} (hc : 0<c) (A : Set Space) :
    volume (c • A)=ENNReal.ofReal (c^3)*volume A := by
  have hd : Module.finrank ℝ Space=3 := by
    simp [Space,Plane,Module.finrank_prod,finrank_euclideanSpace]
  simpa only [hd] using Measure.addHaar_smul_of_nonneg (volume : Measure Space) hc.le A

/-- A positive integral changes variables under dilation even when the
integrand is not measurable. -/
theorem lintegral_space_smul {c : ℝ} (hc : 0<c) (g : Space → ℝ≥0∞) :
    (∫⁻ y, g (c • y))=(ENNReal.ofReal (c^3))⁻¹*(∫⁻ y, g y) := by
  let e : Space ≃ᵐ Space := (Homeomorph.smul (Units.mk0 c hc.ne')).toMeasurableEquiv
  have he : (e : Space → Space)=(fun y => c • y) := rfl
  have hh := lintegral_map_equiv (μ := (volume : Measure Space)) g e
  rw [he,space_volume_map_smul hc,lintegral_smul_measure] at hh
  exact hh.symm

/-- Set-integral change of variables, without a measurability assumption on
its set or integrand. -/
theorem setLIntegral_space_smul {c : ℝ} (hc : 0<c) (A : Set Space) (g : Space → ℝ≥0∞) :
    (∫⁻ y in A, g (c • y))=(ENNReal.ofReal (c^3))⁻¹*(∫⁻ y in c • A, g y) := by
  let e : Space ≃ᵐ Space := (Homeomorph.smul (Units.mk0 c hc.ne')).toMeasurableEquiv
  have he : (e : Space → Space)=(fun y => c • y) := rfl
  have hpre : (fun y : Space => c • y) ⁻¹' (c • A)=A := by
    ext y
    simp only [mem_preimage,mem_smul_set]
    constructor
    · rintro ⟨z,hz,heq⟩
      have : z=y := (smul_right_injective Space hc.ne') heq
      simpa [this] using hz
    · intro hy
      exact ⟨y,hy,rfl⟩
  have hm : ((volume : Measure Space).map e).restrict (c • A)=
      ((volume : Measure Space).restrict A).map e := by
    rw [e.measurableEmbedding.restrict_map,he,hpre]
  have hh := e.measurableEmbedding.lintegral_map (μ := (volume : Measure Space).restrict A) g
  rw [← hm,he,space_volume_map_smul hc,Measure.restrict_smul,lintegral_smul_measure] at hh
  exact hh.symm

/-- Geometric tubes are exactly rescaled sets, not merely comparable ones. -/
theorem geometricTube_eq_smul {c : ℝ} (hc : 0<c) (a b : Space) (r : ℝ) :
    geometricTube (c • a) (c • b) (c*r)=c • geometricTube a b r := by
  ext y
  constructor
  · intro hy
    refine ⟨c⁻¹ • y,?_,smul_inv_smul₀ hc.ne' y⟩
    apply (geometricTube_smul hc a b (c⁻¹ • y) r).mp
    simpa only [smul_inv_smul₀ hc.ne'] using hy
  · rintro ⟨z,hz,rfl⟩
    exact (geometricTube_smul hc a b z r).mpr hz

/-- The normalized average cancels the cubic volume Jacobian exactly. -/
theorem tubeAverage_smul {c : ℝ} (hc : 0<c) (h : Space → ℝ) (A : Set Space) :
    tubeAverage h (c • A)=tubeAverage (fun y => h (c • y)) A := by
  unfold tubeAverage
  rw [space_volume_smul hc A,setLIntegral_space_smul hc A (fun y => ENNReal.ofReal |h y|)]
  rw [ENNReal.mul_inv (Or.inl (ENNReal.ofReal_pos.mpr (pow_pos hc 3)).ne')
    (Or.inl ENNReal.ofReal_ne_top)]
  ac_rfl

end EllipticSquareFunction
