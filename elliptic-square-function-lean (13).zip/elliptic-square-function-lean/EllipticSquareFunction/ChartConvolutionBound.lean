import EllipticSquareFunction.PositiveYoung

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

def familyVector {n : ℕ} (f : Fin n → Space → ℂ) (y : Space) : EuclideanSpace ℂ (Fin n) :=
  (WithLp.equiv 2 (Fin n → ℂ)).symm (fun i => f i y)

theorem norm_familyVector {n : ℕ} (f : Fin n → Space → ℂ) (y : Space) :
    ‖familyVector f y‖=squareFunction Finset.univ f y := by
  simp only [EuclideanSpace.norm_eq,familyVector,WithLp.equiv_symm_pi_apply,
    squareFunction]

theorem continuous_familyVector {n : ℕ} (f : Fin n → Space → ℂ)
    (hf : ∀ i, Continuous (f i)) : Continuous (familyVector f) :=
  (PiLp.continuous_equiv_symm 2 (fun _ : Fin n => ℂ)).comp (continuous_pi hf)

/-- Integrability of the actual vector convolution, proved from the Schwartz
bounds and the L1 chart kernel. -/
theorem integrable_chart_vector {n : ℕ} (f : Fin n → SchwartzMap Space ℂ)
    (K : Space → ℂ) (hK : Integrable K volume) (y : Space) :
    Integrable (fun z => K z • familyVector (fun i => (f i : Space → ℂ)) (y-z)) volume := by
  let C := Real.sqrt (∑ i : Fin n, (SchwartzMap.seminorm ℝ 0 0 (f i))^2)
  have hm : AEStronglyMeasurable (fun z => familyVector (fun i => (f i : Space → ℂ)) (y-z)) volume :=
    ((continuous_familyVector (fun i => (f i : Space → ℂ)) (fun i => (f i).continuous)).comp
    (continuous_const.sub continuous_id)).aestronglyMeasurable
  apply (hK.norm.mul_const C).mono' (hK.1.smul hm)
  filter_upwards with z
  rw [norm_smul,norm_familyVector]
  apply mul_le_mul_of_nonneg_left _ (norm_nonneg _)
  apply Real.sqrt_le_sqrt
  exact Finset.sum_le_sum (fun i hi => pow_le_pow_left₀ (norm_nonneg _)
    (SchwartzMap.norm_le_seminorm ℝ (f i) (y-z)) 2)

/-- Pointwise vector-valued Minkowski for the actual chart convolutions. -/
theorem chart_squareFunction_le_positive_convolution {n : ℕ}
    (f : Fin n → SchwartzMap Space ℂ) (K : Space → ℂ) (hK : Integrable K volume) (y : Space) :
    ENNReal.ofReal (squareFunction Finset.univ
      (fun i y => ∫ z, K z*f i (y-z)) y) ≤
      ∫⁻ z, ENNReal.ofReal ‖K z‖*
        ENNReal.ofReal (squareFunction Finset.univ (fun i => (f i : Space → ℂ)) (y-z)) := by
  let v := fun z => K z • familyVector (fun i => (f i : Space → ℂ)) (y-z)
  have hv : Integrable v volume := integrable_chart_vector f K hK y
  have he : familyVector (fun i y => ∫ z, K z*f i (y-z)) y=∫ z, v z := by
    ext i
    have hh := (EuclideanSpace.proj (𝕜 := ℂ) (ι := Fin n) i).integral_comp_comm hv
    simpa only [v,familyVector,WithLp.equiv_symm_pi_apply,EuclideanSpace.proj,
      PiLp.smul_apply,smul_eq_mul] using hh
  rw [← norm_familyVector,he,ofReal_norm_eq_enorm]
  have hh := enorm_integral_le_lintegral_enorm (μ := (volume : Measure Space)) v
  apply hh.trans_eq
  apply lintegral_congr
  intro z
  dsimp only [v]
  rw [← ofReal_norm_eq_enorm,norm_smul,norm_familyVector,ENNReal.ofReal_mul (norm_nonneg _)]

/-- The chart multiplier square function loses only the L1 norm of its
kernel, uniformly in the number of cap functions. -/
theorem chart_squareFunction_l3_bound {n : ℕ} (f : Fin n → SchwartzMap Space ℂ)
    (K : Space → ℂ) (hKm : Measurable K) (hK : Integrable K volume) :
    l3Real (squareFunction Finset.univ (fun i y => ∫ z, K z*f i (y-z))) ≤
      eLpNorm K 1 volume*l3Real (squareFunction Finset.univ (fun i => (f i : Space → ℂ))) := by
  let S := squareFunction Finset.univ (fun i => (f i : Space → ℂ))
  have hSm : Measurable S := by
    have hh := (continuous_familyVector (fun i => (f i : Space → ℂ)) (fun i => (f i).continuous)).norm.measurable
    simpa only [norm_familyVector,S] using hh
  have hSpos : ∀ y, 0≤S y := fun y => Real.sqrt_nonneg _
  unfold l3Real
  rw [← eLpNorm_ofReal_nonneg volume
    (squareFunction Finset.univ (fun i y => ∫ z, K z*f i (y-z)))
    (fun y => Real.sqrt_nonneg _) 3]
  have hmono : eLpNorm (fun y => ENNReal.ofReal (squareFunction Finset.univ
      (fun i y => ∫ z, K z*f i (y-z)) y)) 3 volume ≤
      eLpNorm (fun y => ∫⁻ z, ENNReal.ofReal ‖K z‖*ENNReal.ofReal (S (y-z))) 3 volume :=
    eLpNorm_mono_enorm (fun y => chart_squareFunction_le_positive_convolution f K hK y)
  apply hmono.trans
  have hh := positive_young_l3 (fun z => ENNReal.ofReal ‖K z‖) (fun y => ENNReal.ofReal (S y))
    hKm.norm.ennreal_ofReal hSm.ennreal_ofReal
  rw [eLpNorm_ofReal_nonneg volume S hSpos] at hh
  simpa only [eLpNorm_one_eq_lintegral_enorm,ofReal_norm_eq_enorm,S] using hh

end EllipticSquareFunction
