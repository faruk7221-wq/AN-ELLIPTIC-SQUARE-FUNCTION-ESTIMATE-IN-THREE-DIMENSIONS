import EllipticSquareFunction.CountablePositiveLp

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction

/-- Summable-weight assembly of positive L3 bounds. In particular, tube
lengths may vary with n because their norms are bounded before summation. -/
theorem positive_l3_weighted_tsum_bound {α : Type*} [MeasurableSpace α]
    (μ : Measure α) (f : ℕ → α → ℝ≥0∞) (hf : ∀ n, Measurable (f n))
    (w : ℕ → ℝ≥0∞) (hw : ∀ n, w n≠⊤) (B : ℝ≥0∞)
    (hbound : ∀ n, eLpNorm (f n) 3 μ≤B) :
    eLpNorm (fun x => ∑' n, w n*f n x) 3 μ ≤ (∑' n, w n)*B := by
  calc
    _ ≤ ∑' n, eLpNorm (fun x => w n*f n x) 3 μ :=
      positive_l3_tsum_le μ _ (fun n => measurable_const.mul (hf n))
    _ = ∑' n, w n*eLpNorm (f n) 3 μ :=
      tsum_congr (fun n => positive_l3_const_mul μ (f n) (w n) (hw n))
    _ ≤ ∑' n, w n*B := ENNReal.tsum_le_tsum (fun n => mul_le_mul_left' (hbound n) (w n))
    _ = _ := ENNReal.tsum_mul_right

end EllipticSquareFunction
