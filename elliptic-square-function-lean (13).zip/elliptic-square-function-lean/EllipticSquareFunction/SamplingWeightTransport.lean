import EllipticSquareFunction.SamplingConvolution

noncomputable section
open scoped BigOperators
namespace EllipticSquareFunction

def productBracketWeight (M : ℝ) (z : Space) : ℝ :=
  bracket z.1^(-M)*bracket z.2^(-M)

theorem shearScale_sub (r R : ℝ) (V : Plane) (y z : Space) :
    shearScale r R V (y-z)=shearScale r R V y-shearScale r R V z := by
  apply Prod.ext
  · simp only [shearScale,Prod.fst_sub,Prod.snd_sub,sub_smul,smul_sub,smul_add]
    abel
  · simp only [shearScale,Prod.snd_sub,sub_div]

theorem packetWeight_shearScale (R M : ℝ) (V v : Plane) (s : ℝ) (y : Space) :
    packetWeight R M V v s y =
      productBracketWeight M (shearScale (Real.sqrt R) R V (y-(v,s))) := rfl

theorem productBracketWeight_sub_symm (M : ℝ) (y z : Space) :
    productBracketWeight M (y-z)=productBracketWeight M (z-y) := by
  simp only [productBracketWeight,Prod.fst_sub,Prod.snd_sub,bracket,norm_sub_rev]

theorem samplePoint_lattice_normalized {R A B : ℝ} (hR : 0<R)
    (V : Plane) (i : IntPlane × ℤ) :
    shearScale (Real.sqrt R) R V
      (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2)=
        (latticePoint A⁻¹ i.1,B⁻¹*(i.2:ℝ)) := by
  rw [shearScale_samplePoint (Real.sqrt_pos.mpr hR).ne' hR.ne']
  rw [← latticePoint_mul,mul_one,div_eq_inv_mul]

/-- The actual sheared packet weights satisfy the sampling convolution bound,
uniformly in R, slope, and observation points. No sampling identity is assumed
or proved here: this is the geometric summation step after (6.12). -/
theorem sampling_packet_weight_convolution {R A B M L : ℝ}
    (hR : 0<R) (hA : 0<A) (hB : 0<B) (hM : 0≤M) (hLM : 2<L-M)
    (V : Plane) (y z : Space) (T : Finset (IntPlane × ℤ)) :
    let p := fun i : IntPlane × ℤ =>
      samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2
    (∑ i ∈ T, packetWeight R L V (p i).1 (p i).2 z *
      packetWeight R M V (p i).1 (p i).2 y) ≤
      (scaledLatticeSumConstant A⁻¹ (L-M)*scaledTimeSumConstant B⁻¹ (L-M))*
        packetWeight R M V 0 0 (y-z) := by
  dsimp only
  let u := shearScale (Real.sqrt R) R V z
  let v := shearScale (Real.sqrt R) R V y
  have hh := sampling_lattice_convolution_finite (inv_pos.mpr hA) (inv_pos.mpr hB)
    hM hLM u v T
  have he (i : IntPlane × ℤ) :
      packetWeight R L V
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).1
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).2 z *
      packetWeight R M V
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).1
        (samplePoint (Real.sqrt R) R A B V (latticePoint 1 i.1) i.2).2 y =
      (bracket (u.1-latticePoint A⁻¹ i.1)^(-L)*bracket (latticePoint A⁻¹ i.1-v.1)^(-M))*
      (bracket (u.2-B⁻¹*i.2)^(-L)*bracket (B⁻¹*i.2-v.2)^(-M)) := by
    simp only [packetWeight_shearScale,Prod.mk.eta,shearScale_sub,
      samplePoint_lattice_normalized hR,productBracketWeight,Prod.fst_sub,Prod.snd_sub]
    dsimp [u,v]
    simp only [bracket,norm_sub_rev]
    ring
  simp_rw [he]
  have he' : packetWeight R M V 0 0 (y-z)=
      bracket (u.1-v.1)^(-M)*bracket (u.2-v.2)^(-M) := by
    rw [packetWeight_shearScale]
    change productBracketWeight M (shearScale (Real.sqrt R) R V ((y-z)-0))=_
    rw [sub_zero,shearScale_sub,productBracketWeight_sub_symm]
    rfl
  rw [he']
  exact hh

end EllipticSquareFunction
