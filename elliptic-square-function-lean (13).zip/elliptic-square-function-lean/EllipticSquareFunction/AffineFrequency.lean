import EllipticSquareFunction.FrequencyJacobian
import EllipticSquareFunction.SpaceFourierBox
import EllipticSquareFunction.Coordinates

noncomputable section
open MeasureTheory Set
open scoped BigOperators ENNReal
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

def spacePair (y ζ : Space) : ℝ := @inner ℝ Plane _ y.1 ζ.1+y.2*ζ.2

def tangentPhase (ν V : Plane) (h : ℝ) (ξ : Plane) : ℝ :=
  h+@inner ℝ Plane _ V (ξ-ν)

theorem continuous_tangentPhase (ν V : Plane) (h : ℝ) :
    Continuous (tangentPhase ν V h) := by
  unfold tangentPhase
  fun_prop

theorem spacePair_sub_left (y z ζ : Space) :
    spacePair (y-z) ζ=spacePair y ζ-spacePair z ζ := by
  simp only [spacePair,Prod.fst_sub,Prod.snd_sub,inner_sub_left]
  ring

theorem spacePair_neg_left (y ζ : Space) : spacePair (-y) ζ= -spacePair y ζ := by
  simp [spacePair,inner_neg_left]
  ring

/-- Duality between affine frequency coordinates and the sheared physical lattice. -/
theorem tangent_frequency_pair (ν V : Plane) (h r R : ℝ) (q ζ : Space) :
    spacePair q (r • (ζ.1-ν),R*(ζ.2-tangentPhase ν V h ζ.1)) =
      spacePair (unshearScale r R V q) ζ-spacePair (unshearScale r R V q) (ν,h) := by
  simp only [spacePair,tangentPhase,unshearScale,inner_smul_right,inner_sub_right,
    inner_sub_left,inner_smul_left,starRingEnd_apply,star_trivial]
  ring

/-- The normalized Fourier integral is the actual sample, times its exact
Jacobian and a unit complex phase. -/
theorem inverse_affine_frequency_coordinates
    (ν V : Plane) (h : ℝ) {r R : ℝ} (hr : 0<r) (hR : 0<R)
    (f : Space → ℂ) (hf : Continuous f) (hfs : HasCompactSupport f) (q : Space) :
    let e := curvedFrequencyHomeomorph (tangentPhase ν V h)
      (continuous_tangentPhase ν V h) hr.ne' hR.ne' ν
    inverseSpaceTransform (fun z => f (e.symm z)) q =
      ((r^2*R:ℝ):ℂ)*oscillation (-spacePair (unshearScale r R V q) (ν,h))*
        inverseSpaceTransform f (unshearScale r R V q) := by
  intro e
  let H := fun ζ : Space => f ζ*oscillation (spacePair q (e ζ))
  have ho : Continuous (fun ζ : Space => oscillation (spacePair q (e ζ))) := by
    apply continuous_oscillation.comp
    unfold spacePair
    exact (continuous_const.inner (continuous_fst.comp e.continuous)).add
      (continuous_const.mul (continuous_snd.comp e.continuous))
  have hc : Continuous H := hf.mul ho
  have hs : HasCompactSupport H := hfs.mul_right
  have hj := integral_curved_frequency_inverse (tangentPhase ν V h)
    (continuous_tangentPhase ν V h) hr hR ν H hc hs
  change (∫ z, H (e.symm z))=((r^2*R:ℝ):ℂ)*(∫ ζ, H ζ) at hj
  have he (z : Space) : H (e.symm z)=f (e.symm z)*oscillation (spacePair q z) := by
    simp only [H,e.apply_symm_apply]
  simp_rw [he] at hj
  change inverseSpaceTransform (fun z => f (e.symm z)) q=_ at hj
  rw [hj]
  have hp (ζ : Space) : H ζ=
      oscillation (-spacePair (unshearScale r R V q) (ν,h))*
        (f ζ*oscillation (spacePair (unshearScale r R V q) ζ)) := by
    change f ζ*oscillation (spacePair q
      (r • (ζ.1-ν),R*(ζ.2-tangentPhase ν V h ζ.1)))=_
    rw [tangent_frequency_pair,sub_eq_add_neg,oscillation_add]
    ring
  simp_rw [hp]
  rw [integral_const_mul]
  exact (mul_assoc _ _ _).symm

/-- The sample lattice in (6.7), with a common fixed box side D. -/
theorem affine_dual_lattice_sample (r R D : ℝ) (V : Plane) (n : Fin 3 → ℤ) :
    unshearScale r R V (spaceFrequencyLattice D n)=
      samplePoint r R D D V (latticePoint 1 (fun i => n i.succ)) (n 0) := by
  unfold unshearScale spaceFrequencyLattice samplePoint
  apply Prod.ext
  · have hlat : r • latticePoint D⁻¹ (fun i => n i.succ)=
        (r/D) • latticePoint 1 (fun i => n i.succ) := by
      ext i
      simp only [latticePoint,WithLp.equiv_symm_pi_apply,PiLp.smul_apply,smul_eq_mul]
      ring
    rw [hlat]
    congr 2 <;> dsimp <;> ring
  · ring

end EllipticSquareFunction
