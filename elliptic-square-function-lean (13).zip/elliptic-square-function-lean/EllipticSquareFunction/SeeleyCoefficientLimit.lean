import EllipticSquareFunction.SeeleyUniformBounds
import Mathlib.Topology.Order.MonotoneConvergence

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

def seeleyOrientation (k : ℕ) : ℝ := if 0 ≤ seeleyFiniteCoeff k k then 1 else -1

theorem seeley_successor_factor_ge_one {N k : ℕ} (hk : k ≤ N) :
    1 ≤ (1+(2 : ℝ)^(N+1))/(2^(N+1)-2^k) := by
  have hd : 0 < (2 : ℝ)^(N+1)-2^k := sub_pos.mpr
    ((pow_right_strictMono₀ (by norm_num : (1 : ℝ)<2)) (by omega))
  rw [le_div_iff₀ hd]
  have hp : 0 < (2 : ℝ)^k := by positivity
  linarith

theorem seeley_finite_abs_monotone (k : ℕ) :
    Monotone (fun N => |seeleyFiniteCoeff N k|) := by
  apply monotone_nat_of_le_succ
  intro N
  by_cases hk : k ≤ N
  · rw [seeley_finite_coeff_succ hk, abs_mul,
      abs_of_nonneg ((zero_le_one : (0 : ℝ) ≤ 1).trans (seeley_successor_factor_ge_one hk))]
    exact le_mul_of_one_le_right (abs_nonneg _) (seeley_successor_factor_ge_one hk)
  · rw [seeley_finite_coeff_zero (Nat.lt_of_not_ge hk), abs_zero]
    exact abs_nonneg _

theorem seeley_finite_coeff_orientation (N k : ℕ) :
    seeleyFiniteCoeff N k = seeleyOrientation k * |seeleyFiniteCoeff N k| := by
  by_cases hk : k ≤ N
  · obtain ⟨n,rfl⟩ := Nat.exists_eq_add_of_le hk
    induction n with
    | zero =>
      simp only [add_zero, seeleyOrientation]
      split_ifs with h
      · simp [abs_of_nonneg h]
      · simp [abs_of_neg (lt_of_not_ge h)]
    | succ n ih =>
      rw [show k+(n+1)=k+n+1 by omega, seeley_finite_coeff_succ (by omega), abs_mul,
        abs_of_nonneg ((zero_le_one : (0 : ℝ) ≤ 1).trans (seeley_successor_factor_ge_one (by omega)))]
      conv_lhs => rw [ih (by omega)]
      ring
  · simp [seeley_finite_coeff_zero (Nat.lt_of_not_ge hk)]

def seeleyCoeff (k : ℕ) : ℝ :=
  seeleyOrientation k * (⨆ N : ℕ, |seeleyFiniteCoeff N k|)

theorem seeley_finite_coeff_tendsto (k : ℕ) :
    Tendsto (fun N => seeleyFiniteCoeff N k) atTop (𝓝 (seeleyCoeff k)) := by
  have hb : BddAbove (Set.range (fun N => |seeleyFiniteCoeff N k|)) :=
    ⟨Real.exp 4 * seeleyMajorant k, by rintro _ ⟨N,rfl⟩; exact seeley_finite_coeff_uniform_bound N k⟩
  have ht := (tendsto_atTop_ciSup (seeley_finite_abs_monotone k) hb).const_mul (seeleyOrientation k)
  simpa only [seeleyCoeff, ← seeley_finite_coeff_orientation] using ht

theorem seeley_coeff_bound (k : ℕ) :
    |seeleyCoeff k| ≤ Real.exp 4 * seeleyMajorant k := by
  exact le_of_tendsto (seeley_finite_coeff_tendsto k).abs
    (Filter.Eventually.of_forall (fun N => seeley_finite_coeff_uniform_bound N k))

end EllipticSquareFunction
