import EllipticSquareFunction.SeeleyCompactHalfLine
import Mathlib.Analysis.Calculus.BumpFunction.FiniteDimension

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

/-- Every smooth Banach-valued function on the closed half-line has a smooth
extension agreeing near its endpoint. This is a one-dimensional theorem. -/
theorem smooth_halfline_local_extension {f : ℝ → E}
    (hf : ContDiffOn ℝ (⊤ : ℕ∞) f (Set.Ici 0)) :
    ∃ F : ℝ → E, ContDiff ℝ (⊤ : ℕ∞) F ∧ Set.EqOn F f (Set.Icc 0 1) := by
  let χ : ContDiffBump (0 : ℝ) := ⟨1,2,by norm_num,by norm_num⟩
  let g : ℝ → E := fun t => χ t • f t
  have hg : ContDiffOn ℝ (⊤ : ℕ∞) g (Set.Ici 0) := χ.contDiff.contDiffOn.smul hf
  have hz : ∀ s : ℝ, 2 < s → g s = 0 := by
    intro s hs
    have hχ : χ s = 0 := χ.zero_of_le_dist (by
      rw [dist_zero_right, Real.norm_eq_abs, abs_of_pos (by linarith : 0 < s)]
      change 2 ≤ s
      linarith)
    simp only [g,hχ,zero_smul]
  obtain ⟨F,hF,hFg⟩ := smooth_halfline_extension_of_zero_tail hg hz
  refine ⟨F,hF,fun t ht => ?_⟩
  rw [hFg ht.1]
  have hχ : χ t = 1 := χ.one_of_mem_closedBall (by
    rw [Metric.mem_closedBall,dist_zero_right,Real.norm_eq_abs,abs_of_nonneg ht.1]
    exact ht.2)
  simp only [g,hχ,one_smul]

end EllipticSquareFunction
