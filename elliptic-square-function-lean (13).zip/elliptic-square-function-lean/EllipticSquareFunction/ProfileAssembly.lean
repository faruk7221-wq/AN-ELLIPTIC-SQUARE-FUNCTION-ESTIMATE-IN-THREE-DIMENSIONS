import EllipticSquareFunction.GlobalPackets

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

theorem packetConstant_mono_parameter {P Q N : ℝ} (hP : 0≤P) (hPQ : P≤Q) (κ η : ℝ) :
    packetConstant P κ η (N^2)≤packetConstant Q κ η (N^2) := by
  have hl : 0≤Real.log (2+N^2) := Real.log_nonneg (by nlinarith [sq_nonneg N])
  unfold packetConstant
  apply mul_le_mul_of_nonneg_right _ (Real.rpow_nonneg hl _)
  exact mul_le_mul_of_nonneg_right (Real.rpow_le_rpow hP hPQ (by norm_num))
    (Real.rpow_nonneg (sq_nonneg N) _)

/-- The finite profile collection costs only the sum of its fixed constants.
There is no separation requirement between different profile types. -/
theorem finite_profile_norm_bound {τ : Type*} (T : Finset τ)
    (F : τ → Space → ℂ) (D : τ → Space → ℝ) (C : τ → ℝ) (K R : ℝ)
    (hF : ∀ r ∈ T, Continuous (F r)) (hD : ∀ r ∈ T, ∀ y, 0≤D r y)
    (hC : ∀ r ∈ T, 0≤C r) (hK : 0≤K)
    (hbound : ∀ r ∈ T, l3 (F r) (volume.restrict (timeSlab R)) ≤
      ENNReal.ofReal (C r*K)*densityCubeRoot (D r) R) :
    l3 (fun y => ∑ r ∈ T, F r y) (volume.restrict (timeSlab R)) ≤
      ENNReal.ofReal ((∑ r ∈ T, C r)*K)*densityCubeRoot (fun y => ∑ r ∈ T, D r y) R := by
  have hsum : l3 (fun y => ∑ r ∈ T, F r y) (volume.restrict (timeSlab R)) ≤
      ∑ r ∈ T, l3 (F r) (volume.restrict (timeSlab R)) := by
    have hh := eLpNorm_sum_le (fun r hr => (hF r hr).aestronglyMeasurable
      (μ := volume.restrict (timeSlab R))) (by norm_num : (1:ℝ≥0∞)≤3)
    have he : (∑ r ∈ T, F r) = (fun y => ∑ r ∈ T, F r y) := by
      ext y
      simp only [Finset.sum_apply]
    rw [he] at hh
    exact hh
  calc
    _ ≤ ∑ r ∈ T, ENNReal.ofReal (C r*K)*densityCubeRoot (fun y => ∑ q ∈ T, D q y) R := by
      apply hsum.trans
      apply Finset.sum_le_sum
      intro r hr
      apply (hbound r hr).trans
      apply mul_le_mul_left'
      apply densityCubeRoot_mono
      intro y
      exact Finset.single_le_sum (fun q hq => hD q hq y) hr
    _ = _ := by
      rw [← Finset.sum_mul, ← ENNReal.ofReal_sum_of_nonneg
        (fun r hr => mul_nonneg (hC r hr) hK), Finset.sum_mul]

/-- Finite packet data, with independent position sets at each frequency. -/
structure FinitePacketArray (ι : Type*) where
  labels : Finset ι
  positions : ι → Finset IntPlane
  coefficient : ι → IntPlane → ℂ
  frequency : ι → Plane
  position : ι → IntPlane → Plane

def arrayPacketSum {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    (b : Plane → ℂ) (N : ℝ) (y : Space) : ℂ :=
  ∑ i ∈ d.labels, ∑ p ∈ d.positions i,
    d.coefficient i p*freePacket φ b N (d.frequency i) (d.position i p) y

def arraySpatialDensity {ι : Type*} (d : FinitePacketArray ι) (φ : Phase)
    (N M : ℝ) : Space → ℝ :=
  spatialDensity (d.labels.sigma d.positions) (fun ip => d.coefficient ip.1 ip.2)
    (fun ip => velocity φ (d.frequency ip.1)) (fun ip => d.position ip.1 ip.2) N M

def SeparatedPacketArray {ι : Type*} (d : FinitePacketArray ι) (N c σ F : ℝ) : Prop :=
  (∀ i ∈ d.labels, ‖d.frequency i‖≤F) ∧
  (∀ i ∈ d.labels, ∀ k ∈ d.labels, i≠k → σ/N≤‖d.frequency i-d.frequency k‖) ∧
  (∀ i ∈ d.labels, ∀ p ∈ d.positions i, ∀ q ∈ d.positions i, p≠q →
    c*N≤‖d.position i p-d.position i q‖)

def UniformSingleProfileBound (ι : Type*) (φ : Phase) (b : Plane → ℂ)
    (c σ F M C P κ η : ℝ) : Prop :=
  ∀ j : ℕ, 1≤j → ∀ d : FinitePacketArray ι,
    SeparatedPacketArray d ((2:ℝ)^j) c σ F →
    l3 (arrayPacketSum d φ b ((2:ℝ)^j)) (volume.restrict (timeSlab (((2:ℝ)^j)^2))) ≤
      ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
        densityCubeRoot (arraySpatialDensity d φ ((2:ℝ)^j) M) (((2:ℝ)^j)^2)

theorem continuous_arrayPacketSum {ι : Type*} (d : FinitePacketArray ι)
    (φ : Phase) (hφ : Continuous φ) (b : Plane → ℂ) (hb : Continuous b)
    (hbs : HasCompactSupport b) {N : ℝ} (hN : N≠0) :
    Continuous (arrayPacketSum d φ b N) :=
  continuous_finset_sum d.labels (fun i hi => continuous_finset_sum (d.positions i)
    (fun p hp => continuous_const.mul (continuous_freePacket φ hφ b hb hbs hN _ _)))

/-- Finite profile witnesses can be made simultaneous, preserving the order
`fixed constant`, then loss parameters, then external constant, then scale. -/
theorem uniform_finite_profiles_of_single {ι : Type*} {n : ℕ}
    (φ : Phase) (hφ : Continuous φ) (b : Fin n → Plane → ℂ)
    (hb : ∀ r, Continuous (b r)) (hbs : ∀ r, HasCompactSupport (b r))
    (c σ F M : ℝ)
    (hsingle : ∀ r, ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ,
      0<κ → κ<1/10 → 0<η → η≤1 → ∃ P : ℝ, 1≤P ∧
      UniformSingleProfileBound ι φ (b r) c σ F M C P κ η) :
    ∃ C : ℝ, 0<C ∧ ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
      ∃ P : ℝ, 1≤P ∧ ∀ j : ℕ, 1≤j → ∀ d : Fin n → FinitePacketArray ι,
      (∀ r, SeparatedPacketArray (d r) ((2:ℝ)^j) c σ F) →
      l3 (fun y => ∑ r, arrayPacketSum (d r) φ (b r) ((2:ℝ)^j) y)
        (volume.restrict (timeSlab (((2:ℝ)^j)^2))) ≤
      ENNReal.ofReal (C*packetConstant P κ η (((2:ℝ)^j)^2))*
        densityCubeRoot (fun y => ∑ r, arraySpatialDensity (d r) φ ((2:ℝ)^j) M y)
          (((2:ℝ)^j)^2) := by
  classical
  choose C hC hsingle using hsingle
  have hCsum : 0≤∑ r, C r := Finset.sum_nonneg (fun r _ => (hC r).le)
  refine ⟨(∑ r, C r)+1,by positivity,?_⟩
  intro κ η hκ hκ' hη hη'
  choose P hP hbound using fun r => hsingle r κ η hκ hκ' hη hη'
  let Pmax := 1+∑ r, P r
  have hPmax : 1≤Pmax := by
    have hh : 0≤∑ r, P r := Finset.sum_nonneg (fun r _ => by linarith [hP r])
    dsimp [Pmax]; linarith
  have hPP (r : Fin n) : P r≤Pmax := by
    have hh := Finset.single_le_sum (fun r (_ : r∈(Finset.univ : Finset (Fin n))) =>
      (show 0≤P r by linarith [hP r])) (Finset.mem_univ r)
    dsimp [Pmax]; linarith
  refine ⟨Pmax,hPmax,?_⟩
  intro j hj d hd
  let N : ℝ := (2:ℝ)^j
  have hN : N≠0 := by positivity
  have hK : 0≤packetConstant Pmax κ η (N^2) := packetConstant_nonneg_global (by linarith) κ η
  have hbnd (r : Fin n) : l3 (arrayPacketSum (d r) φ (b r) N)
      (volume.restrict (timeSlab (N^2))) ≤
      ENNReal.ofReal (C r*packetConstant Pmax κ η (N^2))*
        densityCubeRoot (arraySpatialDensity (d r) φ N M) (N^2) := by
    apply (hbound r j hj (d r) (hd r)).trans
    apply mul_le_mul_right'
    apply ENNReal.ofReal_le_ofReal
    exact mul_le_mul_of_nonneg_left
      (packetConstant_mono_parameter (by linarith [hP r]) (hPP r) κ η) (hC r).le
  have hh := finite_profile_norm_bound Finset.univ
    (fun r => arrayPacketSum (d r) φ (b r) N) (fun r => arraySpatialDensity (d r) φ N M)
    C (packetConstant Pmax κ η (N^2)) (N^2)
    (fun r _ => continuous_arrayPacketSum (d r) φ hφ (b r) (hb r) (hbs r) hN)
    (fun r _ y => spatialDensity_nonneg_global ..) (fun r _ => (hC r).le) hK
    (fun r _ => hbnd r)
  apply hh.trans
  apply mul_le_mul_right'
  apply ENNReal.ofReal_le_ofReal
  exact mul_le_mul_of_nonneg_right (by linarith) hK

end EllipticSquareFunction
