import EllipticSquareFunction.UniformTubeComparison

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- Unit-mass averaging kernel of a symmetric sheared tube. -/
def symmetricTubeAverageKernel (r T : ℝ) (V : Plane) (y : Space) : ℝ :=
  (volume.real (symmetricTube r T V))⁻¹*(symmetricTube r T V).indicator (fun _ => 1) y

theorem real_volume_symmetricTube {r T : ℝ} (hr : 0≤r) (hT : 0≤T) (V : Plane) :
    volume.real (symmetricTube r T V)=2*Real.pi*r^2*T := by
  rw [measureReal_def,volume_symmetricTube]
  simp only [ENNReal.toReal_mul,ENNReal.toReal_pow,ENNReal.toReal_ofReal hr,
    ENNReal.toReal_ofReal Real.pi_pos.le,ENNReal.toReal_ofReal (by positivity : 0≤2*T)]
  ring

theorem symmetricTubeAverageKernel_integrable {r T : ℝ} (hr : 0<r) (hT : 0<T) (V : Plane) :
    Integrable (symmetricTubeAverageKernel r T V) volume := by
  apply Integrable.const_mul
  apply (integrableOn_const (C := (1:ℝ))).2 (Or.inr ?_) |>.integrable_indicator (measurableSet_symmetricTube r T V)
  rw [volume_symmetricTube]
  exact ENNReal.mul_lt_top (ENNReal.mul_lt_top (ENNReal.pow_lt_top ENNReal.ofReal_lt_top)
    ENNReal.ofReal_lt_top) ENNReal.ofReal_lt_top

theorem integral_symmetricTubeAverageKernel {r T : ℝ} (hr : 0<r) (hT : 0<T) (V : Plane) :
    (∫ y, symmetricTubeAverageKernel r T V y)=1 := by
  unfold symmetricTubeAverageKernel
  rw [integral_const_mul,integral_indicator (measurableSet_symmetricTube r T V),setIntegral_const]
  simp only [smul_eq_mul,mul_one]
  exact inv_mul_cancel₀ (by rw [real_volume_symmetricTube hr.le hT.le]; positivity)

/-- Exact conversion from a dyadic polynomial cutoff to a normalized tube
average. The coefficient is 2^{-m(M-3)}, as in (7.3). -/
theorem dyadic_tube_normalization {R : ℝ} (hR : 0<R) (M : ℝ) (V : Plane) (m : ℕ) (y : Space) :
    (R^2)⁻¹*(if ‖shearScale (Real.sqrt R) R V y‖≤(2:ℝ)^m
      then ((2:ℝ)^m)^(-M) else 0) =
    (2*Real.pi)*((2:ℝ)^m)^(-(M-3))*
      symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V y := by
  classical
  let d := (2:ℝ)^m
  have hd : 0<d := by positivity
  have he : y∈symmetricTube (d*Real.sqrt R) (d*R) V ↔
      ‖shearScale (Real.sqrt R) R V y‖≤d := by
    rw [← normalized_ball_eq_symmetricTube (Real.sqrt_pos.mpr hR) hR V]
    rfl
  have hv : volume.real (symmetricTube (d*Real.sqrt R) (d*R) V)=2*Real.pi*d^3*R^2 := by
    rw [real_volume_symmetricTube (by positivity) (by positivity),mul_pow,Real.sq_sqrt hR.le]
    ring
  have hp : d^(-(M-3))=d^(-M)*d^3 := by
    rw [show -(M-3)=-M+(3:ℝ) by ring,Real.rpow_add hd]
    congr 1
    exact Real.rpow_natCast d 3
  change (R^2)⁻¹*(if ‖shearScale (Real.sqrt R) R V y‖≤d then d^(-M) else 0)=_
  unfold symmetricTubeAverageKernel
  change _=(2*Real.pi)*d^(-(M-3))*((volume.real (symmetricTube (d*Real.sqrt R) (d*R) V))⁻¹*
    (symmetricTube (d*Real.sqrt R) (d*R) V).indicator (fun _ => 1) y)
  rw [hv,hp]
  by_cases hy : ‖shearScale (Real.sqrt R) R V y‖≤d
  · rw [if_pos hy,Set.indicator_of_mem (he.mpr hy)]
    field_simp
    ring
  · rw [if_neg hy,Set.indicator_of_not_mem (fun hh => hy (he.mp hh))]
    ring

/-- The full pointwise dyadic decomposition in terms of normalized sheared
tube averages. Their Euclidean enclosing tubes have uniform volume control. -/
theorem tubeKernel_normalized_dyadic_majorant {R M : ℝ} (hR : 0<R) (hM : 0<M)
    (V : Plane) (y : Space) :
    tubeKernel R M V y ≤ (2*Real.pi)*(2:ℝ)^M*
      ∑' m : ℕ, ((2:ℝ)^m)^(-(M-3))*
        symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V y := by
  have hh := tubeKernel_dyadic_majorant (R := R) hM V y
  have he : (R^2)⁻¹*(2:ℝ)^M*(∑' m : ℕ,
      if ‖shearScale (Real.sqrt R) R V y‖≤(2:ℝ)^m then ((2:ℝ)^m)^(-M) else 0)=
      (2*Real.pi)*(2:ℝ)^M*(∑' m : ℕ, ((2:ℝ)^m)^(-(M-3))*
        symmetricTubeAverageKernel ((2:ℝ)^m*Real.sqrt R) ((2:ℝ)^m*R) V y) := by
    rw [mul_assoc, mul_left_comm (R^2)⁻¹ ((2:ℝ)^M),← tsum_mul_left]
    simp_rw [dyadic_tube_normalization hR M V]
    simp_rw [mul_assoc (2*Real.pi)]
    rw [tsum_mul_left]
    ring
  exact he ▸ hh

/-- The normalized averaging coefficients are summable in the
range used in Lemma 5. -/
theorem dyadic_tube_coefficients_summable {M : ℝ} (hM : 3<M) :
    Summable (fun m : ℕ => ((2:ℝ)^m)^(-(M-3))) := by
  simpa only [Real.rpow_pow_comm (by norm_num : (0:ℝ)≤2)] using
    summable_geometric_of_lt_one (Real.rpow_nonneg (by norm_num : (0:ℝ)≤2) (-(M-3)))
      (Real.rpow_lt_one_of_one_lt_of_neg (by norm_num : (1:ℝ)<2) (by linarith : -(M-3)<0))

end EllipticSquareFunction
