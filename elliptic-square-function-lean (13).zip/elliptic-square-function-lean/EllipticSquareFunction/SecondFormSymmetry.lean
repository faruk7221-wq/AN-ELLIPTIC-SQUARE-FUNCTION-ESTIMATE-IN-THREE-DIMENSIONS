import EllipticSquareFunction.SecondFormReparametrization
import Mathlib.Analysis.Calculus.FDeriv.Symmetric

noncomputable section
namespace EllipticSquareFunction

/-- The second fundamental form is symmetric for a C2 parametrization. -/
theorem euclidean_second_form_symmetric {F : Plane → EuclideanThree} {a : Plane}
    (hF : ContDiffAt ℝ 2 F a) (N : EuclideanThree) (v w : Plane) :
    euclideanSecondFundamentalForm F N a v w = euclideanSecondFundamentalForm F N a w v := by
  unfold euclideanSecondFundamentalForm
  rw [(hF.isSymmSndFDerivAt (by norm_num)).eq v w]

/-- The standard form is linear in its first tangent parameter. -/
theorem euclidean_second_form_add_left (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a u v w : Plane) :
    euclideanSecondFundamentalForm F N a (u+v) w =
      euclideanSecondFundamentalForm F N a u w+euclideanSecondFundamentalForm F N a v w := by
  simp [euclideanSecondFundamentalForm,map_add,inner_add_right]

theorem euclidean_second_form_smul_left (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a v w : Plane) (c : ℝ) :
    euclideanSecondFundamentalForm F N a (c • v) w =
      c*euclideanSecondFundamentalForm F N a v w := by
  simp [euclideanSecondFundamentalForm,map_smul,inner_smul_right]

end EllipticSquareFunction
