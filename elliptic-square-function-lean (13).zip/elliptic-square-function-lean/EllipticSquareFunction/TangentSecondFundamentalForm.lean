import EllipticSquareFunction.SecondFormSymmetry
import EllipticSquareFunction.EuclideanEmbeddedSurface

noncomputable section
namespace EllipticSquareFunction

/-- The second fundamental form as an actual bilinear map on parameter
vectors, rather than only its scalar evaluation function. -/
def parameterSecondForm (F : Plane → EuclideanThree) (N : EuclideanThree) (a : Plane) :
    Plane →ₗ[ℝ] Plane →ₗ[ℝ] ℝ where
  toFun v :=
    { toFun := fun w => euclideanSecondFundamentalForm F N a v w
      map_add' := by intros; simp [euclideanSecondFundamentalForm,map_add,inner_add_right]
      map_smul' := by intros; simp [euclideanSecondFundamentalForm,map_smul,inner_smul_right] }
  map_add' := by
    intro v w
    apply LinearMap.ext
    intro u
    exact euclidean_second_form_add_left F N a v w u
  map_smul' := by
    intro c v
    apply LinearMap.ext
    intro w
    exact euclidean_second_form_smul_left F N a v w c

/-- The tangent plane is the image of the differential of the immersion. -/
def euclideanTangentPlane (F : Plane → EuclideanThree) (a : Plane) : Submodule ℝ EuclideanThree :=
  LinearMap.range (fderiv ℝ F a).toLinearMap

def tangentParameterEquiv (F : Plane → EuclideanThree) (a : Plane)
    (hD : Function.Injective (fderiv ℝ F a)) : Plane ≃ₗ[ℝ] euclideanTangentPlane F a :=
  LinearEquiv.ofInjective (fderiv ℝ F a).toLinearMap hD

/-- The second fundamental form on actual vectors in the tangent subspace.
For a unit normal this is the standard Euclidean second fundamental form. -/
def tangentSecondForm (F : Plane → EuclideanThree) (N : EuclideanThree) (a : Plane)
    (hD : Function.Injective (fderiv ℝ F a)) :
    euclideanTangentPlane F a →ₗ[ℝ] euclideanTangentPlane F a →ₗ[ℝ] ℝ :=
  (parameterSecondForm F N a).compl₁₂
    (tangentParameterEquiv F a hD).symm.toLinearMap
    (tangentParameterEquiv F a hD).symm.toLinearMap

theorem tangent_second_form_on_parameter_vectors (F : Plane → EuclideanThree)
    (N : EuclideanThree) (a : Plane) (hD : Function.Injective (fderiv ℝ F a)) (v w : Plane) :
    tangentSecondForm F N a hD (tangentParameterEquiv F a hD v)
      (tangentParameterEquiv F a hD w) = euclideanSecondFundamentalForm F N a v w := by
  simp [tangentSecondForm,parameterSecondForm]

theorem tangent_second_form_symmetric {F : Plane → EuclideanThree} {a : Plane}
    (hF : ContDiffAt ℝ 2 F a) (N : EuclideanThree) (hD : Function.Injective (fderiv ℝ F a))
    (v w : euclideanTangentPlane F a) :
    tangentSecondForm F N a hD v w=tangentSecondForm F N a hD w v :=
  euclidean_second_form_symmetric hF N _ _

/-- Definiteness on the tangent plane is equivalent to the parameter form
used by the surface theorem. There is no extra curvature hypothesis hidden
in the choice of parameters. -/
theorem tangent_second_form_positive_iff (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a : Plane) (hD : Function.Injective (fderiv ℝ F a)) :
    (∀ v : euclideanTangentPlane F a, v ≠ 0 → 0 < tangentSecondForm F N a hD v v) ↔
      ∀ v : Plane, v ≠ 0 → 0 < euclideanSecondFundamentalForm F N a v v := by
  let E := tangentParameterEquiv F a hD
  constructor
  · intro hp v hv
    have hn : E v ≠ 0 := fun hz => hv (E.injective (hz.trans (map_zero E).symm))
    have hh := hp (E v) hn
    simpa only [E,tangent_second_form_on_parameter_vectors] using hh
  · intro hp v hv
    exact hp (E.symm v) (fun hz => hv (E.symm.injective (hz.trans (map_zero E.symm).symm)))

theorem tangent_second_form_negative_iff (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a : Plane) (hD : Function.Injective (fderiv ℝ F a)) :
    (∀ v : euclideanTangentPlane F a, v ≠ 0 → tangentSecondForm F N a hD v v < 0) ↔
      ∀ v : Plane, v ≠ 0 → euclideanSecondFundamentalForm F N a v v < 0 := by
  let E := tangentParameterEquiv F a hD
  constructor
  · intro hp v hv
    have hn : E v ≠ 0 := fun hz => hv (E.injective (hz.trans (map_zero E).symm))
    have hh := hp (E v) hn
    simpa only [E,tangent_second_form_on_parameter_vectors] using hh
  · intro hp v hv
    exact hp (E.symm v) (fun hz => hv (E.symm.injective (hz.trans (map_zero E.symm).symm)))

theorem tangent_second_form_definite_iff (F : Plane → EuclideanThree) (N : EuclideanThree)
    (a : Plane) (hD : Function.Injective (fderiv ℝ F a)) :
    ((∀ v : euclideanTangentPlane F a, v ≠ 0 → 0 < tangentSecondForm F N a hD v v) ∨
      (∀ v : euclideanTangentPlane F a, v ≠ 0 → tangentSecondForm F N a hD v v < 0)) ↔
      EuclideanDefiniteSecondForm F N a := by
  exact or_congr (tangent_second_form_positive_iff F N a hD)
    (tangent_second_form_negative_iff F N a hD)

end EllipticSquareFunction
