import EllipticSquareFunction.SeeleyInfiniteMoments
import Mathlib.Analysis.NormedSpace.FunctionSeries

noncomputable section
open Filter
open scoped BigOperators Topology
namespace EllipticSquareFunction

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

def seeleyJetSeries (m : ℕ) (g : ℝ → E) (t : ℝ) : E :=
  ∑' k : ℕ, (seeleyCoeff k * seeleyNode k ^ m) • g (seeleyNode k * t)

theorem seeley_node_neg (k : ℕ) : seeleyNode k < 0 := by
  unfold seeleyNode
  exact neg_neg_of_pos (by positivity)

theorem seeley_reflected_nonneg {t : ℝ} (ht : t ≤ 0) (k : ℕ) :
    0 ≤ seeleyNode k * t := mul_nonneg_of_nonpos_of_nonpos
      (le_of_lt (seeley_node_neg k)) ht

theorem seeley_moment_summable (m : ℕ) :
    Summable (fun k : ℕ => seeleyCoeff k * seeleyNode k ^ m) := by
  apply (seeley_coeff_weighted_summable m).of_norm_bounded
  intro k
  simp only [Real.norm_eq_abs, abs_mul, seeley_node_power_abs, le_refl]

theorem seeley_jet_term_bound (m : ℕ) {g : ℝ → E} {B : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B) {t : ℝ} (ht : t ≤ 0) (k : ℕ) :
    ‖(seeleyCoeff k * seeleyNode k ^ m) • g (seeleyNode k * t)‖ ≤
      (|seeleyCoeff k| * (2 : ℝ)^(k*m)) * B := by
  rw [norm_smul, Real.norm_eq_abs, abs_mul, seeley_node_power_abs]
  exact mul_le_mul_of_nonneg_left (hg _ (seeley_reflected_nonneg ht k))
    (mul_nonneg (abs_nonneg _) (by positivity))

theorem seeley_jet_series_summable (m : ℕ) {g : ℝ → E} {B : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B) {t : ℝ} (ht : t ≤ 0) :
    Summable (fun k : ℕ => (seeleyCoeff k * seeleyNode k ^ m) • g (seeleyNode k*t)) := by
  exact ((seeley_coeff_weighted_summable m).mul_right B).of_norm_bounded _
    (seeley_jet_term_bound m hg ht)

theorem seeley_jet_series_uniform (m : ℕ) {g : ℝ → E} {B : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B) :
    TendstoUniformlyOn
      (fun N : ℕ => fun t : ℝ => ∑ k ∈ Finset.range N,
        (seeleyCoeff k * seeleyNode k ^ m) • g (seeleyNode k*t))
      (seeleyJetSeries m g) atTop (Set.Iic 0) := by
  exact tendstoUniformlyOn_tsum_nat ((seeley_coeff_weighted_summable m).mul_right B)
    (fun k t ht => seeley_jet_term_bound m hg ht k)

theorem seeley_jet_series_zero (m : ℕ) (g : ℝ → E) :
    seeleyJetSeries m g 0 = g 0 := by
  simp only [seeleyJetSeries, mul_zero]
  rw [(seeley_moment_summable m).tsum_smul_const, seeley_moment, one_smul]

theorem seeley_reflection_tendsto (k : ℕ) :
    Tendsto (fun t : ℝ => seeleyNode k*t) (𝓝[Set.Iic 0] 0) (𝓝[Set.Ici 0] 0) := by
  apply tendsto_nhdsWithin_iff.mpr
  constructor
  · simpa using ((continuous_const.mul continuous_id).tendsto (0 : ℝ)).mono_left inf_le_left
  · filter_upwards [self_mem_nhdsWithin] with t ht
    exact seeley_reflected_nonneg ht k

theorem seeley_jet_series_boundary_limit (m : ℕ) {g : ℝ → E} {B : ℝ}
    (hg : ∀ s : ℝ, 0 ≤ s → ‖g s‖ ≤ B)
    (hc : ContinuousWithinAt g (Set.Ici 0) 0) :
    Tendsto (seeleyJetSeries m g) (𝓝[Set.Iic 0] 0) (𝓝 (g 0)) := by
  have ht : Tendsto (seeleyJetSeries m g) (𝓝[Set.Iic 0] 0)
      (𝓝 (∑' k : ℕ, (seeleyCoeff k * seeleyNode k ^ m) • g 0)) := by
    apply tendsto_tsum_of_dominated_convergence
      ((seeley_coeff_weighted_summable m).mul_right B)
    · intro k
      exact (hc.tendsto.comp (seeley_reflection_tendsto k)).const_smul _
    · filter_upwards [self_mem_nhdsWithin] with t ht
      exact fun k => seeley_jet_term_bound m hg ht k
  simpa only [(seeley_moment_summable m).tsum_smul_const, seeley_moment, one_smul] using ht

end EllipticSquareFunction
