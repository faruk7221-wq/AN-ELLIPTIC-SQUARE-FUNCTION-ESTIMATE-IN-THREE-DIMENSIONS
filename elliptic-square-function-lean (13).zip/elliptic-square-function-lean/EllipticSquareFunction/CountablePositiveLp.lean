import EllipticSquareFunction.PositiveLpBounds

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1000000

/-- Monotone convergence for actual nonnegative L3 norms. -/
theorem positive_l3_iSup {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (f : ℕ → α → ℝ≥0∞) (hf : ∀ n, Measurable (f n)) (hmono : Monotone f) :
    eLpNorm (fun x => ⨆ n, f n x) 3 μ=⨆ n, eLpNorm (f n) 3 μ := by
  simp only [eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3:ℝ≥0∞)≠0)
    (by norm_num : (3:ℝ≥0∞)≠⊤),ENNReal.toReal_ofNat,enorm_eq_self]
  have hp (x : α) : (⨆ n, f n x)^(3:ℝ)=⨆ n, (f n x)^(3:ℝ) :=
    (ENNReal.orderIsoRpow 3 (by norm_num)).map_iSup _
  simp_rw [hp]
  rw [lintegral_iSup (fun n => (hf n).pow_const (3:ℝ))
    (fun n m hnm x => ENNReal.rpow_le_rpow (hmono hnm x) (by norm_num : (0:ℝ)≤3))]
  exact (ENNReal.orderIsoRpow (1/3) (by norm_num)).map_iSup _

/-- Countable positive L3 Minkowski, allowing infinite norms and series.
Measurability is required only for the summands. -/
theorem positive_l3_tsum_le {α : Type*} [MeasurableSpace α] (μ : Measure α)
    (f : ℕ → α → ℝ≥0∞) (hf : ∀ n, Measurable (f n)) :
    eLpNorm (fun x => ∑' n, f n x) 3 μ ≤ ∑' n, eLpNorm (f n) 3 μ := by
  have hm (n : ℕ) : Measurable (fun x => ∑ i∈Finset.range n, f i x) :=
    Finset.measurable_sum _ (fun i _ => hf i)
  have hmono : Monotone (fun n x => ∑ i∈Finset.range n, f i x) := by
    intro n m hnm x
    exact Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hnm) (fun _ _ _ => bot_le)
  simp only [ENNReal.tsum_eq_iSup_nat]
  rw [positive_l3_iSup μ _ hm hmono]
  apply iSup_le
  intro n
  exact le_iSup_of_le n (positive_l3_finset_sum_le μ (Finset.range n) f (fun i _ => hf i))

end EllipticSquareFunction
