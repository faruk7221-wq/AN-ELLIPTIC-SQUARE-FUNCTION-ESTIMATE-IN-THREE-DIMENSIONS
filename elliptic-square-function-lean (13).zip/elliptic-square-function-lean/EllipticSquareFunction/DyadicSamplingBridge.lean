import EllipticSquareFunction.SamplingNormLimit

noncomputable section
open MeasureTheory
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1500000

/-- The density integral in Proposition 3 is the L3 norm of its square root. -/
theorem global_density_integral_eq_norm (H : Space → ℝ) (hH : ∀ y, 0≤H y) :
    (∫⁻ y, (ENNReal.ofReal (H y))^(3/2:ℝ))^(1/3:ℝ)=l3Real (fun y => Real.sqrt (H y)) := by
  rw [l3Real,eLpNorm_sqrt _ H hH,
    eLpNorm_eq_lintegral_rpow_enorm (by norm_num : (3/2:ℝ≥0∞)≠0)
      ((ENNReal.div_lt_top (by norm_num) (by norm_num)).ne : (3/2:ℝ≥0∞)≠∞)]
  simp only [ENNReal.toReal_div,ENNReal.toReal_ofNat]
  rw [← ENNReal.rpow_mul]
  have hn (y : Space) : ‖H y‖ₑ=ENNReal.ofReal (H y) := by
    rw [← ofReal_norm_eq_enorm,Real.norm_eq_abs,abs_of_nonneg (hH y)]
  simp only [hn]
  norm_num

/-- The packet/sampling bridge at all dyadic spatial scales, with actual
Schwartz data and constants uniform in the cap family. The only analytic
hypothesis beyond the continued phase is DiscreteDensityInput for the
constructed adequate setup. -/
theorem dyadic_packet_sampling_bridge (G : GraphSetup) (T₀ : DiscreteSetup)
    (heφ : T₀.φ=G.φ) (hphase : ContinuedPhase G.φ) {M : ℝ} (hM : 2<M) :
    ∃ S : DiscreteSetup, S.φ=G.φ ∧ S.χ=T₀.χ ∧ S.D=T₀.D ∧
      (DiscreteDensityInput S →
        ∀ κ η : ℝ, 0<κ → κ<1/10 → 0<η → η≤1 →
        ∃ A B : ℝ, 0<A ∧ 0<B ∧ ∀ j : ℕ, 1≤j →
        ∀ (n : ℕ) (ν : Fin n → Plane) (f : Fin n → SchwartzMap Space ℂ),
        AdmissibleFamily G (((2:ℝ)^j)^2) ν f → ∃ H : Space → ℝ,
          (∀ y, 0≤H y) ∧
          l3 (fun y => ∑ θ, f θ y) ≤
            ENNReal.ofReal (A*(((2:ℝ)^j)^2)^((10*κ+η)/6)*
              Real.log (2+((2:ℝ)^j)^2)^(2/3:ℝ))*l3Real (fun y => Real.sqrt (H y)) ∧
          (∀ y, H y≤B*smoothedSquareDensity G (((2:ℝ)^j)^2) M ν f y)) := by
  obtain ⟨χ,ρ,D,Cd,hχ,hχs,hρs,hD,hCd,hlemma⟩ :=
    lemma_four_synthesis_and_density hphase G.C₀_pos.le hM
  obtain ⟨F,hF⟩ := G.compact_K.exists_bound_of_continuousOn (continuous_id : Continuous (id : Plane → Plane)).continuousOn
  have hD₀ : (0:ℝ)<D := by exact_mod_cast hD
  obtain ⟨S,hSφ,hSχ,hSD,_,_,_,hpacket⟩ := single_profile_enlarged_uniform_cap_count
    T₀ (by simpa only [heφ] using hphase) χ hχ hχs (inverseTimeProfile ρ)
    (inv_pos.mpr hD₀) G.c₀_pos (show 0 ≤ max F 0 from le_max_right F 0) hM
  refine ⟨S,hSφ.trans heφ,hSχ,hSD,?_⟩
  intro hinput κ η hκ hκ' hη hη'
  obtain ⟨Cp,hCp,hpacket⟩ := hpacket hinput
  obtain ⟨P,hP,hpacket⟩ := hpacket κ η hκ hκ' hη hη'
  have hP₀ : 0<P := by linarith
  refine ⟨(D:ℝ)*Cp*P^(1/3:ℝ),Cd,by positivity,hCd,?_⟩
  intro j hj n ν f hf
  let N : ℝ := (2:ℝ)^j
  have hN : 0<N := by positivity
  have hN₁ : 1≤N := one_le_pow₀ (by norm_num)
  have hR : 1≤N^2 := one_le_pow₀ hN₁
  obtain ⟨hs,hds,hd⟩ := hlemma (N^2) hR n ν f hf.2.2
  simp only [Real.sqrt_sq hN.le] at hs hds hd
  let p := fun θ (i : IntPlane × ℤ) => samplePoint N (N^2) D D
    (velocity G.φ (ν θ)) (latticePoint 1 i.1) i.2
  let a := fun θ i => ((((D:ℝ)^3)⁻¹:ℝ):ℂ)*f θ (p θ i)
  let H := fun y => ∑ θ, ∑' i, ‖a θ i‖^2*packetWeight (N^2) M
    (velocity G.φ (ν θ)) (p θ i).1 (p θ i).2 y
  have hH (y : Space) : 0≤H y := Finset.sum_nonneg (fun θ _ =>
    tsum_nonneg (fun i => mul_nonneg (sq_nonneg _) (packetWeight_nonneg ..)))
  have hφ : Continuous G.φ := by
    rcases hphase with ⟨_,_,_,_,_,_,_,_,_,_,hh,_⟩
    exact hh.continuous
  have hbound : UniformTimeProfileBound (Fin n) G.φ χ (inverseTimeProfile ρ)
      (D:ℝ)⁻¹ G.c₀ (max F 0) M Cp P κ η := by simpa only [heφ] using hpacket n
  have hν (θ : Fin n) : ‖ν θ‖≤ max F 0 := (hF (ν θ) (hf.1 θ)).trans (le_max_left _ _)
  have hsep (θ θ' : Fin n) (hh : θ≠θ') : G.c₀/N≤‖ν θ-ν θ'‖ := by
    simpa only [N,Real.sqrt_sq (pow_nonneg (by norm_num : (0:ℝ)≤2) j),div_eq_mul_inv] using hf.2.1 θ θ' hh
  have hh := sampling_synthesis_l3_of_uniform G.φ hφ χ hχ.continuous hχs
    (inverseTimeProfile ρ) (inverseTimeProfile ρ).continuous D hD G.c₀ (max F 0) M Cp P κ η
    hCp.le hP₀.le hbound j hj ν hν hsep a (fun θ => (f θ : Space → ℂ)) hs hds
  change l3 (fun y => ∑ θ, f θ y) ≤
    ENNReal.ofReal ((D:ℝ)*Cp*packetConstant P κ η (N^2))*
      (∫⁻ y, (ENNReal.ofReal (H y))^(3/2:ℝ))^(1/3:ℝ) at hh
  rw [global_density_integral_eq_norm H hH] at hh
  refine ⟨H,hH,?_,hd⟩
  convert hh using 1
  congr 2
  unfold packetConstant
  ring

end EllipticSquareFunction
