import EllipticSquareFunction.SymmetricTubeGeometry

noncomputable section
open MeasureTheory Set
open scoped ENNReal BigOperators
namespace EllipticSquareFunction
set_option maxHeartbeats 1200000

/-- The symmetric sheared box lies inside a genuine Euclidean tube with the
same spatial radius and endpoints on its central axis. -/
theorem symmetricTube_subset_geometricTube {r T : ℝ} (hT : 0<T) (V : Plane) :
    symmetricTube r T V ⊆ geometricTube (T • V,-T) (-T • V,T) r := by
  intro y hy
  let s := (y.2+T)/(2*T)
  have hs : s∈Icc (0:ℝ) 1 := by
    obtain ⟨hlo,hhi⟩ := abs_le.mp hy.1
    constructor
    · exact div_nonneg (by linarith) (by positivity)
    · apply (div_le_one (by positivity : 0<2*T)).mpr
      linarith
  have he : (2*s-1)*T=y.2 := by dsimp [s]; field_simp; ring
  have hc : (1-s) • (T • V,-T)+s • (-T • V,T)=(-y.2 • V,y.2) := by
    rw [← he]
    apply Prod.ext
    · dsimp
      module
    · dsimp
      ring
  refine ⟨s,hs,?_⟩
  rw [hc]
  simp only [euclideanLength,Prod.fst_sub,Prod.snd_sub,neg_smul,sub_neg_eq_add,
    sub_self,show (0:ℝ)^2=0 by norm_num,add_zero,Real.sqrt_sq_eq_abs,abs_norm]
  exact hy.2

/-- Exact Euclidean length of the axis segment. -/
theorem tube_axis_length {T : ℝ} (hT : 0≤T) (V : Plane) :
    euclideanLength ((-T • V,T)-(T • V,-T))=2*T*Real.sqrt (1+‖V‖^2) := by
  have he : (-T • V,T)-(T • V,-T)=(-(2*T) • V,2*T) := by
    apply Prod.ext
    · dsimp
      module
    · dsimp
      ring
  rw [he]
  simp only [euclideanLength,norm_smul,Real.norm_eq_abs,abs_neg,abs_of_nonneg (by positivity : 0≤2*T)]
  have hpoly : (2*T*‖V‖)^2+(2*T)^2=(2*T)^2*(1+‖V‖^2) := by ring
  rw [hpoly,Real.sqrt_mul (sq_nonneg _),Real.sqrt_sq (by positivity : 0≤2*T)]

/-- An upper bound for the volume of a genuine slanted Euclidean tube, proved
by containment in a sheared box rather than an unproved rotation formula. -/
theorem volume_geometricTube_upper {r T : ℝ} (hr : 0≤r) (hT : 0≤T) (V : Plane) :
    volume (geometricTube (T • V,-T) (-T • V,T) r) ≤
      ENNReal.ofReal (2*Real.pi*(r*(1+‖V‖))^2*(T+r)) := by
  apply (measure_mono (geometricTube_subset_symmetricTube hT V)).trans
  rw [volume_symmetricTube]
  have hc : 0≤r*(1+‖V‖) := by positivity
  rw [ENNReal.ofReal_mul (by positivity : 0≤2*Real.pi*(r*(1+‖V‖))^2),
    ENNReal.ofReal_mul (by positivity : 0≤2*Real.pi),
    ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2),
    ENNReal.ofReal_pow hc,ENNReal.ofReal_mul (by norm_num : (0:ℝ)≤2)]
  exact le_of_eq (by ring)

/-- Both tube volumes are finite, and their ratio is uniformly controlled
when the slope and aspect ratio are controlled. -/
theorem volume_geometricTube_le_box_multiple {r T F : ℝ}
    (hr : 0≤r) (hT : 0<T) (hrT : r≤T) (hF : 0≤F)
    (V : Plane) (hV : ‖V‖≤F) :
    volume (geometricTube (T • V,-T) (-T • V,T) r) ≤
      ENNReal.ofReal (2*(1+F)^2)*volume (symmetricTube r T V) := by
  apply (volume_geometricTube_upper hr hT.le V).trans
  rw [volume_symmetricTube]
  have he : ENNReal.ofReal (2*(1+F)^2)*
      (ENNReal.ofReal r^2*ENNReal.ofReal Real.pi*ENNReal.ofReal (2*T)) =
      ENNReal.ofReal (4*Real.pi*r^2*T*(1+F)^2) := by
    rw [← ENNReal.ofReal_pow hr]
    simp only [← ENNReal.ofReal_mul (by positivity : 0≤2*(1+F)^2),
      ← ENNReal.ofReal_mul (sq_nonneg r)]
    rw [← ENNReal.ofReal_mul (by positivity : 0≤r^2*Real.pi)]
    rw [← ENNReal.ofReal_mul (by positivity : 0≤2*(1+F)^2)]
    congr 1
    ring
  rw [he]
  apply ENNReal.ofReal_le_ofReal
  have hv : (1+‖V‖)^2≤(1+F)^2 := pow_le_pow_left₀ (by positivity) (by linarith) 2
  have ha : T+r≤2*T := by linarith
  calc
    _ = 2*Real.pi*r^2*((1+‖V‖)^2*(T+r)) := by ring
    _ ≤ 2*Real.pi*r^2*((1+F)^2*(2*T)) :=
      mul_le_mul_of_nonneg_left (mul_le_mul hv ha (by positivity) (by positivity)) (by positivity)
    _ = _ := by ring

end EllipticSquareFunction
