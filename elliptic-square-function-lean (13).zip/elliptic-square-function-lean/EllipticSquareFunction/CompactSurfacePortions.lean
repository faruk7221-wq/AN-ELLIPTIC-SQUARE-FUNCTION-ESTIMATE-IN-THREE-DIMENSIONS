import EllipticSquareFunction.SmoothBoundaryTheorem
import EllipticSquareFunction.SurfaceEstimateRestriction

noncomputable section
open scoped Manifold Topology
namespace EllipticSquareFunction

/-- A subset of a carrier with local elliptic extensions has the same local
extensions. No regularity of the subset's boundary is required. -/
theorem euclidean_elliptic_extensions_mono {K L : Set EuclideanThree}
    (hKL : K ⊆ L) (hL : EuclideanEllipticSurfaceExtensions L) :
    EuclideanEllipticSurfaceExtensions K := by
  intro p hp
  obtain ⟨F,U,a,W,N,hU,ha,hF,hemb,hFa,hW,hpW,hcover,hD,hN,horth,hdef⟩ := hL p (hKL hp)
  exact ⟨F,U,a,W,N,hU,ha,hF,hemb,hFa,hW,hpW,
    (Set.inter_subset_inter_left W hKL).trans hcover,hD,hN,horth,hdef⟩

variable {H M : Type*} [TopologicalSpace H] [TopologicalSpace M]
    (I : ModelWithCorners ℝ Plane H) [ChartedSpace H M]

/-- Compact portions of a possibly noncompact smooth manifold inherit the
surface estimate. The portion itself may have corners or an irregular boundary. -/
theorem compact_model_surface_portion_estimate {f : M → EuclideanThree}
    (hf : ContMDiff I 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f) (hext : HasSmoothModelExtensions I f)
    (himm : ∀ x, Function.Injective (mfderiv I 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv I 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm I f x N)
    {K : Set EuclideanThree} (hK : IsCompact K) (hKf : K ⊆ Set.range f)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ :=
  article_extension_surface_theorem hK
    (euclidean_elliptic_extensions_mono hKf
      (model_embedding_surface_extensions I hf hemb hext himm hcurv))
    hc₀ hC₀ hplacement hnikodym hdiscrete

/-- Smoothness alone supplies all local extensions for compact portions of
Mathlib's actual boundary model, without assuming that the whole manifold is compact. -/
theorem compact_smooth_boundary_portion_estimate
    {M : Type*} [TopologicalSpace M] [ChartedSpace (EuclideanHalfSpace 2) M]
    [IsManifold (𝓡∂ 2) (⊤ : ℕ∞) M] {f : M → EuclideanThree}
    (hf : ContMDiff (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f)
    (himm : ∀ x, Function.Injective (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N (mfderiv (𝓡∂ 2) 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      ModelDefiniteSecondForm (𝓡∂ 2) f x N)
    {K : Set EuclideanThree} (hK : IsCompact K) (hKf : K ⊆ Set.range f)
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate K c₀ C₀ :=
  compact_model_surface_portion_estimate (𝓡∂ 2) hf hemb
    (halfspace_extensions_of_smooth hf) himm hcurv hK hKf hc₀ hC₀
    hplacement hnikodym hdiscrete

end EllipticSquareFunction
