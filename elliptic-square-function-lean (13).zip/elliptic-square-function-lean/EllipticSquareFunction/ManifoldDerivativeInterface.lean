import EllipticSquareFunction.ManifoldSurfaceAdapter
import Mathlib.Geometry.Manifold.ContMDiffMFDeriv

noncomputable section
open scoped Manifold
namespace EllipticSquareFunction

variable {M : Type*} [TopologicalSpace M] [ChartedSpace Plane M]
  [IsManifold 𝓘(ℝ, Plane) (⊤ : ℕ∞) M]

/-- The coordinate derivative used by the adapter is exactly Mathlib's
manifold derivative, not an additional immersion assumption. -/
theorem manifold_derivative_eq_chart_derivative {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) (x : M) :
    mfderiv 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) f x =
      fderiv ℝ (manifoldSurfaceParam f x) (chartAt Plane x x) := by
  rw [((hf.mdifferentiable (by norm_cast)) x).mfderiv]
  simp only [writtenInExtChartAt,mfld_simps,manifoldSurfaceParam,fderivWithin_univ]

theorem manifold_immersion_iff_chart_immersion {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f) :
    (∀ x, Function.Injective (mfderiv 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) f x)) ↔
      ∀ x, Function.Injective (fderiv ℝ (manifoldSurfaceParam f x) (chartAt Plane x x)) := by
  simp only [manifold_derivative_eq_chart_derivative hf]
  rfl

/-- A version of the compact manifold theorem with immersion explicitly
stated using Mathlib's derivative on tangent spaces. -/
theorem compact_manifold_surface_estimate_of_mfderiv [CompactSpace M] {f : M → EuclideanThree}
    (hf : ContMDiff 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) (⊤ : ℕ∞) f)
    (hemb : Topology.IsEmbedding f)
    (himm : ∀ x, Function.Injective (mfderiv 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) f x))
    (hcurv : ∀ x, ∃ N : EuclideanThree, ‖N‖=1 ∧
      (∀ v, @inner ℝ EuclideanThree _ N
        (mfderiv 𝓘(ℝ, Plane) 𝓘(ℝ, EuclideanThree) f x v)=0) ∧
      EuclideanDefiniteSecondForm (manifoldSurfaceParam f x) N (chartAt Plane x x))
    {c₀ C₀ : ℝ} (hc₀ : 0 < c₀) (hC₀ : 0 < C₀)
    (hplacement : PlacementInput) (hnikodym : NikodymInput)
    (hdiscrete : ∀ G : DiscreteSetup, ContinuedPhase G.φ → DiscreteDensityInput G) :
    EuclideanSurfaceEstimate (Set.range f) c₀ C₀ := by
  apply compact_manifold_surface_estimate hf hemb _ hc₀ hC₀ hplacement hnikodym hdiscrete
  intro x
  refine ⟨(manifold_immersion_iff_chart_immersion hf).mp himm x,?_⟩
  simpa only [manifold_derivative_eq_chart_derivative hf] using hcurv x

end EllipticSquareFunction
